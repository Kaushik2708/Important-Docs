package labvantage.custom.alcon.ddt;

import sapphire.action.BaseSDCRules;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.xml.PropertyList;
/**
 * $Author: BAGCHAN1 $
 * $Date: 2022-04-20 01:26:41 +0530 (Wed, 20 Apr 2022) $
 * $Revision: 46 $
 */

/********************************************************************************************************
 * $Revision: 46 $
 * Description: SDC rule for User.
 * This class is being called when SysUser table populated with User data while creating a new user
 *
 *******************************************************************************************************/
public class User extends BaseSDCRules {
    public static final String DEVOPS_ID = "$Revision: 46 $";

    @Override
    public void preAdd(SDIData sdiData, PropertyList actionProps) {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);

        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }
        convertToUpper(dsPrimary);
    }

    /**
     * Description: This method is used to convert the string to uppercase
     *
     * @param dsPrimary
     */
    public void convertToUpper(DataSet dsPrimary) {

        String sysuserId = dsPrimary.getColumnValues("sysuserid", ";");
        String newSysUserId = sysuserId.toUpperCase();

        dsPrimary.setValue(0, "sysuserid", newSysUserId);
    }

}
