/*
 *  Copyright (c) 2000-2016 LabVantage Solutions, Inc.  All rights reserved.
 *
 *  No part of this work may be reproduced or distributed without the
 *  permission of LabVantage Solutions, Inc.
 *
 *  If you are not authorized by LabVantage to utilize this
 *  software and/or documentation, you must immediately discontinue any
 *  further use or viewing of this software and documentation.
 *  Violaters will be prosecuted to the fullest extent of the law by
 *  LabVantage Solutions, Inc.
 *
 *  Developed by LabVantage Solutions, Inc.
 *  265, Davidson Avenue, Suite 220
 *  Somerset, NJ, 08873
 */
package labvantage.custom.alcon.ddt;

import labvantage.custom.alcon.sap.util.SAPPlants;
import labvantage.custom.alcon.util.AlconUtil;
import sapphire.SapphireException;
import sapphire.action.BaseSDCRules;
import sapphire.action.EditDataItem;
import sapphire.action.EditSDI;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.Calendar;
import java.util.HashMap;

/**
 * $Revision: 305 $
 * Description:
 * Sample Rule to populate information from SamplingPlan during creation
 *
 * @author Souvik Manna
 * @version $Author: DIANAR1 $
 * $Source: /extra/CVS/profserv/Alcon_06651/java/labvantage/custom/alcon/ddt/Sample.java,v $
 * $Revision: 305 $
 * $Date: 2022-11-11 11:22:09 +0530 (Fri, 11 Nov 2022) $
 * $State: Exp $
 * $Branches: ALCONFWNLIMS $
 * $Id: Sample.java,v 1.8.2.6 2018/10/12 11:06:46 paritoshs Exp $
 * <p>
 * DevOps commit
 * $Author: DIANAR1 $
 * $Date: 2022-11-11 11:22:09 +0530 (Fri, 11 Nov 2022) $
 * $Revision: 305 $
 */

/**
 * DevOps commit
 * $Author: DIANAR1 $
 * $Date: 2022-11-11 11:22:09 +0530 (Fri, 11 Nov 2022) $
 * $Revision: 305 $
 */
public class Sample extends BaseSDCRules {
    public static final String COLUMN_SAMPLE_SAMPLE_ID = "s_sampleid";
    public static final String COLUMN_SAMPLE_STATUS = "samplestatus";
    public static final String COLUMN_SAMPLE_MUST_START_DATE = "u_muststartdate";
    public static final String COLUMN_SAMPLE_PRODUCT_ID = "productid";
    public static final String COLUMN_PRODUCT_LONGEST_TEST_DAYS = "u_msddays";
    public static final String PROPERTY_SAMPLE_STATUS = "Received";
    public static final String DEFAULT_SECURITY_USER = "AUTOMATION_SECURITY";
    public static final String __PROPS_RELEASEDFLAG = "releasedflag";

    private static final String __PROPS_KEYID_1 = "keyid1";
    private static final String __PROPS_KEYID_2 = "keyid2";
    private static final String __PROPS_KEYID_3 = "keyid3";
    private static final String __PROPS_PARAMLISTID = "paramlistid";
    private static final String __PROPS_PARAMLISTVERSIONID = "paramlistversionid";
    private static final String __PROPS_VARIANTID = "variantid";
    private static final String __PROPS_DATASET = "dataset";
    private static final String __PROPS_PARAMID = "paramid";
    private static final String __PROPS_PARAMTYPE = "paramtype";
    private static final String __PROPS_REPLICATEID = "replicateid";
    // ******** DataSet details required for Sample Stability Pull Request Service ********* //
    private static final String PARAM_NUMBER_OF_REQUIRED_UNITS = "NUMBER OF REQUIRED UNITS";
    private static final String __VARIANT_FWMDOC_00237 = "FWMDOC-00237";
    private static final String __PARAMLIST_STABILITY_ENROLLMENT = "STABILITY ENROLLMENT";
    private static final String __ENTERED_VALUE = "enteredvalue";

    static final String LABVANTAGE_CVS_ID = "$Revision: 305 $";
    static final String DEVOPS_ID = "$Revision: 305 $";
    private static final String __SERVICE_STABILITY_PULL_SAMPLE_REQUEST = "StabilityPullSampleRequest";
    private static final String __SERVICE_STABILITY_PULL_SAMPLE_REQUEST_VERSIONID = "1";
    private static final String __PROPS_PARAM_TYPE_ANY = "Any";


    /**
     * @return
     */
    public boolean requiresBeforeEditImage() {
        return true;

    }

    @Override
    public void postReleaseData(DataSet releaseData, PropertyList actionProps) throws SapphireException {
        // ********* Called for Save & Release only **********
        if (releaseData.size() > 0) {
            // ********** Calling service Stability Pull Sample Request *********
            callStabilityPullSampleRequest(releaseData);
        }
    }

    @Override
    public void postEditSDIDataItem(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        // ********* Called for Released --> Save(Not for Save & Releaed) AND UnReleased --> Save only **********
        // ********* Getting only Released DataItems *************
        DataSet releaseData = getReleasedDataItem(sdiData);
        if (releaseData.size() > 0) {
            // ********** Calling service Stability Pull Sample Request *********
            callStabilityPullSampleRequest(releaseData);
        }
    }

    /*******************************************************************************
     * This method is used to get DataSet of SDIDataItem which are ready for RELEASE
     * @param sdiData SDI Data
     * @return DataSet of Released Data Item
     * @throws SapphireException OOB Sapphire Exception
     *******************************************************************************/
    private DataSet getReleasedDataItem(SDIData sdiData) throws SapphireException {
        DataSet dsPrimary = sdiData.getDataset(SDIData.DATAITEM);
        DataSet releaseData = new DataSet();
        PropertyList plFilter = new PropertyList();
        plFilter.setProperty(__PROPS_RELEASEDFLAG, "Y");
        // ************ Filtering DataSet When Released Flag is Y ********** //
        if (dsPrimary.isValidColumn(__PROPS_RELEASEDFLAG)) {
            releaseData = dsPrimary.getFilteredDataSet(plFilter);
            // ************ If Released then Call Stability Pull Sample Request ************ //
            if (releaseData.size() > 0) {
                return releaseData;
            }
        }
        return releaseData;
    }

    /*************************************************************************
     * This method is used to call Stability Pull Sample Request Action
     * @param releaseData Filtered DataSet
     * @throws SapphireException OOB Sapphire Exception
     */
    private void callStabilityPullSampleRequest(DataSet releaseData) throws SapphireException {
        // *************** Creating filter criteria ****************
        PropertyList plStabilityPullSampleReq = new PropertyList();
        PropertyList plFilter = new PropertyList();
        plFilter.setProperty(__PROPS_PARAMLISTID, __PARAMLIST_STABILITY_ENROLLMENT);
        plFilter.setProperty(__PROPS_VARIANTID, __VARIANT_FWMDOC_00237);
        plFilter.setProperty(__PROPS_PARAMID,PARAM_NUMBER_OF_REQUIRED_UNITS);
        plFilter.setProperty(__PROPS_PARAMTYPE, __PROPS_PARAM_TYPE_ANY);
        // *************** Filtering actual DataSet based on filter criteria ******************
        DataSet dsActualtResult = releaseData.getFilteredDataSet(plFilter);
        // *************** If Actual Filtered DataSet is not BLANK then call action with action props ***************
        if (dsActualtResult.size() > 0) {
            plStabilityPullSampleReq.setProperty(__PROPS_KEYID_1, dsActualtResult.getColumnValues(__PROPS_KEYID_1, ";"));
            plStabilityPullSampleReq.setProperty(__PROPS_KEYID_2, dsActualtResult.getColumnValues(__PROPS_KEYID_2, ";"));
            plStabilityPullSampleReq.setProperty(__PROPS_KEYID_3, dsActualtResult.getColumnValues(__PROPS_KEYID_3, ";"));
            plStabilityPullSampleReq.setProperty(__PROPS_PARAMLISTID, dsActualtResult.getColumnValues(__PROPS_PARAMLISTID, ";"));
            plStabilityPullSampleReq.setProperty(__PROPS_PARAMLISTVERSIONID, dsActualtResult.getColumnValues(__PROPS_PARAMLISTVERSIONID, ";"));
            plStabilityPullSampleReq.setProperty(__PROPS_VARIANTID, dsActualtResult.getColumnValues(__PROPS_VARIANTID, ";"));
            plStabilityPullSampleReq.setProperty(__PROPS_DATASET, dsActualtResult.getColumnValues(__PROPS_DATASET, ";"));
            plStabilityPullSampleReq.setProperty(__PROPS_PARAMID, dsActualtResult.getColumnValues(__PROPS_PARAMID, ";"));
            plStabilityPullSampleReq.setProperty(__PROPS_PARAMTYPE, dsActualtResult.getColumnValues(__PROPS_PARAMTYPE, ";"));
            plStabilityPullSampleReq.setProperty(__PROPS_REPLICATEID, dsActualtResult.getColumnValues(__PROPS_REPLICATEID, ";"));
            // ********** Calling Stability Pull Sample Request Action ***************
            getActionProcessor().processAction(__SERVICE_STABILITY_PULL_SAMPLE_REQUEST, __SERVICE_STABILITY_PULL_SAMPLE_REQUEST_VERSIONID, plStabilityPullSampleReq);
        }
    }


    /**
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void preEdit(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        logger.info("################################V###########################################");
        logger.info("Sample.java - preEdit: DEVOPS - DEBUG STATEMENT - ONHOLD SAMPLE STATUS CHECK STOPPED ");
        logger.info("################################V###########################################");
/*

        logger.info("Sample Rule : CVS Version (preEdit) " + LABVANTAGE_CVS_ID);
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        if (!"Y".equals(actionProps.getProperty("__sdcruleignore", "N"))) {
            //Alcon FWN LIMS : Below Logic is for Alcon FWN Site for Batch Validation
            //@todo : Un-Commenting the below method for Alcon FWN LIMS
            if (!dsPrimary.isValidColumn("samplestatus")) {
                sampleStatusValidation(dsPrimary.getColumnValues("s_sampleid", ";"));
            } else {
                for (int i = 0; i < dsPrimary.getRowCount(); i++) {
                    if (dsPrimary.getValue(i, "samplestatus", "").equalsIgnoreCase("OnHold")
                            && getOldPrimaryValue(dsPrimary, i, "samplestatus").equalsIgnoreCase("OnHold")) {
                        throw new SapphireException("Sample(s) - '" + dsPrimary.getValue(i, "s_sampleid", "") + "' belong to 'On Hold' status and cannot be edited.");
                    }
                }
            }
        }
*/
        DataSet primary = sdiData.getDataset(SDIData.PRIMARY);
        if (null == primary || primary.getRowCount() == 0) {
            return;
        }
        /*************
         * DevOps:: SAP-LIMS Interface
         * Description:: Inspection Lot # added from Batch
         */
        setInspectionLotNumber(primary);

    }


    /**
     * This methhod is called to add business logic after the database updates in the EnterDataItem action
     *
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void postDataEntry(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        logger.debug("################################V###########################################");
        logger.debug("Sample.java - postDataEntry: DEVOPS - DEBUG STATEMENT - ONHOLD SAMPLE STATUS CHECK STOPPED ");
        logger.debug("################################V###########################################");

        String reagentStatus = "";
        HashMap hmFilter = new HashMap();
        hmFilter.put("u_validateconsumableflag", "Y");
        DataSet dsConsumableToBeValidated = sdiData.getDataset(SDIData.DATAITEM).getFilteredDataSet(hmFilter);
        hmFilter.clear();

        if (dsConsumableToBeValidated.size() > 0) {
            fetchAndSetDataItem(dsConsumableToBeValidated);
        }
    }

    /**
     * This method is used to fetch reagent status from ReagentLot SDC and set the same in DataItem SDC
     *
     * @param dsConsumableToBeValidated
     * @throws SapphireException
     */
    private void fetchAndSetDataItem(DataSet dsConsumableToBeValidated) throws SapphireException {
        DataSet dsReagentLot;
        String sql;
        String enteredText;
        PropertyList plEditAttr;

        sql = "select reagentlotid, reagentstatus from reagentlot where reagentlotid in ('" +
                StringUtil.replaceAll(dsConsumableToBeValidated.getColumnValues("enteredtext", ";"), ";", "','") + "')";
        dsReagentLot = getQueryProcessor().getSqlDataSet(sql, true);
        for (int i = 0; i < dsConsumableToBeValidated.getRowCount(); i++) {
            plEditAttr = setPropertyForDataItem(i, dsConsumableToBeValidated, dsReagentLot);
            getActionProcessor().processAction(EditDataItem.ID, EditDataItem.VERSIONID, plEditAttr);
        }
    }

    /**
     * This method is used to set the the property list for DataItem based on business logic
     *
     * @param dsConsumableToBeValidated
     * @param dsReagentLot
     * @param rowCount
     * @throws SapphireException
     */
    private PropertyList setPropertyForDataItem(int rowCount, DataSet dsConsumableToBeValidated, DataSet dsReagentLot) {
        PropertyList plEditAttr = new PropertyList();
        plEditAttr.setProperty(EditDataItem.PROPERTY_SDCID, dsConsumableToBeValidated.getValue(rowCount, "sdcid"));
        plEditAttr.setProperty(EditDataItem.PROPERTY_KEYID1, dsConsumableToBeValidated.getValue(rowCount, "keyid1"));
        plEditAttr.setProperty(EditDataItem.PROPERTY_PARAMLISTID, dsConsumableToBeValidated.getValue(rowCount, "paramlistid"));
        plEditAttr.setProperty(EditDataItem.PROPERTY_PARAMLISTVERSIONID, dsConsumableToBeValidated.getValue(rowCount, "paramlistversionid"));
        plEditAttr.setProperty(EditDataItem.PROPERTY_VARIANTID, dsConsumableToBeValidated.getValue(rowCount, "variantid"));
        plEditAttr.setProperty(EditDataItem.PROPERTY_DATASET, dsConsumableToBeValidated.getValue(rowCount, "dataset"));
        plEditAttr.setProperty(EditDataItem.PROPERTY_PARAMID, dsConsumableToBeValidated.getValue(rowCount, "paramid"));
        plEditAttr.setProperty(EditDataItem.PROPERTY_PARAMTYPE, dsConsumableToBeValidated.getValue(rowCount, "paramtype"));
        plEditAttr.setProperty(EditDataItem.PROPERTY_REPLICATEID, dsConsumableToBeValidated.getValue(rowCount, "replicateid"));

        int reagentLotRowId = dsReagentLot.findRow("reagentlotid", dsConsumableToBeValidated.getValue(rowCount, "enteredtext", ""));
        if (reagentLotRowId == -1) {
            plEditAttr.setProperty("u_consumablelotstatus", "");
        } else {
            plEditAttr.setProperty("u_consumablelotstatus", dsReagentLot.getValue(reagentLotRowId, "reagentstatus", ""));
        }
        return plEditAttr;
    }

    @Override
    public void postAddDataSet(SDIData sdiData, PropertyList actionProps) {

        logger.info("###########################################################################");
        logger.info("Sample.java - postAddDataSet: DEVOPS - DEBUG STATEMENT - ONHOLD SAMPLE STATUS CHECK STOPPED ");
        logger.info("################################V###########################################");
/*
        DataSet dsDataSet = sdiData.getDataset(SDIData.DATASET);
        if (!"Y".equals(actionProps.getProperty("__sdcruleignore", "N"))) {
            //Alcon FWN LIMS : Below Logic is for Alcon FWN Site for Batch Validation
            //@todo : Un-Commenting the below method for Alcon FWN LIMS
            String strSampleID = dsDataSet.getColumnValues("keyid1", ";");
            sampleStatusValidation(strSampleID);
        }
*/

    }


    /**
     * Below Logic is for Alcon FWN Site for Batch Validation
     *
     * @param SampleIDs
     * @throws SapphireException
     */
    private void sampleStatusValidation(String SampleIDs) throws SapphireException {
        String query = "select s_sample.s_sampleid from s_sample\n" +
                " \n" +
                "where  s_sample.samplestatus = 'OnHold' and s_sample.s_sampleid in ('" + SampleIDs + "')";
        DataSet ds = getQueryProcessor().getSqlDataSet(query);
        if (ds.getRowCount() > 0) {
            String OnHoldSamples = ds.getColumnValues("s_sampleid", "','");
            throw new SapphireException("Sample(s) - '" + OnHoldSamples + "' belong to 'On Hold' status and cannot be edited.");
        }
    }


    /**
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void preAddWorkItem(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        logger.info("Sample Rule : CVS Version (postAddWorkItem) " + LABVANTAGE_CVS_ID);

        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        DataSet dsWorkItemID = sdiData.getDataset(SDIData.SDIWORKITEM);
        DataSet dsWorkItemItemItem = sdiData.getDataset(SDIData.SDIWORKITEMITEM);


        String strRSet = getDAMProcessor().createRSet("WorkItem", dsWorkItemID.getColumnValues("workitemid", ";"), dsWorkItemID.getColumnValues("workitemversionid", ";"), "");
        String strQuery = "select workitem.workitemid,workitem.workitemversionid,workitem.u_testingtime " +
                "from workitem, rsetitems where rsetitems.sdcid='WorkItem' " +
                " and rsetitems.keyid1=workitem.workitemid" +
                " and  rsetitems.keyid2=workitem.workitemversionid " +
                "and rsetitems.keyid3='(null)' " +
                "and workitem.u_testingtime is not null " +
                "and rsetitems.rsetid= ? ";
        DataSet dsWorkItemInfo = getQueryProcessor().getPreparedSqlDataSet(strQuery, new Object[]{strRSet});
        if (!"".equals(strRSet)) {
            getDAMProcessor().clearRSet(strRSet);
        }
        if (null == dsWorkItemInfo) {
            throw new SapphireException("Unable to retrieve dsWorkItemInfo.\n Please contact System Administrator..!");
        }

        if (!dsWorkItemID.isValidColumn("u_testingtime")) {
            dsWorkItemID.addColumn("u_testingtime", DataSet.NUMBER);
        }
        if (dsWorkItemInfo.getRowCount() > 0) {
            for (int i = 0; i < dsWorkItemInfo.getRowCount(); i++) {
                for (int j = 0; j < dsWorkItemID.getRowCount(); j++) {
                    if (dsWorkItemInfo.getValue(i, "workitemid").equalsIgnoreCase(dsWorkItemID.getValue(j, "workitemid")) && dsWorkItemInfo.getValue(i, "workitemversionid").equalsIgnoreCase(dsWorkItemID.getValue(j, "workitemversionid"))) {
                        dsWorkItemID.setNumber(j, "u_testingtime", dsWorkItemInfo.getValue(i, "u_testingtime"));
                    }
                }
            }
        }
    }

    @Override
    public void preAdd(SDIData sdiData, PropertyList actionProps) throws SapphireException {


        DataSet primary = sdiData.getDataset(SDIData.PRIMARY);
        if (null == primary || primary.getRowCount() == 0) {
            return;
        }

        //Validates and Updates Security User where the value is empty
        validateAndUpdateSecurityUser(DEFAULT_SECURITY_USER, primary);

        /*************
         * DevOps:: SAP-LIMS Interface
         * Description:: Inspection Lot # added from Batch
         */
        setInspectionLotNumber(primary);

        /**
         * Alcon 06651-00125
         * - Fields entered in the Batch Login page, should copy down to the Sample level (Sample Edit page)
         Specifically:  The "Batch Created by" should populate the "Submitter" field ,The "Batch created Date" would populate the "Submitted Date" in the Sample Edit page WHEN Batch Template is in (Finished, Intermediate) only.
         */

        checkBatchTypeAndUpdateSampleColumn(primary);
        for (int i = 0; i < primary.size(); i++) {
            primary.addColumn("u_otherdept", DataSet.STRING);
            if (primary.isValidColumn("securitydepartment")) {
                primary.setValue(i, "u_otherdept", primary.getValue(i, "securitydepartment", ""));
            }
        }
        String parentSampleid = actionProps.getProperty("parentsampleid", "");
        String batchId = primary.getColumnValues("batchid", "','");
        batchId = StringUtil.replaceAll(batchId, ";", "','");
        String smpQuantity = "";
        String quantityUnits = "";
        String containerType = "";
        String storageConditions = "";
        String smpLevel = "";
        String smpSourcelabel = "";
        String smpbatchStage = "";
        String smpBatchId = "";
        int findRowNo = 0;
        /**
         * auto-populate information from SamplingPlan (Level Sample Tab) to Sample during Sample Creation.
         */

        String samplingplanIdQuery = new StringBuilder("select bt.s_batchid,spd.u_quantity,spd.u_quantityunit,spd.u_storagecondition,\n" +
                "spd.u_containertype,nvl(spd.levelid,'') levelid ,nvl(spd.sourcelabel,'') sourcelabel ,\n" +
                "nvl(bstg.s_batchstageid,'') s_batchstageid ,nvl(spd.processstageid,'') processstageid \n" +
                "from s_spdetail spd\n" +
                "Inner join s_batch bt on spd.s_samplingplanid=bt.samplingplanid and spd.s_samplingplanversionid=bt.samplingplanversionid\n" +
                "left outer join s_batchstage bstg on bstg.batchid=bt.s_batchid and bstg.samplingplanid=spd.s_samplingplanid\n" +
                "and bstg.samplingplanversionid=spd.s_samplingplanversionid and bstg.processstageid=spd.processstageid\n" +
                "where bt.s_batchid in ('" + batchId + "')").toString();


        DataSet dsSamplingplanIdQuery = getQueryProcessor().getSqlDataSet(samplingplanIdQuery);
        if (null == dsSamplingplanIdQuery) {
            throw new SapphireException("Incorrect SQL Query");
        }
        HashMap<String, String> hmSample = new HashMap<String, String>();
        if (dsSamplingplanIdQuery.getRowCount() > 0) {

            if (!primary.isValidColumn("u_quantity")) {
                primary.addColumn("u_quantity", DataSet.STRING);
            }
            if (!primary.isValidColumn("u_quantityunit")) {
                primary.addColumn("u_quantityunit", DataSet.STRING);
            }
            if (!primary.isValidColumn("u_storagecondition")) {
                primary.addColumn("u_storagecondition", DataSet.STRING);
            }
            if (!primary.isValidColumn("u_containertype")) {
                primary.addColumn("u_containertype", DataSet.STRING);
            }

            for (int rowNo = 0; rowNo < primary.getRowCount(); rowNo++) {

                smpBatchId = primary.getValue(rowNo, "batchid", "");
                smpLevel = primary.getValue(rowNo, "sourcesplevelid", "");
                smpSourcelabel = primary.getValue(rowNo, "sourcespsourcelabel", "");
                smpbatchStage = primary.getValue(rowNo, "batchstageid", "");

                hmSample.put("s_batchid", smpBatchId);
                hmSample.put("levelid", smpLevel);
                hmSample.put("sourcelabel", smpSourcelabel);
                if (!"".equals(smpbatchStage)) {
                    hmSample.put("s_batchstageid", smpbatchStage);
                }

                findRowNo = dsSamplingplanIdQuery.findRow(hmSample);
                hmSample.clear();

                if (findRowNo > -1) {
                    smpQuantity = dsSamplingplanIdQuery.getValue(findRowNo, "u_quantity", "");
                    quantityUnits = dsSamplingplanIdQuery.getValue(findRowNo, "u_quantityunit", "");
                    storageConditions = dsSamplingplanIdQuery.getValue(findRowNo, "u_storagecondition", "");
                    containerType = dsSamplingplanIdQuery.getValue(findRowNo, "u_containertype", "");

                    primary.setValue(rowNo, "u_quantity", smpQuantity);
                    primary.setValue(rowNo, "u_quantityunit", quantityUnits);
                    primary.setValue(rowNo, "u_storagecondition", storageConditions);
                    primary.setValue(rowNo, "u_containertype", containerType);
                }
            }
        }

    }

    /**
     * @param securityUser
     * @param dsPrimary
     * @return void
     * @throws SapphireException
     */
    private void validateAndUpdateSecurityUser(String securityUser, DataSet dsPrimary) throws SapphireException {
        for (int i = 0; i < dsPrimary.size(); i++) {
            if (!dsPrimary.isValidColumn("securityuser")) {
                dsPrimary.addColumn("securityuser", DataSet.STRING);
            }
            if (dsPrimary.getValue(i, "securityuser", "").equalsIgnoreCase("")) {
                dsPrimary.setValue(i, "securityuser", securityUser);
            }
        }
    }


    @Override
    public void postEdit(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        // This method is used to calculate the Sample must date based on Sample Due Date & Longest Test Days present in Product
        calculateMustStartDate(dsPrimary);
    }

    /**
     * Method to calculate the Sample must date based on Sample Due Date & Longest Test Days present in Product
     *
     * @param dsPrimary : primary DataSet
     * @throws SapphireException
     */
    private void calculateMustStartDate(DataSet dsPrimary) throws SapphireException {
        DataSet dsSampleInformation = new DataSet();
        dsSampleInformation.addColumn("sampleid", DataSet.STRING);
        //dsSampleInformation.addColumn("productid", DataSet.STRING);
        for (int i = 0; i < dsPrimary.getRowCount(); i++) {
            if (!dsPrimary.isNull(i, COLUMN_SAMPLE_STATUS) && hasPrimaryValueChanged(dsPrimary, i, COLUMN_SAMPLE_STATUS) && dsPrimary.getValue(i, COLUMN_SAMPLE_STATUS, "").equalsIgnoreCase(PROPERTY_SAMPLE_STATUS)) {
                int row = dsSampleInformation.addRow();
                dsSampleInformation.setValue(row, "sampleid", dsPrimary.getValue(i, COLUMN_SAMPLE_SAMPLE_ID, ""));
            }
        }

        // If the DataSet has record then calculate the Sample Must Date
        if (dsSampleInformation.size() > 0) {
            String strProductIdInfo = new StringBuilder("SELECT SS.S_SAMPLEID sampleid,SS.PRODUCTID productid,sysdate,sp.duedtoffset,sp.duedtoffsettimeunit,sp.u_msddays FROM S_SAMPLE SS, S_PRODUCT SP WHERE SS.S_SAMPLEID " +
                    "IN('" + dsSampleInformation.getColumnValues("sampleid", "','") + "') AND SS.PRODUCTID IS NOT NULL AND SP.S_PRODUCTID=SS.PRODUCTID AND SP.S_PRODUCTVERSIONID = SS.PRODUCTVERSIONID AND sp.duedtoffset is not null and sp.duedtoffsettimeunit is not null ").toString();
            DataSet dsProductIdInfo = getQueryProcessor().getSqlDataSet(strProductIdInfo);
            if (null == dsProductIdInfo) {
                throw new SapphireException("Incorrect SQL Query");
            }

            if (dsProductIdInfo.size() > 0) {
                dsProductIdInfo.addColumn("muststartdays", DataSet.DATE);
                dsProductIdInfo.addColumn("duedt", DataSet.DATE);
                for (int j = 0; j < dsProductIdInfo.size(); j++) {
                    if (!dsProductIdInfo.getValue(j, "").equalsIgnoreCase("u_msddays")) {
                        Calendar calcDate = getOffsetDate(dsProductIdInfo.getCalendar(j, "sysdate"), dsProductIdInfo.getValue(j, "duedtoffsettimeunit"), Float.parseFloat(dsProductIdInfo.getValue(j, "duedtoffset")));
                        calcDate.add(Calendar.DAY_OF_MONTH, -Integer.valueOf(dsProductIdInfo.getValue(j, "u_msddays")));
                        dsProductIdInfo.setDate(j, "muststartdays", calcDate);
                        Calendar duedate = getOffsetDate(dsProductIdInfo.getCalendar(j, "sysdate"), dsProductIdInfo.getValue(j, "duedtoffsettimeunit"), Float.parseFloat(dsProductIdInfo.getValue(j, "duedtoffset")));
                        dsProductIdInfo.setDate(j, "duedt", duedate);
                    } else {
                        throw new SapphireException("Must Start Days/Sample Due Date Cannot be blank for the Sample : " + dsProductIdInfo.getColumnValues("sampleid", ";") + ". Please contact your system administrator! ");
                    }
                }

                if (dsProductIdInfo.size() > 0) {
                    PropertyList plEditSDI = new PropertyList();
                    plEditSDI.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    plEditSDI.setProperty(EditSDI.PROPERTY_KEYID1, dsProductIdInfo.getColumnValues("sampleid", ";"));
                    plEditSDI.setProperty(COLUMN_SAMPLE_MUST_START_DATE, dsProductIdInfo.getColumnValues("muststartdays", ";"));
                    plEditSDI.setProperty("duedt", dsProductIdInfo.getColumnValues("duedt", ";"));
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plEditSDI);
                    } catch (SapphireException se) {
                        throw new SapphireException("Error in EditSDI " + se.getMessage());
                    }
                }
            }

        }
    }

    /**
     * Method to calculate the Sample must date based on Sample Due Date & Longest Test Days present in Product
     * Currently not in use
     */
    private void calculateMustStartDateTest(DataSet dsPrimary) throws SapphireException {
        DataSet dsSampleInformation = new DataSet();
        dsSampleInformation.addColumn("sampleid", DataSet.STRING);
        //dsSampleInformation.addColumn("productid", DataSet.STRING);

        for (int i = 0; i < dsPrimary.getRowCount(); i++) {
            if (!dsPrimary.isNull(i, COLUMN_SAMPLE_STATUS) && hasPrimaryValueChanged(dsPrimary, i, COLUMN_SAMPLE_STATUS) && dsPrimary.getValue(i, COLUMN_SAMPLE_STATUS, "").equalsIgnoreCase(PROPERTY_SAMPLE_STATUS)) {
                int row = dsSampleInformation.addRow();
                dsSampleInformation.setValue(row, "sampleid", dsPrimary.getValue(i, COLUMN_SAMPLE_SAMPLE_ID, ""));
            }
        }

        // If the DataSet has record then calculate the Sample Must Date
        if (dsSampleInformation.size() > 0) {
            String strProductIdInfo = new StringBuilder(" SELECT S_SAMPLEID sampleid,PRODUCTID productid FROM S_SAMPLE WHERE S_SAMPLEID IN('" + dsSampleInformation.getColumnValues("sampleid", "','") + "') AND PRODUCTID IS NOT NULL ").toString();
            DataSet dsProductIdInfo = getQueryProcessor().getSqlDataSet(strProductIdInfo);
            if (null == dsProductIdInfo) {
                throw new SapphireException("Incorrect SQL Query");
            }

            if (dsProductIdInfo.size() > 0) {

                String strGetLongestTestDays = new StringBuilder("SELECT SS.S_SAMPLEID sampleid,NVL(to_char((SS.DUEDT -SP.U_MSDDAYS), 'DD-MM-YYYY'), '0') muststartdays FROM S_SAMPLE SS, S_PRODUCT SP WHERE SS.PRODUCTID=SP.S_PRODUCTID AND SS.productversionid = SP.s_productversionid AND SS.S_SAMPLEID IN('" + dsProductIdInfo.getColumnValues("sampleid", "','") + "') AND SP.S_PRODUCTID IN('" + dsProductIdInfo.getColumnValues("productid", "','") + "') ").toString();
                DataSet dsGetLongestTestDays = getQueryProcessor().getSqlDataSet(strGetLongestTestDays);
                if (null == dsGetLongestTestDays) {
                    throw new SapphireException("Incorrect SQL Query");
                }

                HashMap hmFilter = new HashMap();
                hmFilter.put("muststartdays", "0");
                DataSet dsFilter = dsGetLongestTestDays.getFilteredDataSet(hmFilter);
                if (dsFilter.size() > 0) {
                    throw new SapphireException("Must Start Days/Sample Due Date Cannot be blank for the Sample : " + dsGetLongestTestDays.getColumnValues("sampleid", ";") + ". Please contact your system administrator! ");
                } else {
                    PropertyList plEditSDI = new PropertyList();
                    plEditSDI.setProperty(EditSDI.PROPERTY_SDCID, "Sample");
                    plEditSDI.setProperty(EditSDI.PROPERTY_KEYID1, dsGetLongestTestDays.getColumnValues("sampleid", ";"));
                    plEditSDI.setProperty(COLUMN_SAMPLE_MUST_START_DATE, dsGetLongestTestDays.getColumnValues("muststartdays", ";"));
                    try {
                        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plEditSDI);
                    } catch (SapphireException se) {
                        throw new SapphireException("Error in EditSDI " + se.getMessage());
                    }
                }
            }

        }
    }

    /**
     * To calculate Due Date and Must Start Date in Sample
     *
     * @param offsetfromDt : Sysdate
     * @param periodUnit   : DueDateOffset unit at Product level
     * @param period       : DueDateOffset defined at Product level
     * @return
     * @throws SapphireException
     */
    private Calendar getOffsetDate(Calendar offsetfromDt, String periodUnit, float period)
            throws SapphireException {
        Calendar offSetDate = (Calendar) offsetfromDt.clone();
        boolean validUnit = false;
        if (periodUnit.equalsIgnoreCase("Days")) {
            int realPartOfPeriod = Math.round(period * 24.0F);
            offSetDate.add(11, realPartOfPeriod);
            validUnit = true;
        } else if (periodUnit.equalsIgnoreCase("Months")) {
            int realPartOfPeriod = (int) period;
            offSetDate.add(2, realPartOfPeriod);
            float fractionPrtOfPeriod = period - realPartOfPeriod;
            if (fractionPrtOfPeriod > 0.0D) {
                int fraction = Math.round(fractionPrtOfPeriod * 30.0F);
                offSetDate.add(5, fraction);
            }
            validUnit = true;
        } else if (periodUnit.equalsIgnoreCase("Years")) {
            int realPartOfPeriod = (int) period;
            offSetDate.add(1, realPartOfPeriod);
            float fractionPrtOfPeriod = period - realPartOfPeriod;
            if (fractionPrtOfPeriod > 0.0D) {
                int fraction = Math.round(fractionPrtOfPeriod * 365.0F);
                offSetDate.add(5, fraction);
            }
            validUnit = true;
        } else if (periodUnit.equalsIgnoreCase("Hours")) {
            int realPartOfPeriod = (int) period;
            offSetDate.add(11, realPartOfPeriod);
            float fractionPrtOfPeriod = period - realPartOfPeriod;
            if (fractionPrtOfPeriod > 0.0D) {
                int fraction = Math.round(fractionPrtOfPeriod * 60.0F);
                offSetDate.add(12, fraction);
            }
            validUnit = true;
        } else if (periodUnit.equalsIgnoreCase("Weeks")) {
            int realPartOfPeriod = (int) period;
            offSetDate.add(4, realPartOfPeriod);
            float fractionPrtOfPeriod = period - realPartOfPeriod;
            if (fractionPrtOfPeriod > 0.0D) {
                int fraction = Math.round(fractionPrtOfPeriod * 7.0F);
                offSetDate.add(5, fraction);
            }
            validUnit = true;
        } else if (periodUnit.equalsIgnoreCase("Minutes")) {
            int realPartOfPeriod = (int) period;
            offSetDate.add(12, realPartOfPeriod);
            float fractionPrtOfPeriod = period - realPartOfPeriod;
            if (fractionPrtOfPeriod > 0.0D) {
                int fraction = Math.round(fractionPrtOfPeriod * 60.0F);
                offSetDate.add(13, fraction);
            }
            validUnit = true;
        }
        if (validUnit) {
            return offSetDate;
        }
        throw new SapphireException(periodUnit + " is invalid Period Unit.");
    }

    /**************
     * This method is used to set Batch inspection Lot # to Sample inspection Lot#
     * @param dsPrimary
     * @throws SapphireException
     ***************/
    private void setInspectionLotNumber(DataSet dsPrimary) throws SapphireException {
        String batchid = "";
        for (int rowNum = 0; rowNum < dsPrimary.getRowCount(); rowNum++) {
            batchid = dsPrimary.getValue(rowNum, "batchid", "");
            // if sample is created from batch
            if (!"".equalsIgnoreCase(batchid)) {
                // Getting SAPPlant and Inspection Lot Number from SAP created batch Batch
                String sqlText = " SELECT " +
                        "    s_batch.u_sapplant, " +
                        "    s_batch.u_sapinspectionlot, " +
                        "    s_batch.u_issapflag " +
                        "FROM " +
                        "    s_batch " +
                        "WHERE " +
                        "    s_batch.s_batchid = ? ";

                DataSet dsBatchDetails = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{batchid});
                if (null == dsBatchDetails) {
                    throw new SapphireException(" Aborting Transaction. Unable to execute BatchQry. Please contact System Administrator.");
                }
                // If Batch details found
                if (dsBatchDetails.getRowCount() > 0) {
                    String plantId = dsBatchDetails.getValue(0, "u_sapplant", "");
                    String isSAPFlag = dsBatchDetails.getValue(0, "u_issapflag", "");
                    String batchInspectionLot = dsBatchDetails.getValue(0, "u_sapinspectionlot", "");
                    // If SAP batch
                    if (!"".equalsIgnoreCase(plantId) && "Y".equalsIgnoreCase(isSAPFlag) && !"".equalsIgnoreCase(batchInspectionLot)) {
                        // Check if VisionCare RM plant
                        if (SAPPlants.PROPS_VISION_CARE_PLANT_ID01.equalsIgnoreCase(plantId) || SAPPlants.PROPS_VISION_CARE_PLANT_MY10.equalsIgnoreCase(plantId) || SAPPlants.PROPS_VISION_CARE_PLANT_SG03.equalsIgnoreCase(plantId) || SAPPlants.PROPS_VISION_CARE_PLANT_U612.equalsIgnoreCase(plantId)) {
                            if (!dsPrimary.isValidColumn("u_inspectionlot")) {
                                dsPrimary.addColumn("u_inspectionlot", DataSet.STRING);
                            }
                            // Setting batch inspection lot number to Sample inspection lot number
                            dsPrimary.setValue(rowNum, "u_inspectionlot", dsBatchDetails.getValue(0, "u_sapinspectionlot", ""));
                        }
                    }
                }

            }
        }
    }

    /**
     * Alcon 06651-00125
     * - Fields entered in the Batch Login page, should copy down to the Sample level (Sample Edit page)
     * Specifically:  The "Batch Created by" should populate the "Submitter" field ,The "Batch created Date" would populate the "Submitted Date" in the Sample Edit page WHEN Batch Template is in (Finished, Intermediate) only.
     * <p/>
     * * @param dsPrimary
     *
     * @throws SapphireException
     */
    private void checkBatchTypeAndUpdateSampleColumn(DataSet dsPrimary) throws SapphireException {

        String strStringBatchSampleQry = "select sb.s_batchid,sb.createby submitterid,sb.createdt submitteddt, nvl(sb.u_sapbatchcreateby,'') u_sapbatchcreateby from  s_batch sb where   sb.batchtype in ('Finished','Intermediate') and sb.s_batchid in ('%s')";
        DataSet dsBatchInformation = getQueryProcessor().getPreparedSqlDataSet(String.format(strStringBatchSampleQry, dsPrimary.getColumnValues("batchid", "','")), new Object[]{});
        if (null == dsBatchInformation) {
            throw new SapphireException("Unable to execute BatchSampleQry. Please contact System Administrator.");
        }
        if (dsBatchInformation.size() > 0) {
            if (!dsPrimary.isValidColumn("submitterid")) {
                dsPrimary.addColumn("submitterid", DataSet.STRING);
            }
            if (!dsPrimary.isValidColumn("submitteddt")) {
                dsPrimary.addColumn("submitteddt", DataSet.DATE);
            }
            HashMap hmFilter = new HashMap();
            DataSet dsTemp = new DataSet();

            for (int inBatchSample = 0; inBatchSample < dsBatchInformation.size(); inBatchSample++) {
                hmFilter.put("batchid", dsBatchInformation.getValue(inBatchSample, "s_batchid"));
                dsTemp = dsPrimary.getFilteredDataSet(hmFilter);
                for (int i = 0; i < dsTemp.size(); i++) {
                    dsTemp.setValue(i, "submitterid", dsBatchInformation.getValue(inBatchSample, "submitterid").equalsIgnoreCase("(system)") ? dsBatchInformation.getValue(inBatchSample, "u_sapbatchcreateby", "") : dsBatchInformation.getValue(inBatchSample, "submitterid"));
                    dsTemp.setDate(i, "submitteddt", dsBatchInformation.getCalendar(inBatchSample, "submitteddt"));
                }
            }
        }

    }


    /**
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void preAddDataSet(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        logger.info("Sample Rule : CVS Version (preAddDataSet) " + LABVANTAGE_CVS_ID);

        if (!actionProps.getProperty("auditactivity").equalsIgnoreCase("Copy")) {

            DataSet dsDataItem = sdiData.getDataset(SDIData.DATAITEM);
            if (dsDataItem == null || dsDataItem.getRowCount() == 0) {
                logger.info("No DataItem Found");
                return;
            }
            //Alcon FWN LIMS : This method is used to copy the Pom Assay and Chart Value
            //@todo : Un-Commenting the below method for Alcon FWN LIMS
            copyDownValueToDataItemLevel(dsDataItem);
        }

    }


    /**
     * This method is used to copy the Pom Assay and Chart Value
     */
    private void copyDownValueToDataItemLevel(DataSet dsDataItem) throws SapphireException {
        //reading all paramlists and paramlistversionids
        String paramLists = dsDataItem.getColumnValues("paramlistid", ";");
        //making the paramlistid unique
        paramLists = AlconUtil.getUniqueList(paramLists, ";", true);
        paramLists = StringUtil.replaceAll(paramLists, ";", "','");

        String paramListVersionIds = dsDataItem.getColumnValues("paramlistversionid", ";");
        //making the paramlistversionid unique
        paramListVersionIds = AlconUtil.getUniqueList(paramListVersionIds, ";", true);
        paramListVersionIds = StringUtil.replaceAll(paramListVersionIds, ";", "','");

        String variantId = dsDataItem.getColumnValues("variantid", ";");
        //making the variantid unique
        variantId = AlconUtil.getUniqueList(variantId, ";", true);
        variantId = StringUtil.replaceAll(variantId, ";", "','");

        String GET_PARAMLISTITEM = "SELECT paramlistid,\n" +
                "       paramlistversionid,\n" +
                "       variantid,\n" +
                "       paramid,\n" +
                "       paramtype,\n" +
                "       u_pomsassay,u_chartflag\n" +
                "FROM paramlistitem\n" +
                "WHERE paramlistid IN('%s')\n" +
                "  AND paramlistversionid IN('%s')\n" +
                "  AND variantid IN ('%s')\n" +
                "ORDER BY paramlistid,\n" +
                "         paramlistversionid,\n" +
                "         variantid,\n" +
                "         paramid,\n" +
                "         paramtype";

        //Processing the query
        DataSet dataSet = getQueryProcessor().getPreparedSqlDataSet(String.format(GET_PARAMLISTITEM, paramLists, paramListVersionIds, variantId), new Object[]{});
        if (dataSet == null) {
            logger.info("There is a fault in the query:" + GET_PARAMLISTITEM);
            throw new SapphireException("There is a fault in the query:" + GET_PARAMLISTITEM);
        }
        if (!dsDataItem.isValidColumn("u_pomsassay")) {
            dsDataItem.addColumn("u_pomsassay", DataSet.STRING);
        }
        if (!dsDataItem.isValidColumn("u_chartflag")) {
            dsDataItem.addColumn("u_chartflag", DataSet.STRING);
        }

        HashMap<String, String> hmFilter = new HashMap<String, String>();

        for (int row = 0; row < dsDataItem.getRowCount(); row++) {
            String strParamListDataItem = dsDataItem.getValue(row, "paramlistid", "");
            String strParamListVersionIdsDataItem = dsDataItem.getValue(row, "paramlistversionid", "");
            String strvariantIdDataItem = dsDataItem.getValue(row, "variantid", "");
            String strParamIdDataItem = dsDataItem.getValue(row, "paramid", "");
            String strParamTypeDataItem = dsDataItem.getValue(row, "paramtype", "");

            hmFilter.clear();
            //setting up the filter condition
            hmFilter.put("paramlistid", strParamListDataItem);
            hmFilter.put("paramlistversionid", strParamListVersionIdsDataItem);
            hmFilter.put("variantid", strvariantIdDataItem);
            hmFilter.put("paramid", strParamIdDataItem);
            hmFilter.put("paramtype", strParamTypeDataItem);

            //applying filter on the dataSet(i.e. paramlistitem)
            DataSet dsFilteredparamlistitem = dataSet.getFilteredDataSet(hmFilter);
            if (dsFilteredparamlistitem.getRowCount() == 0) {
                continue;
            }

            //reading the u_reportable_ind column
            String strPOMAssay = dsFilteredparamlistitem.getValue(0, "u_pomsassay", "");
            String strChartValue = dsFilteredparamlistitem.getValue(0, "u_chartflag", "");
            //Copying the u_pomsassay from paramlistitem to dataitem
            dsDataItem.setValue(row, "u_pomsassay", strPOMAssay);
            dsDataItem.setValue(row, "u_chartflag", strChartValue);
        }
    }


    @Override
    public void preEditSDIData(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet dsDataSet = sdiData.getDataset(SDIData.DATASET);

        if (dsDataSet.isValidColumn("s_remeasureinstance") && dsDataSet.getRowCount() == 1) {
            // Alcon FWN LIMS :  Copy Down of PomsAssay && ChartValue when doing Remeasure
            //@todo : Un-Commenting the below method for Alcon FWN LIMS
            copyDataItemValueWhenRemeasure(dsDataSet);
        }
    }


    /**
     * Copy Down of PomsAssay && ChartValue when doing Remeasure
     *
     * @param dsDataSet
     * @throws SapphireException
     */
    private void copyDataItemValueWhenRemeasure(DataSet dsDataSet) throws SapphireException {
        String strQuery = "select distinct sdcid,keyid1,dataset,paramlistversionid,paramlistid,variantid,paramid,paramtype,replicateid,u_pomsassay,u_chartflag from sdidataitem where (keyid1,dataset,paramlistversionid,paramlistid,variantid) in (select keyid1,dataset,paramlistversionid,paramlistid,variantid from sdidata where keyid1= ? and dataset= ? and paramlistversionid= ? and paramlistid= ? and variantid= ? )";
        //Processing the query
        DataSet dsEditDataItem = getQueryProcessor().getPreparedSqlDataSet(strQuery, new Object[]{dsDataSet.getValue(0, "keyid1"), dsDataSet.getValue(0, "s_remeasureinstance"), dsDataSet.getValue(0, "paramlistversionid"), dsDataSet.getValue(0, "paramlistid"), dsDataSet.getValue(0, "variantid")});
        if (dsEditDataItem == null) {
            logger.info("There is a fault in the query:" + strQuery);
            throw new SapphireException("There is a fault in the query:" + strQuery);
        }
        if (dsEditDataItem.getRowCount() > 0) {
            PropertyList plEditDataSet = new PropertyList();
            plEditDataSet.setProperty(EditDataItem.PROPERTY_SDCID, "Sample");
            plEditDataSet.setProperty(EditDataItem.PROPERTY_KEYID1, dsEditDataItem.getColumnValues("keyid1", ";"));
            plEditDataSet.setProperty(EditDataItem.PROPERTY_PROPSMATCH, "Y");
            plEditDataSet.setProperty("paramlistid", dsEditDataItem.getColumnValues("paramlistid", ";"));
            plEditDataSet.setProperty("paramlistversionid", dsEditDataItem.getColumnValues("paramlistversionid", ";"));
            plEditDataSet.setProperty("variantid", dsEditDataItem.getColumnValues("variantid", ";"));
            plEditDataSet.setProperty("dataset", StringUtil.repeat(dsDataSet.getValue(0, "dataset"), dsEditDataItem.size(), ";"));
            plEditDataSet.setProperty("paramid", dsEditDataItem.getColumnValues("paramid", ";"));
            plEditDataSet.setProperty("paramtype", dsEditDataItem.getColumnValues("paramtype", ";"));
            plEditDataSet.setProperty("replicateid", dsEditDataItem.getColumnValues("replicateid", ";"));
            plEditDataSet.setProperty("u_pomsassay", dsEditDataItem.getColumnValues("u_pomsassay", ";"));
            plEditDataSet.setProperty("u_chartflag", dsEditDataItem.getColumnValues("u_chartflag", ";"));
            try {
                logger.info("Processing Sample. (Action) : plEditDataSet : " + plEditDataSet.toJSONString());
                getActionProcessor().processAction(EditDataItem.ID, EditDataItem.VERSIONID, plEditDataSet);
            } catch (Exception ex) {
                throw new SapphireException("Unable to Sample Data Set due to " + ex.getMessage());
            }
        }
    }

}
