package labvantage.custom.alcon.ddt;

import sapphire.SapphireException;
import sapphire.action.BaseSDCRules;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * $Author: BAGCHAN1 $
 * $Date: 2022-11-02 00:45:36 +0530 (Wed, 02 Nov 2022) $
 * $Revision: 268 $
 */

/*********************************************************************
 * $Revision: 268 $
 * SDC rule for IntfTransaction
 * This class is being called when IntfTrancation table populated with SAP data
 *
 *********************************************************************/

public class IntfTrans extends BaseSDCRules {
    public static final String DEVOPS_ID = "$Revision: 268 $";

    @Override
    public void preDelete(String rsetid, PropertyList actionProps) throws SapphireException {
        cascadeDeleteTransError(actionProps);
    }

    /**
     * Delete the related the error table record(s) when deleting IntfTrans records.
     *
     * @param actionProps
     * @throws SapphireException
     */
    private void cascadeDeleteTransError(PropertyList actionProps) throws SapphireException {
        if (actionProps == null || actionProps.size() == 0) {
            return;
        }
        String transIds = actionProps.getProperty("keyid1", "");

        //Purposefully running the raw SQL to speedup the code execution.
        String deleteSQL = "delete from u_intferror where intftransid in ('" + StringUtil.replaceAll(transIds, ";", "','") + "')";
        database.executeUpdate(deleteSQL);
    }


}
