package labvantage.custom.alcon.ddt;

import sapphire.SapphireException;
import sapphire.action.BaseSDCRules;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.xml.PropertyList;



/**
 * $Author: CHATTSA1 $
 * $Date: 2022-05-30 01:43:48 -0500 (Mon, 30 May 2022) $
 * $Revision: 67 $
 */

/*********************************************************************
 * $Revision: 67 $
 * SDC rule for Reference Types
 * This class is being called when a new data is added or edited
 *
 *********************************************************************/
public class RefType extends BaseSDCRules {

    public static final String DEVOPS_ID = "$Revision: 67 $";
    public static final String REFERENCE_TYPE = "refvalue";
    public static final String COLUMN_REFERENCE_VALUE_ID = "refvalueid";
    public static final String COLUMN_REFERENCE_VALUE_DESCRIPTION = "refvaluedesc";
    public static final String COLUMN_REFERENCE_DISPLAY_VALUE = "refdisplayvalue";

    @Override
    public void preAddDetail(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet reference = sdiData.getDataset(REFERENCE_TYPE);
        if (null == reference || reference.getRowCount() == 0) {
            return;
        }
        trimWhiteSpace(reference);
    }

    @Override
    public void preEditDetail(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet reference = sdiData.getDataset(REFERENCE_TYPE);
        if (null == reference || reference.getRowCount() == 0) {
            return;
        }
        trimWhiteSpace(reference);
    }

    /**
     * Delete any leading or tailing white spaces from the reference values.
     *
     * @param dsReference
     * @throws SapphireException
     */
    private void trimWhiteSpace(DataSet dsReference) throws SapphireException {
        for (int i = 0; i < dsReference.size(); i++) {
            dsReference.setValue(i, COLUMN_REFERENCE_VALUE_ID, dsReference.getValue(i, COLUMN_REFERENCE_VALUE_ID, "").trim());
            dsReference.setValue(i, COLUMN_REFERENCE_VALUE_DESCRIPTION, dsReference.getValue(i, COLUMN_REFERENCE_VALUE_DESCRIPTION, "").trim());
            dsReference.setValue(i, COLUMN_REFERENCE_DISPLAY_VALUE, dsReference.getValue(i, COLUMN_REFERENCE_DISPLAY_VALUE, "").trim());
        }
    }

}
