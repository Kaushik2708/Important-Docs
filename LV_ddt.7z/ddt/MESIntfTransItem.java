package labvantage.custom.alcon.ddt;
/**
 * $Author: SAHAPI1 $
 * $Date: 2022-12-01 03:02:30 +0530 (Thu, 01 Dec 2022) $
 * $Revision: 364 $
 */

import labvantage.custom.alcon.mes.action.MESErrorHandler;
import labvantage.custom.alcon.mes.action.MESProcessController;
import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import org.json.JSONException;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseSDCRules;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.util.SafeSQL;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/********************************************************************************************************
 * $Revision: 364 $
 * Description:
 *
 ********************************************************************************************************/
public class MESIntfTransItem extends BaseSDCRules {

    public static final String DEVOPS_ID = "$Revision: 364 $";
    public static final String __PROP_SDC_MES_INTF_ERROR = "MESIntfError";
    public static final String __PROP_MES_INTFTRANS_ID = "mesintftransid";
    public static final String __PROP_MES_INTFTRANS_ITEM_ID = "mesintftransitemid";
    public static final String __PROP_MES_TRANS_ITEM_COL_ITEM_ID = "u_mesintftransitemid";
    public static final String __PROP_ERROR_MESSAGE = "errormsg";
    public static final String __PROP_PROGRAM = "program";
    public static final String __PROP_SERVICE_NAME = "servicename";
    public static final String __PROP_SITE = "plant";
    public static final String __PROP_TRANS_ITEM_COL_ITEM_DATA = "itemdata";
    public static final String __PROP_STATUS = "status";
    private static final String __PROP_CREATEBY = "createby";
    private static final String LIMSBATCHID = "limsbatchid";
    private static final String LIMSSAMPLEID = "limssampleid";
    private static final String __PROP_REPROCESSFLAG = "reprocessingflag";
    private static final String __PROP_MES_OPCENTER = "MES_INTERFACE";
    private static final String MES_TRANS_ITEM_STATUS_ERROR = "ERROR";
    private static final String MES_TRANS_ITEM_STATUS_SUCCESS = "SUCCESS";
    public static final String PROP_MES_TRANS_ITEM_COL_REPROCESS_DATE = "reprocessdate";
    public static final String PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT = "reprocesscount";
    public static final String PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD = "itemdata";
    public static final String PROP_TRANS_ITEM_COL_ITEM_ID = "u_mesintftransitemid";

    /**
     * @param rsetid      String
     * @param actionProps PropertyList
     * @throws SapphireException
     */
    @Override
    public void preDelete(String rsetid, PropertyList actionProps) throws SapphireException {
        cascadeDeleteMESTansItemError(actionProps);
    }


    /**
     * Delete the related the error table record(s) when deleting TransItem.
     *
     * @param actionProps
     * @throws SapphireException
     */
    private void cascadeDeleteMESTansItemError(PropertyList actionProps) throws SapphireException {
        if (actionProps == null || actionProps.size() == 0) {
            return;
        }
        String transItemIds = actionProps.getProperty("keyid1", "");
        //Purposefully running the raw SQL to speedup the code execution.
        String deleteSQL = "delete from u_mesintferror where mesintftransitemid in ('" + StringUtil.replaceAll(transItemIds, ";", "','") + "')";
        database.executeUpdate(deleteSQL);
    }


    /**
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void preEdit(SDIData sdiData, PropertyList actionProps) {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        try {
            if (dsPrimary.size() == 1 && dsPrimary.getValue(0, __PROP_STATUS, "").equalsIgnoreCase(MES_TRANS_ITEM_STATUS_ERROR)) {
                logMESError(dsPrimary.getValue(0, __PROP_MES_INTFTRANS_ID, ""), dsPrimary.getValue(0, __PROP_MES_TRANS_ITEM_COL_ITEM_ID, ""), actionProps.getProperty(__PROP_ERROR_MESSAGE, ""), dsPrimary.getValue(0, __PROP_SERVICE_NAME, ""));
            }
            handleReprocessing(dsPrimary, sdiData);

        } catch (SapphireException ex) {
            String errorMsg = ex.getMessage();
            logger.error(errorMsg);
        }
    }


    /*************************************************************************
     * This method is used to handle Handles reprocessing of transaction item
     * @param dsPrimary Primary DataSet
     * @throws SapphireException OOB Sapphire Exception
     *************************************************************************/
    private void handleReprocessing(DataSet dsPrimary, SDIData sdidata) throws SapphireException {
        String modifiedMESIntftransItemid = "";
        for (int i = 0; i < dsPrimary.size(); i++) {
            if (hasPrimaryValueChanged(dsPrimary, i, PROP_MES_TRANS_ITEM_COL_REPROCESS_DATE)) {
                modifiedMESIntftransItemid += ";" + dsPrimary.getValue(i, __PROP_MES_TRANS_ITEM_COL_ITEM_ID, "");
            }
        }

        if (modifiedMESIntftransItemid.startsWith(";")) {
            modifiedMESIntftransItemid = modifiedMESIntftransItemid.substring(1);
        } else {
            return;
        }
        //******************* Safe SQL addIn added for IN clause *******************
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT ").append(__PROP_MES_TRANS_ITEM_COL_ITEM_ID).append(", ").append(PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD).append(" FROM u_mesintftransitem ");
        // ************** Using SafeSQL--> addVar to use as bind variable ***************
        strSQL.append("WHERE ").append(__PROP_MES_TRANS_ITEM_COL_ITEM_ID).append(" IN (").append(safeSQL.addIn(modifiedMESIntftransItemid, ";")).append(")");
        // ************** Using SafeSQL--> getValues to replace bind variable with values  ***************
        DataSet dsSql = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues(), true);
        if (dsSql == null) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.GENERAL_ERR_00002));

        }

        HashMap hmFilter;
        DataSet dsFilter;
        for (int i = 0; i < dsPrimary.size(); i++) {

            int reprocessCount = Integer.parseInt(getOldPrimaryValue(dsPrimary, i, PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT).equals("") ? "0" : getOldPrimaryValue(dsPrimary, i, PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT));
            reprocessCount++;

            if (!dsPrimary.isValidColumn(PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT)) {
                dsPrimary.addColumn(PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT, DataSet.NUMBER);
            }
            dsPrimary.setNumber(i, PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT, reprocessCount);


            String mesIntfTransItemId = dsPrimary.getValue(i, PROP_TRANS_ITEM_COL_ITEM_ID, "");
            hmFilter = new HashMap();
            hmFilter.put(PROP_TRANS_ITEM_COL_ITEM_ID, mesIntfTransItemId);

            dsFilter = getBeforeEditImage().getDataset(SDIData.PRIMARY).getFilteredDataSet(hmFilter);

            if (!dsFilter.isValidColumn(PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD)) {
                dsFilter.addColumn(PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD, DataSet.CLOB);
            }

            dsFilter.setClob(0, PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD, dsSql.getFilteredDataSet(hmFilter).getClob(0, PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD));
            String[] retVal = callMESProcessController(dsFilter, "Y");
            //Setting reporcessing status = SUCCESS
            if (dsFilter.getValue(0, __PROP_STATUS, "").equalsIgnoreCase(MES_TRANS_ITEM_STATUS_SUCCESS)) {
                if (!dsPrimary.isValidColumn(__PROP_STATUS)) {
                    dsPrimary.addColumn(__PROP_STATUS, DataSet.STRING);
                }
                dsPrimary.setValue(i, __PROP_STATUS, MES_TRANS_ITEM_STATUS_SUCCESS);
            }

            //Setting reporcessing status = ERROR
            if (MES_TRANS_ITEM_STATUS_ERROR.equalsIgnoreCase(retVal[0])) {
                if (!dsPrimary.isValidColumn(__PROP_STATUS)) {
                    dsPrimary.addColumn(__PROP_STATUS, DataSet.STRING);
                }
                dsPrimary.setValue(i, __PROP_STATUS, MES_TRANS_ITEM_STATUS_ERROR);
            }

            if (!"".equalsIgnoreCase(retVal[1])) {
                if (!dsPrimary.isValidColumn(LIMSBATCHID)) {
                    dsPrimary.addColumn(LIMSBATCHID, DataSet.STRING);
                }
                dsPrimary.setValue(i, LIMSBATCHID, retVal[1]);
            }
            if (!"".equalsIgnoreCase(retVal[2])) {
                if (!dsPrimary.isValidColumn(LIMSSAMPLEID)) {
                    dsPrimary.addColumn(LIMSSAMPLEID, DataSet.STRING);
                }
                dsPrimary.setValue(i, LIMSSAMPLEID, retVal[2]);
            }

        }
    }


    /**
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void preAdd(SDIData sdiData, PropertyList actionProps) {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);

        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }
        try {
            String[] retVal = callMESProcessController(dsPrimary, "N");
            // ************ Code added for setting LIMS Batch Id and LIMS Sample Id *********

            //Setting when status = ERROR
            if (MES_TRANS_ITEM_STATUS_ERROR.equalsIgnoreCase(retVal[0])) {
                if (!dsPrimary.isValidColumn(__PROP_STATUS)) {
                    dsPrimary.addColumn(__PROP_STATUS, DataSet.STRING);
                }
                dsPrimary.setValue(0, __PROP_STATUS, MES_TRANS_ITEM_STATUS_ERROR);
            }

            if (!"".equalsIgnoreCase(retVal[1])) {
                if (!dsPrimary.isValidColumn(LIMSBATCHID)) {
                    dsPrimary.addColumn(LIMSBATCHID, DataSet.STRING);
                }
                dsPrimary.setValue(0, LIMSBATCHID, retVal[1]);
            }
            if (!"".equalsIgnoreCase(retVal[2])) {
                if (!dsPrimary.isValidColumn(LIMSSAMPLEID)) {
                    dsPrimary.addColumn(LIMSSAMPLEID, DataSet.STRING);
                }
                dsPrimary.setValue(0, LIMSSAMPLEID, retVal[2]);
            }

        } catch (SapphireException ex) {
            String errorMsg = ex.getMessage();
            logger.error(errorMsg);
        }
    }

    /*************************************************************
     * This method is used to get snapshot of data before editing
     * @return Returns true or false.
     *************************************************************/
    public boolean requiresBeforeEditImage() {
        return true;
    }


    /***
     * Description: Calls Controller to process payload.
     * @param dsPrimary Dataset
     * @param reprocessingFlag String
     * @throws SapphireException
     */
    private String[] callMESProcessController(DataSet dsPrimary, String reprocessingFlag) throws SapphireException {

        String[] retVal = new String[3];
        PropertyList plMESTransItem = new PropertyList();
        PropertyList plJson = new PropertyList();
        PropertyList plPayload = new PropertyList();
        if (!dsPrimary.isValidColumn(LIMSBATCHID)) {
            dsPrimary.addColumn(LIMSBATCHID, DataSet.STRING);
        }
        if (!dsPrimary.isValidColumn(LIMSSAMPLEID)) {
            dsPrimary.addColumn(LIMSSAMPLEID, DataSet.STRING);
        }

        for (int i = 0; i < dsPrimary.getRowCount(); i++) {

            String mesTransId = dsPrimary.getValue(i, "mesintftransid", "");
            String mesTransItemId = dsPrimary.getValue(i, "u_mesintftransitemid", "");
            String serviceName = dsPrimary.getValue(i, "servicename", "");
            String itemData = dsPrimary.getValue(i, __PROP_TRANS_ITEM_COL_ITEM_DATA, "");
            String plant = dsPrimary.getValue(i, "plant", "");
            plMESTransItem.clear();
            plJson.clear();
            try {
                JSONObject jsPayload = new JSONObject(itemData);
                plJson = new PropertyList(jsPayload);
            } catch (JSONException e) {
                throw new SapphireException(e);
            }
            plMESTransItem.clear();
            plMESTransItem = plJson.getPropertyList("PAYLOAD");
            plMESTransItem.setProperty(__PROP_SERVICE_NAME, serviceName);
            plMESTransItem.setProperty(__PROP_SITE, plant);
            plMESTransItem.setProperty(__PROP_MES_INTFTRANS_ID, mesTransId);
            plMESTransItem.setProperty(__PROP_MES_INTFTRANS_ITEM_ID, mesTransItemId);
            plMESTransItem.setProperty(__PROP_TRANS_ITEM_COL_ITEM_DATA, itemData);
            plMESTransItem.setProperty(__PROP_REPROCESSFLAG, reprocessingFlag);// Reprocessing -Y or N
            plMESTransItem.setProperty(__PROP_STATUS, "");
            plMESTransItem.setProperty(LIMSBATCHID, "");
            plMESTransItem.setProperty(LIMSSAMPLEID, "");

            try {
                getActionProcessor().processAction(MESProcessController.ID, MESProcessController.VERSIONID, plMESTransItem, true);
                dsPrimary.setValue(i, __PROP_STATUS, MES_TRANS_ITEM_STATUS_SUCCESS);

            } catch (SapphireException e) {
                dsPrimary.setValue(i, __PROP_STATUS, MES_TRANS_ITEM_STATUS_ERROR);
                String[] errWithDetails = StringUtil.split(e.getMessage(), "|");
                retVal[0] = MES_TRANS_ITEM_STATUS_ERROR; // ERROR Status
                // Below if blocks are added to avoid array index problem
                if (errWithDetails.length >= 2) {
                    retVal[1] = "".equalsIgnoreCase(errWithDetails[1]) ? "" : errWithDetails[1]; // LIMS Batch Id
                } else {
                    retVal[1] = "";
                }
                if (errWithDetails.length == 3) {
                    retVal[2] = "".equalsIgnoreCase(errWithDetails[2]) ? "" : errWithDetails[2]; // LIMS Sample Id
                } else {
                    retVal[2] = "";
                }
                logMESError(mesTransId, mesTransItemId, errWithDetails[0], serviceName);
                return retVal;

            } catch (Exception e) {
                dsPrimary.setValue(i, __PROP_STATUS, MES_TRANS_ITEM_STATUS_ERROR);
                String[] errWithDetails = e.getMessage().split("[|]");
                retVal[0] = MES_TRANS_ITEM_STATUS_ERROR; // ERROR Status
                // Below if blocks are added to avoid array index problem
                if (errWithDetails.length >= 2) {
                    retVal[1] = "".equalsIgnoreCase(errWithDetails[1]) ? "" : errWithDetails[1]; // LIMS Batch Id
                } else {
                    retVal[1] = "";
                }
                if (errWithDetails.length == 3) {
                    retVal[2] = "".equalsIgnoreCase(errWithDetails[2]) ? "" : errWithDetails[2]; // LIMS Sample Id
                } else {
                    retVal[2] = "";
                }
                logMESError(mesTransId, mesTransItemId, errWithDetails[0], serviceName);
                return retVal;
            }
          /*  // *********** For ERROR Only ********* //
            if(MES_TRANS_ITEM_STATUS_ERROR.equalsIgnoreCase(plMESTransItem.getProperty(__PROP_STATUS, ""))){
                dsPrimary.setValue(i, __PROP_STATUS, MES_TRANS_ITEM_STATUS_ERROR);
                String errMsg = plMESTransItem.getProperty(__PROP_ERROR_MESSAGE, "");
                logMESError(mesTransId, mesTransItemId, errMsg, serviceName);
            }*/
            // *********** For SUCCESS Only ********* //
            /*if (MES_TRANS_ITEM_STATUS_SUCCESS.equalsIgnoreCase(plMESTransItem.getProperty(__PROP_STATUS, ""))) {
                dsPrimary.setValue(i, __PROP_STATUS, MES_TRANS_ITEM_STATUS_SUCCESS);
                retVal[0] = plMESTransItem.getProperty(__PROP_STATUS, "");
            }*/
            dsPrimary.setValue(i, __PROP_STATUS, MES_TRANS_ITEM_STATUS_SUCCESS);
            retVal[0] = MES_TRANS_ITEM_STATUS_SUCCESS;
            // *********** For Success & ERROR case ********* //
            if (!"".equalsIgnoreCase(plMESTransItem.getProperty(LIMSBATCHID, ""))) {
                dsPrimary.setValue(i, LIMSBATCHID, plMESTransItem.getProperty(LIMSBATCHID, ""));
                retVal[1] = plMESTransItem.getProperty(LIMSBATCHID, "");
            }
            if (!"".equalsIgnoreCase(plMESTransItem.getProperty(LIMSSAMPLEID, ""))) {
                dsPrimary.setValue(i, LIMSSAMPLEID, plMESTransItem.getProperty(LIMSSAMPLEID, ""));
                retVal[2] = plMESTransItem.getProperty(LIMSSAMPLEID, "");
            }
        }
        return retVal;
    }


    /*********************************************************************
     * This method is used to Log the SAP interfacing error or exceptions.
     * @param transId MES Transaction Id
     * @param transItemId MES Transaction Item Id
     * @param errormsg Error Message
     * @param serviceName Service Name
     *********************************************************************/
    public void logMESError(String transId, String transItemId, String errormsg, String serviceName) throws SapphireException {

        logger.error("================================ mesintferrordesc In logMESError ===========================");

        PropertyList pl = new PropertyList();
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        pl.setProperty(AddSDI.PROPERTY_SDCID, __PROP_SDC_MES_INTF_ERROR);
        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
        pl.setProperty(__PROP_MES_INTFTRANS_ID, transId);
        pl.setProperty(__PROP_MES_INTFTRANS_ITEM_ID, transItemId);
        //pl.setProperty(__PROP_ERROR_MESSAGE, errormsg);
        String msg="";
        if(errormsg.contains("Reason:")){
            msg = StringUtil.split(errormsg,"Reason:")[StringUtil.split(errormsg,"Reason:").length-1];
        }
        else{
            msg=errormsg;
        }
        pl.setProperty(__PROP_ERROR_MESSAGE, msg);
        pl.setProperty(__PROP_STATUS, MES_TRANS_ITEM_STATUS_ERROR);
        pl.setProperty(__PROP_PROGRAM, serviceName);
        pl.setProperty(__PROP_CREATEBY, currentUser);
        try {
            getActionProcessor().processAction(MESErrorHandler.ID, MESErrorHandler.VERSIONID, pl);

        } catch (SapphireException e) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.GENERAL_ERR_00012));
        }

    }
}
