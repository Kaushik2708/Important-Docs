package labvantage.custom.alcon.ddt;

import sapphire.SapphireException;
import sapphire.action.BaseSDCRules;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.Calendar;

/**
 * $Author: BAGCHAN1 $
 * $Date: 2022-02-08 00:16:36 -0500 (Tue, 08 Feb 2022) $
 * $Revision: 13 $
 */

/********************************************************************************************************
 * $Revision: 13 $
 * Description: SDC rule for Reagent Lot Expiry date .
 *******************************************************************************************************/
public class TrackItemSDC extends BaseSDCRules {
    public static final String DEVOPS_ID = "$Revision: 13 $";

    @Override
    public void preAdd(SDIData sdiData, PropertyList actionProps) throws SapphireException {

        logger.info("---------TrackItemSDC Invoked for preAdd---------");

        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);

        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }
        if (dsPrimary.getValue(0, "linksdcid", "").equalsIgnoreCase("LV_ReagentLot")) {
            calculateExpiryDate(dsPrimary, "PreAdd");
        }
    }

    public void preEdit(SDIData sdiData, PropertyList actionProps) throws SapphireException {

        logger.info("---------TrackItemSDC Invoked for preEdit---------");

        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);

        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }
        if (dsPrimary.getValue(0, "linksdcid", "").equalsIgnoreCase("LV_ReagentLot")) {
            calculateExpiryDate(dsPrimary, "PreEdit");
        }
    }

    /**
     * @return
     */
    public boolean requiresBeforeEditImage() {
        return true;
    }

    /**
     * Description: This method is used to calculate the Expiry Date
     *
     * @param dsPrimary
     */

    public void calculateExpiryDate(DataSet dsPrimary, String event) throws SapphireException {
        DataSet dsOutput = null;
        DataSet dsLinkKeyIds = null;
        DataSet dsFinal = new DataSet(connectionInfo);
        // Forming final DataSet when there is a change in Open Date
        for (int i = 0; i < dsPrimary.size(); i++) {
            if (hasPrimaryValueChanged(dsPrimary, i, "u_opendate")) {
                dsFinal.copyRow(dsPrimary, i, 1);
            }
        }
        PropertyList plFilter = new PropertyList();
        if (dsFinal != null) {
            if (dsFinal.getRowCount() > 0) {
                // If preEdit event the get the linkkeyid1 / Reagent Lot Ids from trackitem as it's missing in props
                if (event.equalsIgnoreCase("PreEdit")) {
                    String sqlReagentLotIds = " SELECT " +
                            "    trackitem.trackitemid, " +
                            "    trackitem.linkkeyid1 " +
                            "FROM " +
                            "    trackitem " +
                            "WHERE " +
                            "    trackitem.trackitemid IN( '" + StringUtil.replaceAll(dsFinal.getColumnValues("trackitemid", ";"), ";", "','") + "') ";
                    try {
                        dsLinkKeyIds = getQueryProcessor().getSqlDataSet(sqlReagentLotIds);
                    } catch (Exception ex) {
                        throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
                    }
                    if (null == dsLinkKeyIds) {
                        throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Wrong query defined. Please contact your system administrator. \n" + sqlReagentLotIds));
                    }
                    if (dsLinkKeyIds.getRowCount() > 0) {
                        if (!dsFinal.isValidColumn("linkkeyid1")) {
                            dsFinal.addColumn("linkkeyid1", DataSet.STRING);
                        }
                        String reagentLotId = "";
                        for (int rowCount = 0; rowCount < dsFinal.getRowCount(); rowCount++) {
                            plFilter.setProperty("trackitemid", dsFinal.getValue(rowCount, "trackitemid", ""));
                            reagentLotId = dsLinkKeyIds.getValue(dsLinkKeyIds.findRow(plFilter), "linkkeyid1", "");
                            dsFinal.setValue(rowCount, "linkkeyid1", reagentLotId);
                            plFilter.clear();
                        }
                    }
                }
                // Forming the SQL text for preAdd / preEdit
                String sql = " SELECT " +
                        "    reagentlot.reagentlotid,  reagentlot.expirydt," +
                        "    reagenttype.u_containerexpiryperiod, " +
                        "    reagenttype.u_containerexpiryperiodunit " +
                        "FROM " +
                        "    reagentlot " +
                        "    INNER JOIN reagenttype ON reagentlot.reagenttypeid = reagenttype.reagenttypeid " +
                        "                              AND reagentlot.reagenttypeversionid = reagenttype.reagenttypeversionid " +
                        "WHERE " +
                        "    reagentlot.reagentlotid IN ('" + StringUtil.replaceAll(dsFinal.getColumnValues("linkkeyid1", ";"), ";", "','") + "')";

                // Getting the details from DB for selected trackitems
                try {
                    dsOutput = getQueryProcessor().getSqlDataSet(sql);
                } catch (Exception ex) {
                    throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
                }
                if (null == dsOutput) {
                    throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Wrong query defined. Please contact your system administrator. \n" + sql));
                }
                if (dsOutput.size() == 0) {
                    return;
                }
                for (int rowNum = 0; rowNum < dsFinal.size(); rowNum++) {
                    plFilter.clear();
                    plFilter.setProperty("reagentlotid", dsFinal.getValue(rowNum, "linkkeyid1", ""));
                    String openDate = dsFinal.getValue(rowNum, "u_opendate", "");

                    Calendar lotExpiryDt = dsOutput.getCalendar(dsOutput.findRow(plFilter), "expirydt");
                    String containerExpPeriod = dsOutput.getValue(dsOutput.findRow(plFilter), "u_containerexpiryperiod", "");
                    String containerExpUnit = dsOutput.getValue(dsOutput.findRow(plFilter), "u_containerexpiryperiodunit", "");

                    if (!"".equalsIgnoreCase(openDate) && !"".equalsIgnoreCase(containerExpPeriod) && !"".equalsIgnoreCase(containerExpUnit)) {
                        if (!dsPrimary.isValidColumn("expirydt")) {
                            dsPrimary.addColumn("expirydt", DataSet.DATE);
                        }
                        Calendar c1 = getExpiryDate(dsFinal.getCalendar(rowNum, "u_opendate"), Integer.parseInt(containerExpPeriod), containerExpUnit);
                        plFilter.clear();
                        plFilter.setProperty("trackitemid", dsFinal.getValue(rowNum, "trackitemid", ""));

                        if (lotExpiryDt != null && c1.compareTo(lotExpiryDt) == 1) {
                            dsPrimary.setDate(dsPrimary.findRow(plFilter), "expirydt", lotExpiryDt);
                        } else {
                            dsPrimary.setDate(dsPrimary.findRow(plFilter), "expirydt", c1);
                        }

                    } else {
                        plFilter.clear();
                        plFilter.setProperty("trackitemid", dsFinal.getValue(rowNum, "trackitemid", ""));
                        dsPrimary.setDate(dsPrimary.findRow(plFilter), "expirydt", "");

                    }
                    plFilter.clear();

                }
            }
        }

    }


    /************
     * This method is used to calculate expiry date = Open Date + (Container offset / Unit)
     * @param openDt
     * @param containerExpiryPeriod
     * @param containerExpiryPeriodUnit
     * @return
     * @throws SapphireException
     ************/
    private Calendar getExpiryDate(Calendar openDt, int containerExpiryPeriod, String containerExpiryPeriodUnit) throws SapphireException {
        Calendar modOpenDt = (Calendar) openDt.clone();
        if (containerExpiryPeriodUnit.equalsIgnoreCase("Days")) {
            modOpenDt.add(Calendar.DATE, containerExpiryPeriod);
        } else if (containerExpiryPeriodUnit.equalsIgnoreCase("Months")) {
            modOpenDt.add(Calendar.MONTH, containerExpiryPeriod);
        } else if (containerExpiryPeriodUnit.equalsIgnoreCase("Years")) {
            modOpenDt.add(Calendar.YEAR, containerExpiryPeriod);
        } else if (containerExpiryPeriodUnit.equalsIgnoreCase("Hours")) {
            modOpenDt.add(Calendar.HOUR, containerExpiryPeriod);
        }
        return modOpenDt;
    }

}