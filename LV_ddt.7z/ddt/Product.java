package labvantage.custom.alcon.ddt;

import sapphire.SapphireException;
import sapphire.accessor.ActionException;
import sapphire.action.AddSDISecurityDept;
import sapphire.action.BaseSDCRules;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.xml.PropertyList;

/**
 * $Author: BAGCHAN1 $
 * $Date: 2022-04-20 01:26:41 +0530 (Wed, 20 Apr 2022) $
 * $Revision: 46 $
 */

/*********************************************************************
 * $Revision: 46 $
 * SDC rule for Product
 * This class is being called when Product SDC is created.
 *
 *********************************************************************/
public class Product extends BaseSDCRules {
    public static final String DEVOPS_ID = "$Revision: 46 $";

    private static final String PROP_SDC_PRODUCT = "Product";
    private static final String PROP_COL_PRODUCTID = "s_productid";
    private static final String PROP_COL_PRODUCTVERSIONID = "s_productversionid";
    private static final String PROP_COL_SECURITY_DEPARTMENT = "securitydepartment";
    private static final String PROP_COL_OPERATIONID = "operationid";

    @Override
    public void postAdd(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        // the condition mentioned below checks whether the product version is new or not.
        if (Integer.parseInt(dsPrimary.getValue(0, PROP_COL_PRODUCTVERSIONID)) > 1) {
            addSDISharedSecurityDepartment(dsPrimary);
        }
    }

    /**
     * creates the query and invokes the function to add the shared departments to new version of the product
     *
     * @param dsPrimary
     * @throws SapphireException
     */
    private void addSDISharedSecurityDepartment(DataSet dsPrimary) throws SapphireException {
        String sqlSharedDepartment = "SELECT operationid, securitydepartment FROM sdisecuritydepartment WHERE sdcid = ? AND keyid1 = ? AND keyid2 = ?";
        DataSet dsSharedDepartment = getQueryProcessor().getPreparedSqlDataSet(sqlSharedDepartment, new Object[]{PROP_SDC_PRODUCT,
                dsPrimary.getValue(0, PROP_COL_PRODUCTID),
                String.valueOf(Integer.parseInt(dsPrimary.getValue(0, PROP_COL_PRODUCTVERSIONID)) - 1)});
        if (null != dsSharedDepartment && dsSharedDepartment.getRowCount() > 0) {
            processActionForSecurityDepartment(dsPrimary, dsSharedDepartment);
        }
    }

    /**
     * Creates the property list and processes the action addSDISecurityDept for the New version of the selected product
     *
     * @param dsPrimary
     * @param dsSharedDepartment
     * @throws ActionException
     */
    private void processActionForSecurityDepartment(DataSet dsPrimary, DataSet dsSharedDepartment) throws SapphireException {
        PropertyList plAddSDISecurityDept = new PropertyList();
        plAddSDISecurityDept.setProperty(AddSDISecurityDept.PROPERTY_SDCID, PROP_SDC_PRODUCT);
        plAddSDISecurityDept.setProperty(AddSDISecurityDept.PROPERTY_KEYID1, dsPrimary.getValue(0, PROP_COL_PRODUCTID));
        plAddSDISecurityDept.setProperty(AddSDISecurityDept.PROPERTY_KEYID2, dsPrimary.getValue(0, PROP_COL_PRODUCTVERSIONID));
        plAddSDISecurityDept.setProperty(AddSDISecurityDept.PROPERTY_KEYID3, "(null)");
        plAddSDISecurityDept.setProperty(AddSDISecurityDept.PROPERTY_DEPARTMENTID, dsSharedDepartment.getColumnValues(PROP_COL_SECURITY_DEPARTMENT, ";"));
        plAddSDISecurityDept.setProperty(AddSDISecurityDept.PROPERTY_OPERATIONID, dsSharedDepartment.getColumnValues(PROP_COL_OPERATIONID, ";"));

        try {
            getActionProcessor().processAction(AddSDISecurityDept.ID, AddSDISecurityDept.VERSIONID, plAddSDISecurityDept);
        } catch (SapphireException ex) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().
                    translate(" Aborting transaction. Unable to copy Shared Security Department(s) - " +
                            dsSharedDepartment.getColumnValues(PROP_COL_SECURITY_DEPARTMENT, ";")));
        }
    }

}
