package labvantage.custom.alcon.ddt;

import sapphire.SapphireException;
import sapphire.action.BaseSDCRules;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * $Author $
 * $Date: 2022-04-20 01:26:41 +0530 (Wed, 20 Apr 2022) $
 * $Revision: 46 $
 */

/*******************************************************************
 * $Revision: 46 $
 * Description:
 * Jira ID: MDLIMS-21
 * This action is called from ResetMDApproval task.
 ************************************************************************/
public class QCBatchSampleType extends BaseSDCRules {
    //static final String DEVOPS_ID = "Sprint_4";
    public static final String DEVOPS_ID = "$Revision: 46 $";

    public boolean requiresBeforeEditImage() {
        return true;
    }

    @Override
    public void preEdit(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet primaryDs = sdiData.getDataset("primary");
        DataSet dsPrimaryCopy = new DataSet();
        for (int j = 0; j < primaryDs.size(); j++) {
            if (hasPrimaryValueChanged(primaryDs, j, "reagenttypeid")) {
                dsPrimaryCopy.copyRow(primaryDs, j, 1);
            }
        }
        if (dsPrimaryCopy != null && dsPrimaryCopy.size() > 0) {
            setCurrentVersion(dsPrimaryCopy, primaryDs);
        }

    }


    public void setCurrentVersion(DataSet dsPrimary, DataSet dsPrimaryOrg) throws SapphireException {
        if (dsPrimary.size() > 0) {
            HashMap hmFilter = new HashMap();
            hmFilter.put("reagenttypeversionid", "");
            DataSet dsFilterPrimary = dsPrimary.getFilteredDataSet(hmFilter);
            if (dsFilterPrimary != null & dsFilterPrimary.size() > 0) {
                String reagentTypeId = dsFilterPrimary.getColumnValues("reagenttypeid", ";");
                String sqlReagent = "select reagenttypeid,reagenttypeversionid,versionstatus from " +
                        "reagenttype where versionstatus in ('C','P') and " +
                        "reagenttypeid in ('" + StringUtil.replaceAll(reagentTypeId, ";", "','") + "')";
                DataSet dsCurrentRT = getQueryProcessor().getSqlDataSet(sqlReagent);
                if (dsCurrentRT != null & dsCurrentRT.size() > 0) {
                    for (int i = 0; i < dsFilterPrimary.getRowCount(); i++) {
                        hmFilter.clear();
                        hmFilter.put("reagenttypeid", dsFilterPrimary.getValue(i, "reagenttypeid", ""));
                        hmFilter.put("versionstatus", "C");
                        DataSet dsCurrentVersion = dsCurrentRT.getFilteredDataSet(hmFilter);
                        if (dsCurrentVersion != null && dsCurrentVersion.size() > 0) {
                            String versionId = dsCurrentVersion.getValue(0, "reagenttypeversionid", "");
                            hmFilter.clear();
                            hmFilter.put("s_qcbatchsampletypeid", dsFilterPrimary.getValue(i, "s_qcbatchsampletypeid", ""));
                            int row = dsPrimaryOrg.findRow(hmFilter);
                            if (row > -1) {
                                dsPrimaryOrg.setValue(row, "reagenttypeversionid", versionId);
                            }
                        } else {
                            hmFilter.clear();
                            hmFilter.put("reagenttypeid", dsFilterPrimary.getValue(i, "reagenttypeid", ""));
                            hmFilter.put("versionstatus", "P");
                            DataSet dsProvisionalVersion = dsCurrentRT.getFilteredDataSet(hmFilter);
                            if (dsProvisionalVersion != null && dsProvisionalVersion.size() > 0) {
                                dsProvisionalVersion.sort("reagenttypeversionid D");
                                String versionId = dsProvisionalVersion.getValue(0, "reagenttypeversionid", "");
                                hmFilter.clear();
                                hmFilter.put("s_qcbatchsampletypeid", dsFilterPrimary.getValue(i, "s_qcbatchsampletypeid", ""));
                                int row = dsPrimaryOrg.findRow(hmFilter);
                                if (row > -1) {
                                    dsPrimaryOrg.setValue(row, "reagenttypeversionid", versionId);
                                }
                            }

                        }
                    }
                }
            }
        }

    }
}
