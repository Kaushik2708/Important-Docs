package labvantage.custom.alcon.ddt;

import labvantage.custom.alcon.sap.action.SAPErrorHandler;
import labvantage.custom.alcon.sap.action.SAPLVInbound;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseSDCRules;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;
/**
 * $Author: GHOSHKA1 $
 * $Date: 2022-09-30 22:02:53 +0530 (Fri, 30 Sep 2022) $
 * $Revision: 166 $
 */

/********************************************************************************************************
 * $Revision: 166 $
 * Description: SDC rule for Transaction item.
 * This class is being called when trancation item table populated with SAP data
 *
 *******************************************************************************************************/
public class IntfTransItem extends BaseSDCRules {
    public static final String DEVOPS_ID = "$Revision: 166 $";

    public static final String PROPERTY_ERROR_FLAG = "errorflag";
    public static final String PROPERTY_COMPLETE_FLAG = "completeflag";

    public static final String TRANS_ITEM_STATUS_CREATED = "CREATED";
    public static final String TRANS_ITEM_STATUS_ERROR = "ERROR";
    public static final String TRANS_ITEM_STATUS_COMPLETE = "COMPLETE";
    public static final String TRANS_ITEM_STATUS_PENDING = "PENDING";
    public static final String PROP_TRANS_ITEM_COL_PENDING_LOT = "pendinglotflag";

    public static final String PROP_TRANS_ITEM_COL_STATUS = "status";

    public static final String PROP_TRANS_ITEM_COL_LIMSKEYVALUE = "limskeyvalue";

    public static final String PROP_TRANS_ITEM_COL_REPROCESS_DATE = "reprocessdate";
    public static final String PROP_TRANS_ITEM_COL_REPROCESS_COUNT = "reprocesscount";
    public static final String PROP_TRANS_ITEM_COL_ITEM_DATA = "itemdata";
    public static final String PROP_TRANS_ITEM_COL_ITEM_ID = "u_intftransitemid";

    public static final String PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "processassysuserid";
    private static final String __PROPS_VALUE_INVALID = "INVALID";
    public String VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "";

    @Override
    public void preAdd(SDIData sdiData, PropertyList actionProps) {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);

        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }
        //***** Checking if date format is valid or invalid *****
        if (__PROPS_VALUE_INVALID.equalsIgnoreCase(actionProps.getProperty(SAPLVInbound.__PROPS_VALID_OR_INVALID_DATE_FLAG))) {
            if (!dsPrimary.isValidColumn(SAPLVInbound.__PROPS_VALID_OR_INVALID_DATE_FLAG)) {
                dsPrimary.addColumn(SAPLVInbound.__PROPS_VALID_OR_INVALID_DATE_FLAG, DataSet.STRING);
            }
            if (!dsPrimary.isValidColumn(SAPLVInbound.__PROPS_ACTUAL_DATE)) {
                dsPrimary.addColumn(SAPLVInbound.__PROPS_ACTUAL_DATE, DataSet.STRING);
            }
            if (!dsPrimary.isValidColumn(SAPLVInbound.__PROPS_UD_DATETIME)) {
                dsPrimary.addColumn(SAPLVInbound.__PROPS_UD_DATETIME, DataSet.STRING);
            }
            dsPrimary.setValue(0, SAPLVInbound.__PROPS_VALID_OR_INVALID_DATE_FLAG, actionProps.getProperty(SAPLVInbound.__PROPS_VALID_OR_INVALID_DATE_FLAG));
            dsPrimary.setValue(0, SAPLVInbound.__PROPS_ACTUAL_DATE, actionProps.getProperty(SAPLVInbound.__PROPS_ACTUAL_DATE));
            dsPrimary.setValue(0, SAPLVInbound.__PROPS_UD_DATETIME, actionProps.getProperty(SAPLVInbound.__PROPS_UD_DATETIME));
        }

        VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = actionProps.getProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, "");

        callSAPProcessController(dsPrimary, "N");

    }

    @Override
    public void preDelete(String rsetid, PropertyList actionProps) throws SapphireException {
        cascadeDeleteTansItemError(actionProps);
    }

    /**
     * Delete the related the error table record(s) when deleting TransItem.
     *
     * @param actionProps
     * @throws SapphireException
     */
    private void cascadeDeleteTansItemError(PropertyList actionProps) throws SapphireException {
        if (actionProps == null || actionProps.size() == 0) {
            return;
        }
        String transItemIds = actionProps.getProperty("keyid1", "");
        //Purposefully running the raw SQL to speedup the code execution.
        String deleteSQL = "delete from u_intferror where intftransitemid in ('" + StringUtil.replaceAll(transItemIds, ";", "','") + "')";
        database.executeUpdate(deleteSQL);
    }

    /**
     * @return
     */
    public boolean requiresBeforeEditImage() {
        return true;
    }


    /**
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void preEdit(SDIData sdiData, PropertyList actionProps) {

        VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = actionProps.getProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, "");

        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        handleReprocessing(dsPrimary);


    }

    /***
     * Handles reprocessing of transaction item
     * @param dsPrimary
     * @throws SapphireException
     */
    private void handleReprocessing(DataSet dsPrimary) {

        String modifiedIntftransitemid = "";
        for (int i = 0; i < dsPrimary.size(); i++) {
            if (hasPrimaryValueChanged(dsPrimary, i, PROP_TRANS_ITEM_COL_REPROCESS_DATE)) {
                modifiedIntftransitemid += ";" + dsPrimary.getValue(i, PROP_TRANS_ITEM_COL_ITEM_ID, "");
            }
        }

        if (modifiedIntftransitemid.startsWith(";")) {
            modifiedIntftransitemid = modifiedIntftransitemid.substring(1);
        } else {
            return;
        }

        String sql = "select u_intftransitemid, itemdata from u_intftransitem where u_intftransitemid in ('" + StringUtil.replaceAll(modifiedIntftransitemid, ";", "','") + "')";
        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql, true);

        HashMap hmFilter;
        DataSet dsFilter;

        for (int i = 0; i < dsPrimary.size(); i++) {

            int reprocessCount = Integer.parseInt(getOldPrimaryValue(dsPrimary, i, PROP_TRANS_ITEM_COL_REPROCESS_COUNT).equals("") ? "0" : getOldPrimaryValue(dsPrimary, i, PROP_TRANS_ITEM_COL_REPROCESS_COUNT));
            reprocessCount++;

            if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_REPROCESS_COUNT)) {
                dsPrimary.addColumn(PROP_TRANS_ITEM_COL_REPROCESS_COUNT, DataSet.NUMBER);
            }
            dsPrimary.setNumber(i, PROP_TRANS_ITEM_COL_REPROCESS_COUNT, reprocessCount);


            String intftransitemid = dsPrimary.getValue(i, PROP_TRANS_ITEM_COL_ITEM_ID, "");
            hmFilter = new HashMap();
            hmFilter.put(PROP_TRANS_ITEM_COL_ITEM_ID, intftransitemid);

            dsFilter = getBeforeEditImage().getDataset(SDIData.PRIMARY).getFilteredDataSet(hmFilter);

            if (!dsFilter.isValidColumn(PROP_TRANS_ITEM_COL_ITEM_DATA)) {
                dsFilter.addColumn(PROP_TRANS_ITEM_COL_ITEM_DATA, DataSet.CLOB);
            }

            dsFilter.setClob(0, PROP_TRANS_ITEM_COL_ITEM_DATA, dsSql.getFilteredDataSet(hmFilter).getClob(0, PROP_TRANS_ITEM_COL_ITEM_DATA));
            callSAPProcessController(dsFilter, "Y");

            //Setting reporcessing status =COMPLETE
            if (dsFilter.getValue(0, PROP_TRANS_ITEM_COL_STATUS, "").equalsIgnoreCase(TRANS_ITEM_STATUS_COMPLETE)) {
                if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_STATUS)) {
                    dsPrimary.addColumn(PROP_TRANS_ITEM_COL_STATUS, DataSet.STRING);
                }
                dsPrimary.setValue(i, PROP_TRANS_ITEM_COL_STATUS, TRANS_ITEM_STATUS_COMPLETE);

                // Setting LIMS Batch Id
                if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_LIMSKEYVALUE)) {
                    dsPrimary.addColumn(PROP_TRANS_ITEM_COL_LIMSKEYVALUE, DataSet.STRING);
                }
                String limsBatchId = dsFilter.getValue(0, IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, "");
                dsPrimary.setValue(i, IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, limsBatchId);
                /**
                 * Uncommented by KG
                 * Below lines for BATCH CONSUMPTION
                 * Else the pending lot flag is not removed.
                 */

                // Checking the pendingLot flag to set it to N if already Y
                String pendingLotFlag = dsFilter.getValue(0, PROP_TRANS_ITEM_COL_PENDING_LOT, "");
                if ("Y".equalsIgnoreCase(pendingLotFlag)) {
                    if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_PENDING_LOT)) {
                        dsPrimary.addColumn(PROP_TRANS_ITEM_COL_PENDING_LOT, DataSet.STRING);
                    }
                    dsPrimary.setValue(i, PROP_TRANS_ITEM_COL_PENDING_LOT, "N");
                }
            }

            /**
             * Added by KG
             * Added While Batch Consumption
             * Reason: When there is an PENDING during reporcessing
             */
            //Setting reporcessing status =PENDING
            if (dsFilter.getValue(0, PROP_TRANS_ITEM_COL_STATUS, "").equalsIgnoreCase(TRANS_ITEM_STATUS_PENDING)) {
                if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_STATUS)) {
                    dsPrimary.addColumn(PROP_TRANS_ITEM_COL_STATUS, DataSet.STRING);
                }
                dsPrimary.setValue(i, PROP_TRANS_ITEM_COL_STATUS, TRANS_ITEM_STATUS_PENDING);

                // Setting LIMS Batch Id
                if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_LIMSKEYVALUE)) {
                    dsPrimary.addColumn(PROP_TRANS_ITEM_COL_LIMSKEYVALUE, DataSet.STRING);
                }
                String limsBatchId = dsFilter.getValue(0, IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, "");
                dsPrimary.setValue(i, IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, limsBatchId);
                // Checking the pendingLot flag to set it to N if already Y
                String pendingLotFlag = dsFilter.getValue(0, PROP_TRANS_ITEM_COL_PENDING_LOT, "");
                if ("Y".equalsIgnoreCase(pendingLotFlag)) {
                    if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_PENDING_LOT)) {
                        dsPrimary.addColumn(PROP_TRANS_ITEM_COL_PENDING_LOT, DataSet.STRING);
                    }
                    dsPrimary.setValue(i, PROP_TRANS_ITEM_COL_PENDING_LOT, "Y");
                }
            }
            /**
             * Added by KG
             * Added While Batch Consumption
             * Reason: When there is an ERROR during reporcessing, Transaction Item status is not updating
             * Below check is to confirm the status and set the value
             */
            //Setting reporcessing status =ERROR
            if (dsFilter.getValue(0, PROP_TRANS_ITEM_COL_STATUS, "").equalsIgnoreCase(TRANS_ITEM_STATUS_ERROR)) {
                if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_STATUS)) {
                    dsPrimary.addColumn(PROP_TRANS_ITEM_COL_STATUS, DataSet.STRING);
                }
                dsPrimary.setValue(i, PROP_TRANS_ITEM_COL_STATUS, TRANS_ITEM_STATUS_ERROR);

                // Setting LIMS Batch Id
                if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_LIMSKEYVALUE)) {
                    dsPrimary.addColumn(PROP_TRANS_ITEM_COL_LIMSKEYVALUE, DataSet.STRING);
                }
                String limsBatchId = dsFilter.getValue(0, IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, "");
                dsPrimary.setValue(i, IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, limsBatchId);
                // Checking the pendingLot flag to set it to N if already Y
                String pendingLotFlag = dsFilter.getValue(0, PROP_TRANS_ITEM_COL_PENDING_LOT, "");
                if ("Y".equalsIgnoreCase(pendingLotFlag)) {
                    if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_PENDING_LOT)) {
                        dsPrimary.addColumn(PROP_TRANS_ITEM_COL_PENDING_LOT, DataSet.STRING);
                    }
                    dsPrimary.setValue(i, PROP_TRANS_ITEM_COL_PENDING_LOT, "N");
                }
            }

        }


    }


    /***
     * Description: Calls Controller to process payload.
     * @param dsPrimary
     * @throws SapphireException
     */
    private void callSAPProcessController(DataSet dsPrimary, String reprocessingFlag) {

        PropertyList plTransItem = new PropertyList();

        for (int i = 0; i < dsPrimary.getRowCount(); i++) {
            //One Lot at a time
            String transId = dsPrimary.getValue(i, "intftransid", "");
            String transItemId = dsPrimary.getValue(i, "u_intftransitemid", "");
            String serviceName = dsPrimary.getValue(i, "transname", "");
            String itemData = dsPrimary.getValue(i, PROP_TRANS_ITEM_COL_ITEM_DATA, "");
            String plant = dsPrimary.getValue(i, "plant", "");
            String limskeyvalue = dsPrimary.getValue(i, PROP_TRANS_ITEM_COL_LIMSKEYVALUE, "");
            String validInvalidFlag = "";
            String actualDate = "";
            String manipulatedDate = "";
            if (dsPrimary.isValidColumn(SAPLVInbound.__PROPS_VALID_OR_INVALID_DATE_FLAG)) {
                validInvalidFlag = dsPrimary.getValue(i, SAPLVInbound.__PROPS_VALID_OR_INVALID_DATE_FLAG, "");
            }
            if (dsPrimary.isValidColumn(SAPLVInbound.__PROPS_ACTUAL_DATE)) {
                actualDate = dsPrimary.getValue(i, SAPLVInbound.__PROPS_ACTUAL_DATE, "");
            }
            if (dsPrimary.isValidColumn(SAPLVInbound.__PROPS_UD_DATETIME)) {
                manipulatedDate = dsPrimary.getValue(i, SAPLVInbound.__PROPS_UD_DATETIME, "");
            }

            if (serviceName == null || "".equals(serviceName) || itemData == null || "".equals(itemData)) {
                continue;
            }


            plTransItem.clear();
            plTransItem.setProperty("transid", transId);
            plTransItem.setProperty("transitemid", transItemId);
            plTransItem.setProperty("servicename", serviceName);
            plTransItem.setProperty(PROP_TRANS_ITEM_COL_ITEM_DATA, itemData);
            plTransItem.setProperty("plantid", plant);// plantid is the site id  (For Eg - U630, U636)
            plTransItem.setProperty("reprocessingflag", reprocessingFlag);// Reprocessing -Y or N
            plTransItem.setProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);
            plTransItem.setProperty(SAPLVInbound.__PROPS_VALID_OR_INVALID_DATE_FLAG, validInvalidFlag);
            plTransItem.setProperty(SAPLVInbound.__PROPS_ACTUAL_DATE, actualDate);
            plTransItem.setProperty(SAPLVInbound.__PROPS_UD_DATETIME, manipulatedDate);
            plTransItem.setProperty("errormsg", "");
            try {
                //As one Lot will be created at one time so calling action within the loop
                getActionProcessor().processAction("SAPProcessController", "1", plTransItem, true);

            } catch (SapphireException e) {
                String errormsg = e.getMessage();
                logger.error(errormsg);
                plTransItem.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, IntfTransItem.TRANS_ITEM_STATUS_ERROR);
                logSAPError(transId, transItemId, errormsg, serviceName);

            } catch (Exception e) {
                String errormsg = e.getMessage();
                logger.error(errormsg);
                plTransItem.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, IntfTransItem.TRANS_ITEM_STATUS_ERROR);
                logSAPError(transId, transItemId, errormsg, serviceName);
            }

            //Setting status in transItem table and update "pendinglotflag" with Y.

            String intfTransItemStatus = plTransItem.getProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, "");
            String limsBatchId = plTransItem.getProperty(IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, "");

            if (intfTransItemStatus.equalsIgnoreCase(TRANS_ITEM_STATUS_PENDING)) {
                if (!dsPrimary.isValidColumn("pendinglotflag")) {
                    dsPrimary.addColumn("pendinglotflag", DataSet.STRING);

                }
                dsPrimary.setValue(i, "pendinglotflag", "Y");
            }

            if (!dsPrimary.isValidColumn(PROP_TRANS_ITEM_COL_STATUS)) {
                dsPrimary.addColumn(PROP_TRANS_ITEM_COL_STATUS, DataSet.STRING);
            }
            dsPrimary.setValue(i, PROP_TRANS_ITEM_COL_STATUS, intfTransItemStatus);

            if (dsPrimary.getValue(i, PROP_TRANS_ITEM_COL_STATUS, "").equalsIgnoreCase(TRANS_ITEM_STATUS_ERROR)) {
                logSAPError(transId, transItemId, plTransItem.getProperty("errormsg"), serviceName);
            }

            if (!dsPrimary.isValidColumn(IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE)) {
                dsPrimary.addColumn(IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, DataSet.STRING);
            }
            dsPrimary.setValue(i, IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, limsBatchId);
            // Todo remove
            if (dsPrimary.isValidColumn(SAPLVInbound.__PROPS_VALID_OR_INVALID_DATE_FLAG)) {
                dsPrimary.removeColumn(SAPLVInbound.__PROPS_VALID_OR_INVALID_DATE_FLAG);
            }
            if (dsPrimary.isValidColumn(SAPLVInbound.__PROPS_ACTUAL_DATE)) {
                dsPrimary.removeColumn(SAPLVInbound.__PROPS_ACTUAL_DATE);
            }
            if (dsPrimary.isValidColumn(SAPLVInbound.__PROPS_UD_DATETIME)) {
                dsPrimary.removeColumn(SAPLVInbound.__PROPS_UD_DATETIME);
            }

        }
    }

    /***
     * Logs the SAP interfacing error or exceptions.
     * @param transId
     * @param transItemId
     * @param errormsg
     * @param serviceName
     */
    public void logSAPError(String transId, String transItemId, String errormsg, String serviceName) {

        logger.error("================================ intferrordesc In logSAPError ===========================");

        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "IntfError");
        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
        pl.setProperty("intftransid", transId);
        pl.setProperty("intftransitemid", transItemId);
        pl.setProperty("errormsg", errormsg);
        pl.setProperty("program", serviceName);
        try {
            getActionProcessor().processAction(SAPErrorHandler.ID, SAPErrorHandler.VERSIONID, pl);
            //getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl,true);

        } catch (SapphireException e) {
            String err = "Cannot process SAPErrorHandler. " + e.getMessage();
            logger.error(err);
        }
    }


}
