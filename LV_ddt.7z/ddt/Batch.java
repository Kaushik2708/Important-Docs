/*
 *  Copyright (c) 2000-2016 LabVantage Solutions, Inc.  All rights reserved.
 *
 *  No part of this work may be reproduced or distributed without the
 *  permission of LabVantage Solutions, Inc.
 *
 *  If you are not authorized by LabVantage to utilize this
 *  software and/or documentation, you must immediately discontinue any
 *  further use or viewing of this software and documentation.
 *  Violaters will be prosecuted to the fullest extent of the law by
 *  LabVantage Solutions, Inc.
 *
 *  Developed by LabVantage Solutions, Inc.
 *  265, Davidson Avenue, Suite 220
 *  Somerset, NJ, 08873
 */
package labvantage.custom.alcon.ddt;

import sapphire.SapphireException;
import sapphire.accessor.ConfigurationProcessor;
import sapphire.action.*;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.Calendar;

/***************************
 * Changed On : 05-Nov-2021
 * Change Description : When LIMS Batch is Received. If Received Date attributed is present, populate it with Received Date field Value.
 * Added By : Kaushik Ghosh
 **************************/

/*****************************************************************************************************
 * $Revision: 65 $
 * Batch Rule to calculate Retest Date, Expiry Date and to validate MES/SAP Batch
 *
 * @author Kaushik Ghosh
 * @version $Author: CHATTSA1 $
 * $Revision: 65 $
 * $Date: 2022-05-19 08:11:53 -0500 (Thu, 19 May 2022) $
 ******************************************************************************************************/
public class Batch extends BaseSDCRules {
    public static final String DEVOPS_ID = "$Revision: 65 $";

    public static final String COLUMN_BATCH_ID = "s_batchid";
    // While fixing problem concerning COA Report not working for FW because their
    //  manually entered expiry and retest dates on Batches were being blanked
    //  out (from here on out: <COA_FW_DATES_CHG> ) by this preexisting sdc rule written for ATL, i refactored the name
    //  of this variable from ...PRODUCTION_ID   to   ...PRODUCT_ID so it made
    //  more semantic sense.  - William Prochazka 15 Aug 2012
    public static final String COLUMN_BATCH_PRODUCT_ID = "productid";
    public static final String COLUMN_BATCH_RECEIVED_DT = "receiveddt";
    public static final String COLUMN_BATCH_STATUS = "batchstatus";
    public static final String COLUMN_BATCH_RETEST_DT = "u_retestdate";
    public static final String COLUMN_BATCH_EXPIRY_DT = "expirydt";
    public static final String COLUMN_BATCH_MESORDERORSAPBATCH_FIRST = "u_mesordersapbatch1";
    public static final String COLUMN_BATCH_MESORDERORSAPBATCH_SECOND = "u_mesordersapbatch2";
    public static final String COLUMN_BATCH_SECURITY_DEPARTMENT = "securitydepartment";
    public static final String COLUMN_BATCH_RECEIVEDBY = "receivedby";
    public static final String COLUMN_BATCH_SAPBATCHCREATEBY = "u_sapbatchcreateby";
    public static final String STATUS_BATCH_RECEIVED = "Received";
    public static final String STATUS_BATCH_CANCELLED = "Cancelled";
    private static final String COLUMN_BATCH_ISSAPFLAG = "u_issapflag";
    private static final String COLUMN_SDIATTRIBUTE_ATTRIBUTEID = "attributeid";
    private static final String COLUMN_SDIATTRIBUTE_KEYID1 = "keyid1";
    public static final String DEFAULT_SECURITY_USER = "AUTOMATION_SECURITY";
    private String strSource = "";
    private String strUsers = "";


    /**
     * @return
     */
    public boolean requiresBeforeEditImage() {
        return true;
    }


    /**
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void preEdit(SDIData sdiData, PropertyList actionProps) throws SapphireException {
/*        logger.info("Batch Rule : CVS Version (preEdit) " + LABVANTAGE_CVS_ID + " with small "
                + "ALCON Change related to method calculateReTestDate().  See <COA_FW_DATES_CHG> "
                + "notes in JAVA src file.  This change relates to the need to bypass the expiry "
                + "and retest date calculations on the Batch in some scenarios.");*/
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        if (!"Y".equals(actionProps.getProperty("__sdcruleignore", "N"))) {
            // Alcon FWN LIMS : Below Logic is for Alcon FWN Site for Batch Validation
            batchStatusValidation(dsPrimary);

        }

        deriveSAPBatchCreateBy(dsPrimary, actionProps);

    }

    private void setReceivedDtAttribute(DataSet dsPrimary) throws SapphireException {
        logger.debug("------------ Start ::: setReceivedDtAttribute --------------");

        //-------------- Identify rows that are meant for setReceivedAttribute --------------------//
        DataSet dsFinal = new DataSet((connectionInfo));
        for (int i = 0; i < dsPrimary.size(); i++) {
            if (hasPrimaryValueChanged(dsPrimary, i, COLUMN_BATCH_STATUS)
                    && (STATUS_BATCH_RECEIVED.equalsIgnoreCase(dsPrimary.getValue(i, COLUMN_BATCH_STATUS, "")))
                    && (!"".equals(dsPrimary.getValue(i, COLUMN_BATCH_RECEIVED_DT, ""))
                    && "Y".equalsIgnoreCase(getBeforeEditImage().getDataset("primary").getValue(i, COLUMN_BATCH_ISSAPFLAG, ""))
            )) {
                dsFinal.copyRow(dsPrimary, i, 1);
            }

        }
        if (dsFinal.size() == 0) {
            return;
        }

        // Checking and adding SAP Batch Column
        if (!dsFinal.isValidColumn(COLUMN_BATCH_ISSAPFLAG)) {
            dsFinal.addColumn(COLUMN_BATCH_ISSAPFLAG, DataSet.STRING);
            dsFinal.setValue(-1, COLUMN_BATCH_ISSAPFLAG, "Y");
        }

        //---------------------------------------------------------------------------------------------------------------------------//

        // Getting attribute details of all LIMS Batch
        DataSet dsSDIAttribute = getBatchAttributeIds(dsFinal.getColumnValues(COLUMN_BATCH_ID, ";"));

        // Attribute exits for a Batch
        if (dsSDIAttribute.size() == 0) {
            return;
        }

        PropertyList plFilter = new PropertyList();
        // Looping each LIMS Batch
        for (int batchCount = 0; batchCount < dsFinal.size(); batchCount++) {
            plFilter.clear();
            // SAP Batch and Batch status is Received
            plFilter.setProperty(COLUMN_SDIATTRIBUTE_KEYID1, dsFinal.getValue(batchCount, COLUMN_BATCH_ID, ""));
            plFilter.setProperty(COLUMN_SDIATTRIBUTE_ATTRIBUTEID, "Received_DT");

            // Checking if received date attribute exists for Batch
            if (dsSDIAttribute.findRow(plFilter) != -1) {
                // Setting attribute
                setReceivedDateAttribute(dsFinal.getValue(batchCount, COLUMN_BATCH_ID), "Received_DT", dsFinal.getValue(batchCount, COLUMN_BATCH_RECEIVED_DT));
            }

        }


        logger.debug("------------ End ::: setReceivedDtAttribute --------------");
    }

    /***************************************************************
     * This method is used to edit and set the ReceivedDate attribute.
     *
     * @param batchId  LIMS Batch ID.
     * @param attributeId Batch Attribute Id.
     * @param attributeValue Batch attribute value.
     * @throws SapphireException Throws OOB Sapphire exception.
     ****************************************************************/
    private void setReceivedDateAttribute(String batchId, String attributeId, String attributeValue) throws SapphireException {
        logger.debug("Processing  setReceivedDateAttribute (method)");
        PropertyList plEditAttr = new PropertyList();
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_SDCID, "Batch");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_KEYID1, batchId);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTEID, attributeId);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTEINSTANCE, "1");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTESDCID, "Batch");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_VALUE, attributeValue);

        try {
            getActionProcessor().processAction(EditSDIAttribute.ID, EditSDIAttribute.VERSIONID, plEditAttr);
        } catch (SapphireException ex) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Unable to execute EditSDIAttribute. Please contact your system adminstration."));
        }
    }

    /********************************************************
     * This method is used to get attribute details of Batch.
     * @param limsBatchId
     * @return
     * @throws SapphireException
     ********************************************************/
    private DataSet getBatchAttributeIds(String limsBatchId) throws SapphireException {
        String sqlText = "SELECT keyid1, attributeid FROM sdiattribute WHERE sdcid = 'Batch' AND keyid1 IN('" + limsBatchId.replaceAll(";", "','") + "') AND keyid2 = '(null)' AND keyid3 = '(null)'";
        DataSet dsAttributeIds = getQueryProcessor().getSqlDataSet(sqlText);
        if (null == dsAttributeIds) {
            throw new SapphireException("General Error:::", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Null DataSet Blank."));
        }
        return dsAttributeIds;
    }

    /***********************************************
     * This method is used to get SAP Flag for Batch
     * @param limsBatchIDs
     * @return
     * @throws SapphireException
     ************************************************/
    private String isSAPBatch(String limsBatchIDs) throws SapphireException {
        logger.debug("------------ Start ::: isSAPBatch --------------");
        String sapBatchFlag = "";
        String sqlText = "SELECT " + COLUMN_BATCH_ISSAPFLAG + " FROM s_batch WHERE s_batchid IN('" + limsBatchIDs.replaceAll(";", "','") + "') ";
        DataSet dsISSAPBatch = getQueryProcessor().getSqlDataSet(sqlText);
        if (null == dsISSAPBatch) {
            throw new SapphireException("General Error:::", ErrorDetail.TYPE_FAILURE, "SQL Error: Unable to execute query. Query is \n" + sqlText);
        }
        if (dsISSAPBatch.getRowCount() > 0) {
            sapBatchFlag = dsISSAPBatch.getColumnValues(COLUMN_BATCH_ISSAPFLAG, ";");
        }
        logger.debug("------------ End ::: isSAPBatch --------------");
        return sapBatchFlag;
    }


    /**
     * @param dsPrimary
     * @param actionProps
     * @throws SapphireException
     */
    private void copyTemporaryVendorBatchNumberOnReceive(DataSet dsPrimary, PropertyList actionProps) {


    }

    /**
     * @param dsPrimary
     * @param actionProps
     * @throws SapphireException
     */
    private void deriveSAPBatchCreateBy(DataSet dsPrimary, PropertyList actionProps) {

        for (int inRow = 0; inRow < dsPrimary.size(); inRow++) {
            if (hasPrimaryValueChanged(dsPrimary, inRow, COLUMN_BATCH_STATUS)
                    && STATUS_BATCH_RECEIVED.equalsIgnoreCase(dsPrimary.getValue(inRow, COLUMN_BATCH_STATUS, ""))) {

                if ("(system)".equalsIgnoreCase(connectionInfo.getSysuserId())) {

                    if (!dsPrimary.isValidColumn(COLUMN_BATCH_RECEIVEDBY)) {
                        dsPrimary.addColumn(COLUMN_BATCH_RECEIVEDBY, DataSet.STRING);
                    }

                    dsPrimary.setValue(inRow, COLUMN_BATCH_RECEIVEDBY, getOldPrimaryValue(dsPrimary, inRow, COLUMN_BATCH_SAPBATCHCREATEBY));

                }
            }
        }

    }

    /**
     * Below Logic is for Alcon FWN Site for Batch Validation
     *
     * @param dsPrimary
     * @throws SapphireException
     */
    private void batchStatusValidation(DataSet dsPrimary) throws SapphireException {
        if (dsPrimary.isValidColumn("batchstatus")) {
            for (int inRow = 0; inRow < dsPrimary.getRowCount(); inRow++) {
                if (dsPrimary.getValue(inRow, "batchstatus").equalsIgnoreCase("OnHold")) {
                    if ((dsPrimary.getValue(inRow, "batchstatus", "").equals(getOldPrimaryValue(dsPrimary, inRow, "batchstatus")))) {
                        // Throw Exception Now
                        throw new SapphireException("On Hold batches cannot be edited");
                    }
                }
            }
        }
    }


    @Override
    public void preAdd(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet primary = sdiData.getDataset(SDIData.PRIMARY);
        if (null == primary || primary.getRowCount() == 0) {
            return;
        }

        //Validates and Updates Security User where the value is empty
        validateAndUpdateSecurityUser(DEFAULT_SECURITY_USER, primary);

        //Check existance of MES Order/SAP Batch existance
        checkUniquenessOfMESOrderOrSAPBatchInfo(primary, "add");

        if (primary.getRowCount() == 1) {
            // Alcon FWN LIMS : Child Parent Batch Relation
            // DEVOPS: Business does not want this feature any more. Change applied with SAP-LIMS Phase 2
//            childParentBatchRelation(primary, "PRE");
        }
    }

    /**
     *
     * @param securityUser
     * @param dsPrimary
     * @return void
     * @throws SapphireException
     */
    private void validateAndUpdateSecurityUser(String securityUser, DataSet dsPrimary) throws SapphireException {
        for(int i = 0; i < dsPrimary.size(); i++) {
            if(!dsPrimary.isValidColumn("securityuser")) {
                dsPrimary.addColumn("securityuser", DataSet.STRING);
            }
            if(dsPrimary.getValue(i, "securityuser", "").equalsIgnoreCase("")) {
                dsPrimary.setValue(i, "securityuser", securityUser);
            }
        }
    }

    @Override
    public void postAdd(SDIData sdiData, PropertyList actionProps) {
        DataSet primary = sdiData.getDataset(SDIData.PRIMARY);
        if (null == primary || primary.getRowCount() == 0) {
            return;
        }
        if (primary.getRowCount() == 1) {
            // Alcon FWN LIMS : Child Parent Batch Relation
            // DEVOPS: Business does not want this feature any more. Change applied with SAP-LIMS Phase 2
//            childParentBatchRelation(primary, "POST");
        }
    }


    /**
     * Alcon FWN LIMS : Child Parent Batch Relation
     *
     * @param primary
     * @param strMode
     * @throws SapphireException
     */
    private void childParentBatchRelation(DataSet primary, String strMode) throws SapphireException {
        PropertyList policyHolder = new ConfigurationProcessor(getConnectionid()).getPolicy("BatchReducedLevelTesting", "setValues");
        String strMonth = policyHolder.getProperty("month", "");
        String strLevel = policyHolder.getProperty("batchlevel", "");
        if (strMonth.equalsIgnoreCase("") || strLevel.equalsIgnoreCase("")) {
            logger.info("Batch Rule : postAdd : BatchLotProgramDateRange :  Month/Level Cannot be Blank..!");
            logger.error("Batch Rule : postAdd : BatchLotProgramDateRange : Month/Level is Blank..!");
            return;
        }

        String strQry = "select s_batchid,batchdesc,batchstatus,productid,productversionid,batchtype from s_batch where batchstatus not in ('Cancelled','Rejected')\n" +
                " and\n" +
                " createdt >= add_months(sysdate, -" + strMonth + ") \n" +
                " and s_batchid not in (select parentbatchid from s_batchgenealogy) \n" +
                " and productid= ? and prodvariantlotreference = ? and s_batchid not in ('" + primary.getValue(0, "s_batchid") + "') ";

        DataSet dsBatchID = getQueryProcessor().getPreparedSqlDataSet(strQry, new Object[]{primary.getValue(0, "productid"), primary.getValue(0, "prodvariantlotreference")});
        if (dsBatchID == null) {
            throw new SapphireException("Batch Rule : postAdd : dsBatchID : Unable to retrieve Data.\n Please contact System Administrator..!");
        }
        logger.info("Batch Rule : postAdd : dsBatchID : " + dsBatchID.toJSONString());
        if (dsBatchID.getRowCount() > 0 && strMode.equalsIgnoreCase("POST")) {
            PropertyList plAddSDIDetails = new PropertyList();
            plAddSDIDetails.setProperty(AddSDIDetail.PROPERTY_LINKID, "batch genealogy");
            plAddSDIDetails.setProperty(AddSDIDetail.PROPERTY_SDCID, "Batch");
            plAddSDIDetails.setProperty("batchtype", dsBatchID.getColumnValues("batchtype", ";"));
            plAddSDIDetails.setProperty("batchstage", dsBatchID.getColumnValues("batchstage", ";"));
            plAddSDIDetails.setProperty("parentbatchid", dsBatchID.getColumnValues("s_batchid", ";"));
            plAddSDIDetails.setProperty("s_batchid", StringUtil.repeat(primary.getValue(0, "s_batchid"), dsBatchID.getRowCount(), ";"));
            plAddSDIDetails.setProperty("propsmatch", "Y");
            plAddSDIDetails.setProperty("batchdesc", dsBatchID.getColumnValues("batchdesc", ";"));
            plAddSDIDetails.setProperty("copies", String.valueOf(dsBatchID.getRowCount()));
            plAddSDIDetails.setProperty("parentproductid", dsBatchID.getColumnValues("productid", ";"));
            plAddSDIDetails.setProperty("parentproductversionid", dsBatchID.getColumnValues("productversionid", ";"));

            try {
                logger.info("Batch Rule : postAdd : plAddSDIDetails : " + plAddSDIDetails.toJSONString());
                getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, plAddSDIDetails);
            } catch (SapphireException se) {
                throw new SapphireException("Error in AddSDIDetail " + se.getMessage());
            }
        } else if (dsBatchID.getRowCount() > 0 && strMode.equalsIgnoreCase("PRE")) {
            if (!primary.isValidColumn("levelid")) {
                primary.addColumn("levelid", DataSet.STRING);
            }
            primary.setValue(0, "levelid", strLevel);
        }
    }

    @Override
    public void postEdit(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }
        // This method is used to set Received Date attribute
        setReceivedDtAttribute(dsPrimary);
        // This method is used to calculate the Sample must date based on Sample Due Date & Longest Test Days present in Product
        calculateReTestDate(dsPrimary);
        //Check existance of MES Order/SAP Batch existance
        //checkUniquenessOfMESOrderOrSAPBatchInfo(dsPrimary, "edit");
    }


    /**
     * This method is used to calculate the Sample must date based on Sample Due Date & Longest Test Days present in Product
     *
     * @param dsPrimary : primary dataset
     * @throws SapphireException
     */
    private void calculateReTestDate(DataSet dsPrimary) throws SapphireException {

        DataSet dsBatchInformation = new DataSet();
        dsBatchInformation.addColumn("batchid", DataSet.STRING);
        dsBatchInformation.addColumn("productid", DataSet.STRING);
        // <COA_FW_DATES_CHG> modification
        String calcNotRequiredFlag = "N";
        //dsBatchInformation.addColumn( "releaseddt", DataSet.STRING );

        for (int i = 0; i < dsPrimary.getRowCount(); i++) {
            if (!dsPrimary.isNull(i, COLUMN_BATCH_STATUS) && hasPrimaryValueChanged(dsPrimary, i, COLUMN_BATCH_STATUS) && dsPrimary.getValue(i, COLUMN_BATCH_STATUS, "").equalsIgnoreCase("Released")) {
                int row = dsBatchInformation.addRow();
                // <COA_FW_DATES_CHG> modification
                dsBatchInformation.setValue(row, "batchid", dsPrimary.getValue(i, COLUMN_BATCH_ID, ""));
                dsBatchInformation.setValue(row, "productid", dsPrimary.getValue(i, COLUMN_BATCH_PRODUCT_ID, ""));
                //     dsBatchInformation.setValue( row, "releaseddt", dsPrimary.getValue( i, COLUMN_BATCH_RELEASE_DT, "" ) );
            }
        }

        if (dsBatchInformation.size() > 0) {
            String strGetRetestAndExpiryDates = new StringBuilder("select SB.releaseddt,SR.SECURITYDEPARTMENT,SR.U_RETESTDAYS,SR.U_EXPIRYDAYS,SB.S_BATCHID batchid,NVL(to_char((SB.releaseddt+SR.U_RETESTDAYS), 'DD-MM-YYYY'), '0') retestdate,NVL(to_char((SB.releaseddt+SR.U_EXPIRYDAYS), 'DD-MM-YYYY'), '0') expirydate  from S_BATCH SB, S_PRODUCT SR where  SB.S_BATCHID IN ('" + dsBatchInformation.getColumnValues("batchid", "','") + "') AND SB.PRODUCTID=SR.S_PRODUCTID ").toString();
            DataSet dsGetRetestAndExpiryDates = getQueryProcessor().getSqlDataSet(strGetRetestAndExpiryDates);
            if (null == dsGetRetestAndExpiryDates) {
                throw new SapphireException("Incorrect SQL Query");
            }
            // Modified for VT Issue Alcon 06651-00061
            DataSet dsRefined = new DataSet();
            dsRefined.addColumn("batchid", DataSet.STRING);
            dsRefined.addColumn("retestdate", DataSet.DATE);
            dsRefined.addColumn("expirydate", DataSet.DATE);
            for (int i = 0; i < dsGetRetestAndExpiryDates.size(); i++) {

                // <COA_FW_DATES_CHG> modification - START
                String sec_dept = dsGetRetestAndExpiryDates.getValue(i, "SECURITYDEPARTMENT");
                logger.info("WKP sec_dept : " + sec_dept);

                String strGetCalcNotRequiredFlag_sql = new StringBuilder(
                        "SELECT u_calcofdatesnotrequired FROM Department "
                                + "WHERE departmentid='" + sec_dept + "'").toString();
                logger.info("BATCH.JAVA SDC RULE: strGetCalcNotRequiredFlag_sql : " + strGetCalcNotRequiredFlag_sql);
                DataSet dsGetCalcNotRequiredFlag = getQueryProcessor().getSqlDataSet(strGetCalcNotRequiredFlag_sql);
                calcNotRequiredFlag = dsGetCalcNotRequiredFlag.getValue(0, "u_calcofdatesnotrequired");
                logger.info("BATCH.JAVA SDC RULE: calcNotRequiredFlag : " + calcNotRequiredFlag);
                if (!calcNotRequiredFlag.equals("Y")) {
                    logger.info("BATCH.JAVA SDC RULE: Flag on Department related to Batch's Product's Department was not 'Y', "
                            + "so original ATL code runs determining what expiry and retest dates get set to:  "
                            + "calcNotRequiredFlag: " + calcNotRequiredFlag);
                    Calendar calRetest, calExpirary;
                    calRetest = Calendar.getInstance();
                    calExpirary = Calendar.getInstance();
                    // Modified for VT Issue Alcon 06651-00061
                    int row = dsRefined.addRow();
                    if (!dsGetRetestAndExpiryDates.getValue(i, "u_retestdays").equalsIgnoreCase("0") && !dsGetRetestAndExpiryDates.getValue(i, "u_retestdays").equals("")) {
                        calRetest.add(Calendar.DAY_OF_MONTH, Integer.valueOf(dsGetRetestAndExpiryDates.getValue(i, "u_retestdays")));
                        dsRefined.setDate(row, "retestdate", calRetest);
                    } else {
                        dsRefined.setDate(row, "retestdate", "(null)");
                    }

                    if (!dsGetRetestAndExpiryDates.getValue(i, "u_expirydays").equalsIgnoreCase("0") && !dsGetRetestAndExpiryDates.getValue(i, "u_expirydays").equals("")) {
                        calExpirary.add(Calendar.DAY_OF_MONTH, Integer.valueOf(dsGetRetestAndExpiryDates.getValue(i, "u_expirydays")));
                        dsRefined.setDate(row, "expirydate", calExpirary);
                    } else {
                        dsRefined.setDate(row, "expirydate", "(null)");
                    }
                    dsRefined.setValue(row, "batchid", dsGetRetestAndExpiryDates.getValue(i, "batchid", ""));
                } else {
                    logger.info("BATCH.JAVA SDC RULE: Flag on Department related to Batch's Product's Department was 'Y', "
                            + "so original ATL code determining what expiry and retest dates get set to will NOT run "
                            + "and manually entered dates on the Batch will be maintained.");
                }
            }

            if (!calcNotRequiredFlag.equals("Y")) {
                logger.info("BATCH.JAVA SDC RULE: Flag on Department related to Batch's Product's Department was not 'Y', "
                        + "so original ATL code runs determining what expiry and retest dates get set to:  "
                        + "EditSDI() called.");

                PropertyList plEditSDI = new PropertyList();
                plEditSDI.setProperty(EditSDI.PROPERTY_SDCID, "Batch");
                plEditSDI.setProperty(EditSDI.PROPERTY_KEYID1, dsRefined.getColumnValues("batchid", ";"));
                plEditSDI.setProperty(COLUMN_BATCH_RETEST_DT, dsRefined.getColumnValues("retestdate", ";"));
                plEditSDI.setProperty(COLUMN_BATCH_EXPIRY_DT, dsRefined.getColumnValues("expirydate", ";"));
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plEditSDI);
                } catch (SapphireException se) {
                    throw new SapphireException("Error in EditSDI " + se.getMessage());
                }
            }
        }
    }
    // <COA_FW_DATES_CHG> modification - END

    /**
     * This method will check uniqueness of MES Order/SAP Batch during Batch Creation and Edit operation
     * Alcon 06651-00124
     * New Requirement: change "uniqueness" logic  in the Batch Login page- from a unique MES/SAP Batch # to unique combination of Product ID# and MES/SAP Batch #
     *
     * @param primary : primary DataSet
     * @param mode    : from which function it is called i.e., from preAdd or postEdit
     * @throws SapphireException
     */
    private void checkUniquenessOfMESOrderOrSAPBatchInfo(DataSet primary, String mode) throws SapphireException {

        if ("add".equalsIgnoreCase(mode)) {
            if (primary.isValidColumn(COLUMN_BATCH_MESORDERORSAPBATCH_FIRST) || primary.isValidColumn(COLUMN_BATCH_MESORDERORSAPBATCH_SECOND)) {
                //***** Validation for security department & Product added for MDLIMS 1157
                if (primary.isValidColumn(COLUMN_BATCH_SECURITY_DEPARTMENT) && primary.isValidColumn(COLUMN_BATCH_PRODUCT_ID)) {
                    // ********** Checking if security department is BLANK
                    String securityDept = primary.getValue(0, COLUMN_BATCH_SECURITY_DEPARTMENT, "");
                    if ("".equalsIgnoreCase(securityDept)) {
                        return;
                    }
                    String productId = primary.getValue(0, COLUMN_BATCH_PRODUCT_ID, "");
                    // ********** Checking if Product Id is BLANK
                    if ("".equalsIgnoreCase(productId)) {
                        return;
                    }
                    // ********** Get the MES Order Restriction of Department
                    String isRestricted = "";
                    String sqlMESOrderRestriction = " SELECT u_mesorderrestriction FROM department WHERE departmentid = ? ";
                    DataSet dsMESOrderRestriction = getQueryProcessor().getPreparedSqlDataSet(sqlMESOrderRestriction, new Object[]{securityDept});
                    if (null == dsMESOrderRestriction) {
                        throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Aborting transaction .Incorrect SQL statement found. SQL is \n" + sqlMESOrderRestriction));
                    } else {
                        isRestricted = dsMESOrderRestriction.getValue(0, "u_mesorderrestriction", "N");
                    }
                    String mesOrderSAPBatchNo = "";
                    // Check if Restricted department
                    if ("Y".equalsIgnoreCase(isRestricted)) {
                        // Checking if MES Order / SAP Batch 1 field is BLANK
                        if ("".equalsIgnoreCase(primary.getValue(0, COLUMN_BATCH_MESORDERORSAPBATCH_FIRST, ""))) {
                            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Aborting transaction. MES Order/SAP Batch # can't be BLANK."));
                        } else {
                            mesOrderSAPBatchNo = primary.getValue(0, COLUMN_BATCH_MESORDERORSAPBATCH_FIRST, "");
                        }

                        // Getting all Existing LIMS Batch details by matching MES Order / SAP Batch # + Product Id + Security Department combination
                        String sqlBatch = " SELECT s_batchid,batchstatus,createdt FROM s_batch WHERE u_mesordersapbatch1 = ? AND productid = ? AND securitydepartment = ?  ";
                        DataSet dsExistingBatch = getQueryProcessor().getPreparedSqlDataSet(sqlBatch, new Object[]{mesOrderSAPBatchNo, productId, securityDept});
                        if (null == dsExistingBatch) {
                            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Aborting transaction .Incorrect SQL statement found. SQL is \n" + sqlBatch));
                        } else if (dsExistingBatch.getRowCount() == 0) {
                            //indicates that no batch exists with dupilicate mesorder no.
                            return;
                        }

                        PropertyList plFilter = new PropertyList();
                        plFilter.setProperty(COLUMN_BATCH_STATUS, STATUS_BATCH_CANCELLED);
                        // DataSet other than Cancelled LIMS Batch
                        DataSet dsRestrictedBatch = dsExistingBatch.getFilteredDataSet(plFilter, true);
                        if (dsRestrictedBatch.size() > 0) {
                            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. MES Order/SAP Batch " + mesOrderSAPBatchNo + " is already used in other LIMS batch."));
                        }
                    }

                }
            }
        }
    }

    /**
     * This method will send Bulletin to users defined in Policy if MES/SAP Batch already exists in the system during manual batch creation.
     *
     * @param sDescription : Subject
     * @param sBody        : Body
     * @throws SapphireException
     */
    private void sendCustomSendBulletin(String sDescription, String sBody) throws SapphireException {

        getBulletinInformation();
        PropertyList plSendBulletin = new PropertyList();
        plSendBulletin.setProperty(SendBulletin.PROPERTY_USER, strUsers);
        plSendBulletin.setProperty(SendBulletin.PROPERTY_DESCRIPTION, sDescription);
        plSendBulletin.setProperty(SendBulletin.PROPERTY_BODY, sBody);
        plSendBulletin.setProperty(SendBulletin.PROPERTY_SOURCE, strSource);

        logger.info("Action: SUCCESS SendBulletin: " + plSendBulletin.toJSONString());
        getActionProcessor().processAction(SendBulletin.ID, SendBulletin.VERSIONID, plSendBulletin, true);
        logger.info("Action: Action Completed with SUCCESS.");
    }

    /**
     * This method fetch from user and to usres list for sending Bulletin.
     *
     * @throws SapphireException
     */
    private void getBulletinInformation() throws SapphireException {
        try {
            PropertyList policyHolder = new ConfigurationProcessor(getConnectionid()).getPolicy("UserToNotifyUsingBulletin", "notifyusers");
            strSource = policyHolder.getProperty("source");
            int sizeOfPolicy = policyHolder.getCollection("users").size();
            for (int i = 0; i < sizeOfPolicy; i++) {
                strUsers = strUsers + ";" + policyHolder.getCollection("users").getPropertyList(i).getProperty("userlist", "");
            }
            if (strUsers.length() > 0) strUsers = strUsers.substring(1, strUsers.length());
        } catch (Exception err) {
            throw new SapphireException(err.getMessage().toString());
        }
    }
}
