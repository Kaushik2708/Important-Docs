package labvantage.custom.alcon.ddt;

import sapphire.SapphireException;
import sapphire.action.BaseSDCRules;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.Calendar;

/**
 * $Author: BAGCHAN1 $
 * $Date: 2022-02-08 00:16:36 -0500 (Tue, 08 Feb 2022) $
 * $Revision: 13 $
 */

public class LV_ReagentLot extends BaseSDCRules {
    public static final String DEVOPS_ID = "$Revision: 13 $";

    @Override
    public void postEdit(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);

        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }

        handleContainerExpiryDate(dsPrimary);

    }

    /**
     * Description: This method is used to convert the string to uppercase
     *
     * @param dsPrimary
     */
    public void handleContainerExpiryDate(DataSet dsPrimary) throws SapphireException {

        String validLot = "";
        for (int i = 0; i < dsPrimary.size(); i++) {
            if (hasPrimaryValueChanged(dsPrimary, i, "expirydt")
                    ) {
                validLot += ";" + dsPrimary.getValue(i, "reagentlotid", "");
            }
        }

        if ("".equals(validLot)) {
            return;
        }

        validLot = validLot.substring(1);

        String sql = "select rl.REAGENTLOTID, t.TRACKITEMID, rl.EXPIRYDT LOTEXPIRYDT, t.U_OPENDATE,  rt.U_CONTAINEREXPIRYPERIOD, rt.U_CONTAINEREXPIRYPERIODUNIT" +
                " from TRACKITEM t, REAGENTLOT rl, REAGENTTYPE rt  " +
                " where " +
                " rl.REAGENTTYPEID=rt.REAGENTTYPEID and rl.REAGENTTYPEVERSIONID=rt.REAGENTTYPEVERSIONID" +
                " and t.LINKSDCID = 'LV_ReagentLot' and t.LINKKEYID1 = rl.REAGENTLOTID" +
                " and ( t.trackitemstatus <> 'Expired'  OR t.trackitemstatus is null) " +
                " and rl.REAGENTLOTID in ('" + StringUtil.replaceAll(validLot, ";", "','") + "')";

        DataSet dsSql = getQueryProcessor().getSqlDataSet(sql);

        if (dsSql == null) {
            throw new SapphireException("General error", ErrorDetail.TYPE_FAILURE, "Error while querying Container table.");
        }

        if (dsSql.size() == 0) {
            return;
        }

        dsSql.addColumn("calcexpirydt", DataSet.DATE);

        for (int i = 0; i < dsSql.size(); i++) {
            dsSql.setDate(i, "calcexpirydt", getExpiryDate(dsSql.getCalendar(i, "lotexpirydt")
                    , dsSql.getCalendar(i, "u_opendate")
                    , Integer.parseInt(dsSql.getValue(i, "u_containerexpiryperiod", "0"))
                    , dsSql.getValue(i, "u_containerexpiryperiodunit", "")));
        }

        PropertyList pl = new PropertyList();
        pl.setProperty("sdcid", "TrackItemSDC");
        pl.setProperty("keyid1", dsSql.getColumnValues("trackitemid", ";"));
        pl.setProperty("expirydt", dsSql.getColumnValues("calcexpirydt", ";"));

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);


    }

    /************
     * This method calculates expiry date = Open Date + (Container offset / Unit), max'ed out at Lot Expiry Date
     * @param openDt
     * @param containerExpiryPeriod
     * @param containerExpiryPeriodUnit
     * @return
     * @throws SapphireException
     ************/
    private Calendar getExpiryDate(Calendar lotExpiryDt, Calendar openDt, int containerExpiryPeriod, String containerExpiryPeriodUnit) throws SapphireException {

        Calendar finalDt;

        if (openDt == null || "".equals(containerExpiryPeriod) || "".equals(containerExpiryPeriodUnit)) {
            finalDt = lotExpiryDt;
        } else {

            Calendar modOpenDt = (Calendar) openDt.clone();
            if (containerExpiryPeriodUnit.equalsIgnoreCase("Days")) {
                modOpenDt.add(Calendar.DATE, containerExpiryPeriod);
            } else if (containerExpiryPeriodUnit.equalsIgnoreCase("Months")) {
                modOpenDt.add(Calendar.MONTH, containerExpiryPeriod);
            } else if (containerExpiryPeriodUnit.equalsIgnoreCase("Years")) {
                modOpenDt.add(Calendar.YEAR, containerExpiryPeriod);
            } else if (containerExpiryPeriodUnit.equalsIgnoreCase("Hours")) {
                modOpenDt.add(Calendar.HOUR, containerExpiryPeriod);
            }


            if (lotExpiryDt == null && openDt != null) {
                finalDt = modOpenDt;
            } else if (modOpenDt.compareTo(lotExpiryDt) == 1) {
                finalDt = lotExpiryDt;
            } else {
                finalDt = modOpenDt;
            }
        }

        return finalDt;
    }


    @Override
    public boolean requiresBeforeEditImage() {
        return true;
    }
}
