package labvantage.custom.alcon.ddt;


/**
 * $Author: DIANAR1 $
 * $Date: 2022-11-15 18:51:11 +0530 (Tue, 15 Nov 2022) $
 * $Revision: 317 $
 */

import labvantage.custom.alcon.mes.action.MESErrorHandler;
import labvantage.custom.alcon.mes.action.OpcenterMESLVOutbound;
import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseSDCRules;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.util.SafeSQL;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/********************************************************************************************************
 * $Revision: 317 $
 * Description: SDC rule for Transaction item.
 * This class is being called when transaction table populated with MES data
 *
 *******************************************************************************************************/
public class MESIntfTrans extends BaseSDCRules {
    public static final String DEVOPS_ID = "$Revision: 317 $";
    public static final String PROP_MES_TRANS_ITEM_COL_REPROCESS_DATE = "reprocessdate";
    public static final String PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT = "reprocesscount";
    public static final String PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD = "msgpayload";
    public static final String __PROP_MES_TRANS_ITEM_COL_ITEM_ID = "u_mesintftransid";
    public static final String __PROP_REPROCESSING_FLAG = "reprocessingflag";
    public static final String __PROP_SDC_MES_INTF_ERROR = "MESIntfError";
    public static final String __PROP_MES_INTFTRANS_ID = "mesintftransid";
    public static final String __PROP_ERROR_MESSAGE = "errormsg";
    public static final String __PROP_PROGRAM = "program";
    public static final String __PROP_SERVICE_NAME = "servicename";

    public static final String __PROP_STATUS = "status";
    private static final String __PROP_CREATEBY = "createby";
    private static final String MES_TRANS_ITEM_STATUS_ERROR = "ERROR";


    @Override
    public void preDelete(String rsetid, PropertyList actionProps) throws SapphireException {
        cascadeDeleteMESTransError(actionProps);
    }

    /**
     * Delete the related the error table record(s) when deleting IntfTrans records.
     *
     * @param actionProps
     * @throws SapphireException
     */
    private void cascadeDeleteMESTransError(PropertyList actionProps) throws SapphireException {
        if (actionProps == null || actionProps.size() == 0) {
            return;
        }
        String transIds = actionProps.getProperty("keyid1", "");

        //Purposefully running the raw SQL to speedup the code execution.
        String deleteSQL = "delete from u_mesintferror where mesintftransid in ('" + StringUtil.replaceAll(transIds, ";", "','") + "')";
        database.executeUpdate(deleteSQL);
    }


    /**
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void preEdit(SDIData sdiData, PropertyList actionProps) {

        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        try {
            if (dsPrimary.size() == 1 && dsPrimary.getValue(0, __PROP_STATUS, "").equalsIgnoreCase(MES_TRANS_ITEM_STATUS_ERROR)) {
                logMESError(dsPrimary.getValue(0, __PROP_MES_TRANS_ITEM_COL_ITEM_ID, ""), actionProps.getProperty(__PROP_ERROR_MESSAGE, ""), dsPrimary.getValue(0, __PROP_SERVICE_NAME, ""));
            }
            handleReprocessing(dsPrimary, sdiData);

        } catch (SapphireException ex) {
            String errorMsg = ex.getMessage();
            logger.error(errorMsg);
        }
    }

    /*************************************************************************
     * This method is used to handle Handles reprocessing of transaction item
     * @param dsPrimary Primary DataSet
     * @throws SapphireException OOB Sapphire Exception
     *************************************************************************/
    private void handleReprocessing(DataSet dsPrimary, SDIData sdidata) throws SapphireException {
        String modifiedMESIntftransid = "";
        for (int i = 0; i < dsPrimary.size(); i++) {
            if (hasPrimaryValueChanged(dsPrimary, i, PROP_MES_TRANS_ITEM_COL_REPROCESS_DATE)) {
                modifiedMESIntftransid += ";" + dsPrimary.getValue(i, __PROP_MES_TRANS_ITEM_COL_ITEM_ID, "");
            }
        }

        if (modifiedMESIntftransid.startsWith(";")) {
            modifiedMESIntftransid = modifiedMESIntftransid.substring(1);
        } else {
            return;
        }
        //******************* Safe SQL addIn added for IN clause *******************
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT ").append(__PROP_MES_TRANS_ITEM_COL_ITEM_ID).append(", ").append(PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD).append(" FROM u_mesintftrans ");
        // ************** Using SafeSQL--> addVar to use as bind variable ***************
        strSQL.append("WHERE ").append(__PROP_MES_TRANS_ITEM_COL_ITEM_ID).append(" IN (").append(safeSQL.addIn(modifiedMESIntftransid, ";")).append(")");
        // ************** Using SafeSQL--> getValues to replace bind variable with values  ***************
        DataSet dsSql = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues(), true);
        if (dsSql == null) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.GENERAL_ERR_00002));

        }

        HashMap hmFilter;
        DataSet dsFilter;

        for (int i = 0; i < dsPrimary.size(); i++) {
            int reprocessCount = Integer.parseInt(getOldPrimaryValue(dsPrimary, i, PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT).equals("") ? "0" : getOldPrimaryValue(dsPrimary, i, PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT));
            reprocessCount++;

            if (!dsPrimary.isValidColumn(PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT)) {
                dsPrimary.addColumn(PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT, DataSet.NUMBER);
            }
            dsPrimary.setNumber(i, PROP_MES_TRANS_ITEM_COL_REPROCESS_COUNT, reprocessCount);


            String mesintftransid = dsPrimary.getValue(i, __PROP_MES_TRANS_ITEM_COL_ITEM_ID, "");
            hmFilter = new HashMap();
            hmFilter.put(__PROP_MES_TRANS_ITEM_COL_ITEM_ID, mesintftransid);
            dsFilter = getBeforeEditImage().getDataset(SDIData.PRIMARY).getFilteredDataSet(hmFilter);

            if (!dsFilter.isValidColumn(PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD)) {
                dsFilter.addColumn(PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD, DataSet.CLOB);
            }
            dsFilter.setClob(0, PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD, dsSql.getFilteredDataSet(hmFilter).getClob(0, PROP_MES_TRANS_ITEM_COL_MSG_PAYLOAD));
            if (!dsFilter.isValidColumn(__PROP_REPROCESSING_FLAG)) {
                dsFilter.addColumn(__PROP_REPROCESSING_FLAG, DataSet.STRING);
            }
            dsFilter.setString(0, __PROP_REPROCESSING_FLAG, "Y");
            callOpcenterMESLVOutbound(dsFilter);
        }
    }

    /*****************************************************************************
     * This method is used to call action responsible for sending data to MESPROCESSCONTROLLER.
     * @param dsPrimary Primary DataSet.
     * @throws SapphireException OOB Sapphire Exception
     ******************************************************************************/
    private void callOpcenterMESLVOutbound(DataSet dsPrimary) throws SapphireException {
        PropertyList plMESTransItem = new PropertyList();
        String mesTransId = dsPrimary.getValue(0, OpcenterMESLVOutbound.TRANSACTION_ID, "");
        String serviceName = dsPrimary.getValue(0, OpcenterMESLVOutbound.SERVICE_NAME, "");
        String site = dsPrimary.getValue(0, OpcenterMESLVOutbound.SITE, "");
        String JSONString = dsPrimary.getValue(0, OpcenterMESLVOutbound.TRANSACTION_DATA, "");
        String reprocessingFlag = dsPrimary.getValue(0, OpcenterMESLVOutbound.__PROP_REPROCESSINGFLAG, "");

        // ******** Passing properties to OpcenterMESLVOutbound *********
        PropertyList prop = new PropertyList();
        prop.setProperty(OpcenterMESLVOutbound._PROPS_SERVICE_NAME, serviceName);
        prop.setProperty(OpcenterMESLVOutbound._PROPS_SITE, site);
        prop.setProperty(OpcenterMESLVOutbound.TRANSACTION_ID, mesTransId);
        prop.setProperty(OpcenterMESLVOutbound.__PROPS_ITEMS, JSONString);
        prop.setProperty(OpcenterMESLVOutbound.__PROP_REPROCESSINGFLAG, reprocessingFlag);// Reprocessing -Y or N

        try {
            //As one Lot will be created at one time so calling action within the loop
            getActionProcessor().processAction(OpcenterMESLVOutbound.ID, OpcenterMESLVOutbound.VERSIONID, prop, true);

        } catch (SapphireException e) {
            plMESTransItem.setProperty(__PROP_STATUS, MES_TRANS_ITEM_STATUS_ERROR);
            logMESError(mesTransId, e.getMessage(), serviceName);

        } catch (Exception e) {
            plMESTransItem.setProperty(__PROP_STATUS, MES_TRANS_ITEM_STATUS_ERROR);
            logMESError(mesTransId, e.getMessage(), serviceName);
        }

    }

    /*********************************************************************
     * This method is used to Log the MES interfacing error or exceptions.
     * @param transId MES Transaction Id
     * @param errormsg Error Message
     * @param serviceName Service Name
     *********************************************************************/
    public void logMESError(String transId, String errormsg, String serviceName) throws SapphireException {

        logger.error("================================ intferrordesc In logMESError ===========================");
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, __PROP_SDC_MES_INTF_ERROR);
        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
        pl.setProperty(__PROP_MES_INTFTRANS_ID, transId);
        String msg="";
        if(errormsg.contains("Reason:")){
            msg = StringUtil.split(errormsg,"Reason:")[StringUtil.split(errormsg,"Reason:").length-1];
        }
        else{
            msg=errormsg;
        }
        pl.setProperty(__PROP_ERROR_MESSAGE, msg);
        pl.setProperty(__PROP_STATUS, MES_TRANS_ITEM_STATUS_ERROR);
        pl.setProperty(__PROP_PROGRAM, serviceName);
        pl.setProperty(__PROP_CREATEBY, currentUser);
        try {
            getActionProcessor().processAction(MESErrorHandler.ID, MESErrorHandler.VERSIONID, pl);
        } catch (SapphireException e) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.GENERAL_ERR_00012));
        }
    }

    /*************************************************************
     * This method is used to get snapshot of data before editing
     * @return Returns true or false.
     *************************************************************/
    public boolean requiresBeforeEditImage() {
        return true;
    }


}
