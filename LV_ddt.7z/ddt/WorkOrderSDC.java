package labvantage.custom.alcon.ddt;

import sapphire.SapphireException;
import sapphire.action.BaseSDCRules;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/**
 * $Author: CHATTSA1 $
 * $Date: 2022-08-20 01:12:57 +0530 (Sat, 20 Aug 2022) $
 * $Revision: 77 $
 */

/********************************************************************************************************
 * $Revision: 77 $
 * Description: SDC rule for Work Orders.
 *******************************************************************************************************/
public class WorkOrderSDC extends BaseSDCRules {

    public static final String DEVOPS_ID = "$Revision: 77 $";
    private static final String PROPERTY_INSTRUMENT_SDC = "Instrument";
    private static final String PROPERTY_SOURCESDCID = "sourcesdcid";
    private static final String PROPERTY_SOURCEKEYID1 = "sourcekeyid1";
    private static final String PROPERTY_SCHEDULEPLANID = "scheduleplanid";
    private static final String PROPERTY_SCHEDULEPLANITEMID = "scheduleplanitemid";
    private static final String PROPERTY_INSTRUMENT_STATUS = "instrumentstatus";
    private static final String PROPERTY_INSTRUMENTSTATUS_AVAILABLE = "Available";
    private static final String PROPERTY_INSTRUMENT_UNAVAILABLITY_REASON = "unavailabilityreason";

    private static final String PROPERTY_WORKORDER_SDC = "WorkOrderSDC";
    private static final String PROPERTY_WORKORDER_ID = "workorderid";
    private static final String PROPERTY_WORKORDER_STATUS = "workorderstatus";
    private static final String PROPERTY_WORKORDERSTATUS_PENDING = "Pending";
    private static final String PROPERTY_WORKORDERSTATUS_CANCELLED = "Cancelled";
    private static final String PROPERTY_WORKORDERSTATUS_SCHEDULED = "Scheduled";

    private static final String PROPERTY_SAMPLE_SDC = "Sample";
    private static final String PROPERTY_SAMPLE_ID = "s_sampleid";
    private static final String PROPERTY_SAMPLE_STATUS = "samplestatus";
    private static final String PROPERTY_SAMPLESTATUS_INITIAL = "Initial";
    private static final String PROPERTY_SAMPLESTATUS_RECEIVED = "Received";
    private static final String PROPERTY_SAMPLESTATUS_CANCELLED = "Cancelled";

    private static final String PROPERTY_DEFAULT_DELIMETER = ";";


    /**
     * @return
     */
    public boolean requiresBeforeEditImage() {
        return true;
    }


    @Override
    public void preAdd(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);

        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }
        // ************* Proceed Further only if Source SDC ID is Instrument
        if (dsPrimary.getValue(0, PROPERTY_SOURCESDCID, "").equalsIgnoreCase(PROPERTY_INSTRUMENT_SDC)) {
            checkAndCancelPreviousWorkOrders(dsPrimary);
        }
    }

    /***
     * Description: Checks and Cancels Previous unused WorkOrders.
     * @param dsPrimary
     * @throws SapphireException
     */
    private void checkAndCancelPreviousWorkOrders(DataSet dsPrimary) throws SapphireException {
        String instrumentId = dsPrimary.getValue(0, PROPERTY_SOURCEKEYID1, "");
        String schedulePlanId = dsPrimary.getValue(0, PROPERTY_SCHEDULEPLANID, "");
        String schedulePlanItemId = dsPrimary.getValue(0, PROPERTY_SCHEDULEPLANITEMID, "");
        // ************* Getting all workorders by instruments
        String sqlText = " SELECT workorderid, workorderstatus FROM workorder WHERE sourcekeyid1 = ?  AND sourcesdcid = ? " +
                "AND (workorderstatus = ? OR workorderstatus = ? OR workorderstatus = ?) AND SCHEDULEPLANID = ? AND SCHEDULEPLANITEMID = ? ";
        DataSet dsPendingOrScheduledWorkOrders = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{instrumentId,
                PROPERTY_INSTRUMENT_SDC, PROPERTY_WORKORDERSTATUS_PENDING, PROPERTY_WORKORDERSTATUS_SCHEDULED, PROPERTY_WORKORDERSTATUS_CANCELLED, schedulePlanId, schedulePlanItemId});
        // ************* If Null DataSet found
        if (null == dsPendingOrScheduledWorkOrders) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE,
                    getTranslationProcessor().translate(" Aborting transaction. Inside checkAndCancelPreviousWorkOrders - Unable to create Workorder dataset. "));
        }
        // ************* If any workorder associated with Instrument found having status Pending or Scheduled
        if (dsPendingOrScheduledWorkOrders.size() > 0) {
            DataSet dsToBeCancelledWorkOrders = checkAndCancelLinkedSamples(dsPendingOrScheduledWorkOrders);
            // ************ If all linked Samples are in Initial / Received / Cancelled status
            if (dsToBeCancelledWorkOrders.size() > 0) {
                cancelWorkOrders(dsToBeCancelledWorkOrders);
            }
        }
    }

    /***
     * Description: Checks and Cancels Samples linked to the WorkOrders.
     * @param dsPendingOrScheduledWorkOrders
     * @throws SapphireException
     */
    private DataSet checkAndCancelLinkedSamples(DataSet dsPendingOrScheduledWorkOrders) throws SapphireException {
        String workOrderId = "";
        String workOrderStatus = "";
        HashMap hmFilter = new HashMap();
        String rSetId = "";
        DataSet dsSamplesByWorkorder = new DataSet();
        // ************* New Comlumn is added
        dsPendingOrScheduledWorkOrders.addColumn("deleteflag", DataSet.STRING);

        // ************ Fetch the list of all workorderids having status pending or scheduled
        String workOrderIds = dsPendingOrScheduledWorkOrders.getColumnValues(PROPERTY_WORKORDER_ID, PROPERTY_DEFAULT_DELIMETER);
        try {
            rSetId = getDAMProcessor().createRSet(PROPERTY_WORKORDER_SDC, workOrderIds, "(null)", "(null)");
            // ************ Fetch the list of all Samples linked to the Pending or Scheduled WorkOrders
            String sqlWororderSamples = " SELECT s.s_sampleid, s.samplestatus, s.workorderid FROM s_sample s, rsetitems rsi " +
                    " WHERE rsi.keyid1 = s.workorderid " +
                    " AND rsi.rsetid = ? " +
                    " AND rsi.keyid2 = '(null)' " +
                    " AND rsi.keyid3 = '(null)' " +
                    " AND rsi.sdcid = ? ";
            // ************* DataSet of all eligible Sample ids to be cancelled.
            dsSamplesByWorkorder = getQueryProcessor().getPreparedSqlDataSet(sqlWororderSamples, new Object[]{rSetId, PROPERTY_WORKORDER_SDC});
            if (null == dsSamplesByWorkorder) {
                throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE,
                        getTranslationProcessor().translate(" Aborting transaction. Inside - createRSet.Unable to find Sample details for Workorder Ids  -" + workOrderIds.replaceAll(";", ",")));
            }
        } catch (SapphireException ex) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
        } finally {
            // *********** If RSet Id is not a BLANK string
            if (!"".equalsIgnoreCase(rSetId)) {
                getDAMProcessor().clearRSet(rSetId);
            }
        }
        // *************** If any eligible Sample Id found
        if (dsSamplesByWorkorder.size() > 0) {
            DataSet dsToBeCancelledSample = new DataSet();
            // **************** Looping through each workorder id(s) having status Pending or Scheduled
            for (int i = 0; i < dsPendingOrScheduledWorkOrders.size(); i++) {
                workOrderId = dsPendingOrScheduledWorkOrders.getValue(i, PROPERTY_WORKORDER_ID, "");
                workOrderStatus = dsPendingOrScheduledWorkOrders.getValue(i, PROPERTY_WORKORDER_STATUS, "");
                hmFilter.clear();
                hmFilter.put(PROPERTY_WORKORDER_ID, workOrderId);
                // ************ Fetching individual Samples for a workorder id
                dsToBeCancelledSample = dsSamplesByWorkorder.getFilteredDataSet(hmFilter);
                dsToBeCancelledSample.addColumn("cancelflag", DataSet.STRING);
                // ************ 1.If No Sample Id(s) assocaited with workorder id then continue and move to next workorder id in DataSet.
                // ************ 2 If Cancellable Sample Id(s) found against workorder id then Cancel all Samples assocaited with it and continue.
                // ************ 2 If Cancellable Sample Id(s) not found against workorder id then remove that workorder id from workorder DataSet
                if (dsToBeCancelledSample.size() > 0) {
                    if (checkSampleStatus(dsToBeCancelledSample, workOrderStatus)) {
                        cancelLinkedSamples(dsToBeCancelledSample);
                        // ************ WorkOrders to be cancelled
                        dsPendingOrScheduledWorkOrders.setValue(i, "deleteflag", "Y");
                    } else if (workOrderStatus.equalsIgnoreCase(PROPERTY_WORKORDERSTATUS_CANCELLED)) {
                        // ************ WorkOrders Already Cancelled
                        dsPendingOrScheduledWorkOrders.setValue(i, "deleteflag", "N");
                    } else {
                        // ************ WorkOrders not to be cancelled
                        dsPendingOrScheduledWorkOrders.setValue(i, "deleteflag", "N");
                    }
                } else {
                    //To ensure only non-cancelled workorders are cancelled
                    if (!workOrderStatus.equalsIgnoreCase(PROPERTY_WORKORDERSTATUS_CANCELLED)) {
                        dsPendingOrScheduledWorkOrders.setValue(i, "deleteflag", "Y");
                    }
                }
            }
        } else {
            for (int i = 0; i < dsPendingOrScheduledWorkOrders.size(); i++) {
                workOrderStatus = dsPendingOrScheduledWorkOrders.getValue(i, PROPERTY_WORKORDER_STATUS, "");
                //Already Cancelled WorkOrders are being removed from
                if (workOrderStatus.equalsIgnoreCase(PROPERTY_WORKORDERSTATUS_CANCELLED)) {
                    // ************ WorkOrders Already Cancelled
                    dsPendingOrScheduledWorkOrders.setValue(i, "deleteflag", "N");
                } else {
                    dsPendingOrScheduledWorkOrders.setValue(i, "deleteflag", "Y");
                }
            }
        }
        hmFilter.clear();
        hmFilter.put("deleteflag", "Y");
        return dsPendingOrScheduledWorkOrders.getFilteredDataSet(hmFilter);
    }

    /***
     * Description: Checks Sample Status of each samples linked to the WorkOrder.
     * @param dsToBeCancelledSample
     * @throws SapphireException
     */
    private boolean checkSampleStatus(DataSet dsToBeCancelledSample, String workOrderStatus) {
        boolean samplesCanBeCancelled = true;
        String sampleStatus = "";
        if (workOrderStatus.equalsIgnoreCase(PROPERTY_WORKORDERSTATUS_CANCELLED)) {
            for (int i = 0; i < dsToBeCancelledSample.getRowCount(); i++) {
                sampleStatus = dsToBeCancelledSample.getValue(i, PROPERTY_SAMPLE_STATUS, "");
                // ************ Validating Sample Status
                if (sampleStatus.equalsIgnoreCase(PROPERTY_SAMPLESTATUS_INITIAL) || sampleStatus.equalsIgnoreCase(PROPERTY_SAMPLESTATUS_RECEIVED)) {
                    dsToBeCancelledSample.setValue(i, "cancelflag", "Y");
                    continue;
                } else {
                    dsToBeCancelledSample.setValue(i, "cancelflag", "N");
                    continue;
                }
            }
        } else {
            for (int i = 0; i < dsToBeCancelledSample.getRowCount(); i++) {
                sampleStatus = dsToBeCancelledSample.getValue(i, PROPERTY_SAMPLE_STATUS, "");
                // ************ Validating Sample Status
                if (sampleStatus.equalsIgnoreCase(PROPERTY_SAMPLESTATUS_INITIAL) || sampleStatus.equalsIgnoreCase(PROPERTY_SAMPLESTATUS_RECEIVED)) {
                    dsToBeCancelledSample.setValue(i, "cancelflag", "Y");
                    continue;
                } else if (sampleStatus.equalsIgnoreCase(PROPERTY_SAMPLESTATUS_CANCELLED)) {
                    dsToBeCancelledSample.setValue(i, "cancelflag", "Y");
                    continue;
                } else {
                    samplesCanBeCancelled = false;
                    dsToBeCancelledSample.setValue(i, "cancelflag", "Y");
                    break;
                }
            }
        }
        return samplesCanBeCancelled;
    }

    /***
     * Description: Cancels Previously unused WorkOrders.
     * @param dsPendingOrScheduledWorkOrders
     * @throws SapphireException
     */
    private void cancelWorkOrders(DataSet dsPendingOrScheduledWorkOrders) throws SapphireException {
        PropertyList plEditSDI = new PropertyList();
        plEditSDI.setProperty(EditSDI.PROPERTY_SDCID, PROPERTY_WORKORDER_SDC);
        plEditSDI.setProperty(EditSDI.PROPERTY_KEYID1, dsPendingOrScheduledWorkOrders.getColumnValues(PROPERTY_WORKORDER_ID, ";"));
        plEditSDI.setProperty(PROPERTY_WORKORDER_STATUS, PROPERTY_WORKORDERSTATUS_CANCELLED);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plEditSDI);
        } catch (SapphireException ex) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE,
                    getTranslationProcessor().translate(" Aborting transaction. Unable to cancel workorder Id(s) - " + dsPendingOrScheduledWorkOrders.getColumnValues(PROPERTY_WORKORDER_ID, ";")));
        }
    }

    /***
     * Description: Cancels all Linked Samples.
     * @param dsToBeCancelledSample
     * @throws SapphireException
     */
    private void cancelLinkedSamples(DataSet dsToBeCancelledSample) throws SapphireException {
        PropertyList plEditSDI = new PropertyList();
        HashMap hmFilter = new HashMap();
        hmFilter.put("cancelflag", "Y");
        dsToBeCancelledSample = dsToBeCancelledSample.getFilteredDataSet(hmFilter);
        hmFilter.clear();
        if (dsToBeCancelledSample.size() > 0) {
            plEditSDI.setProperty(EditSDI.PROPERTY_SDCID, PROPERTY_SAMPLE_SDC);
            plEditSDI.setProperty(EditSDI.PROPERTY_KEYID1, dsToBeCancelledSample.getColumnValues(PROPERTY_SAMPLE_ID, ";"));
            plEditSDI.setProperty(PROPERTY_SAMPLE_STATUS, PROPERTY_SAMPLESTATUS_CANCELLED);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plEditSDI);
            } catch (SapphireException ex) {
                throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE,
                        getTranslationProcessor().translate(" Aborting transaction. Unable to cancel Sample Id(s) - " + dsToBeCancelledSample.getColumnValues(PROPERTY_SAMPLE_ID, ";")));
            }
        }
    }

    @Override
    public void postEdit(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);

        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }

        //Only the first record is checked since for Cancellation all records will have the same Status and same Instrument Id
        //Process further only if the WorkOrder SDC Type is Instrument
        if (PROPERTY_INSTRUMENT_SDC.equalsIgnoreCase(getBeforeEditImage().getDataset("primary").getValue(0, PROPERTY_SOURCESDCID, ""))) {
            //Process further only if the workorder status is changed and the status is cancelled
            if (hasPrimaryValueChanged(dsPrimary, 0, "workorderstatus") &&
                    (dsPrimary.getValue(0, "workorderstatus", "").equalsIgnoreCase(PROPERTY_WORKORDERSTATUS_CANCELLED))) {
                checkWorkOrderStatus(dsPrimary);
            }
        }
    }

    /***
     * Description: Checks workorder status belonging to the same Instrument
     * @param dsPrimary
     * @throws SapphireException
     */
    private void checkWorkOrderStatus(DataSet dsPrimary) throws SapphireException {
        String instrumentId = getBeforeEditImage().getDataset("primary").getValue(0, PROPERTY_SOURCEKEYID1, "");

        // ************* Getting all WorkOrders by Instrument Id which has Pending or Scheduled status
        String sqlText = " SELECT workorderid, workorderstatus FROM workorder WHERE sourcekeyid1 = ? AND sourcesdcid = ? AND (workorderstatus = ? OR workorderstatus = ?) ";
        DataSet dsPendingOrScheduledWorkOrders = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{instrumentId,
                PROPERTY_INSTRUMENT_SDC, PROPERTY_WORKORDERSTATUS_PENDING, PROPERTY_WORKORDERSTATUS_SCHEDULED});

        // ************* If Null DataSet found
        if (null == dsPendingOrScheduledWorkOrders) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE,
                    getTranslationProcessor().translate(" Aborting transaction. Inside checkWorkOrderStatus - Unable to create Workorder dataset. "));
        }

        // ************* Proceed further if no workorder associated with Instrument having status Pending or Scheduled
        if (dsPendingOrScheduledWorkOrders.size() == 0) {
            fetchAndMakeInstrumentAvailable(instrumentId);
        } else {
            return;
        }
    }

    /***
     * Description: Fetches the associated Instrument ID and changes the status to Available
     * @param instrumentId
     * @throws SapphireException
     */
    private void fetchAndMakeInstrumentAvailable(String instrumentId) throws SapphireException {
        PropertyList plEditSDI = new PropertyList();

        plEditSDI.setProperty(EditSDI.PROPERTY_SDCID, PROPERTY_INSTRUMENT_SDC);
        plEditSDI.setProperty(EditSDI.PROPERTY_KEYID1, instrumentId);
        plEditSDI.setProperty(PROPERTY_INSTRUMENT_STATUS, PROPERTY_INSTRUMENTSTATUS_AVAILABLE);
        plEditSDI.setProperty(PROPERTY_INSTRUMENT_UNAVAILABLITY_REASON, "");

        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plEditSDI);
        } catch (SapphireException ex) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE,
                    getTranslationProcessor().translate(" Aborting transaction. Unable to change Instrument Status to Available - " + instrumentId));
        }
    }
}

