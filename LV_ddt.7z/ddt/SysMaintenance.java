package labvantage.custom.alcon.ddt;

import labvantage.custom.alcon.util.AlconUtil;
import sapphire.SapphireException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseSDCRules;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SDIData;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.Calendar;

/**
 * $Author: BAGCHAN1 $
 * $Date: 2022-04-20 01:26:41 +0530 (Wed, 20 Apr 2022) $
 * $Revision: 46 $
 */

/********************************************************************************************
 * $Revision: 46 $
 * Description:
 * SDC rule for System Maintenance.
 * This class is being called when trancation item table populated with System Maintenance Properties
 *
 *
 *******************************************************************************************/

public class SysMaintenance extends BaseSDCRules {

    public static final String DEVOPS_ID = "$Revision: 46 $";
    private static final String __PROPS_DATE_FORMAT = "MM/dd/yyyy";
    //System Maintenance SDC Properties
    private static final String __PROPS_SDCID = "SysMaintenance";
    private static final String __PROPS_PLANNED_START_DATE = "plannedstartdate";
    private static final String __PROPS_PLANNED_START_DATE_HOURS = "plannedstarttimehh";
    private static final String __PROPS_PLANNED_START_DATE_MINUTES = "plannedstarttimemm";
    private static final String __PROPS_PLANNED_END_DATE = "plannedenddate";
    private static final String __PROPS_PLANNED_END_DATE_HOURS = "plannedendtimehh";
    private static final String __PROPS_PLANNED_END_DATE_MINUTES = "plannedendtimemm";
    private static final String __PROPS_SYSMAINT_MAINTEANCE_STATUS = "maintenancestatus";
    private static final String __PROPS_KEYID = "u_sysmaintenanceid";
    //Policy Details
    private static final String __PROPS_POLICYID = "SystemMaintenance";
    private static final String __PROPS_NODEID = "SystemMaintenanceDefaultValues";
    private static final String __PROPS_JOBTYPE_NODEID = "DefaultJobType";
    private static final String __PROPS_USERID_NODEID = "DefaultUserId";
    //Job Detailed SDC
    private static final String __PROPS_JOBTYPE_ID = "JobType";
    private static final String __PROPS_JOBTYPE_KEYID = "jobtypeid";
    private static final String __PROPS_JOBTYPE_LINKID = "sysmaintenancejobtype_link";
    //User Detailed SDC
    private static final String __PROPS_USER_ID = "UserId";
    private static final String __PROPS_USER_TYPE_ID = "UserType";
    private static final String __PROPS_USER_KEYID = "sysuserid";
    private static final String __PROPS_USER_LINKID = "sysmaintenanceuser_link";
    // Maintenace Status
    private static final String STARTED_SYSTEM_MAINTENANCE = "Started";
    private static final String EXTENDED_SYSTEM_MAINTENANCE = "Extended";
    private static final String ENDED_SYSTEM_MAINTENANCE = "Ended";
    private String __ERRORMSG = "";

    /**
     * This methhod is called to add business logic BEFORE the database inserts in the AddSDI action
     *
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void preAdd(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }
        validateAndUpdateDateTime(dsPrimary);
    }

    /**
     * This methhod is called to add business logic BEFORE the database updates in the EditSDI action
     *
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void preEdit(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }
        if (dsPrimary.getValue(0, __PROPS_SYSMAINT_MAINTEANCE_STATUS, "").equalsIgnoreCase(STARTED_SYSTEM_MAINTENANCE) ||
                dsPrimary.getValue(0, __PROPS_SYSMAINT_MAINTEANCE_STATUS, "").equalsIgnoreCase(EXTENDED_SYSTEM_MAINTENANCE) ||
                dsPrimary.getValue(0, __PROPS_SYSMAINT_MAINTEANCE_STATUS, "").equalsIgnoreCase(ENDED_SYSTEM_MAINTENANCE)) {
            return;
        } else {
            validateAndUpdateDateTime(dsPrimary);
        }
    }

    /**
     * This methhod is called to validate the entered date, hours and minutes and format it into proper date object
     *
     * @param dsPrimary
     * @throws SapphireException
     */
    private void validateAndUpdateDateTime(DataSet dsPrimary) throws SapphireException {
        logger.debug("Inside validateAndUpdateDateTime (method)");

        Calendar plannedStartDate = dsPrimary.getCalendar(0, __PROPS_PLANNED_START_DATE);
        String plannedStartHours = dsPrimary.getValue(0, __PROPS_PLANNED_START_DATE_HOURS, "");
        String plannedStartMinutes = dsPrimary.getValue(0, __PROPS_PLANNED_START_DATE_MINUTES, "");
        Calendar plannedEndDate = dsPrimary.getCalendar(0, __PROPS_PLANNED_END_DATE);
        String plannedEndHours = dsPrimary.getValue(0, __PROPS_PLANNED_END_DATE_HOURS, "");
        String plannedEndMinutes = dsPrimary.getValue(0, __PROPS_PLANNED_END_DATE_MINUTES, "");

        Calendar plannedStartDateFormatted = AlconUtil.addHoursMinutesToJavaUtilDate(plannedStartDate.getTime(), plannedStartHours, plannedStartMinutes);
        Calendar plannedEndDateFormatted = AlconUtil.addHoursMinutesToJavaUtilDate(plannedEndDate.getTime(), plannedEndHours, plannedEndMinutes);


        if (plannedEndDateFormatted.before(plannedStartDateFormatted) || plannedEndDateFormatted.equals(plannedStartDateFormatted)) {
            __ERRORMSG = "Planned Start Date must be less than Planned End Date.";
            throw new SapphireException("Validation", ErrorDetail.TYPE_VALIDATION, __ERRORMSG);
        }

        dsPrimary.setDate(0, __PROPS_PLANNED_START_DATE, plannedStartDateFormatted);
        dsPrimary.setDate(0, __PROPS_PLANNED_END_DATE, plannedEndDateFormatted);
    }


    /**
     * This methhod is called to add business logic AFTER the database inserts in the AddSDI action
     *
     * @param sdiData
     * @param actionProps
     * @throws SapphireException
     */
    @Override
    public void postAdd(SDIData sdiData, PropertyList actionProps) throws SapphireException {
        DataSet dsPrimary = sdiData.getDataset(SDIData.PRIMARY);
        if (null == dsPrimary || dsPrimary.getRowCount() == 0) {
            return;
        }
        String id = dsPrimary.getValue(0, __PROPS_KEYID, "");
        addDafaultValueFromPolicy(id);

    }

    /**
     * This methhod is called to add default jobtype and user id to the System Maintenance Detail table
     *
     * @param id
     * @return String
     * @throws SapphireException
     */
    private String addDafaultValueFromPolicy(String id) throws SapphireException {
        logger.debug("Inside addDafaultValueFromPolicy (method)");
        String templateId = "";

        PropertyList plJobTypeUserList = getConfigurationProcessor().getPolicy(__PROPS_POLICYID, __PROPS_NODEID);
        PropertyListCollection plJobTypes = plJobTypeUserList.getCollection(__PROPS_JOBTYPE_NODEID);
        if (plJobTypes != null && plJobTypes.size() > 0) {
            for (int i = 0; i < plJobTypes.size(); i++) {
                addValueToLinkedSDI(id, ((PropertyList) plJobTypes.get(i)).getProperty(__PROPS_JOBTYPE_ID), __PROPS_JOBTYPE_ID);
            }
        }
        PropertyListCollection plUsers = plJobTypeUserList.getCollection(__PROPS_USERID_NODEID);
        if (plUsers != null && plUsers.size() > 0) {
            for (int i = 0; i < plUsers.size(); i++) {
                addValueToLinkedSDI(id, ((PropertyList) plUsers.get(i)).getProperty(__PROPS_USER_ID), __PROPS_USER_TYPE_ID);
            }
        }

        return templateId;
    }

    private void addValueToLinkedSDI(String id, String value, String type) throws SapphireException {

        if (value.trim().equals("")) {
            return;
        }

        value = value.trim();
        PropertyList plAddSDIDetail = new PropertyList();
        plAddSDIDetail.setProperty(AddSDIDetail.PROPERTY_SDCID, __PROPS_SDCID);
        plAddSDIDetail.setProperty(AddSDIDetail.PROPERTY_KEYID1, id);

        if (type.equalsIgnoreCase(__PROPS_JOBTYPE_ID)) {
            plAddSDIDetail.setProperty(AddSDIDetail.PROPERTY_LINKID, __PROPS_JOBTYPE_LINKID);
            plAddSDIDetail.setProperty(__PROPS_JOBTYPE_KEYID, value);
        } else if (type.equalsIgnoreCase(__PROPS_USER_TYPE_ID)) {
            plAddSDIDetail.setProperty(AddSDIDetail.PROPERTY_LINKID, __PROPS_USER_LINKID);
            plAddSDIDetail.setProperty(__PROPS_USER_KEYID, value);
        }

        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, plAddSDIDetail);

    }

}
