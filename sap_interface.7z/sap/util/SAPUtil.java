package labvantage.custom.alcon.sap.util;

import com.labvantage.sapphire.services.ConnectionInfo;
import labvantage.custom.alcon.sap.action.BatchMaster;
import sapphire.SapphireException;
import sapphire.accessor.QueryProcessor;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * $Author: GHOSHKA1 $
 * $Date: 2022-04-26 11:56:32 -0500 (Tue, 26 Apr 2022) $
 * $Revision: 771 $
 */

/*******************************************************************
 * $Revision: 771 $
 * Description:
 * Utility class
 *******************************************************************/
public class SAPUtil {
    public static final String DEVOPS_ID = "$Revision: 771 $";

    public static String INPUT_DATASET_COLUMN_ENTITY_NAME = "entityname";
    public static String INPUT_DATASET_COLUMN_COL_ID = "colname";
    public static String INPUT_DATASET_COLUMN_COL_VALUE = "colvalue";
    public static String INPUT_DATASET_COLUMN_GROUP = "group";


    public static String BATCH_MASTER_TABLE_Z1Z8CQBATMAS = "Z1Z8CQBATMAS";


    public static DataSet getEntityDataSet(DataSet dsSource, String entityname) throws SapphireException {
        DataSet dsFilter = null;
        if (dsSource == null || dsSource.getRowCount() == 0) {
            throw new SapphireException("Source DataSet is null.");
        }
        if (entityname == null || entityname.equals("")) {
            return dsSource;
        }

        HashMap filter = new HashMap();
        filter.clear();
        filter.put(INPUT_DATASET_COLUMN_ENTITY_NAME, entityname);
        dsFilter = dsSource.getFilteredDataSet(filter);

        return dsFilter;
    }

    /**
     * This utility method is being used for getting values by Entity Name, Column Name and Group Name
     *
     * @param dsSource   Source DataSet to filter.
     * @param entityName Entity Name
     * @param colName    Column Name
     * @param groupName  Group Name
     * @return Returns filtered DataSet
     * @throws SapphireException OOB Sapphire Exception
     */
    public static DataSet getColumnValueByGroup(DataSet dsSource, String entityName, String colName, String groupName) throws SapphireException {
        PropertyList filterCriteria = new PropertyList();
        filterCriteria.setProperty(INPUT_DATASET_COLUMN_ENTITY_NAME, entityName);
        filterCriteria.setProperty(INPUT_DATASET_COLUMN_COL_ID, colName);
        filterCriteria.setProperty(INPUT_DATASET_COLUMN_GROUP, groupName);
        // Filtering Source DataSet by Entity Name, Columna Name and Group Name
        DataSet dsFilter = dsSource.getFilteredDataSet(filterCriteria);
        if (null == dsFilter) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, ErrorMessageUtil.NULL_DATASET_FOUND);
        }
        return dsFilter;
    }

    public static DataSet getRowValues(DataSet dsSource, String entityname, String colname) throws SapphireException {
        DataSet dsFilter = null;
        if (dsSource == null || dsSource.getRowCount() == 0) {
            throw new SapphireException("Source DataSet is null.");
        }
        if (entityname == null || entityname.equals("")) {
            return dsSource;
        }

        HashMap filter = new HashMap();
        filter.clear();
        filter.put(INPUT_DATASET_COLUMN_ENTITY_NAME, entityname);
        filter.put(INPUT_DATASET_COLUMN_COL_ID, colname);
        dsFilter = dsSource.getFilteredDataSet(filter);

        return dsFilter;

    }

    /**
     * if single row exists in filter them returns one string otherwise semicolon seperated record.
     *
     * @param dsSource
     * @param entityname
     * @param colname
     * @return
     * @throws SapphireException
     */
    public static String getColumnValue(DataSet dsSource, String entityname, String colname) throws SapphireException {
        DataSet dsFilter = null;
        if (dsSource == null || dsSource.getRowCount() == 0) {
            throw new SapphireException("Source DataSet is null.");
        }
        if (entityname == null || entityname.equals("")) {
            throw new SapphireException("Entity name not passed.");
        }

        HashMap filter = new HashMap();
        filter.clear();
        filter.put(INPUT_DATASET_COLUMN_ENTITY_NAME, entityname);
        filter.put(INPUT_DATASET_COLUMN_COL_ID, colname);
        dsFilter = dsSource.getFilteredDataSet(filter);

        if (dsFilter != null && dsFilter.getRowCount() > 0) {
            if (dsFilter.getRowCount() == 1)
                return dsFilter.getValue(0, INPUT_DATASET_COLUMN_COL_VALUE, "");
            else
                return dsFilter.getColumnValues(INPUT_DATASET_COLUMN_COL_VALUE, ";");
        }

        return null;

    }

    public static DataSet getDataSetFromXMLString(String xmlString) {

        DataSet dsInput = new DataSet(xmlString);

        return dsInput;
    }

    public static String getGroupName(DataSet dsSource, String entityName, String colId, String colValue) throws SapphireException {
        DataSet dsFilter = null;
        if (dsSource == null || dsSource.getRowCount() == 0) {
            throw new SapphireException("Source DataSet is null.");
        }
        if (entityName == null || entityName.equals("")) {
            throw new SapphireException("Entity name not passed.");
        }

        HashMap filter = new HashMap();
        filter.clear();
        filter.put(INPUT_DATASET_COLUMN_ENTITY_NAME, entityName);
        filter.put(INPUT_DATASET_COLUMN_COL_ID, colId);
        filter.put(INPUT_DATASET_COLUMN_COL_VALUE, colValue);
        dsFilter = dsSource.getFilteredDataSet(filter);

        if (dsFilter != null && dsFilter.getRowCount() > 0) {
            return dsFilter.getValue(0, INPUT_DATASET_COLUMN_GROUP, "");
        }
        return "";
    }

    /**
     * This method is used to check null dates and replaces it with 00000000.
     *
     * @param s Input date.
     * @return Returns date or 00000000 if the date string is null.
     */
    public static String checkNullDate(String s) {
        if (s.equalsIgnoreCase("00000000")) {
            return "(null)";
        }

        return s;
    }

    /**
     * This method is used to handle null value.
     *
     * @param keyValue Input for which null value need to check.
     * @return Blank if null or actual string.
     */
    public static String replaceInvalidValuewithBlank(String keyValue) {
        String retVal = null == keyValue ? "" : keyValue;
        return retVal;
    }

    public static String getValuationByName(DataSet dsSource, String entityName, String indicatorColId, String indicatorColValue, String actualColId) throws SapphireException {
        DataSet dsFilter = null;
        if (dsSource == null || dsSource.getRowCount() == 0) {
            throw new SapphireException("Source DataSet is null.");
        }
        if (entityName == null || entityName.equals("")) {
            throw new SapphireException("Entity name not passed.");
        }

        String targetDataSetGroupName = "";
        HashMap filter = new HashMap();
        filter.clear();
        filter.put(INPUT_DATASET_COLUMN_ENTITY_NAME, entityName);
        filter.put(INPUT_DATASET_COLUMN_COL_ID, indicatorColId);
        filter.put(INPUT_DATASET_COLUMN_COL_VALUE, indicatorColValue);
        dsFilter = dsSource.getFilteredDataSet(filter);

        if (dsFilter != null && dsFilter.getRowCount() > 0) {
            targetDataSetGroupName = dsFilter.getValue(0, INPUT_DATASET_COLUMN_GROUP, "");

            HashMap innerfilter = new HashMap();
            innerfilter.put(INPUT_DATASET_COLUMN_ENTITY_NAME, entityName);
            innerfilter.put(INPUT_DATASET_COLUMN_GROUP, targetDataSetGroupName);
            DataSet dsInnerFilter = dsSource.getFilteredDataSet(innerfilter);

            String targetString = getColumnValue(dsInnerFilter, entityName, actualColId);
            return targetString;
        }
        return "";
    }

    public static int getGroupCount(DataSet dsSource, String entityname) throws SapphireException {
        DataSet dsFilter = null;
        if (dsSource == null || dsSource.getRowCount() == 0) {
            throw new SapphireException("Source DataSet is null.");
        }
        if (entityname == null || entityname.equals("")) {
            throw new SapphireException("Entity name not passed.");
        }

        HashMap filter = new HashMap();
        filter.clear();
        filter.put(INPUT_DATASET_COLUMN_ENTITY_NAME, entityname);
        dsFilter = dsSource.getFilteredDataSet(filter);

        if (dsFilter != null && dsFilter.getRowCount() > 0) {

            String sortColumn = INPUT_DATASET_COLUMN_ENTITY_NAME + "," + INPUT_DATASET_COLUMN_GROUP;
            dsFilter.sort(sortColumn);
            ArrayList groupByGROUPArray = dsFilter.getGroupedDataSets(sortColumn);

            return groupByGROUPArray.size();
        }
        return 0;
    }

    public static ArrayList getAllGroup(DataSet dsSource, String entityname) throws SapphireException {
        DataSet dsFilter = null;
        if (dsSource == null || dsSource.getRowCount() == 0) {
            throw new SapphireException("Source DataSet is null.");
        }
        if (entityname == null || entityname.equals("")) {
            throw new SapphireException("Entity name not passed.");
        }
        if (!dsSource.isValidColumn(INPUT_DATASET_COLUMN_ENTITY_NAME)) {
            throw new SapphireException("Not a valid column in DataSet.");
        }

        HashMap filter = new HashMap();
        filter.put(INPUT_DATASET_COLUMN_ENTITY_NAME, entityname);
        dsFilter = dsSource.getFilteredDataSet(filter);
        if (dsFilter != null && dsFilter.getRowCount() > 0) {

            String sortColumn = INPUT_DATASET_COLUMN_ENTITY_NAME + "," + INPUT_DATASET_COLUMN_GROUP;
            dsFilter.sort(sortColumn);
            ArrayList groupByGROUPArray = dsFilter.getGroupedDataSets(sortColumn);

            return groupByGROUPArray;
        }
        return null;
    }

    /********************************************
     * Utility to get unique DataSet by columns.
     * @param dsSource Source DataSet .
     * @param colNames List of columns that need to be used for finding unique rows. If nothing passed then filter based on all columns.
     * @return Returns unique DataSet.
     * @throws SapphireException Throws a OOB Sapphire exception.
     ********************************************/
    public static DataSet getUniqueDataSet(ConnectionInfo connInfo, DataSet dsSource, String... colNames) throws SapphireException {
        // Target DataSet
        DataSet dsTarget = new DataSet(connInfo);
        // HashMap Filter
        PropertyList plFilter = new PropertyList();
        // If Source DataSet is NULL or BLANK then ERROR
        if (dsSource == null || dsSource.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, " Aborting transaction. Null / Blank DataSet value found.");
        }
        // If no columns passed then filter by all column
        if (colNames.length == 0) {
            colNames = dsSource.getColumns();
        }
        // adding columns to target from source
        for (int cols = 0; cols < colNames.length; cols++) {
            dsTarget.addColumn(colNames[cols], dsSource.getColumnType(colNames[cols]));
        }
        // Variable for new Row
        int newRow;
        // Looping the source DataSet
        for (int rowNum = 0; rowNum < dsSource.getRowCount(); rowNum++) {
            // Setting the filter HashMap
            for (int colNum = 0; colNum < colNames.length; colNum++) {
                // Filter value converted to UPPER case to make it case insensitive
                plFilter.setProperty(colNames[colNum], dsSource.getValue(rowNum, colNames[colNum], "").toUpperCase());
            }
            // If the row is not present in Target DataSet then copy.
            if (dsTarget.findRow(plFilter) == -1) {
                // Adding Target DS rows
                newRow = dsTarget.addRow();
                // Looping and setting column values
                for (int cols = 0; cols < colNames.length; cols++) {
                    dsTarget.setValue(newRow, colNames[cols], dsSource.getValue(rowNum, colNames[cols], "").toUpperCase());
                }
            }
            // Clearing filter HashMap
            plFilter.clear();
        }
        return dsTarget;
    }

    /**
     * This method used for checking if a service (Lot Receipt / Batch Master / Material Master) is ACTIVE for a given PLANT.
     *
     * @param qp        Handler for LV internal Query Processor
     * @param plantId   SAP Plant Id
     * @param serviceId Service Name
     * @return Returns TRUE / FALSE
     * @throws SapphireException Throws OOB Sapphire Exception
     */
    public static boolean validateSystemService(QueryProcessor qp, String plantId, String serviceId) throws SapphireException {

        if (plantId == null || plantId.equalsIgnoreCase("")) {
            String err = "Site ID is missing";
            throw new SapphireException(err);
        }
        if (qp == null) {
            String err = "Query processor is null.";
            throw new SapphireException(err);
        }

        String sql =
                "select sys.u_intfsystemid,sys.sysstatus, s.sitename, s.sitecode, s.sapsubsystem,s.sapplant, ser.serviceid, ser.servicestatus" +
                        " from u_intfsystem sys,u_intfsystemsites ss,u_sites s,u_intfsystemservice ser" +
                        " where sys.u_intfsystemid = ss.u_intfsystemid and ss.siteid = s.u_sitesid and sys.u_intfsystemid = ser.u_intfsystemid" +
                        " and ser.serviceid = ? and s.sapplant = ?";

        DataSet ds = qp.getPreparedSqlDataSet(sql, new Object[]{serviceId, plantId});
        if (ds == null || ds.size() == 0) {
            String err = "Master data for the site - " + plantId + " is not setup in LIMS.";
            throw new SapphireException(err);
        }

        String systemStatus = ds.getValue(0, "sysstatus", "");
        String serviceStatus = ds.getValue(0, "servicestatus", "");
        return systemStatus.equalsIgnoreCase("ACTIVE") && serviceStatus.equalsIgnoreCase("ACTIVE");

    }

    public static String getDateWithProperFormat(String dateStr, ConnectionInfo conInfo) throws SapphireException {

        if (dateStr == null || "".equals(dateStr) || "(null)".equalsIgnoreCase(dateStr)) {
            return "";
        }

        //SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy"); //dateStr format, you must know
        SimpleDateFormat sdf = new SimpleDateFormat(BatchMaster.BATCH_MASTER_DATE_FORMAT); //dateStr format, you must know
        DataSet dsDt = new DataSet(conInfo);
        dsDt.addColumn("dtcol", DataSet.DATE);

        int rowIdx = dsDt.addRow();
        sdf.setTimeZone(dsDt.getTimeZone());

        DateFormat defaultFormat = dsDt.getDateDisplayFormat("dtcol");
        Date dt;
        Date dtSubmitDate = null;

        try {

            dt = sdf.parse(dateStr);
            dtSubmitDate = defaultFormat.parse(defaultFormat.format(dt));

        } catch (ParseException e) {
            throw new SapphireException(e.getMessage());
        }

        if (dtSubmitDate == null) {
            return null;
        }

        dsDt.setDate(rowIdx, "dtcol", dtSubmitDate.getTime());
        String strMyDate = "";
        strMyDate = dsDt.getValue(0, "dtcol", null);

        return strMyDate;

    }

    /******************************************************************
     * This method is used to format a Date in given format and timezone
     * @param inputDateString Input date string
     * @param dateFormat Date format
     * @param timeZone Timezone if blank
     * @return Date string
     * @throws SapphireException OOB Sapphire Exception
     *******************************************************************/
    public static String getDateStringWithProperFormat(String inputDateString, String dateFormat, String timeZone, com.labvantage.sapphire.services.ConnectionInfo conInfo) throws SapphireException {
        // Creating date formatter
        Date dt;
        String dateToString = "";
        DataSet dsDate = new DataSet(conInfo);
        if (!dsDate.isValidColumn("datecol")) {
            dsDate.addColumn("datecol", DataSet.DATE);
        }
        int dateRow = dsDate.addRow();
        Calendar cal = Calendar.getInstance();
        TimeZone timezone = TimeZone.getTimeZone(timeZone);
        cal.setTimeZone(timezone);
        // Return blank if input date is not found.
        if (inputDateString.equalsIgnoreCase("")) {
            SimpleDateFormat dtf = new SimpleDateFormat(dateFormat);
            inputDateString = dtf.format(cal.getTime());
        }

        try {
            DateFormat sdf = new SimpleDateFormat(dateFormat);
            sdf.setTimeZone(timezone);
            dt = sdf.parse(inputDateString);
            dsDate.setDateDisplayFormat("datecol", sdf);
            dsDate.setDate(dateRow, "datecol", dt.getTime());
            dateToString = dsDate.getTimestamp(dateRow, "datecol").toString();
        } catch (ParseException e) {
            throw new SapphireException(e.getMessage());
        }
        return dateToString;
    }

    public static String removeLeadingZeroes(String input) {
        int count = 0;
        while (count < input.length() && input.charAt(count) == '0') {

            count++;
        }
        StringBuffer sb = new StringBuffer(input);
        sb.replace(0, count, "");

        return sb.toString();
    }

    /**
     * Validate processassysuserid passed as a property to recurring task PollerFetchSAPMessage
     *
     * @param qp
     * @param sysuserid
     * @return boolean
     * @throws SapphireException
     */
    public static boolean validateProcessAsSysuserId(QueryProcessor qp, String sysuserid) {

        if ("".equals(sysuserid)) {
            return true;
        }

        String sql = "select sysuserid from sysuser where sysuserid = ? ";
        DataSet ds = qp.getPreparedSqlDataSet(sql, new Object[]{sysuserid});
        return ds != null && ds.size() != 0;

    }

    /**
     * Forms Multiple IN Clause for SQL Query based on the columnid, value and the size for each IN Clause
     *
     * @param columnid
     * @param colValue
     * @param
     * @return String
     */
    public static String formMultipleInWithOrForWhereClause(String columnid,
                                                            String colValue,
                                                            int size) {
        String ret = "";
        String arrColValues[] = StringUtil.split(colValue, ";");
        int colValuesSize = arrColValues.length;
        int colValuesSizeQ = colValuesSize / size;
        int colValuesSizeR = colValuesSize % size;
        if (colValuesSizeR != 0) {
            colValuesSizeR = 1;
        }
        int totLoop = colValuesSizeQ + colValuesSizeR;
        for (int idx = 0; idx < totLoop; idx++) {
            int startIndex = size * idx;
            int endIndex = (size * idx) + size;
            ret += columnid + " in (";
            for (int i = startIndex; i < endIndex; i++) {
                if (i < arrColValues.length) {
                    ret += "'" + arrColValues[i];
                    if (i != (endIndex - 1)) {
                        if ((i + 1) == arrColValues.length) {
                            ret += "')";
                        } else {
                            ret += "',";
                        }
                    } else {
                        ret += "')";
                        if (idx != (totLoop - 1)) {
                            ret += " or ";
                        }
                    }
                }
            }
        }
        return ret;
    }


}


