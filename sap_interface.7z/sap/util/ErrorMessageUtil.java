package labvantage.custom.alcon.sap.util;


/**
 * $Author: GHOSHKA1 $
 * $Date: 2022-02-07 11:20:26 -0600 (Mon, 07 Feb 2022) $
 * $Revision: 716 $
 */

/*******************************************************************
 * $Revision: 716 $
 * Description: Util class for storing the validation/error message(s).
 *
 *******************************************************************/

public class ErrorMessageUtil {
    public static final String DEVOPS_ID = "$Revision: 716 $";
    public static String GENERAL_ERROR = "General Error.";
    public static String INVALID_SAP_DATA_PAYLOAD = " Aborting Transaction. Invalid SAP Data Payload Received - Batch can't be processed. ";
    public static String INVALID_BATCH_TYPE = " Aborting Transaction. Invalid Batch Type.";
    public static String PARENT_BATCH_MULTIPLE_PV = " Aborting Transaction. BAT Batch can't have multiple Product Variant. Master Data setup is wrong. ";
    public static String CANCELLED_BATCH = " Aborting Transaction. Batch status is cancelled.";
    public static String PARENT_REJECTED_BATCH = " Aborting Transaction. Parent batch %s is in Rejected status.";
    public static String CANCEL_BATCH_WITH_NO_OPEN_BATCH = " Aborting Inspection Lot Cancellation. LIMS Batch doesn't exist. ";
    public static String BATCH_EXIST = " Aborting Transaction. There is already an Open Batch.";
    public static String FAILED_TO_CANCEL = " Aborting Transaction. Failed to Cancel Batch.";
    public static String FAILED_TO_MARK_AS_CANCEL = " Aborting Transaction. Failed to mark LIMS Batch for Cancellation.";
    public static String NULL_DATASET_FOUND = " Aborting Transaction. DataSet is null.";
    public static String FAILED_TO_EXECUTE_GENEALOGY = " Aborting Transaction. Failed to execute genealogy.Error is %s";
    public static String ONLY_RAW_MATERIAL_PARENT_BATCH = " Aborting Transaction. Payload contains only raw material parent batch information.";
    public static String NO_ROW_FOUND = " Aborting Transaction. DataSet contains no row. ";
    public static String BlANK_VALUE = " Aborting Transaction. Blank or Null value found.";
    public static String NULL_VALUE_FOUND = " Aborting Transaction. Null value found for field %s";
    public static String NULL_OR_BlANK_VALUE = " Aborting Transaction. Blank or Null value found for the field %s.";
    public static String NULL_SQL_VALUE = " Aborting Transaction. Failed to execute SQL. ";
    public static String FAILED_EXECUTING_LIMS_MATERIALID = " Aborting Transaction. Failed to find LIMS material id. ";
    public static String FAILED_EXECUTING_BATCH = " Aborting Transaction. Failed to execute Batch. ";
    public static String NO_PROD_VAR_FOUND = " Aborting Transaction. No Product Variant found. ";
    public static String FAILED_EXECUTING_PROD_VAR = " Aborting Transaction. Failed to execute Product Variant. ";
    public static String DUPLICATE_PROD_VAR_FOUND = " Aborting Transaction. Duplicate product variant found. ";
    public static String FAILED_EXECUTING_PROD_ID = " Aborting Transaction. Failed to execute Product Id. ";
    public static String NO_PROD_ID_FOUND = " Aborting Transaction. No Product Id found. ";
    public static String PARENT_BATCH_NOT_FOUND = "Aborting Transaction. Parent LIMS Batch details not found.";
    public static String INCORRECT_MASTERDATA_SETUP = " Aborting Transaction. Master Data Setup is incorrect. ";
    public static String MORE_THAN_ONE_LIMS_MATERIALID_FOUND = " Aborting Transaction. More than one LIMS Material Id found. ";
    public static String MANDATORY_KEY_NOT_FOUND = " Aborting transaction. Mandatory key %s not found.";
    public static String MANDATORY_KEY_NOT_FOUND_FOR_EN_LANG = " Aborting transaction. Mandatory key %s not found for english(SPRAS=E) language.";
    // All VisionCare RM error messages
    public static String RM_ERR_00000 = " [RM_ERR_00000] Aborting transaction. Mandatory key %s not found in payload.";
    public static String RM_ERR_00001 = " [RM_ERR_00001] Aborting transaction. Mandatory key %s can't be blank.";
    public static String RM_ERR_00002 = " [RM_ERR_00002] Aborting transaction. No pre-shipment sample found for LIMS Batch Id: %s , Product Varinat: %s  and Sampling Plan Id : %s [Ver. %s] ";
    public static String RM_ERR_00003 = " [RM_ERR_00003] Aborting transaction. First-shipment stage type not found in current sampling plan. Check if Stage Type is defined or Process Stage Count is not 0.";
    public static String RM_ERR_00004 = " [RM_ERR_00004] Aborting transaction. Unable to add first-shipment samples. Batch is in %s status. LIMS Batch Id: %s ";
    public static String RM_ERR_00005 = " [RM_ERR_00005] Aborting transaction. Repeat shipment stage type not found in current sampling plan for sampling plan id %s [Ver.%s]. Check if Stage Type is defined or Process Stage Count is not 0.";
    public static String RM_ERR_00006 = " [RM_ERR_00006] Aborting transaction. Unable to add %s samples. Batch is in %s status. LIMS Batch Id: %s ";
    public static String RM_ERR_00007 = " [RM_ERR_00007] Aborting transaction. Unable to create new LIMS batch. MES ORDER RESTRICTION is set to Yes.";
    public static String RM_ERR_00008 = " [RM_ERR_00008] Aborting transaction. Unable to create new LIMS batch. There is already an open LIMS batch %s for %s , Material# : %s and Plant : %s";
    public static String RM_ERR_00009 = " [RM_ERR_00009] Aborting transaction. No batch stage id found in current sampling plan( %s [%s] ) for sample label %s, source label %s and level %s";
    public static String RM_ERR_00010 = " [RM_ERR_00010] Aborting transaction. No label found for process stage id %s";
    public static String RM_ERR_00011 = " [RM_ERR_00011] Aborting transaction. No process stage details found for sampling plan id %s and version id %s";
    public static String RM_ERR_00012 = " [RM_ERR_00012] Aborting transaction. No level samples details found in logged in version of sampling plan ";
    public static String RM_ERR_00013 = " [RM_ERR_00013] Aborting transaction. %s sample count is not zero.";
    public static String RM_ERR_00014 = " [RM_ERR_00014] Aborting transaction. More than one level details found in current sampling plan found for LIMS Batch Id: %s , Product Varinat: %s , Sampling Plan Id : %s [Ver. %s] and stage type %s.";
    public static String RM_ERR_00015 = " [RM_ERR_00015] Aborting transaction. There is no level details found in current sampling plan for stage type %s.";
    public static String RM_ERR_00016 = " [RM_ERR_00016] Aborting transaction. There is no current version of product id %s available.";
    public static String RM_ERR_00017 = " [RM_ERR_00017] Aborting transaction. While adding Sample maximum Sample sequence# not found for LIMS batch id %s.";
    public static String RM_ERR_00018 = " [RM_ERR_00018] Aborting Transaction. No Product Variant found for SAP Batch# %s , SAP Material # %s, SAP Plant %s and SAP Vendor# %s";
    public static String RM_ERR_00019 = " [RM_ERR_00019] Aborting Transaction. Duplicate product variant found but no default product variant found for SAP Batch# %s , SAP Material # %s and SAP Plant %s";
    public static String RM_ERR_00020 = " [RM_ERR_00020] Aborting Transaction. Duplicate Default Product Variant found for SAP Batch# %s , SAP Material # %s and SAP Plant %s";
    public static String RM_ERR_00021 = " [RM_ERR_00021] Aborting Transaction. Multiple Product Variant having same SAP vendor # : %s";
    public static String RM_ERR_00022 = " [RM_ERR_00022] Aborting Transaction. While processing cancel request , No LIMS Batch found for SAP Batch %s , SAP Material # %s and SAP Plant %s";
    public static String RM_ERR_00023 = " [RM_ERR_00023] Aborting Transaction. No sample(s) found for cancellation for inspection lot # %s";
    public static String RM_ERR_00024 = " [RM_ERR_00024] Aborting Transaction. No current sampling plan found for product variant %s";
    public static String RM_ERR_00025 = " [RM_ERR_00025] Aborting transaction. While creating new raw material batch, pre-shipment stage type found in current sampling plan for SAP Batch : %s , SAP Material # : %s and SAP Plant %s ";
    public static String RM_ERR_00026 = " [RM_ERR_00026] Aborting transaction. Retest stage type not found in current sampling plan for sampling plan id %s [Ver.%s]. Check if Stage Type is defined or Process Stage Count is not 0.";

    public static String RM_FOR_FIELDS = " For SAP Batch#: %s , SAP Material#: %s and SAP Plant: %s.";
    public static String RM_LIMS_BATCH_NOT_EXIST = " Aborting transaction. LIMS Batch doesn't exist. ";
    public static String RM_BATCH_TEMPLATE_NOT_FOUND = " Aborting transaction. No batch template defined for batch type %s in %s policy. Please conatct your system administrator ";
    public static String RM_NO_PLANT_FOUND = " Aborting transaction. No site configured against SAP plant %s";
    public static String RM_FAILED_RECEIVE_BATCH = " Aborting transaction. Failed to receive LIMS batch %s. Please contact system administrator";

    // All Aspetic RM Error Messages
    public static String ASEPTIC_RM_ERR_00000 = " [ASEPTIC_RM_ERR_00000] Aborting transaction. Mandatory key %s not found in payload.";
    public static String ASEPTIC_RM_ERR_00001 = " [ASEPTIC_RM_ERR_00001] Aborting transaction. Mandatory key %s can't be blank.";
    public static String ASEPTIC_RM_ERR_00002 = " [ASEPTIC_RM_ERR_00002] Aborting Transaction. There is already an open LIMS Batch: %s in %s status for SAP Batch# : %s , SAP Material# : %s and SAP Plant : %s.";
    public static String ASEPTIC_RM_ERR_00003 = " [ASEPTIC_RM_ERR_00003] Aborting Transaction. No Product Variant found for SAP Batch# %s , SAP Material # %s, SAP Plant %s and SAP Vendor# %s";
    public static String ASEPTIC_RM_ERR_00004 = " [ASEPTIC_RM_ERR_00004] Aborting Transaction. Duplicate product variant found but no default product variant found for SAP Batch# %s , SAP Material # %s and SAP Plant %s";
    public static String ASEPTIC_RM_ERR_00005 = " [ASEPTIC_RM_ERR_00005] Aborting Transaction. Duplicate Default Product Variant found for SAP Batch# %s , SAP Material # %s and SAP Plant %s";
    public static String ASEPTIC_RM_ERR_00006 = " [ASEPTIC_RM_ERR_00006] Aborting Transaction. Multiple Product Variant having same SAP vendor # : %s for SAP Batch# %s , SAP Material # %s and SAP Plant %s .";
    public static String ASEPTIC_RM_ERR_00007 = " [ASEPTIC_RM_ERR_00007] Aborting Transaction. No LIMS Batch found for cancellation for Inspection Lot# : %s , SAP Batch : %s , SAP Material# : %s and SAP Plant %s .";
    public static String ASEPTIC_RM_ERR_00008 = " [ASEPTIC_RM_ERR_00008] Aborting Transaction. Failed to cancel LIMS Batch id: %s . Error is %s .";
    public static String ASEPTIC_RM_ERR_00009 = " [ASEPTIC_RM_ERR_00009] Aborting Transaction. Failed to mark batch for cancellation for LIMS Batch id: %s . Error is %s .";

}
