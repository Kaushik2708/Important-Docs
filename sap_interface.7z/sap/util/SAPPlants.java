package labvantage.custom.alcon.sap.util;
/**
 * $Author: BAGCHAN1 $
 * $Date: 2021-10-05 23:27:54 +0530 (Tue, 05 Oct 2021) $
 * $Revision: 613 $
 */

/*******************************************************************
 * $Revision: 613 $
 * Description: Util class for SAP Plants.
 *
 *******************************************************************/

public class SAPPlants {
    public static final String DEVOPS_ID = "$Revision: 613 $";
    // Vision care plants
    public static final String PROPS_VISION_CARE_PLANT_U612 = "U612";
    public static final String PROPS_VISION_CARE_PLANT_SG03 = "SG03";
    public static final String PROPS_VISION_CARE_PLANT_ID01 = "ID01";
    public static final String PROPS_VISION_CARE_PLANT_MY10 = "MY10";
    // Aspetic plants
    public static final String PROPS_ASEPTIC_PLANT_U630 = "U630";
    public static final String PROPS_ASEPTIC_PLANT_SG20 = "SG20";
    public static final String PROPS_ASEPTIC_PLANT_U636 = "U636";

}
