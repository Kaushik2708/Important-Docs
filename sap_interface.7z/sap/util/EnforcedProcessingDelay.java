package labvantage.custom.alcon.sap.util;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.util.Logger;
import sapphire.xml.PropertyList;

/**
 * $Author: BAGCHAN1 $
 * $Date: 2021-09-24 06:42:54 +0530 (Fri, 24 Sep 2021) $
 * $Revision: 576 $
 *
 * @author Aniruddha Bagchi
 */

/**
 * $Revision: 576 $
 * Description: The action is responsible to introduce delay in the process when necessary. Input to the action is the delay in seconds (defaulted to 5 seconds if valid input is not passed)
 */
public class EnforcedProcessingDelay extends BaseAction {
    private static final String DEVOPS_ID = "$Revision: 576 $";
    private static final String __DEFAULT_DELAY = "5";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String delayInSeconds = properties.getProperty("delay", "").trim();

        if ("".equals(delayInSeconds)) {
            delayInSeconds = __DEFAULT_DELAY;
        }

        try {
            if (Integer.parseInt(delayInSeconds) != Integer.parseInt(delayInSeconds)) {
                delayInSeconds = __DEFAULT_DELAY;
            }
        } catch (NumberFormatException e) {
            delayInSeconds = __DEFAULT_DELAY;
        }

        try {
            Thread.sleep(Long.parseLong(delayInSeconds) * 1000);
        } catch (InterruptedException e) {
//            e.printStackTrace();
            Logger.logError(" ######### FAILED TO SLEEP FOR DEFINED PERIOD: " + delayInSeconds + " ##########");
        }

    }
}
