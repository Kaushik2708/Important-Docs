package labvantage.custom.alcon.sap.action;


import sapphire.SapphireException;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.net.InetAddress;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;

/**
 * $Author: BAGCHAN1 $
 * $Date: 2021-07-02 15:39:03 -0500 (Fri, 02 Jul 2021) $
 * $Revision: 379 $
 */

/***************************************************************
 * $Revision: 379 $
 * Description:
 * This class is used to fetch the Data from SAP message table.
 *
 * @author Aniruddha Bagchi
 * @version 1
 ****************************************************************/


public class FetchSAPMessage extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 379 $";
    public static final String ID = "FetchSAPMessage";
    public static final String VERSIONID = "1";
    public static final String PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "processassysuserid";
    public String VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "";

    /**
     * Description: processAction is an OOB LabVantage method. This is the main method where execution starts.
     *
     * @param properties
     */

    @Override
    public void processAction(PropertyList properties) {
        logger.info("--------- Processing Action:" + ID + ", Version:" + VERSIONID + "---------");

        VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = properties.getProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, "");

        StringBuilder errMsg = new StringBuilder().append("  ");
        try {
            // 1. Checking Mandatory Fields.
            // Todo Uncomment
            // checkMadatoryFields(properties);
            // 2. Processing Message Payload.
            processSAPMessage();
        } catch (SapphireException ex) {
            errMsg.append(" Failed to execute Action: " + ID + ", Version: " + VERSIONID + ". Error details is: ").append("\r\n").append(ex.getMessage());
            logger.error(errMsg.toString());
        } catch (Exception e) {
            errMsg.append(" Failed to execute Action: " + ID + ", Version: " + VERSIONID + ". Error details is: ").append("\r\n").append(e.getMessage());
            logger.error(errMsg.toString());
        }
        logger.info("--------- Processed Action:" + ID + ", Version:" + VERSIONID + "---------");
    }

    /**
     * Description: This method is used to check the mandatory fields.
     *
     * @param props
     * @throws SapphireException
     */

    private void checkMadatoryFields(PropertyList props) throws SapphireException {
        // Getting Iterator object for iterating property list
        StringBuilder errMsg = new StringBuilder().append("");
        Iterator propertyIterator = props.entrySet().iterator();
        while (propertyIterator.hasNext()) {
            Map.Entry property = (Map.Entry) propertyIterator.next();
            String propValue = property.getValue().toString();
            if (null == propValue || "".equalsIgnoreCase(propValue)) {
                errMsg.append(" Mandatory field ").append(property.getKey()).append(" can't be Blank or Null!!!");
                throw new SapphireException(errMsg.toString());
            }
        }
    }

    /**
     * Description: This method is used process the message payload.
     *
     * @throws Exception
     */


    private void processSAPMessage() throws Exception {
        // 1. Checking SAPMessageIds having Null Status
        DataSet dsNullSAPMessage = getSAPMsgByStatus(null);
        if (dsNullSAPMessage.getRowCount() > 0) {
            // 2. Setting Process Status from Null to Pending
            updateSAPMessage(dsNullSAPMessage, "PENDING");
        }

        PropertyList prop = new PropertyList();
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, ProcessFetchedSAPMessage.ID);
        prop.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, ProcessFetchedSAPMessage.VERSIONID);
        //prop.setProperty(AddToDoListEntry.PROPERTY_DELETE, "Y");
        prop.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, "n");

        prop.setProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

        getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, prop);

        //DEVELOPER COMMENT FOR REVIEW: Put all the commented lines in a different action called ProcessFetchedSAPMessage.
        // 3. Getting Pending Payloads
        /*DataSet dsPendingSAPMsg = getSAPMsgByStatus("PENDING");
        if (dsPendingSAPMsg.getRowCount() > 0) {
            dsPendingSAPMsg.sort("createdt");
            String msgStageId = "";
            String serviceName = "";
            String payload = "";
            try {
                for (int row = 0; row < dsPendingSAPMsg.getRowCount(); row++) {
                    msgStageId = dsPendingSAPMsg.getValue(row, "u_saplvmessagestageid", "");
                    serviceName = dsPendingSAPMsg.getValue(row, "servicename", "");
                    payload = dsPendingSAPMsg.getClob(row, "msgpayload", "");
                    // 4. Passing payload to LVInbound Action
                    callLVInbound(msgStageId,serviceName, payload);
                }
            } catch (SapphireException ex) {
                //Todo: Nothing
            } finally {
                updateSAPMessage(dsPendingSAPMsg, "DONE");
            }
        }*/
    }

    /**
     * Description: This method is used to check the null status.
     *
     * @param status
     * @return
     * @throws SapphireException
     */

    private DataSet getSAPMsgByStatus(String status) throws SapphireException {

        StringBuilder errMsg = new StringBuilder().append("  ");
        StringBuilder sqlText = new StringBuilder().append(" select TO_NUMBER(u_saplvmessagestageid) u_saplvmessagestageid, servicename, msgpayload, createdt from u_saplvmessagestage");
        if (null == status) {
            sqlText.append(" where processingstatus is null");
        } else {
            sqlText.append(" where processingstatus='").append(status).append("'");
        }
        sqlText.append(" and createdt <= (sysdate - interval '15' second)");

        DataSet dsMsgStatus = getQueryProcessor().getSqlDataSet(sqlText.toString(), true);

        if (null == dsMsgStatus) {
            errMsg.append(" Unable to execute SAPLVMessageStage status details");
            logger.error(errMsg.toString());
            throw new SapphireException(errMsg.toString());
        } else {
            dsMsgStatus.sort("createdt, u_saplvmessagestageid");
            return dsMsgStatus;
        }
    }

    /**
     * Description: This method is used to set Process Status.
     *
     * @param dsMsgIds
     * @param Status
     * @throws Exception
     */

    private void updateSAPMessage(DataSet dsMsgIds, String Status) throws Exception {

        StringBuilder sqlText = new StringBuilder().append("update u_saplvmessagestage set processingstatus = ? ,");
        if ("PENDING".equalsIgnoreCase(Status)) {
            sqlText.append(" processpendingdt = sysdate, processpendingserver = ? where  u_saplvmessagestageid = ?");
        } else if ("DONE".equalsIgnoreCase(Status)) {
            sqlText.append("processdonedt = sysdate, processdoneserver = ? where  u_saplvmessagestageid = ?");
        }
        try {
            PreparedStatement psMsgUpdate = database.prepareStatement(sqlText.toString());
            for (int row = 0; row < dsMsgIds.getRowCount(); row++) {
                try {
                    psMsgUpdate.setString(1, Status);
                    psMsgUpdate.setString(2, getServerDetails());
                    psMsgUpdate.setString(3, dsMsgIds.getValue(row, "u_saplvmessagestageid"));
                    psMsgUpdate.addBatch();
                } catch (SQLException ex) {
                    throw new SapphireException("Unable to set Prepared Statement:Reason:" + ex.getMessage());
                }
            }
            try {
                psMsgUpdate.executeBatch();
                psMsgUpdate.clearParameters();
                psMsgUpdate.clearBatch();
                psMsgUpdate.close();
            } catch (SQLException e) {
                throw new SapphireException("Failed to execute Staging update:Reason:" + e.getMessage());
            } finally {
                psMsgUpdate.close();
            }
        } catch (SQLException se) {
            throw new SapphireException("Error encountered during updating staging table. " + se.getMessage());
        }

    }

    /**
     * Description: This method is used to fetch the server details.
     *
     * @return
     * @throws Exception
     */

    private String getServerDetails() throws Exception {
        StringBuilder errMsg = new StringBuilder().append(" ");
        InetAddress ip;
        try {
            ip = InetAddress.getLocalHost();

        } catch (Exception e) {
            errMsg.append(" Can't get the Server Address. ");
            logger.error(errMsg.toString());
            throw new Exception(errMsg.toString());
        }
        return ip.toString();
    }

    /**
     * Description: This method is used to pass the data from staging table to Inbound service.
     *
     * @param servicename
     * @param payload
     * @throws SapphireException
     */
/*
    private void callLVInbound(String msgStageId, String servicename, String payload) throws SapphireException {
        StringBuilder errMsg = new StringBuilder().append("  ");
        PropertyList plSAPService = new PropertyList();
        plSAPService.setProperty(SAPLVInbound.PROP_MSG_STAGE_ID, msgStageId);
        plSAPService.setProperty(SAPLVInbound.PROP_PAY_LOAD, payload);
        plSAPService.setProperty(SAPLVInbound.PROP_SERVICE_NAME, servicename);
        plSAPService.setProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);
        getActionProcessor().processAction(SAPLVInbound.ID, SAPLVInbound.VERSIONID, plSAPService, true);
    }
 */
}
