package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.sap.util.ErrorMessageUtil;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * $Author: GHOSHKA1 $
 * $Date: 2021-10-05 10:08:04 -0500 (Tue, 05 Oct 2021) $
 * $Revision: 609 $
 */

/********************************************************************************************
 * $Revision: 609 $
 * Description:
 * This class is for Aspetic Raw Material Result Upload data setup.
 *
 * @author Kaushik Ghosh
 * @version 1
 *******************************************************************************************/

public class Aseptic_RM_SetSAPResults extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 609 $";
    public static final String ID = "Aseptic_RM_SetSAPResults";
    public static final String VERSIONID = "1";
    // Batch columns
    private static final String __PROPS_BATCH_SDCID = "Batch";
    private static final String __PROPS_LIMS_BATCH_ID = "s_batchid";
    private static final String __PROPS_LIMS_BATCH_TYPE = "batchtype";
    private static final String __PROPS_SAP_PLANT = "u_sapplant";
    private static final String __PROPS_SAP_LAB_CONF_NUM = "u_saplabconfnum";
    private static final String __PROPS_SAP_SELECTED_SET = "u_sapselectedset";
    // Batch Types
    private static final String __PROPS_BATCHTYPE_RAW_MATERIAL = "Raw Material";
    private static final String __PROPS_BATCHTYPE_INTERMEDIATE = "Intermediate";
    private static final String __PROPS_BATCHTYPE_FINISHED = "Finished";
    // SAP Test Name
    private static final String __PROPS_KURZTEXT_LAB_SYSTEM_CONF_NUM = "Laboratory System Confirmation";
    // SDIDataItem columns
    private static final String __RESULTUPLOAD_SAPLABCONFNO = "RESULTUPLOAD_SAPLABCONFNO";
    private static final String __RESULTUPLOAD_SAPSELECTEDSET = "RESULTUPLOAD_SAPSELECTEDSET";
    private static final String __RESULTUPLOAD_SAMPLEID = "sampleid";
    private static final String __RESULTUPLOAD_PARAMLISTID = "paramlistid";
    private static final String __RESULTUPLOAD_PARAMLISTVERSIONID = "paramlistversionid";
    private static final String __RESULTUPLOAD_PARAMLISTVARINATID = "paramlistvariantid";
    private static final String __RESULTUPLOAD_PARAMID = "paramid";
    // Plants
    private static final String __PROPS_ASEPTIC_PLANT_SG20 = "SG20";
    private static final String __PROPS_ASEPTIC_PLANT_U630 = "U630";
    private static final String __PROPS_ASEPTIC_PLANT_U636 = "U636";

    // Hashmap for mandatory fileds
    private static HashMap<String, String> hmMandatoryFields = null;

    // For additional mandatory checks
    // Just add an entry in this HashMap --> hmMandatoryFields
    static {
        hmMandatoryFields = new PropertyList();
        hmMandatoryFields.put(__PROPS_LIMS_BATCH_ID, "LIMS Batch Id");
        hmMandatoryFields.put(__PROPS_LIMS_BATCH_TYPE, "LIMS Batch Type");
        hmMandatoryFields.put(__PROPS_SAP_PLANT, "SAP Plant");
        hmMandatoryFields.put(__PROPS_SAP_LAB_CONF_NUM, "SAP Lab Confirmation Number");
        hmMandatoryFields.put(__PROPS_SAP_SELECTED_SET, "SAP Selected Set");
    }

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("=============== Start Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
        String limsBatchId = properties.getProperty(__PROPS_LIMS_BATCH_ID, "");
        String sapLabConfNumber = properties.getProperty(__PROPS_SAP_LAB_CONF_NUM, "");
        String sapSelectedSet = properties.getProperty(__PROPS_SAP_SELECTED_SET, "");
        String batchType = properties.getProperty(__PROPS_LIMS_BATCH_TYPE, "");
        String sapPlant = properties.getProperty(__PROPS_SAP_PLANT, "");
        // Todo need to implement mandatory check
        // ******** pass the values to function for Batch Type decision
        setSAPResultsByType(limsBatchId, sapPlant, batchType, sapSelectedSet, sapLabConfNumber);
        logger.info("=============== End Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
    }


    /*******************
     * This method is used to decide batch type
     * @param limsBatchId
     * @param sapPlant
     * @param batchType
     * @param sapSelectedSet
     * @param sapLabConfNum
     * @throws SapphireException
     *******************/
    private void setSAPResultsByType(String limsBatchId, String sapPlant, String batchType, String sapSelectedSet, String sapLabConfNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside setSAPResultsByType (method)");
        switch (batchType) {
            case __PROPS_BATCHTYPE_RAW_MATERIAL:
                // ****** Calling function to set result upload data for Batch Type raw Material
                setAseptic_RM_SAPResultsByPlant(limsBatchId, sapPlant, sapSelectedSet, sapLabConfNum);
                break;
            case __PROPS_BATCHTYPE_INTERMEDIATE:
                // ****** Calling function to set result upload data for Batch Type Intermediate
                setAseptic_RM_SAPResultsByPlant(limsBatchId, sapPlant, sapSelectedSet, sapLabConfNum);
                break;
            case __PROPS_BATCHTYPE_FINISHED:
                // todo ****** Calling function to set result upload data for Batch Type Finished
                setAseptic_FN_SAPResultsByPlant(limsBatchId, sapPlant, sapSelectedSet, sapLabConfNum);
                break;
            default:
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Not a valid batch type " + batchType));
        }
    }

    private void setAseptic_FN_SAPResultsByPlant(String limsBatchId, String sapPlant, String sapSelectedSet, String sapLabConfNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside setSAPResultsByPlant (method)");
        switch (sapPlant) {
            case __PROPS_ASEPTIC_PLANT_SG20:
                // ****** Calling function to set result upload data for Batch Type raw Material
                //setSAPResultsByPlant(limsBatchId, sapPlant, sapSelectedSet, sapLabConfNum);
                break;
            case __PROPS_ASEPTIC_PLANT_U630:
                // ****** Calling function to set result upload data for Batch Type Intermediate
                //setSAPResultsByPlant(limsBatchId, sapPlant, sapSelectedSet, sapLabConfNum);
                break;
            case __PROPS_ASEPTIC_PLANT_U636:
                // todo ****** Calling function to set result upload data for Batch Type Finished
                //setSAPResultsByPlant(limsBatchId, sapPlant, sapSelectedSet, sapLabConfNum);
                break;
            default:
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Not a valid Aspetic SAP Plant " + sapPlant));
        }

    }

    private void setAseptic_RM_SAPResultsByPlant(String limsBatchId, String sapPlant, String sapSelectedSet, String sapLabConfNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside setSAPResultsByPlant (method)");
        switch (sapPlant) {
            case __PROPS_ASEPTIC_PLANT_SG20:
                // ****** Calling function to set result upload data for Batch Type raw Material
                setAsepticRMSAPResultData(limsBatchId, sapSelectedSet, sapLabConfNum);
                break;
            case __PROPS_ASEPTIC_PLANT_U630:
                // ****** Calling function to set result upload data for Batch Type Intermediate
                setAsepticRMSAPResultData(limsBatchId, sapSelectedSet, sapLabConfNum);
                break;
            case __PROPS_ASEPTIC_PLANT_U636:
                // ****** Calling function to set result upload data for Batch Type Finished
                setAsepticRMSAPResultData(limsBatchId, sapSelectedSet, sapLabConfNum);
                break;
            default:
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Not a valid Aspetic SAP Plant " + sapPlant));
        }
    }


    /**
     * This method is used to set SAP Test(QAIMV-KURZTEXT) results to support RESULT UPLOAD service.
     * If SAP Test is Laboratory System Confimtaion then corresponding details are stored in Batch Table.
     * Else for all other SAP Tests, details are added at LIMS Data Entry level.
     *
     * @param limsBatchId    LIMS Batch Id for which SAP Test details to be added.
     * @param sapSelectedSet
     * @param sapLabConfNum
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private void setAsepticRMSAPResultData(String limsBatchId, String sapSelectedSet, String sapLabConfNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside setAsepticFNSAPResultData (method)");

        // Setting Characteristics at SDIDataItem for Result Upload
        DataSet dsSDIDataItems = getResultUploadParams(limsBatchId, __PROPS_KURZTEXT_LAB_SYSTEM_CONF_NUM, sapLabConfNum);
        // Creating columns for SAP Selected Set and SAP Lab Confirmation Number
        if (!dsSDIDataItems.isValidColumn(__RESULTUPLOAD_SAPLABCONFNO)) {
            dsSDIDataItems.addColumn(__RESULTUPLOAD_SAPLABCONFNO, DataSet.STRING);
        }
        if (!dsSDIDataItems.isValidColumn(__RESULTUPLOAD_SAPSELECTEDSET)) {
            dsSDIDataItems.addColumn(__RESULTUPLOAD_SAPSELECTEDSET, DataSet.STRING);
        }

        // Looping thorugh the parameters and setting SAP Selected Set and SAP Lab Confirmation Number
        for (int sdiNo = 0; sdiNo < dsSDIDataItems.getRowCount(); sdiNo++) {
            //Updating SDIDataItem
            dsSDIDataItems.setValue(sdiNo, __RESULTUPLOAD_SAPLABCONFNO, sapLabConfNum);
            dsSDIDataItems.setValue(sdiNo, __RESULTUPLOAD_SAPSELECTEDSET, sapSelectedSet);
        }
        if (dsSDIDataItems != null && dsSDIDataItems.getRowCount() > 0) {
            updateSDIDataItem(dsSDIDataItems);
        }
    }

    /**
     * This method is used to update SAP Lab Confirmation Number and SAP Selected Set for each SAP Characteristics except Laboratory Syste Confirmation.
     *
     * @param dsSAPTestDetails Input DataSet containing all SAP characteristic details except Laboratory System Confirmation.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private void updateSDIDataItem(DataSet dsSAPTestDetails) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside updateSDIDataItem (method)");
        // Reading SDIDataItem Column from Test Details except Laboratory System Confirmation
        try {
            String sqlStmt = "";
            if (database.isOracle()) {
                sqlStmt = "UPDATE SdiDataItem SET u_sapconfnum = ?,u_sapselectedset = ? WHERE sdcid = 'Sample' AND keyid1 = ? AND paramlistid = ? AND paramlistversionid = ? AND variantid = ? AND paramid = ? ";
            } else if ((database.isSqlServer())) {
                // if DataBase migrated to SQL Server
            }
            PreparedStatement psSDIDataItemMap = database.prepareStatement(sqlStmt);
            for (int testNo = 0; testNo < dsSAPTestDetails.getRowCount(); testNo++) {
                try {
                    psSDIDataItemMap.setString(1, dsSAPTestDetails.getValue(testNo, __RESULTUPLOAD_SAPLABCONFNO, ""));
                    psSDIDataItemMap.setString(2, dsSAPTestDetails.getValue(testNo, __RESULTUPLOAD_SAPSELECTEDSET, ""));
                    psSDIDataItemMap.setString(3, dsSAPTestDetails.getValue(testNo, __RESULTUPLOAD_SAMPLEID, ""));
                    psSDIDataItemMap.setString(4, dsSAPTestDetails.getValue(testNo, __RESULTUPLOAD_PARAMLISTID, ""));
                    psSDIDataItemMap.setString(5, dsSAPTestDetails.getValue(testNo, __RESULTUPLOAD_PARAMLISTVERSIONID, ""));
                    psSDIDataItemMap.setString(6, dsSAPTestDetails.getValue(testNo, __RESULTUPLOAD_PARAMLISTVARINATID, ""));
                    psSDIDataItemMap.setString(7, dsSAPTestDetails.getValue(testNo, __RESULTUPLOAD_PARAMID, ""));

                    psSDIDataItemMap.addBatch();
                } catch (SQLException e) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR,ErrorDetail.TYPE_FAILURE,"Unable to set Prepared Statement:Reason:" + e.getMessage());
                }

            }

            try {
                psSDIDataItemMap.executeBatch();
                psSDIDataItemMap.clearParameters();
                psSDIDataItemMap.clearBatch();
                psSDIDataItemMap.close();
            } catch (SQLException e) {
                throw new SapphireException("Failed to execute SDIDataItem update:Reason:" + e.getMessage());
            } finally {
                psSDIDataItemMap.close();
            }
        } catch (SQLException se) {
            throw new SapphireException("Error encountered during entries into SDIDataItem table. " + se.getMessage());
        }
    }

    /**
     * This method is used to set LIMS Test Param information to support RESULT UPLOAD service.
     *
     * @param limsBatchId LIMS Batch Id for which Param need to set for result upload.
     * @param sapTestName SAP Characteristics /Test Names.
     * @return DataSet containing Param information of passed LIMS Batch Id.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet getResultUploadParams(String limsBatchId, String sapTestName, String labConfNumber) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside setResultUploadParams (method)");
        String sqlText = "select sdi.keyid1 sampleid,wi.u_saptestname saptestname,wii.keyid1 paramlistid,pl.paramlistversionid paramlistversionid, wii.keyid3 paramlistvariantid, sdi.paramid paramid " +
                "from workitem wi,workitemitem wii,paramlist pl,paramlistitem pli,sdidataitem sdi,s_sample s " +
                "where wi.u_saptestname = ? " +
                "and wi.versionstatus = 'C' " +
                "and wii.workitemid = wi.workitemid " +
                "and wii.workitemversionid = wi.workitemversionid " +
                "and wii.sdcid = 'ParamList' " +
                "and pl.paramlistid = wii.keyid1  " +
                "and pl.versionstatus = 'C' " +
                "and sdi.sdcid ='Sample' " +
                "and sdi.paramlistid = wii.keyid1 " +
                "and sdi.paramlistversionid = pl.paramlistversionid " +
                "and sdi.variantid = wii.keyid3 " +
                "and sdi.dataset = 1 " +
                "and sdi.replicateid = 1 " +
                "and sdi.paramid = pli.paramid " +
                "and pli.paramlistid = wii.keyid1 " +
                "and pli.paramlistversionid = pl.paramlistversionid " +
                "and pli.variantid = wii.keyid3 " +
                "and pli.u_issapresult = 'Y' " +
                "and s.s_sampleid = sdi.keyid1 " +
                "and s.batchid = ? ";
        DataSet dsSDIData = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{sapTestName, limsBatchId});

        if (null == dsSDIData) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_DATASET_FOUND + " While executing query for getting Characteristic details"));
        } else if (dsSDIData.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.INCORRECT_MASTERDATA_SETUP + " SAP requested for the following characteristics/conf number: " + sapTestName + "/" + labConfNumber + ".But appropriate master data setup not detected in LIMS "));
        } else {
            return dsSDIData;
        }
        //return dsSDIData;
    }
}