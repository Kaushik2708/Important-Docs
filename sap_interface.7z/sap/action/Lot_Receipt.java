package labvantage.custom.alcon.sap.action;


//import com.google.gwt.junit.client.WithProperties;

import labvantage.custom.alcon.ddt.IntfTransItem;
import labvantage.custom.alcon.sap.util.ErrorMessageUtil;
import labvantage.custom.alcon.sap.util.SAPUtil;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;

/**
 * $Author: GHOSHKA1 $
 * $Date: 2021-11-30 03:13:25 -0600 (Tue, 30 Nov 2021) $
 * $Revision: 685 $
 */

/********************************************************************************************
 * $Revision: 685 $
 * Description:
 * This class is for LOT RECEIPT Service.
 * This service is responsible for creation of LIMS Batch based upon the SAP Inspection Lot.
 *
 * @author Kaushik Ghosh
 * @version 1
 *******************************************************************************************/
public class Lot_Receipt extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 685 $";

    public static final String ID = "Lot_Receipt";
    public static final String VERSIONID = "1";

    public static final String PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "processassysuserid";
    public String VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "";
    private static final String _PROPS_REPROCESSDATE = "reprocessdate";
    private static final String _PROPS_REPROCESSBY = "reprocessedby";
    private static final String _PROPS_TRANSITEMID = "u_intftransitemid";
    private static final String _PROPS_ITEMDATA = "itemdata";
    private static final String _PROPS_TRANSITEM_SDCID = "IntfTransItem";
    private static final String _PROPS_TRANSITEM_STATUS = "status";
    private static final String _PROPS_LIMSKEYVALUE = "limskeyvalue";
    private static final String _PROPS_PENDINGLOTFLAG = "pendinglotflag";

    // Added for Batch Consumption
    private static final String __SAP_PLANT = "plant";
    private static final String __SAP_BATCH = "sapbatch";
    private static final String __SAP_MAT = "sapmatnumber";
    private static final String __SAP_PARENT_BATCH = "sapparentbatch";
    private static final String __SAP_PARENT_MAT = "sapparentmat";
    private static final String __SAP_PARENT_PLANT = "sapparentplant";
    private static final String __REPROCESS_DATE = "reprocessdate";
    private static final String __REPROCESSING_FLAG = "reprocessingflag";

    /**
     * processAction is an OOB LabVantage method. This is the main method where execution starts.
     *
     * @param properties Input properties to the Service are passed here such as transaction id, transaction item id, SAP data payload etc.
     * @throws SapphireException Throws OOB Sapphire exception
     */
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("=============== Start Processing Action: " + ID + ", Version:" + VERSIONID + "===============");

        VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = properties.getProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, "");

        StringBuilder _errMsg = new StringBuilder().append(" ");
        String transID = properties.getProperty("transid");
        String transItemId = properties.getProperty("transitemid");
        String reprocessFlag = properties.getProperty("reprocessingflag");
        String strDataPayload = properties.getProperty("itemdata");
        if (strDataPayload == null || "".equalsIgnoreCase(strDataPayload)) {
            throw new SapphireException("General Error", TYPE_FAILURE, getTranslationProcessor().translate(_errMsg.append(ErrorMessageUtil.INVALID_SAP_DATA_PAYLOAD).toString()));
        }
        // 1. Getting SAP payload
        DataSet dsItemPayLoad = SAPUtil.getDataSetFromXMLString(strDataPayload);
        logger.info(" Lot Receipt SAP payload " + dsItemPayLoad.toJSONString());

        DataSet dsBatchDetails = new DataSet();
        // 2. Setting SAP Required columns
        dsBatchDetails = getSAPDataForBatch(dsItemPayLoad, dsBatchDetails);
        //int size = dsBatchDetails.getRowCount();
        String inspectionLotStatus = dsBatchDetails.getValue(0, "SAPINSPECTIONLOTSTATUS", "");
        String sapBatch = dsBatchDetails.getValue(0, "SAPBATCHNUMBER", "");
        String inspectionLot = dsBatchDetails.getValue(0, "SAPINSPECTIONLOT", "");
        String sapPlant = dsBatchDetails.getValue(0, "SAPPLANT", "");
        String sapMaterial = dsBatchDetails.getValue(0, "SAPMATERIALNUMBER", "");
        String sapInspectionLotOrigin = dsBatchDetails.getValue(0, "INSPECTIONORIGIN", "");
        String sapOriginalBatch = dsBatchDetails.getValue(0, "SAPORIGINALBATCH", "");
        String sapOriginalMat = dsBatchDetails.getValue(0, "SAPORIGINALMATERIAL", "");
        String limsBatchId = "";
        // Checking Mandatory Fields for Inspection Lot, SAP Batch, SAP plant, Mat Number, Inspection Lot Origin
        checkMandatiryFields(dsBatchDetails, "SAPINSPECTIONLOTSTATUS", "SAPBATCHNUMBER", "SAPINSPECTIONLOT", "SAPPLANT", "SAPMATERIALNUMBER", "INSPECTIONORIGIN", "SAPORIGINALBATCH");
        // 3. Checking Cancelled Batch or Not (Inspection Lot Status = 'C' or 'D')
        boolean isCancelledBatch = checkCancelledBatch(inspectionLotStatus);
        // If Cancelled Batch
        if (isCancelledBatch) {
            String arrBatchDetails[] = processCancelBatch(inspectionLot, sapBatch, sapPlant, sapMaterial);
            // Setting Interface Transaction Status to COMPLETE and LIMS Key Value field
            if ("Y".equalsIgnoreCase(arrBatchDetails[0])) {
                properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, arrBatchDetails[1]);
                properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, IntfTransItem.TRANS_ITEM_STATUS_COMPLETE);
            }


        } else if ("Y".equalsIgnoreCase(sapLotBatchExists(inspectionLot, sapBatch, sapPlant, sapMaterial)[0])) {
            // 4. Checking If Already a Open Batch or Not
            _errMsg = _errMsg.append(ErrorMessageUtil.BATCH_EXIST).append(" LIMS Batch Id: ").append(sapLotBatchExists(inspectionLot, sapBatch, sapPlant, sapMaterial)[1]).append(" For SAP Batch Id:").append(sapBatch).append(", SAP Plant:").append(sapPlant).append(" and SAP Material# :").append(sapMaterial).append("\n");
            throw new SapphireException(_errMsg.toString());
        } else {
            // 5. Determining Batch Type and Setting it in Batch Details DataSet
            String batchType = getBatchType(dsBatchDetails, sapInspectionLotOrigin);
            // 6. Determing Batch Template and Setting it in Batch Details DataSet
            String batchTemplateId = getBatchTemplate(dsBatchDetails, batchType);

            //8. Processing Batch based upon Batch Type (Raw Material, Finished, Stock transfer, Expiry Product)

            if (("Raw Material").equalsIgnoreCase(batchType)) {
                // Todo: Next Phase
            } else if (("Finished").equalsIgnoreCase(batchType)) {
                limsBatchId = processNewFinishedGood(dsBatchDetails, inspectionLot, sapBatch, sapMaterial, sapPlant);
            } else if (("Stock Transfer").equalsIgnoreCase(batchType)) {
                //Todo: Next Phase
            } else if (("Expiry Product").equalsIgnoreCase(batchType)) {
                //Todo: Next Phase
            } else {
                _errMsg = _errMsg.append(ErrorMessageUtil.INVALID_BATCH_TYPE);
                throw new SapphireException(_errMsg.toString());
            }
            // Todo: Need to add same for Tool Id attribute as well for Raw Material.
            // 8.1 Adding MARS CODE Attribute
            String marsCode = dsBatchDetails.getValue(0, "MARSCODE", "");
            // Checking if MARS CODE is Blank
            if (!"".equalsIgnoreCase(marsCode)) {
                // Check if Batch is having MARS Code Attribute?
                String marsCodeAttrPresent = isMarsCodeAttrPresentInBatch(limsBatchId);
                if ("Y".equalsIgnoreCase(marsCodeAttrPresent)) {
                    // Editting MARS CODE
                    setMarsCode(limsBatchId, marsCode);
                }

            }

            // 9. Receiving Batch.
            receiveBatch(limsBatchId);

            // 10. Add Batch Genealogy.
            //TODO Add Batch Genealogy is commented for Phase 1 Release 1. To be explored in subsequent releases.
            /*
            if (!sapBatch.equalsIgnoreCase(sapOriginalBatch) && !sapMaterial.equalsIgnoreCase(sapOriginalMat)) {
                addGenealogy(limsBatchId, batchType, sapOriginalBatch, sapOriginalMat);
            }
            */

            // 11. Setting SAP Result IDs for Result Upload.
            setSAPResultData(limsBatchId, dsItemPayLoad, sapBatch, sapMaterial, sapPlant);

            // 12. Checking Batch Master Presence
            DataSet dsPendingBatchMaster = isBatchMasterPresent(sapBatch, sapPlant, sapMaterial);
            String bmTransItemId = dsPendingBatchMaster.getValue(0, _PROPS_TRANSITEMID, "");
            String bmTransItemStatus = dsPendingBatchMaster.getValue(0, _PROPS_TRANSITEM_STATUS, "");
            String bmDataPayload = dsPendingBatchMaster.getClob(0, _PROPS_ITEMDATA, "");
            if (!"".equalsIgnoreCase(bmTransItemId)) {
                // 12.1. Processing Batch Master service for updating the LIMS Batch
                processBatchMaster(bmDataPayload);
                // 12.2 Update all pendingBatchMaster to True
                updateTransItemStatus(dsPendingBatchMaster, limsBatchId);
            }
            // Todo replaced to end
            // 13. Process successful . Time to update TransactionItem Table as status = COMPLETE

            properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, limsBatchId);
            properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, IntfTransItem.TRANS_ITEM_STATUS_COMPLETE);

            // 14. Processing Batch Consumption
            processBatchConsumption(sapBatch, sapMaterial, sapPlant);

        }


        logger.info("============= End Processing Action: " + ID + ", Version:" + VERSIONID + "===============");

    }

    /**
     * This method is responsible for reprocessing Batch Consumption service
     *
     * @param sapBatch    SAP Batch
     * @param sapMaterial SAP Material
     * @param sapPlant    SAP Plant
     * @throws SapphireException OOB Sapphire exception
     */
    private void processBatchConsumption(String sapBatch, String sapMaterial, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside processBatchConsumption (method)");
        DataSet dsBatchConsumptionDetails = checkBatchConsumptionItems(sapBatch, sapMaterial, sapPlant);
        // 14.0 If Batch Consumption transaction item found for Reprocessing
        if (dsBatchConsumptionDetails.getRowCount() > 0) {
            // 14.1 Sorting the DataSet
            dsBatchConsumptionDetails.sort("u_intftransitemid D,createdt D");
            // 14.2 Reporcess Transaction Item
            reprocessTransactionItem(dsBatchConsumptionDetails);
        }
    }

    /************
     *  This method is used to check all batch exist for BATCH CONSUMPTION reprocessing or not.
     * @param sapBatch SAP Batch
     * @param sapMat SAP Material
     * @param sapPlant SAP Plant
     * @param parentSAPBatch Parent SAP Batch
     * @param parentSAPMat Parent SAP Material
     * @param parentSAPPlant Parent SAP Plant
     * @param isParent Is parent batch (Y/N)
     * @return TRUE / FALSE
     * @throws SapphireException
     *************/
    private boolean checkAllBatchConsumptionLIMSBatchExists(String sapBatch, String sapMat, String sapPlant, String parentSAPBatch, String parentSAPMat, String parentSAPPlant, String isParent) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkAllBatchConsumptionBatchExists (method)");
        boolean allLIMSBatchExists = false;
        if ("N".equalsIgnoreCase(isParent)) {
            // Check all parent batches are already exist or not ?
            if (checkParentLIMSBatchExists("", "", "", parentSAPBatch, parentSAPMat, parentSAPPlant)) {
                return true;
            }

        } else {
            // Check child batch exists and all parent except current parent exists
            if ("Y".equalsIgnoreCase(sapLotBatchExists("", sapBatch, sapPlant, sapMat)[0]) && checkParentLIMSBatchExists(sapBatch, sapMat, sapPlant, parentSAPBatch, parentSAPMat, parentSAPMat)) {
                return true;
            }
        }
        return allLIMSBatchExists;
    }

    /**********
     * This method is used to check whether all parent LIMS batch are exist or not
     * @param sapBatch SAP Batch
     * @param sapMaterial SAP Material
     * @param sapPlant SAP Plant
     * @param parentSAPBatch Comma separated SAP parent batch
     * @param parentSAPMaterial Comma separated SAP parent material
     * @param parentSAPPlant Comma separated SAP parent plant
     * @return
     * @throws SapphireException
     **********/
    private boolean checkParentLIMSBatchExists(String sapBatch, String sapMaterial, String sapPlant, String parentSAPBatch, String parentSAPMaterial, String parentSAPPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkParentLIMSBatchExists (method)");
        String sapParentBatch[] = StringUtil.split(parentSAPBatch, ",");
        String sapParentMaterialNum[] = StringUtil.split(parentSAPMaterial, ",");
        String sapParentPlant[] = StringUtil.split(parentSAPPlant, ",");
        boolean allParentBatchExist = true;
        // if length of parent SAP Batch, SAP Material and SAP Plant is same then go ahead
        if (sapParentBatch.length == sapParentMaterialNum.length && sapParentMaterialNum.length == sapParentPlant.length && sapParentPlant.length == sapParentBatch.length) {
            // Looping through Parent Batch, Material and plant set
            for (int parentCount = 0; parentCount < sapParentBatch.length; parentCount++) {
                // If current batch is parent batch. Then skip
                if (sapBatch.equalsIgnoreCase(sapParentBatch[parentCount]) && sapMaterial.equalsIgnoreCase(sapParentMaterialNum[parentCount]) && sapPlant.equalsIgnoreCase(sapParentPlant[parentCount])) {
                    continue;
                } else {
                    // Parent LIMS batch already present
                    allParentBatchExist = sapLotBatchExistsForBC(sapParentBatch[parentCount], sapParentMaterialNum[parentCount], sapParentPlant[parentCount]).getRowCount() > 0 ? true : false;
                    // If not found then return FALSE
                    if (allParentBatchExist == false) {
                        return allParentBatchExist;
                    }
                }
            }
        } else {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Number of Parent SAP Batch, SAP Material and SAP Plant are not same in Batch Cosnumption payload."));
        }
        // return TRUE
        return allParentBatchExist;
    }

    /**
     * This method is used to check whether LIMS Batch already exist or not.
     * Only SAP created batch is considered.
     *
     * @param strSAPBatchId SAP Batch Number.
     * @param strSAPPlant   SAP Plant code.
     * @param strMatNum     SAP Material Number.
     * @return DataSet of LIMS Batch Id iif exists.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet sapLotBatchExistsForBC(String strSAPBatchId, String strSAPPlant, String strMatNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside sapLotBatchExists (method)");
        // method variables
        String limsBatch = "";
        StringBuilder errMsg = new StringBuilder().append("");
        String sqlText = "SELECT " +
                "    s_batch.s_batchid          batchid, " +
                "    s_batch.batchstatus        batchstatus, " +
                "    s_batch.batchtype          batchtype, " +
                "    s_batch.productid          productid, " +
                "    s_batch.productversionid   productversionid, " +
                "    s_batch.createdt           createdt " +
                "FROM " +
                "    s_batch " +
                "    JOIN s_prodvariant ON s_batch.prodvariantid = s_prodvariant.s_prodvariantid " +
                "WHERE " +
                "    s_batch.u_mesordersapbatch1 = ? " +
                "    AND s_batch.u_sapmatnumber = ? " +
                "    AND ( s_batch.u_sapplant = ? " +
                "          OR s_prodvariant.securitydepartment IN ( " +
                "        SELECT " +
                "            department.departmentid " +
                "        FROM " +
                "            department " +
                "            INNER JOIN u_sites ON department.u_siteid = u_sites.u_sitesid " +
                "        WHERE " +
                "            u_sites.sapplant = ? " +
                "    ) ) " +
                "    AND s_batch.u_issapflag = 'Y' ";

        DataSet dslimsBatch = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{strSAPBatchId, strMatNum, strSAPPlant, strSAPPlant});
        if (null == dslimsBatch) {
            errMsg = errMsg.append("").append(ErrorMessageUtil.NULL_SQL_VALUE).append("  While retriving LIMS Batch Id for SAP Batch Id: ").append(strSAPBatchId).append("\n");
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(errMsg.toString()));
        }
        // Sorting to get the latest on top if LIMS Batch found
        if (dslimsBatch.getRowCount() > 0) {
            dslimsBatch.sort("createdt D");
        }
        return dslimsBatch;
    }

    /****
     * This method will update list of transaction items
     * @param dsTransactionItem DataSet containing transaction item Ids
     * @throws SapphireException OOB Sapphire exception
     */
    private void completeTransItem(DataSet dsTransactionItem) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside completeTransItem (method)");
        PropertyList plTransItem = new PropertyList();
        plTransItem.setProperty(EditSDI.PROPERTY_SDCID, _PROPS_TRANSITEM_SDCID);
        plTransItem.setProperty(EditSDI.PROPERTY_KEYID1, dsTransactionItem.getColumnValues(_PROPS_TRANSITEMID, ";"));
        plTransItem.setProperty("status", "COMPLETE");
        plTransItem.setProperty(__REPROCESSING_FLAG, "COMPLETE");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plTransItem, true);
        } catch (Exception ex) {
            throw new SapphireException(ex.getMessage());
        }
    }

    /*****
     * This method is used to reprocess PENDING transaction item Ids.
     * @param dsTransactionItemData DataSet containing transaction item Ids
     * @throws SapphireException OOB Sapphire exception
     */
    private void reprocessTransactionItem(DataSet dsTransactionItemData) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside reprocessTransactionItem (method)");
        PropertyList plReprocessItemPl = new PropertyList();
        // Looping through PENDING transaction items
        for (int itemCount = 0; itemCount < dsTransactionItemData.getRowCount(); itemCount++) {
            plReprocessItemPl.clear();
            plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, EditSDI.ID);
            plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, EditSDI.VERSIONID);
            plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

            //######## - START: TodoList entry processing duedt is set as currenttime+1 min. This is needed since Todolist is polled in every 1 min.(60sec)
            plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, getDueDate(60));
            //######## - END: TodoList entry processing duedt is set as currenttime+1 min. This is needed since Todolist is polled in every 1 min.(60sec)

            plReprocessItemPl.setProperty(EditSDI.PROPERTY_SDCID, _PROPS_TRANSITEM_SDCID);
            plReprocessItemPl.setProperty(EditSDI.PROPERTY_KEYID1, dsTransactionItemData.getValue(itemCount, "u_intftransitemid"));
            plReprocessItemPl.setProperty(__REPROCESS_DATE, "n");
            try {
                getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, plReprocessItemPl);
            } catch (Exception ex) {
                throw new SapphireException(ex.getMessage());
            }
        }
    }

    /****
     * This method is used to check PENDING Batch Consumption Transaction Item
     * @param sapBatch SAP Batch Number
     * @param sapMat SAP Material Number
     * @param sapPlant SAP Plant Number
     * @return Returns DataSet containing list of PENDING batch consumption transaction items
     * @throws SapphireException OOB Sapphire exception
     */
    private DataSet checkBatchConsumptionItems(String sapBatch, String sapMat, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkBatchConsumptionItems (method)");
        String chidSAPBatch = "";
        String childSAPMaterial = "";
        String childSAPPlant = "";
        String parentSAPBatch = "";
        String parentSAPMaterial = "";
        String parentSAPPlant = "";
        // DataSet containing items to be reprocessed
        DataSet dsFinalBatchConsumption = new DataSet();
        DataSet dsBatchConsumptionData = checkForChildBatch(sapBatch, sapMat, sapPlant);
        // If child Batch exists
        if (dsBatchConsumptionData.getRowCount() > 0) {
            // Sorting to get Latest
            dsBatchConsumptionData.sort("u_intftransitemid D,createdt D");
            // Getting SAP Batch, SAP Mat#, SAP Plant, Parent SAP Batch, Parent SAP Material and Parent SAP Plant From TransItem
            chidSAPBatch = dsBatchConsumptionData.getValue(0, __SAP_BATCH);
            childSAPMaterial = dsBatchConsumptionData.getValue(0, __SAP_MAT);
            childSAPPlant = dsBatchConsumptionData.getValue(0, __SAP_PLANT);
            parentSAPBatch = dsBatchConsumptionData.getValue(0, __SAP_PARENT_BATCH);
            parentSAPMaterial = dsBatchConsumptionData.getValue(0, __SAP_PARENT_MAT);
            parentSAPPlant = dsBatchConsumptionData.getValue(0, __SAP_PARENT_PLANT);
            // Check all LIMS Batch present or not ??
            if (checkAllBatchConsumptionLIMSBatchExists(sapBatch, sapMat, sapPlant, parentSAPBatch, parentSAPMaterial, parentSAPPlant, "N")) {
                // If YES
                // Copying 0th row to final data set
                dsFinalBatchConsumption.copyRow(dsBatchConsumptionData, 0, 1);
            }
        }
        // Clearing Child Batch details
        dsBatchConsumptionData.clear();
        // Checking for Parent Batch
        dsBatchConsumptionData = checkForParentBatch(sapBatch, sapMat, sapPlant);
        // If Parent FOUND
        if (dsBatchConsumptionData.getRowCount() > 0) {
            // Declaring Array
            String[] arrParentBatch;
            String[] arrParentMat;
            String[] arrParentPlant;
            // Looping through all Transaction Items and create the final DataSet
            for (int transCount = 0; transCount < dsBatchConsumptionData.getRowCount(); transCount++) {
                arrParentBatch = StringUtil.split(dsBatchConsumptionData.getClob(transCount, __SAP_PARENT_BATCH, ""), ",");
                arrParentMat = StringUtil.split(dsBatchConsumptionData.getClob(transCount, __SAP_PARENT_MAT, ""), ",");
                arrParentPlant = StringUtil.split(dsBatchConsumptionData.getClob(transCount, __SAP_PARENT_PLANT, ""), ",");
                // Looping through Parents
                for (int parentCount = 0; parentCount < arrParentBatch.length; parentCount++) {
                    // Checking matching SAP Batch + SAP Material + SAP Plant
                    if (sapBatch.equalsIgnoreCase(arrParentBatch[parentCount]) && sapMat.equalsIgnoreCase(arrParentMat[parentCount]) && sapPlant.equalsIgnoreCase(arrParentPlant[parentCount])) {
                        chidSAPBatch = dsBatchConsumptionData.getValue(transCount, __SAP_BATCH, "");
                        childSAPMaterial = dsBatchConsumptionData.getValue(transCount, __SAP_MAT, "");
                        childSAPPlant = dsBatchConsumptionData.getValue(transCount, __SAP_PLANT, "");
                        parentSAPBatch = dsBatchConsumptionData.getClob(transCount, __SAP_PARENT_BATCH, "");
                        parentSAPMaterial = dsBatchConsumptionData.getClob(transCount, __SAP_PARENT_MAT, "");
                        parentSAPPlant = dsBatchConsumptionData.getClob(transCount, __SAP_PARENT_PLANT, "");
                        // Check all LIMS Batch present or not ??
                        if (checkAllBatchConsumptionLIMSBatchExists(sapBatch, sapMat, sapPlant, parentSAPBatch, parentSAPMaterial, parentSAPPlant, "Y")) {
                            // If YES
                            // Copying 0th row to final data set
                            // Copy matching combination to Final DataSet
                            dsFinalBatchConsumption.copyRow(dsBatchConsumptionData, transCount, 1);
                        }
                    }
                }

            }
        }
        // Preparing the retunr Arra of DataSet
        // Oth for Reprocessing DataSet
        return dsFinalBatchConsumption;
    }

    /*****
     * This method is used in checking if current batch is in Parent batch list for batch consumption.
     * @param sapBatch SAP Batch Number
     * @param sapMat SAP Material Number
     * @param sapPlant SAP Plant Number
     * @return DataSet containg parent batch details
     * @throws SapphireException OOB Sapphire exception
     */
    private DataSet checkForParentBatch(String sapBatch, String sapMat, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkForParentBatch (method)");
        StringBuilder errMsg = new StringBuilder().append("");
        String sqlQuery = "SELECT u_intftransitemid,plant,key1value sapbatch,key2value sapmatnumber,sapparentbatch,sapparentmat,sapparentplant,createdt FROM u_intftransitem \n" +
                "WHERE transname  ='BATCH_CONSUMPTION'\n" +
                "AND status = 'PENDING' \n" +
                "AND sapparentbatch like '%" + sapBatch + "%' \n" +
                "AND sapparentmat like '%" + sapMat + "%' \n" +
                "AND sapparentplant like '%" + sapPlant + "%'";
        DataSet dsParentBatchtransItem = getQueryProcessor().getSqlDataSet(sqlQuery, true);
        if (null == dsParentBatchtransItem) {
            errMsg.append(ErrorMessageUtil.NULL_DATASET_FOUND).append(" While getting Batch Consumption Details for SAP Material:").append(sapMat).append(", SAP Batch Id: ").append(sapBatch).append(" and SAP Plant: ").append(sapPlant);
            throw new SapphireException(errMsg.toString());
        }
        return dsParentBatchtransItem;
    }

    /****
     * This method is used in checking if current batch is in Parent batch list for batch consumption.
     * @param sapBatch SAP Batch Number
     * @param sapMat SAP Material Number
     * @param sapPlant SAP Plant Number
     * @return Returns DataSet containing lims batch information
     * @throws SapphireException OOB Sapphire exception
     */

    private DataSet checkForChildBatch(String sapBatch, String sapMat, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkForChildBatch (method)");
        StringBuilder errMsg = new StringBuilder().append("");
        String sqlQuery = "SELECT u_intftransitemid,plant,key1value sapbatch,key2value sapmatnumber,sapparentbatch,sapparentmat,sapparentplant,createdt FROM u_intftransitem \n" +
                "WHERE transname  ='BATCH_CONSUMPTION'\n" +
                "AND status = 'PENDING'\n" +
                "AND key1name = 'SAP Batch'\n" +
                "AND key1value = ? \n" +
                "AND key2name = 'Material Number'\n" +
                "AND key2value = ? \n" +
                "AND plant = ?";
        DataSet dsChildBatchTransItem = getQueryProcessor().getPreparedSqlDataSet(sqlQuery, new Object[]{sapBatch, sapMat, sapPlant});
        if (null == dsChildBatchTransItem) {
            errMsg.append(ErrorMessageUtil.NULL_DATASET_FOUND).append(" While getting Batch Consumption Details for SAP Material:").append(sapMat).append(", SAP Batch Id: ").append(sapBatch).append(" and SAP Plant: ").append(sapPlant);
            throw new SapphireException(errMsg.toString());
        }
        return dsChildBatchTransItem;
    }

    /**
     * This method is used to check whether mars_code attribute is attached to Batch or not.
     *
     * @param batchId LIMS Batch Id.
     * @return Returns "Y" or "N" based on availability of mars_code attribute.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String isMarsCodeAttrPresentInBatch(String batchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside isMarsCodeAttrPresentInBatch (method)");
        String retVal = "Y";
        String rsetId = "";
        String sqlText = "";
        DataSet dsSDIAttribute;
        try {
            rsetId = getDAMProcessor().createRSet("Batch", batchId, "(null)", "(null)");
            sqlText = "select sdiattr.keyid1 from sdiattribute sdiattr, rsetitems rsi\n" +
                    "where sdiattr.sdcid = 'Batch'\n" +
                    "and sdiattr.attributeid = 'mars_code'\n" +
                    "and sdiattr.sdcid = rsi.sdcid\n" +
                    "and sdiattr.keyid1= rsi.keyid1\n" +
                    "and sdiattr.keyid2 = rsi.keyid2\n" +
                    "and sdiattr.keyid3 = rsi.keyid3\n" +
                    "and rsi.keyid1 = ?\n" +
                    "and rsi.rsetid = ?";
            dsSDIAttribute = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{batchId, rsetId});
        } catch (SapphireException ex) {
            logger.error(" Unable to execute query. Query is \n" + sqlText + "\n Error is :" + ex.getMessage());
            throw new SapphireException("General Error::", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Unable to execute query."));
        } finally {
            if (!"".equals(rsetId)) {
                getDAMProcessor().clearRSet(rsetId);
            }
        }
        if (dsSDIAttribute.getRowCount() == 0) {
            retVal = "N";
        }
        return retVal;
    }

    /**
     * This method is used to edit and set the MARS CODE attribute.
     *
     * @param batchId  LIMS Batch ID.
     * @param marsCode MARS CODE value.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private void setMarsCode(String batchId, String marsCode) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside setMarsCode (method)");
        PropertyList plEditAttr = new PropertyList();
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_SDCID, "Batch");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_KEYID1, batchId);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTEID, "mars_code");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTEINSTANCE, "1");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTESDCID, "Batch");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_VALUE, marsCode);
        try {
            getActionProcessor().processAction(EditSDIAttribute.ID, EditSDIAttribute.VERSIONID, plEditAttr);
        } catch (SapphireException ex) {
            logger.error("Unable to execute EditSDIAttribute, error is" + ex.getMessage());
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Unable to execute EditSDIAttribute. Please contact your system adminstration."));
        }
    }

    /**
     * This method is used to process PENDING Batch Master transactions.
     *
     * @param itemdata PENDING Batch Master data payload
     * @throws SapphireException SapphireException Throws OOB Sapphire exception.
     */
    private void processBatchMaster(String itemdata) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside processBatchMaster (method)");
        PropertyList plBatchMaster = new PropertyList();
        plBatchMaster.setProperty("itemdata", itemdata);
        getActionProcessor().processAction(BatchMaster.ACTION_ID, BatchMaster.ACTION_VERSION_ID, plBatchMaster);
    }

    /**
     * Method used to add basic genealogy of LIMS Batch.
     *
     * @param limsBatchId         Child LIMS Batch Id.
     * @param batchType           LIMS batch Type(Finished, Semi-Finished, Intermediate, Raw Material etc.)
     * @param parentSAPBatch      Parent LIMS Batch Id.
     * @param parentSAPMaterialId Parent LIMS Batch product details.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private void addGenealogy(String limsBatchId, String batchType, String parentSAPBatch, String parentSAPMaterialId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside addGenealogy (method)");
        StringBuilder errMsg = new StringBuilder().append(" ");
        // Getting Parent Batch details irrespective of status.
        DataSet dsParentLIMSBatch = getBatchDetails(parentSAPBatch, parentSAPMaterialId);
        if (dsParentLIMSBatch.getRowCount() == 0) {
            errMsg.append(" While adding Batch Genealogy,").append(ErrorMessageUtil.PARENT_BATCH_NOT_FOUND).append(" For Parent SAP Material:").append(parentSAPMaterialId).append("  and Parent SAP Batch Id: ").append(parentSAPBatch).append(" for adding Batch Genealogy.");
            throw new SapphireException(errMsg.toString());
        } else {
            // Sorting DataSet in decending order based on Creation Date
            // Will get the
            dsParentLIMSBatch.sort("createdt D");
            PropertyList plGenealogy = new PropertyList();
            plGenealogy.setProperty("sdcid", "Batch");
            plGenealogy.setProperty("s_batchid", limsBatchId);
            plGenealogy.setProperty("batchtype", batchType);
            plGenealogy.setProperty("batchstatus", "Received");
            plGenealogy.setProperty("parentbatchid", dsParentLIMSBatch.getValue(0, "s_batchid", ""));
            plGenealogy.setProperty("parentproductid", dsParentLIMSBatch.getValue(0, "productid", ""));
            plGenealogy.setProperty("parentproductversionid", dsParentLIMSBatch.getValue(0, "productversionid", ""));
            plGenealogy.setProperty("linkid", "batch genealogy");
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, plGenealogy);
        }
    }

    /**
     * This method is used to get basic LIMS Batch details such as LIMS Batch id, status, product id, product version etc by SAP Batch# and SAP Material#.
     *
     * @param sapBatchId    SAP Batch Number.
     * @param sapMaterialId SAP Material Number.
     * @return Returns DataSet containing basic LIMS Batch details.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet getBatchDetails(String sapBatchId, String sapMaterialId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getBatchDetails (method)");
        StringBuilder errMsg = new StringBuilder().append(" ");
        //String sqlText = "select s_batchid,batchstatus,productid,productversionid,createdt from s_batch where u_sapbatchnumber = '" + sapBatchId + "' and u_sapmatnumber = '" + sapMaterialId + "' and batchstatus not in('Cancelled','Rejected','Released') ";
        String sqlText = "select s_batchid,batchstatus,productid,productversionid,createdt from s_batch where u_sapbatchnumber = ? and u_sapmatnumber = ? and batchstatus not in('Cancelled','Rejected','Released') ";
        //DataSet dsParentBatchDetails = getQueryProcessor().getSqlDataSet(sqlText);
        DataSet dsParentBatchDetails = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{sapBatchId, sapMaterialId});
        if (null == dsParentBatchDetails) {
            errMsg.append(ErrorMessageUtil.NULL_DATASET_FOUND).append(" While getting LIMS Batch Details for SAP Material:").append(sapMaterialId).append("  and SAP Batch Id: ").append(sapBatchId);
            throw new SapphireException(errMsg.toString());
        } else {
            dsParentBatchDetails.sort("createdt D");
            return dsParentBatchDetails;
        }
    }

    /**
     * This method is used to set SAP Test(QAIMV-KURZTEXT) results to support RESULT UPLOAD service.
     * If SAP Test is Laboratory System Confimtaion then corresponding details are stored in Batch Table.
     * Else for all other SAP Tests, details are added at LIMS Data Entry level.
     *
     * @param limsBatchId  LIMS Batch Id for which SAP Test details to be added.
     * @param dsSAPPayload Datapayload coming from SAP(QAIVC, QAIMV and QAICA Tab details).
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private void setSAPResultData(String limsBatchId, DataSet dsSAPPayload, String sapBatch, String sapMatNum, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside setSAPResultData (method)");
        // Getting QAIVC Data
        DataSet dsQAIMV = getQAIMVData(dsSAPPayload);
        // Getting Test Names
        String strSAPTestNames = dsQAIMV.getColumnValues("KURZTEXT", ";");
        String strLabConfNum = dsQAIMV.getColumnValues("RUECKMELNR", ";");
        // Setting Characteristics at SDIDataItem for Result Upload
        DataSet dsSDIDataItems = getResultUploadParams(limsBatchId, strSAPTestNames, strLabConfNum, sapBatch, sapMatNum, sapPlant);
        String[] testNames = StringUtil.split(strSAPTestNames, ";");

        // Creating DataSet for SDIDataItem Entry
        DataSet dsSAPTestExceptLC = new DataSet(connectionInfo);
        dsSAPTestExceptLC.addColumn("SAPLABCONFNO", DataSet.STRING);
        dsSAPTestExceptLC.addColumn("SAPSELECTEDSET", DataSet.STRING);
        dsSAPTestExceptLC.addColumn("SAMPLEID", DataSet.STRING);
        dsSAPTestExceptLC.addColumn("PARAMLISTID", DataSet.STRING);
        dsSAPTestExceptLC.addColumn("PARAMLISTVERSIONID", DataSet.STRING);
        dsSAPTestExceptLC.addColumn("PARAMLISTVARINATID", DataSet.STRING);
        dsSAPTestExceptLC.addColumn("PARAMID", DataSet.STRING);

        int rowNo = 0;
        for (int testNo = 0; testNo < testNames.length; testNo++) {

            String sapLabConfNum = dsQAIMV.getValue(testNo, "RUECKMELNR", "");
            String sapSelectedSet = dsQAIMV.getValue(testNo, "AUSWMENGE1", "");
            String testName = testNames[testNo];

            if ("Laboratory System Confirmation".equalsIgnoreCase(testName)) {
                // Updating Batch
                updateBatchForQAIMVData(limsBatchId, sapLabConfNum, sapSelectedSet);
            } else {

                /*********************************** ******************************* ******************************* ********************************
                 * Code updated before Phase 2 delivery , following section commented. Previously assumed testname Chemistry will appear before Microbiology in payload.
                 * In Phase 2, while implementing Intermediate, turned out this may not be the case, however HERKUNFT (Inspection Origin) will be considered as 04 - same as Finished.
                 ******************************** ******************************* ******************************* ***********************************/
 /*
                    // Creating DataSet for Test Names except Laboratory System Confirmation
                    dsSAPTestExceptLC.addRow();
                    dsSAPTestExceptLC.setValue(rowNo, "SAPLABCONFNO", sapLabConfNum);
                    dsSAPTestExceptLC.setValue(rowNo, "SAPSELECTEDSET", sapSelectedSet);
                    dsSAPTestExceptLC.setValue(rowNo, "SAMPLEID", dsSDIDataItems.getValue(rowNo, "sampleid", ""));
                    dsSAPTestExceptLC.setValue(rowNo, "PARAMLISTID", dsSDIDataItems.getValue(rowNo, "paramlistid", ""));
                    dsSAPTestExceptLC.setValue(rowNo, "PARAMLISTVERSIONID", dsSDIDataItems.getValue(rowNo, "paramlistversionid", ""));
                    dsSAPTestExceptLC.setValue(rowNo, "PARAMLISTVARINATID", dsSDIDataItems.getValue(rowNo, "paramlistvariantid", ""));
                    dsSAPTestExceptLC.setValue(rowNo, "PARAMID", dsSDIDataItems.getValue(rowNo, "paramid", ""));
*/

                //Find the correct row number  from dsSDIDataItems for TestName
                int rowPointer = dsSDIDataItems.findRow("saptestname", testName);

                if (rowPointer != -1) {
                    // Creating DataSet for Test Names except Laboratory System Confirmation
                    rowNo = dsSAPTestExceptLC.addRow();
                    dsSAPTestExceptLC.setValue(rowNo, "SAPLABCONFNO", sapLabConfNum);
                    dsSAPTestExceptLC.setValue(rowNo, "SAPSELECTEDSET", sapSelectedSet);
                    dsSAPTestExceptLC.setValue(rowNo, "SAMPLEID", dsSDIDataItems.getValue(rowPointer, "sampleid", ""));
                    dsSAPTestExceptLC.setValue(rowNo, "PARAMLISTID", dsSDIDataItems.getValue(rowPointer, "paramlistid", ""));
                    dsSAPTestExceptLC.setValue(rowNo, "PARAMLISTVERSIONID", dsSDIDataItems.getValue(rowPointer, "paramlistversionid", ""));
                    dsSAPTestExceptLC.setValue(rowNo, "PARAMLISTVARINATID", dsSDIDataItems.getValue(rowPointer, "paramlistvariantid", ""));
                    dsSAPTestExceptLC.setValue(rowNo, "PARAMID", dsSDIDataItems.getValue(rowPointer, "paramid", ""));
                }
            }
        }

        if (dsSAPTestExceptLC != null && dsSAPTestExceptLC.getRowCount() > 0) {
            updateSDIDataItem(dsSAPTestExceptLC);
        }

    }


    /**
     * This method is used to update LIMS Batch with SAP Lab Confirmation# and Selected Set information coming from SAP.
     *
     * @param limsBatchId    LIMS Batch Id for which selected set and confirmation number to be updated.
     * @param sapLabConfNum  SAP lab Confirmation number for Laboratory System Confirmation.
     * @param sapSelectedSet SAP Selected Set information for Laboratory System Confirmation.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private void updateBatchForQAIMVData(String limsBatchId, String sapLabConfNum, String sapSelectedSet) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside updateBatch (method)");
        PropertyList plSAPResultData = new PropertyList();
        plSAPResultData.setProperty(EditSDI.PROPERTY_SDCID, "Batch");
        plSAPResultData.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
        plSAPResultData.setProperty("u_saplabconfnum", sapLabConfNum);
        plSAPResultData.setProperty("u_sapselectedset", sapSelectedSet);
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plSAPResultData);
    }

    /**
     * This method is used to update SAP Lab Confirmation Number and SAP Selected Set for each SAP Characteristics except Laboratory Syste Confirmation.
     *
     * @param dsSAPTestDetailsExceptLC Input DataSet containing all SAP characteristic details except Laboratory System Confirmation.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private void updateSDIDataItem(DataSet dsSAPTestDetailsExceptLC) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside updateSDIDataItem (method)");
        // Reading SDIDataItem Column from Test Details except Laboratory System Confirmation
        try {
            String sqlStmt = "UPDATE SdiDataItem SET u_sapconfnum = ?,u_sapselectedset = ? WHERE sdcid = 'Sample' AND keyid1 = ? AND paramlistid = ? AND paramlistversionid = ? AND variantid = ? AND paramid = ? ";
            PreparedStatement psSDIDataItemMap = database.prepareStatement(sqlStmt);
            for (int testNo = 0; testNo < dsSAPTestDetailsExceptLC.getRowCount(); testNo++) {
                try {
                    String sapLabConfNum = dsSAPTestDetailsExceptLC.getValue(testNo, "SAPLABCONFNO", "");
                    String sapSelectedSet = dsSAPTestDetailsExceptLC.getValue(testNo, "SAPSELECTEDSET", "");
                    String sampleId = dsSAPTestDetailsExceptLC.getValue(testNo, "SAMPLEID", "");
                    String paramlistId = dsSAPTestDetailsExceptLC.getValue(testNo, "PARAMLISTID", "");
                    String paramlistVersionId = dsSAPTestDetailsExceptLC.getValue(testNo, "PARAMLISTVERSIONID", "");
                    String variantId = dsSAPTestDetailsExceptLC.getValue(testNo, "PARAMLISTVARINATID", "");
                    String paramId = dsSAPTestDetailsExceptLC.getValue(testNo, "PARAMID", "");

                    psSDIDataItemMap.setString(1, sapLabConfNum);
                    psSDIDataItemMap.setString(2, sapSelectedSet);
                    psSDIDataItemMap.setString(3, sampleId);
                    psSDIDataItemMap.setString(4, paramlistId);
                    psSDIDataItemMap.setString(5, paramlistVersionId);
                    psSDIDataItemMap.setString(6, variantId);
                    psSDIDataItemMap.setString(7, paramId);

                    psSDIDataItemMap.addBatch();
                } catch (SQLException e) {
                    throw new SapphireException("Unable to set Prepared Statement:Reason:" + e.getMessage());
                }

            }

            try {
                psSDIDataItemMap.executeBatch();
                psSDIDataItemMap.clearParameters();
                psSDIDataItemMap.clearBatch();
                psSDIDataItemMap.close();
            } catch (SQLException e) {
                throw new SapphireException("Failed to execute SDIDataItem update:Reason:" + e.getMessage());
            } finally {
                psSDIDataItemMap.close();
            }
        } catch (SQLException se) {
            throw new SapphireException("Error encountered during entries into SDIDataItem table. " + se.getMessage());
        }
    }

    /**
     * This method is used to set LIMS Test Param information to support RESULT UPLOAD service.
     *
     * @param limsBatchId  LIMS Batch Id for which Param need to set for result upload.
     * @param sapTestNames SAP Characteristics /Test Names.
     * @return DataSet containing Param information of passed LIMS Batch Id.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet getResultUploadParams(String limsBatchId, String sapTestNames, String labConfNumber, String sapBatch, String sapMaterial, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside setResultUploadParams (method)");
        StringBuilder _errMsg = new StringBuilder().append(" ");
        String sqlText = "select sdi.keyid1 sampleid,wi.u_saptestname saptestname,wii.keyid1 paramlistid,pl.paramlistversionid paramlistversionid, wii.keyid3 paramlistvariantid, sdi.paramid paramid\n" +
                "from workitem wi,workitemitem wii,paramlist pl,paramlistitem pli,sdidataitem sdi,s_sample s\n" +
                "where wi.u_saptestname in ('" + StringUtil.replaceAll(sapTestNames, ";", "','") + "')\n" +
                "and wi.versionstatus = 'C'\n" +
                "and wii.workitemid = wi.workitemid\n" +
                "and wii.workitemversionid = wi.workitemversionid\n" +
                "and wii.sdcid = 'ParamList'\n" +
                "and pl.paramlistid = wii.keyid1 \n" +
                "and pl.versionstatus = 'C'\n" +
                "and sdi.sdcid='Sample'\n" +
                "and sdi.paramlistid = wii.keyid1\n" +
                "and sdi.paramlistversionid = pl.paramlistversionid\n" +
                "and sdi.variantid = wii.keyid3\n" +
                "and sdi.dataset =1\n" +
                "and sdi.replicateid =1\n" +
                "and sdi.paramid = pli.paramid\n" +
                "and pli.paramlistid=wii.keyid1\n" +
                "and pli.paramlistversionid = pl.paramlistversionid\n" +
                "and pli.variantid = wii.keyid3\n" +
                "and pli.u_issapresult = 'Y'\n" +
                "and s.s_sampleid = sdi.keyid1\n" +
                "and s.batchid = '" + limsBatchId + "'";
        DataSet dsSDIData = getQueryProcessor().getSqlDataSet(sqlText);

        if (null == dsSDIData) {
            _errMsg.append(ErrorMessageUtil.NULL_DATASET_FOUND).append(" While executing query for getting Characteristic details");
            throw new SapphireException(_errMsg.toString());
        } else if (dsSDIData.getRowCount() == 0) {
            _errMsg.append(ErrorMessageUtil.INCORRECT_MASTERDATA_SETUP).append(" SAP requested for the following characteristics/conf number: ").append(StringUtil.replaceAll(sapTestNames, ";", ",")).append("/").append(StringUtil.replaceAll(labConfNumber, ";", ",")).append(".But appropriate master data setup not detected in LIMS for SAP Batch: ").append(sapBatch).append(", SAP Material: ").append(sapMaterial).append(" and SAP Plant: ").append(sapPlant);
            throw new SapphireException(_errMsg.toString());
        } else {
            // Checking whether Master Data Setup is correct for Result upload.
            String[] retVal = checkForMasterDataSetup(sapTestNames, labConfNumber, dsSDIData);
            if ("N".equalsIgnoreCase(retVal[0])) {
                _errMsg.append(ErrorMessageUtil.INCORRECT_MASTERDATA_SETUP).append(" SAP requested for the following characteristics/conf number: ").append(retVal[1].substring(0, retVal[1].length() - 1)).append(".But appropriate Master Data setup not detected in LIMS  for SAP Batch: ").append(sapBatch).append(", SAP Material: ").append(sapMaterial).append(" and SAP Plant: ").append(sapPlant);
                throw new SapphireException(_errMsg.toString());
            } else {
                return dsSDIData;
            }
        }
        //return dsSDIData;
    }

    /**
     * This method is used to check whether Master Data Setup for SAP Test, ParamList Item is configured correctly or not.
     *
     * @param sapTestName     Characteristics defination sent as a part of QAIMV tab.
     * @param labConfNum      Laboratory Confirmation Number related to characteristics.
     * @param sdiDataItemData LIMS Test information found.
     * @return Array of String containing "Y"/"N" and Return String.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String[] checkForMasterDataSetup(String sapTestName, String labConfNum, DataSet sdiDataItemData) {
        String[] retVal = new String[2];
        retVal[0] = "Y";
        retVal[1] = "";
        String testName = "";
        String retResult = "";
        String sapTestNames[] = StringUtil.split(sapTestName, ";");
        String sapLabConfNum[] = StringUtil.split(labConfNum, ";");
        // Looping through the SAP Test Names
        for (int testNo = 0; testNo < sapTestNames.length; testNo++) {
            // Selecting SAP Test Name one by one
            testName = sapTestNames[testNo];
            // Checking if the Test Name is  Laboratory System Confirmation, then Skip.
            if (!"Laboratory System Confirmation".equalsIgnoreCase(testName)) {
                // Checking if SDIDataItem dataset contains the SAP test name or not.
                if (sdiDataItemData.findRow("saptestname", testName) == -1) {
                    // If Test Names not found then , building the the concatinated testname/Lab Conf# string
                    retResult += testName + " / " + sapLabConfNum[testNo] + ",";
                    // setting the output flag to N
                    retVal[0] = "N";
                }
            }
        }
        if ("N".equalsIgnoreCase(retVal[0])) {
            retVal[1] = retResult;
        }
        return retVal;
    }

    /**
     * This method is used to get SAP Characteristic Information from SAP QAIMV Table.
     *
     * @param dsSAPPayload SAP payload comprises QAIMV, QAICA and QAIVC tables.
     * @return DataSet contains only SAP Characteristic information / QAIMV table data.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet getQAIMVData(DataSet dsSAPPayload) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getQAIVCData (method)");
        StringBuilder _errMsg = new StringBuilder().append(" ");
        DataSet dsQAIMV = new DataSet();
        dsQAIMV.addColumn("KURZTEXT", DataSet.STRING);
        dsQAIMV.addColumn("RUECKMELNR", DataSet.STRING);
        dsQAIMV.addColumn("AUSWMENGE1", DataSet.STRING);
        int sapTestCount = StringUtil.split(SAPUtil.getColumnValue(dsSAPPayload, "QAIMV", "KURZTEXT"), ";").length;
        if (sapTestCount <= 0) {
            _errMsg.append(" No SAP Test Name found for Result Upload.");
            throw new SapphireException(_errMsg.toString());
        } else {
            for (int rowNum = 0; rowNum < sapTestCount; rowNum++) {
                // Adding Rows to QAIMV DataSet
                dsQAIMV.addRow();
                dsQAIMV.setValue(rowNum, "KURZTEXT", StringUtil.split(SAPUtil.getColumnValue(dsSAPPayload, "QAIMV", "KURZTEXT"), ";")[rowNum]);
                dsQAIMV.setValue(rowNum, "RUECKMELNR", StringUtil.split(SAPUtil.getColumnValue(dsSAPPayload, "QAIMV", "RUECKMELNR"), ";")[rowNum]);
                dsQAIMV.setValue(rowNum, "AUSWMENGE1", StringUtil.split(SAPUtil.getColumnValue(dsSAPPayload, "QAIMV", "AUSWMENGE1"), ";")[rowNum]);
            }
        }
        return dsQAIMV;
    }

    /**
     * This method is used to update Transaction Item Status for PENDING BATCH MASTER service.
     * It updates transaction item status = COMPLETE , pendinglot = N and limskeyvalue  = LIMS Batch Id.
     *
     * @param dsPendingBatchMaster
     * @param limsBatchId
     * @throws SapphireException
     */

    private void updateTransItemStatus(DataSet dsPendingBatchMaster, String limsBatchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside updateTransItemStatus (method)");
        PropertyList plPendingBM = new PropertyList();
        plPendingBM.setProperty(EditSDI.PROPERTY_SDCID, _PROPS_TRANSITEM_SDCID);
        plPendingBM.setProperty(EditSDI.PROPERTY_KEYID1, dsPendingBatchMaster.getColumnValues(_PROPS_TRANSITEMID, ";"));
        plPendingBM.setProperty(_PROPS_TRANSITEM_STATUS, "COMPLETE");
        plPendingBM.setProperty(_PROPS_LIMSKEYVALUE, limsBatchId);
        plPendingBM.setProperty(_PROPS_PENDINGLOTFLAG, "N");
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plPendingBM);
    }

    /**
     * This method is used to check null dates and replaces it with 00000000.
     *
     * @param s Input date.
     * @return Returns date or 00000000 if the date string is null.
     */
    private String checkNullDate(String s) {
        if (s.equalsIgnoreCase("00000000")) {
            return "(null)";
        }

        return s;
    }

    /**
     * This method is used to check whether there is any BATCH MASTER payload awaiting LOT RECEIPT service.
     *
     * @param sapBatch  SAP Batch Number.
     * @param sapPlant  SAP plant Information.
     * @param sapMatNum SAP material Number.
     * @return DataSet containing transaction details of BATCH MASTER service.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet isBatchMasterPresent(String sapBatch, String sapPlant, String sapMatNum) throws SapphireException {

        logger.debug("Processing " + ID + ". (Action) : Inside isBatchMasterPresent (method)");
        // For Pending items transaction items having either pending lot flag = Y or Status = PENDING check is given
        // Status = COMPLETE filter given for batch for which earlier a batch is cancelled.
        String sqlText = "select u_intftransitemid,itemdata,status,createdt  from u_intfTransItem " +
                " where key1value = ?  and key2value= ? and plant = ? " +
                " and transname = 'BATCH_MASTER' and (pendinglotflag = 'Y'  OR  status = 'COMPLETE' OR status = 'PENDING') ";

        DataSet dsItemData = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{sapBatch, sapMatNum, sapPlant}, true);

        if (dsItemData == null) {
            throw new SapphireException("", ErrorDetail.TYPE_FAILURE, "Error encountered while checking Batch master presence. --> " + ErrorMessageUtil.NULL_SQL_VALUE);
        }
        //********* Here we are sorting this in DESC as we are taking the 0th item data for reprocessing
        if (dsItemData.size() > 0) {
            dsItemData.sort("createdt D, u_intftransitemid D");
        }

        return dsItemData;
    }

    /**
     * This method is the main method responsible for creating Finished products.
     *
     * @param dsBatchDetails Details for creating LIMS Batch.
     * @param inspectionLot  SAP Inpection Lot Number.
     * @param sapBatch       SAP batch Number.
     * @param sapMaterial    SAP Material Number.
     * @param sapPlant       SAP Plant Information.
     * @return Returns newly created LIMS Batch Number.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String processNewFinishedGood(DataSet dsBatchDetails, String inspectionLot, String sapBatch, String sapMaterial, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside processNewFinishedGood (method)");
        //String transId = dsBatchDetails.getValue(0,"TRANSID");
        //String transItemId = dsBatchDetails.getValue(0,"TRANSITEMID");
        StringBuilder errMsg = new StringBuilder().append(" ");
        // Getting Finished Product Batch Product Variant
        getFinGoodProdVariantData(dsBatchDetails, sapBatch, sapMaterial, sapPlant);
        String strLIMSBatchId = "";
        strLIMSBatchId = createLIMSBatch(dsBatchDetails);
        if ("".equalsIgnoreCase(strLIMSBatchId)) {
            errMsg.append(ErrorMessageUtil.FAILED_EXECUTING_BATCH).append(" LIMS Batch Id not found. ");
            throw new SapphireException(errMsg.toString());
        } else {
            dsBatchDetails.addColumn("LIMSBATCHID", DataSet.STRING);
            dsBatchDetails.setValue(0, "LIMSBATCHID", strLIMSBatchId);
            logger.info(" New Batch Id is: " + strLIMSBatchId);
        }
        return strLIMSBatchId;
    }

    /**
     * This method is used to get Product Varinat details for creating batch based on SAP material number and SAP plant code.
     * If SAP Material# and SAP plant returning multiple product variant, then Product Id of the Parent LIMS batch is taken.
     * Then Parent Product Id and Child Material# is used to get Product Varinat and returned.
     * If Parent Product Id and Child Material returns multiple Product variant then throw error.
     *
     * @param dsBatchDetails Information for creating LIMS batch.
     * @param sapBatch       SAP batch Number.
     * @param sapMatNum      SAP Material Number.
     * @param sapPlant       SAP plant Code.
     * @throws SapphireException Throws OOB Sapphire Exception.
     */
    private void getFinGoodProdVariantData(DataSet dsBatchDetails, String sapBatch, String sapMatNum, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getFinGoodProdVariantData (method)");
        StringBuilder errMsg = new StringBuilder().append(" ");
        // Getting PV and Product Details using SAP Inspection Lot Material# and Plant
        DataSet dsProdVarDetails = getActiveProductVariant(sapMatNum, sapPlant);
        // In case the SAP Inspection Lot Mat# and Plant is returning multiple PVs
        if (dsProdVarDetails.getRowCount() > 1) {
            String sapOriginalBatch = dsBatchDetails.getValue(0, "SAPORIGINALBATCH");
            String sapOriginalMat = dsBatchDetails.getValue(0, "SAPORIGINALMATERIAL");
            // Parent Batch --> BAT Batch can't have multiple PVs.
            if (sapBatch.equalsIgnoreCase(sapOriginalBatch) && sapMatNum.equalsIgnoreCase(sapOriginalMat)) {
                errMsg.append(ErrorMessageUtil.PARENT_BATCH_MULTIPLE_PV).append(" For SAP Batch: ").append(sapBatch).append(" and SAP Material: ").append(sapMatNum);
                throw new SapphireException(errMsg.toString());
            } else {
                // Getting parent Product Id
                String parentProductId = getParentProduct(sapOriginalBatch, sapOriginalMat, sapPlant);
                // Getting PV by passing Parent Product Id and Parent Material#
                DataSet dsProdVariantByParentProdId = getFinProdVariantByParent(parentProductId, sapMatNum);
                //DataSet dsProdVariantByParentProdId = getFinProdVariantByParent(parentProductId, sapOriginalMat);
                // If returned PV DataSet is having more than one row then throw Error
                if (dsProdVariantByParentProdId.getRowCount() > 1) {
                    errMsg.append(ErrorMessageUtil.DUPLICATE_PROD_VAR_FOUND).append(" For SAP Batch: ").append(sapBatch).append(" and SAP Material: ").append(sapMatNum);
                    throw new SapphireException(errMsg.toString());
                } else if (dsProdVariantByParentProdId.getRowCount() == 0) {
                    errMsg.append(ErrorMessageUtil.NO_PROD_VAR_FOUND).append(" For SAP Batch: ").append(sapBatch).append(" and SAP Material: ").append(sapMatNum);
                    throw new SapphireException(errMsg.toString());
                } else {
                    for (int col = 0; col < dsProdVariantByParentProdId.getColumnCount(); col++) {
                        dsBatchDetails.addColumn(dsProdVariantByParentProdId.getColumnId(col), dsProdVariantByParentProdId.getColumnType(dsProdVariantByParentProdId.getColumnId(col)));
                        dsBatchDetails.setValue(0, dsProdVariantByParentProdId.getColumnId(col), dsProdVariantByParentProdId.getValue(0, dsProdVariantByParentProdId.getColumnId(col), ""));
                    }
                }
            }
        } else {
            for (int col = 0; col < dsProdVarDetails.getColumnCount(); col++) {
                dsBatchDetails.addColumn(dsProdVarDetails.getColumnId(col), dsProdVarDetails.getColumnType(dsProdVarDetails.getColumnId(col)));
                dsBatchDetails.setValue(0, dsProdVarDetails.getColumnId(col), dsProdVarDetails.getValue(0, dsProdVarDetails.getColumnId(col), ""));
            }
        }
    }

    /**
     * This method is sued to get Product Varinat having product version as CURRENT.
     *
     * @param sapMatNumber SAP Material Number.
     * @param sapPlant     SAP plant code.
     * @return DataSet containg active Product varint details.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet getActiveProductVariant(String sapMatNumber, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getActiveProductVariant (method)");
        StringBuilder errMsg = new StringBuilder().append("");
        String sqlText = "";
        sqlText = "SELECT p.productdesc, p.sampletypeid, p.materialid, p.u_prodsubtypeid, pv.* " +
                "FROM s_product p, s_prodvariant pv " +
                "WHERE p.s_productid = pv.productid " +
                "AND pv.u_sapmatnumber ='" + sapMatNumber + "' " +
                "AND pv.u_sapplant = '" + sapPlant + "'" +
                "AND pv.productversionid = p.s_productversionid " +
                "AND p.versionstatus = 'C'" +
                "AND nvl(pv.activeflag,'Y')='Y'";
        DataSet dsPVDetails = getQueryProcessor().getSqlDataSet(sqlText);
        if (null == dsPVDetails) {
            errMsg = errMsg.append(" ").append(ErrorMessageUtil.FAILED_EXECUTING_PROD_VAR).append(" for SAP material: ").append(sapMatNumber).append(" & SAP Plant: ").append(sapPlant).append("\n");
            throw new SapphireException(errMsg.toString());
        } else if (dsPVDetails.getRowCount() == 0) {
            errMsg = errMsg.append(" ").append(ErrorMessageUtil.NO_PROD_VAR_FOUND).append(" for SAP material: ").append(sapMatNumber).append(" & SAP Plant: ").append(sapPlant).append("\n");
            throw new SapphireException(errMsg.toString());
        } else {
            return dsPVDetails;
        }
    }

    /**
     * This method is used get Product details of Parent LIMS Batch in case of multiple Product Variant.
     *
     * @param origSAPBatch  SAP Original/Parent Batch Number.
     * @param origSAPMatNum SAP Original?parent Material Number.
     * @param sapPlant      SAP Plant Code.
     * @return Returns Product Id of Parent LIMS Batch.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String getParentProduct(String origSAPBatch, String origSAPMatNum, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getParentProduct (method)");
        StringBuilder errMsg = new StringBuilder().append(" ");
        //String sqlText = "select productid, createdt from s_batch where u_sapplant = '" + sapPlant + "' and u_sapmatnumber = '" + origSAPMatNum + "' and u_sapbatchnumber = '" + origSAPBatch + "' and batchstatus not in('Cancelled','Rejected','Released')";
        // Getting product id from LIMS Batch irrespective of status
        String sqlText = "select productid, createdt from s_batch where u_sapplant = '" + sapPlant + "' and u_sapmatnumber = '" + origSAPMatNum + "' and u_sapbatchnumber = '" + origSAPBatch + "'";
        DataSet dsProdDetails = getQueryProcessor().getSqlDataSet(sqlText);
        if (null == dsProdDetails) {
            errMsg = errMsg.append(" ").append(ErrorMessageUtil.FAILED_EXECUTING_PROD_ID).append(" for Parent Batch: ").append(origSAPBatch).append(", Parent Material: ").append(origSAPMatNum).append(" & SAP Plant: ").append(sapPlant).append("\n");
            throw new SapphireException(errMsg.toString());
        } else if (dsProdDetails.getRowCount() == 0) {
            errMsg = errMsg.append(" ").append(ErrorMessageUtil.NO_PROD_ID_FOUND).append(" for Parent Batch: ").append(origSAPBatch).append(", Parent Material: ").append(origSAPMatNum).append(" & SAP Plant: ").append(sapPlant).append("\n");
            throw new SapphireException(errMsg.toString());
        } else {
            // Sorting DataSet based on Creation Date of LIMS Batch in descending order
            dsProdDetails.sort("createdt D");
            return dsProdDetails.getValue(0, "productid", "");
        }
    }

    /**
     * This method is used to get Product Variant details againats parent product id, parent material number and SAP plant.
     *
     * @param parentProdId      Parent Product Id.
     * @param originalMatNumber Parent Material Number.
     * @return Returns DataSet containing Product Variant details.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet getFinProdVariantByParent(String parentProdId, String originalMatNumber) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getFinProdVariantByParent (method)");
        StringBuilder errMsg = new StringBuilder().append("");
        String sqlText = "";
        sqlText = "SELECT p.productdesc, p.sampletypeid, p.materialid, p.u_prodsubtypeid, pv.* " +
                "FROM s_product p, s_prodvariant pv " +
                "WHERE p.s_productid = pv.productid " +
                "AND pv.u_sapmatnumber ='" + originalMatNumber + "' " +
                "AND pv.productid = '" + parentProdId + "'" +
                "AND pv.productversionid = p.s_productversionid " +
                "AND p.versionstatus = 'C'" +
                "AND nvl(pv.activeflag,'Y')='Y'";
        DataSet dsPVDetails = getQueryProcessor().getSqlDataSet(sqlText);
        if (null == dsPVDetails) {
            errMsg = errMsg.append(" ").append(ErrorMessageUtil.FAILED_EXECUTING_PROD_VAR).append(" for SAP material: ").append(originalMatNumber).append(" & Parent Product Id: ").append(parentProdId).append("\n");
            throw new SapphireException(errMsg.toString());
        } else if (dsPVDetails.getRowCount() == 0) {
            errMsg = errMsg.append(" ").append(ErrorMessageUtil.NO_PROD_VAR_FOUND).append(" for SAP material: ").append(originalMatNumber).append(" & Parent Product Id: ").append(parentProdId).append("\n");
            throw new SapphireException(errMsg.toString());
        } else {
            return dsPVDetails;
        }
    }

    /**
     * This method is used to create LIMS Batch.
     *
     * @param dsBatchDetails Details for creating LIMS batch.
     * @return Returns LIMS Batch Number.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String createLIMSBatch(DataSet dsBatchDetails) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside createLIMSBatch (method)");
        // method variables
        String strBatchId = "";
        String inspectionStartDate = checkNullDate(dsBatchDetails.getValue(0, "INSPECTIONSTARTDATE", ""));
        inspectionStartDate = SAPUtil.getDateWithProperFormat(inspectionStartDate, connectionInfo);
        String inspectionEndDate = checkNullDate(dsBatchDetails.getValue(0, "INSPECTIONENDDATE", ""));
        inspectionEndDate = SAPUtil.getDateWithProperFormat(inspectionEndDate, connectionInfo);

        PropertyList plBatchDetails = new PropertyList();
        plBatchDetails.setProperty(AddSDI.PROPERTY_SDCID, "Batch");
        plBatchDetails.setProperty("productid", dsBatchDetails.getValue(0, "productid", ""));
        plBatchDetails.setProperty("productversionid", dsBatchDetails.getValue(0, "productversionid", ""));
        plBatchDetails.setProperty("prodvariantid", dsBatchDetails.getValue(0, "s_prodvariantid", ""));
        plBatchDetails.setProperty("u_sapinspectionlot", dsBatchDetails.getValue(0, "SAPINSPECTIONLOT", ""));
        plBatchDetails.setProperty("u_sapbatchnumber", dsBatchDetails.getValue(0, "SAPBATCHNUMBER", ""));
        plBatchDetails.setProperty("u_sapmatnumber", dsBatchDetails.getValue(0, "SAPMATERIALNUMBER", ""));
        plBatchDetails.setProperty("u_inspectionorigin", dsBatchDetails.getValue(0, "INSPECTIONORIGIN", ""));
        plBatchDetails.setProperty("u_inspectiontype", dsBatchDetails.getValue(0, "INSPECTIONTYPE", ""));
        //plBatchDetails.setProperty("u_sapvendornum", dsBatchDetails.getValue(0, "SAPVENDORNUMBER", ""));
        plBatchDetails.setProperty("u_sapvendorname", dsBatchDetails.getValue(0, "SAPVENDORNAME", ""));
        plBatchDetails.setProperty("u_sapmaterialdesc", dsBatchDetails.getValue(0, "SAPMATERIALDESC", ""));
        plBatchDetails.setProperty("supplieraddresstype", dsBatchDetails.getValue(0, "supplieraddresstype", ""));
        plBatchDetails.setProperty("supplieraddressid", dsBatchDetails.getValue(0, "supplieraddressid", ""));
        plBatchDetails.setProperty("manufactureraddresstype", dsBatchDetails.getValue(0, "manufactureraddresstype", ""));
        plBatchDetails.setProperty("manufactureraddressid", dsBatchDetails.getValue(0, "manufactureraddressid", ""));
        plBatchDetails.setProperty("securityuser", dsBatchDetails.getValue(0, "securityuser", ""));
        plBatchDetails.setProperty("securitydepartment", dsBatchDetails.getValue(0, "securitydepartment", ""));
        plBatchDetails.setProperty("u_origsapbatch", dsBatchDetails.getValue(0, "SAPORIGINALBATCH", ""));// Need to discuss with Client what will be the actual value.
        plBatchDetails.setProperty("u_originalbatchid", dsBatchDetails.getValue(0, "SAPORIGINALBATCH", ""));// Need to discuss with Client what will be the actual value.
        plBatchDetails.setProperty("u_origsapmat", dsBatchDetails.getValue(0, "SAPORIGINALMATERIAL", ""));// Need to discuss with Client what will be the actual value.
        //plBatchDetails.setProperty("u_marscode", dsBatchDetails.getValue(0, "MARSCODE", ""));
        plBatchDetails.setProperty("u_mesordersapbatch1", dsBatchDetails.getValue(0, "SAPBATCHNUMBER", ""));
        plBatchDetails.setProperty("u_mesordersapbatch2", dsBatchDetails.getValue(0, "SAPBATCHNUMBER", ""));
        plBatchDetails.setProperty("u_toolid", dsBatchDetails.getValue(0, "TOOLID"));
        plBatchDetails.setProperty("u_locmatcode", dsBatchDetails.getValue(0, "LOCALMATERIALCODE", ""));
        plBatchDetails.setProperty("u_sapvendorstatus", dsBatchDetails.getValue(0, "SAPVENDORSTATUS", ""));

        plBatchDetails.setProperty("batchdesc", dsBatchDetails.getValue(0, "productdesc", ""));
        plBatchDetails.setProperty("u_productsubtypeid", dsBatchDetails.getValue(0, "u_prodsubtypeid", ""));
        plBatchDetails.setProperty("u_sapsubsystem", dsBatchDetails.getValue(0, "SAPSUBSYTEM", ""));
        plBatchDetails.setProperty("templateflag", "N");
        plBatchDetails.setProperty("activeflag", "Y");
        plBatchDetails.setProperty("u_resultsuploaded", "N");
        plBatchDetails.setProperty("u_sapvendornum", dsBatchDetails.getValue(0, "MANUFACTURERNUMBER", ""));
        plBatchDetails.setProperty("templateid", dsBatchDetails.getValue(0, "BATCHTEMPLATE"));
        plBatchDetails.setProperty("batchtype", dsBatchDetails.getValue(0, "BATCHTEMPLATE"));
        plBatchDetails.setProperty("u_catcodegrouppass", dsBatchDetails.getValue(0, "CATCODEGROUPPASS", ""));
        plBatchDetails.setProperty("u_catcodepass", dsBatchDetails.getValue(0, "CODEPASS", ""));
        plBatchDetails.setProperty("u_catcodegroupfail", dsBatchDetails.getValue(0, "CATCODEGROUPFAIL", ""));
        plBatchDetails.setProperty("u_catcodefail", dsBatchDetails.getValue(0, "CODEFAIL", ""));
        plBatchDetails.setProperty("u_issapflag", "Y");
        plBatchDetails.setProperty("u_sapplant", dsBatchDetails.getValue(0, "SAPPLANT", ""));
        /*plBatchDetails.setProperty("batchdt", dsBatchDetails.getValue(0, "BATCHDATE", ""));
        plBatchDetails.setProperty("manufacturedt", dsBatchDetails.getValue(0, "BATCHMFGDATE", ""));
        plBatchDetails.setProperty("expirydt", dsBatchDetails.getValue(0, "BATCHEXPIRYDATE", ""));*/
        plBatchDetails.setProperty("batchsize", dsBatchDetails.getValue(0, "BATCHSIZE", ""));
        plBatchDetails.setProperty("batchsizeunits", dsBatchDetails.getValue(0, "BATCHSIZEUNIT", ""));
        plBatchDetails.setProperty("u_sapinspectionstartdt", inspectionStartDate);
        plBatchDetails.setProperty("u_sapinspectionenddt", inspectionEndDate);
        plBatchDetails.setProperty("u_sapbatchcreateby", "(system)".equalsIgnoreCase(connectionInfo.getSysuserId()) ? VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID : connectionInfo.getSysuserId());
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plBatchDetails);

        strBatchId = plBatchDetails.getProperty("newkeyid1");
        logger.info("---- New Batch Id from SAP-LIMS interface : " + strBatchId + " ----");

        return strBatchId;

    }

    /**
     * This method is used to Receive LIMS Batch.
     *
     * @param limsBatchId Newly created LIMS Batch Id.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private void receiveBatch(String limsBatchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside receiveBatch (method)");

        PropertyList plEditSDI = new PropertyList();
        plEditSDI.setProperty("sdcid", "Batch");
        plEditSDI.setProperty("keyid1", limsBatchId);
        plEditSDI.setProperty("operation", "Receive");
        plEditSDI.setProperty("batchstatus", getBatchStatus(limsBatchId));
        plEditSDI.setProperty("receivedby", VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

        try {
            this.getActionProcessor().processAction("EditSDI", "1", plEditSDI);
        } catch (SapphireException ex) {
            throw new SapphireException("General Error", "FAILURE"
                    , this.getTranslationProcessor().translate("Failed to receive Batch. Please contact Administrator."));
        }


        /*
        StringBuilder errMsg = new StringBuilder().append("");
        PropertyList plReceiveBatch = new PropertyList();
        plReceiveBatch.setProperty("keyid1", limsBatchId);
        plReceiveBatch.setProperty("batchstatus", getBatchStatus(limsBatchId));
        plReceiveBatch.setProperty("issapflag", "Y");
        logger.info("============= Calling CreateReducedBatchSamples for Receiving Batch ===============");
        getActionProcessor().processAction("CreateReducedBatchSamples", "1", plReceiveBatch);
*/


    }

    /**
     * This method is used get LIMS Batch status.
     *
     * @param batchId LIMS Batch Id.
     * @return Returns the Batch status.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String getBatchStatus(String batchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getBatchStatus (method)");
        StringBuilder errMsg = new StringBuilder().append(" ");
        String strBatchStatus = "";
        String sqlText = "select batchstatus from s_batch where s_batchid = ?";
        DataSet dsBatchStatus = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{batchId});
        if (dsBatchStatus == null) {
            errMsg.append(ErrorMessageUtil.NULL_SQL_VALUE).append(" For LIMS batch Id: ").append(batchId);
            throw new SapphireException(errMsg.toString());
        }
        if (dsBatchStatus.getRowCount() == 0) {
            errMsg.append(ErrorMessageUtil.NO_ROW_FOUND).append(" For LIMS batch Id: ").append(batchId);
            throw new SapphireException(errMsg.toString());
        }
        strBatchStatus = dsBatchStatus.getValue(0, "batchstatus");
        return strBatchStatus;
    }

    /**
     * This method is used to get Batch Template information.
     *
     * @param dsBatchDetails Batch information.
     * @param batchType      Batch Type (Raw Material, Finished, Semi-Fin, Expiry Product, Stock transfer)
     * @return Returns Batch template Id.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String getBatchTemplate(DataSet dsBatchDetails, String batchType) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getBatchTemplate (method)");
        // private variable
        StringBuilder errMsg = new StringBuilder().append("");
        String templateId = "";

        PropertyList plBatchTemplate = getConfigurationProcessor().getPolicy("SAPInterfacePolicy", "Custom");
        PropertyListCollection plBatchTemplateCol = plBatchTemplate.getCollection("BatchTemplate");
        for (int row = 0; row < plBatchTemplateCol.size(); row++) {
            String policyBatchType = plBatchTemplateCol.getPropertyList(row).getProperty("BatchType");
            if ((policyBatchType).equalsIgnoreCase(batchType)) {
                templateId = plBatchTemplateCol.getPropertyList(row).getProperty("BatchTemplate");
                dsBatchDetails.addColumn("BATCHTEMPLATE", DataSet.STRING);
                dsBatchDetails.setValue(0, "BATCHTEMPLATE", templateId);
                return templateId;
            }
        }
        if (("").equalsIgnoreCase(templateId)) {
            errMsg = errMsg.append("  ").append(ErrorMessageUtil.INVALID_BATCH_TYPE);
            logger.error(errMsg.toString());
            throw new SapphireException(errMsg.toString());
        }
        return templateId;
    }

    /**
     * This method is used determine Batch type based on SAP lot origin.
     *
     * @param dsBatchDetails LIMS batch Information.
     * @param lotOrigin      SAP Lot origin.
     * @return Returns SAP Batch origin.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String getBatchType(DataSet dsBatchDetails, String lotOrigin) throws SapphireException {
        // determine type
        logger.info("Processing " + ID + ". (Action) : Inside getBatchType (method)");
        StringBuilder errMsg = new StringBuilder().append(" ");
        switch (lotOrigin) {
            case "01":
                // Todo for Raw Material
            case "04":
                dsBatchDetails.addColumn("BATCHTYPE", DataSet.STRING);
                dsBatchDetails.setValue(0, "BATCHTYPE", "Finished");
                return "Finished";
            case "08":
                //Todo for Stock Transfer
            case "09":
                // Todo for Expiry Product
            default:
                errMsg.append(ErrorMessageUtil.INVALID_BATCH_TYPE);
                throw new SapphireException();
        }
    }

    /**
     * This method is used to check whether LIMS Batch already exist or not.
     *
     * @param strInspectionLot SAP inspection Lot Number.
     * @param strSAPBatchId    SAP Batch Number.
     * @param strSAPPlant      SAP Plant code.
     * @param strMatNum        SAP Material Number.
     * @return Returns array containing LIMS Batch Id iif exists.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String[] sapLotBatchExists(String strInspectionLot, String strSAPBatchId, String strSAPPlant, String strMatNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside sapLotBatchExists (method)");
        // method variables
        String[] limsBatchFound = new String[3];
        limsBatchFound[0] = "N";
        limsBatchFound[1] = "";
        limsBatchFound[2] = "";
        StringBuilder errMsg = new StringBuilder().append("");
        //String sqlText = "SELECT s_batchid,batchstatus FROM s_batch WHERE u_sapbatchnumber = ? and u_sapmatnumber = ? and u_sapplant = ? AND batchstatus not in('Released','Cancelled','Rejected')";
        // SAP Plant & SAP Batch is a newly added field and not exposed to the Batch maint page while creating LIMS Batch Manually.
        // SAP Batch and MES ORDER NUMBER are same for a LIMS Batch and is a mandatory field while creating a Batch.
        // Hence instead of direct SAP Batch # and Plant #, check for existing LIMS Batch is done on MERS ORDER NUMBER 1 field
        // AND Batch LIMS Security Department(which is having the plant id associated) respectively.
        String sqlText = "SELECT " +
                "    s_batch.s_batchid, " +
                "    s_batch.batchstatus " +
                "FROM " +
                "    s_batch " +
                "    JOIN s_prodvariant ON s_batch.prodvariantid = s_prodvariant.s_prodvariantid " +
                "WHERE " +
                "    s_batch.u_mesordersapbatch1 = ? " +
                "    AND s_batch.u_sapmatnumber = ? " +
                "    AND ( s_batch.u_sapplant = ? " +
                "          OR s_prodvariant.securitydepartment IN ( " +
                "        SELECT " +
                "            department.departmentid " +
                "        FROM " +
                "            department " +
                "            INNER JOIN u_sites ON department.u_siteid = u_sites.u_sitesid " +
                "        WHERE " +
                "            u_sites.sapplant = ? " +
                "    ) ) " +
                "    AND s_batch.batchstatus <> 'Released' " +
                "    AND s_batch.batchstatus <> 'Cancelled' " +
                "    AND s_batch.batchstatus <> 'Rejected'";
        DataSet dslimsBatch = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{strSAPBatchId, strMatNum, strSAPPlant, strSAPPlant});
        if (null == dslimsBatch) {
            errMsg = errMsg.append("").append(ErrorMessageUtil.NULL_SQL_VALUE).append("  While retriving LIMS Batch Id for SAP Batch Id: ").append(strSAPBatchId).append(" and SAP Inspection Lot: ").append(strInspectionLot).append("\n");
            throw new SapphireException(errMsg.toString());
        }
        if (dslimsBatch.getRowCount() > 0) {
            limsBatchFound[0] = "Y";
            limsBatchFound[1] = dslimsBatch.getValue(0, "s_batchid", "");
            limsBatchFound[2] = dslimsBatch.getValue(0, "batchstatus", "");
        }
        return limsBatchFound;
    }

    /**
     * This method is used to check mandatory values.
     *
     * @param dsBatchDetails Information for creating LIMS Batch
     * @param colNames       Mandatory column names for creating a LIMS Batch.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private void checkMandatiryFields(DataSet dsBatchDetails, String... colNames) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkMandatiryFields (method)");
        StringBuilder errMsg = new StringBuilder().append(" ");
        String colName = "";
        String dsColName = "";
        String colValue = "";
        for (int colNum = 0; colNum < colNames.length; colNum++) {
            colName = colNames[colNum];
            for (int dsColNo = 0; dsColNo < dsBatchDetails.getColumnCount(); dsColNo++) {
                dsColName = dsBatchDetails.getColumnId(dsColNo);
                if (colName.equalsIgnoreCase(dsColName)) {
                    colValue = dsBatchDetails.getValue(0, colName, "");
                    if ("".equalsIgnoreCase(colValue)) {
                        errMsg.append(ErrorMessageUtil.BlANK_VALUE).append(" For field: ").append(colName);
                        logger.error(errMsg.toString());
                        throw new SapphireException(errMsg.toString());
                    }
                }
            }
        }
    }

    /**
     * This method is used to handle Cancel Batch request.
     *
     * @param inspectionLot SAP Inspection Lot Number.
     * @param sapBatch      SAP Batch Number.
     * @param sapPlant      SAP Plant Code.
     * @param sapMaterial   SAP Material Number.
     * @return Returns LIMS Batch Id.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String[] processCancelBatch(String inspectionLot, String sapBatch, String sapPlant, String sapMaterial) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside processCancelBatch (method)");
        StringBuilder errMsg = new StringBuilder().append("");
        String[] retVal = new String[3];
        String[] existinglimsBatch = sapLotBatchExists(inspectionLot, sapBatch, sapPlant, sapMaterial);
        if ("N".equalsIgnoreCase(existinglimsBatch[0])) {
            errMsg.append(ErrorMessageUtil.CANCEL_BATCH_WITH_NO_OPEN_BATCH).append(" For Inspection Lot: ").append(inspectionLot).append(" , SAP Batch: ").append(sapBatch).append(" , SAP Plant: ").append(sapPlant).append(" and SAP Material: ").append(sapMaterial);
            throw new SapphireException(errMsg.toString());
        } else {
            String limsBatchId = existinglimsBatch[1];
            String batchStatus = existinglimsBatch[2];
            if ("Initial".equalsIgnoreCase(batchStatus) || "Received".equalsIgnoreCase(batchStatus)) {
                PropertyList plBatchUpdate = new PropertyList();
                plBatchUpdate.setProperty(EditSDI.PROPERTY_SDCID, "Batch");
                plBatchUpdate.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
                plBatchUpdate.setProperty("batchstatus", "Cancelled");
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plBatchUpdate);
                } catch (SapphireException ex) {
                    errMsg.append(ErrorMessageUtil.FAILED_TO_CANCEL).append(" LIMS Batch: ").append(limsBatchId).append(" Error is: ").append("\r\n").append(ex.getMessage());
                    throw new SapphireException(errMsg.toString());
                }
            } else {
                PropertyList plBatchUpdate = new PropertyList();
                plBatchUpdate.setProperty(EditSDI.PROPERTY_SDCID, "Batch");
                plBatchUpdate.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
                plBatchUpdate.setProperty("u_markedforcancel", "Y");
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plBatchUpdate);
                } catch (SapphireException ex) {
                    errMsg.append(ErrorMessageUtil.FAILED_TO_MARK_AS_CANCEL).append(" For LIMS Batch Id: ").append(limsBatchId).append(" Error is: ").append("\r\n").append(ex.getMessage());
                    throw new SapphireException(errMsg.toString());
                }

            }
            // Returning LIMS Batch Details
            retVal = existinglimsBatch;
        }
        return retVal;
    }

    /**
     * This method is used to check whether the Lot Rceipt payload is for cancel Batch or not.
     *
     * @param inspectionLotStatus SAP Inspection Lot status.
     * @return Returns True if Cancel Batch False.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private boolean checkCancelledBatch(String inspectionLotStatus) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkCancelledBatch (method)");
        boolean status = false;
        StringBuilder errMsg = new StringBuilder().append(" Error");
        if ("".equalsIgnoreCase(inspectionLotStatus)) {
            errMsg.append(ErrorMessageUtil.BlANK_VALUE).append(" For SAP Inspection Lot Status.").append("\n");
            throw new SapphireException(errMsg.toString());
        }
        if ("D".equalsIgnoreCase(inspectionLotStatus) || "C".equalsIgnoreCase(inspectionLotStatus)) {
            status = true;
        }
        return status;
    }

    /**
     * This method is used create a DataSet for consolidating all information from SAP which are required to create a LIMS batch.
     *
     * @param dsItemPayLoad  SAP data payload.
     * @param dsBatchDetails LIMS Batch Information.
     * @return Returns Batch information containing SAP information.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet getSAPDataForBatch(DataSet dsItemPayLoad, DataSet dsBatchDetails) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getSAPDataForBatch (method)");
        dsBatchDetails.addColumn("CATCODEGROUPPASS", DataSet.STRING);
        dsBatchDetails.addColumn("CODEPASS", DataSet.STRING);
        dsBatchDetails.addColumn("CATCODEGROUPFAIL", DataSet.STRING);
        dsBatchDetails.addColumn("CODEFAIL", DataSet.STRING);
        dsBatchDetails.addColumn("SAPINSPECTIONLOT", DataSet.STRING);
        dsBatchDetails.addColumn("SAPINSPECTIONLOTSTATUS", DataSet.STRING);
        dsBatchDetails.addColumn("SAPBATCHNUMBER", DataSet.STRING);
        dsBatchDetails.addColumn("SAPMATERIALNUMBER", DataSet.STRING);
        dsBatchDetails.addColumn("INSPECTIONORIGIN", DataSet.STRING);
        dsBatchDetails.addColumn("INSPECTIONTYPE", DataSet.STRING);
        dsBatchDetails.addColumn("SAPVENDORNUMBER", DataSet.STRING);
        dsBatchDetails.addColumn("SAPVENDORNAME", DataSet.STRING);
        dsBatchDetails.addColumn("SAPMATERIALDESC", DataSet.STRING);
        dsBatchDetails.addColumn("MESORDERSAPBATCH1", DataSet.STRING);
        dsBatchDetails.addColumn("MESORDERSAPBATCH2", DataSet.STRING);
        dsBatchDetails.addColumn("TOOLID", DataSet.STRING);
        dsBatchDetails.addColumn("LOCALMATERIALCODE", DataSet.STRING);
        dsBatchDetails.addColumn("SAPVENDORSTATUS", DataSet.STRING);
        dsBatchDetails.addColumn("SAPSUBSYTEM", DataSet.STRING);
        dsBatchDetails.addColumn("SAPPLANT", DataSet.STRING);
        dsBatchDetails.addColumn("SAPORIGINALBATCH", DataSet.STRING);
        dsBatchDetails.addColumn("SAPORIGINALMATERIAL", DataSet.STRING);
        //dsBatchDetails.addColumn("MFGPARTNUMBER",DataSet.STRING);
        dsBatchDetails.addColumn("MANUFACTURER", DataSet.STRING);
        dsBatchDetails.addColumn("BATCHDATE", DataSet.STRING);
        dsBatchDetails.addColumn("BATCHMFGDATE", DataSet.STRING);
        dsBatchDetails.addColumn("BATCHEXPIRYDATE", DataSet.STRING);
        dsBatchDetails.addColumn("MANUFACTURERSTATUS", DataSet.STRING);
        dsBatchDetails.addColumn("BATCHEXPIRYDATE", DataSet.STRING);
        dsBatchDetails.addColumn("MANUFACTURERNUMBER", DataSet.STRING);
        dsBatchDetails.addColumn("BATCHSIZE", DataSet.STRING);
        dsBatchDetails.addColumn("BATCHSIZEUNIT", DataSet.STRING);
        dsBatchDetails.addColumn("INSPECTIONSTARTDATE", DataSet.STRING);
        dsBatchDetails.addColumn("INSPECTIONENDDATE", DataSet.STRING);
        dsBatchDetails.addColumn("MARSCODE", DataSet.STRING);

        int rowId = dsBatchDetails.addRow();
        dsBatchDetails.setValue(rowId, "CATCODEGROUPPASS", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAICA", "CODEGRUPPE")), ";")[0]);
        dsBatchDetails.setValue(rowId, "CODEPASS", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAICA", "CODE")), ";")[0]);
        dsBatchDetails.setValue(rowId, "CATCODEGROUPFAIL", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAICA", "CODEGRUPPE")), ";")[1]);
        dsBatchDetails.setValue(rowId, "CODEFAIL", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAICA", "CODE")), ";")[1]);
        dsBatchDetails.setValue(rowId, "SAPINSPECTIONLOT", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "PRUEFLOS")), ";")[0]);
        dsBatchDetails.setValue(rowId, "SAPINSPECTIONLOTSTATUS", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "PRUEFSTAT")), ";")[0]);
        dsBatchDetails.setValue(rowId, "SAPBATCHNUMBER", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "CHARG")), ";")[0]);
        dsBatchDetails.setValue(rowId, "SAPMATERIALNUMBER", SAPUtil.removeLeadingZeroes(StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "MATNR")), ";")[0]));
        dsBatchDetails.setValue(rowId, "INSPECTIONORIGIN", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "HERKUNFT")), ";")[0]);
        dsBatchDetails.setValue(rowId, "INSPECTIONTYPE", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "ART")), ";")[0]);
        dsBatchDetails.setValue(rowId, "SAPVENDORNAME", "");
        dsBatchDetails.setValue(rowId, "SAPMATERIALDESC", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "KTEXTMAT")), ";")[0]);
        dsBatchDetails.setValue(rowId, "MESORDERSAPBATCH1", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "CHARG")), ";")[0]);
        dsBatchDetails.setValue(rowId, "MESORDERSAPBATCH2", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "CHARG")), ";")[0]);
        dsBatchDetails.setValue(rowId, "TOOLID", "(null)");// Force fully setting this to (Null)
        dsBatchDetails.setValue(rowId, "LOCALMATERIALCODE", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWUSERD1")), ";")[0]);
        dsBatchDetails.setValue(rowId, "SAPVENDORSTATUS", "");
        dsBatchDetails.setValue(rowId, "SAPSUBSYTEM", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SUBSYS")), ";")[0]);
        dsBatchDetails.setValue(rowId, "SAPPLANT", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "WERK")), ";")[0]);
        dsBatchDetails.setValue(rowId, "SAPORIGINALBATCH", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWTPLNR")), ";")[0]);
        dsBatchDetails.setValue(rowId, "SAPORIGINALMATERIAL", SAPUtil.removeLeadingZeroes(StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWPHYNR")), ";")[0]));
        //dsBatchDetails.setValue(rowId,"MFGPARTNUMBER",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWPHYNR"), ";")[0]);
        //dsBatchDetails.setValue(rowId,"MANUFACTURER",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWPHYNR"), ";")[0]);
        dsBatchDetails.setValue(rowId, "MANUFACTURERNUMBER", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "HERSTELLER")), ";")[0]);
        dsBatchDetails.setValue(rowId, "MANUFACTURERSTATUS", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWUSERC1")), ";")[0]);
        dsBatchDetails.setValue(rowId, "BATCHDATE", "(null)");
        dsBatchDetails.setValue(rowId, "BATCHMFGDATE", "(null)");
        dsBatchDetails.setValue(rowId, "BATCHEXPIRYDATE", "(null)");
        dsBatchDetails.setValue(rowId, "BATCHSIZE", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "LOSMENGE")), ";")[0]);
        dsBatchDetails.setValue(rowId, "BATCHSIZEUNIT", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "MENGENEINH")), ";")[0]);
        dsBatchDetails.setValue(rowId, "INSPECTIONSTARTDATE", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "PASTRTERM")), ";")[0]);
        dsBatchDetails.setValue(rowId, "INSPECTIONENDDATE", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "PAENDTERM")), ";")[0]);
        dsBatchDetails.setValue(rowId, "MARSCODE", StringUtil.split(replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWUSERC2")), ";")[0]);

        return dsBatchDetails;
    }

    /**
     * This method is used to handle null value.
     *
     * @param keyValue Input for which null value need to check.
     * @return Blank if null or actual string.
     */
    private String replaceInvalidValuewithBlank(String keyValue) {
        String retVal = null == keyValue ? "" : keyValue;
        return retVal;
    }

    /**
     * This method is used to get delay in seconds
     *
     * @param buffer Seconds to delay
     * @return Calender seconds in seconds
     * @throws SapphireException OOB Sapphire Exception
     */
    private String getDueDate(int buffer) {
        DataSet dsDate = new DataSet(connectionInfo);
        dsDate.addColumn("mydate", DataSet.DATE);
        Calendar cl = Calendar.getInstance();
        cl.add(Calendar.SECOND, buffer);
        int row = dsDate.addRow();
        dsDate.setDate(row, "mydate", cl);

        return dsDate.getValue(row, "mydate", "");
    }

}