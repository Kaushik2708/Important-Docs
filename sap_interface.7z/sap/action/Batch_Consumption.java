package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.ddt.IntfTransItem;
import labvantage.custom.alcon.sap.util.ErrorMessageUtil;
import labvantage.custom.alcon.sap.util.SAPUtil;
import sapphire.SapphireException;
import sapphire.action.AddSDIDetail;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * $Author: BAGCHAN1 $
 * $Date: 2021-07-15 12:16:06 -0500 (Thu, 15 Jul 2021) $
 * $Revision: 404 $
 */

public class Batch_Consumption extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 404 $";
    public static final String ID = "Batch_Consumption";
    public static final String VERSIONID = "1";
    private static final String __ENTITY_HEADER = "Header";
    private static final String __ENTITY_COMPONENT = "Component";
    private static final String __SAP_MAT_NUM = "MATERIAL";
    private static final String __SAP_BATCH = "BATCH";
    private static final String __SAP_PLANT = "PLANT";
    private static final String __MAT_QANTITY = "QUANTITY";
    private static final String __MAT_UNIT = "UNIT";
    private static final String __BATCH_STATUS_RELEASED = "Released";
    private static final String __BATCH_STATUS_CANCELLED = "Cancelled";
    private static final String __BATCH_STATUS_REJECTED = "Rejected";
    private static final String __STATUS_PENDING_LOT = "PENDING";
    private static final String __STATUS_COMPLETE = "COMPLETE";
    private static final String __LIMS_BATCH_ID = "batchid";
    private static final String __LIMS_BATCH_STATUS = "batchstatus";
    private static final String __LIMS_BATCH_TYPE = "batchtype";
    private static final String __LIMS_BATCH_PRODUCT_ID = "productid";
    private static final String __LIMS_BATCH_PRODUCT_VER_ID = "productversionid";


    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("=============== Start Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
        String _errMsg = "";
        String processingstatus = "";
        // LIMS Batch Information DataSet
        DataSet dsLIMSBatch;
        // Variable for Child LIMS Batch
        String childLIMSBatchId = "";
        // Variable for Child Batch Type
        String childLIMSBatchType = "";
        // Variable for Child Batch Status
        String childLIMSBatchStatus = "";
        // Variable for semicolon separated Parent SAP Batchs
        String parentSAPBatch = "";
        // Variable for semicolon separated Parent SAP Material
        String parentSAPMat = "";
        // Variable for semicolon separated Parent SAP Plant
        String parentSAPPlant = "";
        // Array of Parent SAP Batchs
        String[] arrParentSAPBatch;
        // Array of Parent SAP Material
        String[] arrParentSAPMat;
        // Array of Parent SAP Plant
        String[] arrParentSAPPlant;
        // Array of Parent Batch Qty
        String[] arrParentBatchQty;
        // Array of Parent Batch Qty Units
        String[] arrParentBatchQtyUnit;
        // Variable for Child LIMS Batch Ids,Type and Status
        String strChildLIMSBatchIds = "";
        String strchildLIMSBatchStatus = "";
        String strchildLIMSBatchTypes = "";
        // Variables for Parent batch
        String parentLIMSBatchIds = "";
        String parentBatchProduct = "";
        String parentBatchProductVerId = "";
        String parentBatchQty = "";
        String parentBatchQtyUnit = "";
        String finalParentBatchQty = "";
        String finalParentBatchQtyUnit = "";

        String strDatapayload = properties.getProperty("itemdata", "");
        if ("".equals(strDatapayload)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.INVALID_SAP_DATA_PAYLOAD));
        }
        DataSet dsPayload = SAPUtil.getDataSetFromXMLString(strDatapayload);
        if (null == dsPayload) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_DATASET_FOUND) + " While creating DataSet from Batch Consumption XML payload \n");
        }
        // Child SAP Batch ID
        String childBatch = SAPUtil.getColumnValue(dsPayload, __ENTITY_HEADER, __SAP_BATCH);
        // Checking Blank / Null value for Child SAP Batch
        if (checkMandatoryFields(childBatch)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + " For field: " + " SAP Batch. \n"));
        }
        // Child SAP Batch Material ID
        // Trimming leading zeros from SAP Material#
        String childBatchMatId = SAPUtil.removeLeadingZeroes(SAPUtil.getColumnValue(dsPayload, __ENTITY_HEADER, __SAP_MAT_NUM));
        // Checking Blank/Null value for Child Material Id
        if (checkMandatoryFields(childBatchMatId)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + " For field: " + " SAP Material Id. \n"));
        }
        // Child SAP Batch  Plant ID
        String childBatchPlantId = SAPUtil.getColumnValue(dsPayload, __ENTITY_HEADER, __SAP_PLANT);
        // Checking Blank/Null value for Child SAP Batch Plant
        if (checkMandatoryFields(childBatchPlantId)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + " For field: " + " SAP Plant Id. \n"));
        }
        // Checking for corresponding LIMS Batch
        dsLIMSBatch = sapLotBatchExists(childBatch, childBatchPlantId, childBatchMatId);
        childLIMSBatchId = dsLIMSBatch.getValue(0, __LIMS_BATCH_ID, "");

        if ("".equalsIgnoreCase(childLIMSBatchId)) {
            // If not exist
            // set the processing status to PENDING
            processingstatus = __STATUS_PENDING_LOT;
        } else {
            // Read child  batch status, batch type
            childLIMSBatchStatus = dsLIMSBatch.getValue(0, __LIMS_BATCH_STATUS, "");
            childLIMSBatchType = dsLIMSBatch.getValue(0, __LIMS_BATCH_TYPE, "");
            // Check if the LIMS Batch is not in Released or Cancelled status
            if (childLIMSBatchStatus.equalsIgnoreCase(__BATCH_STATUS_CANCELLED) || childLIMSBatchStatus.equalsIgnoreCase(__BATCH_STATUS_RELEASED) || childLIMSBatchStatus.equalsIgnoreCase(__BATCH_STATUS_REJECTED)) {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Aborting transaction. LIMS batch: " + childLIMSBatchId + " for SAP Batch: " + childBatch + ", SAP Material: " + childBatchMatId + " and SAP plant: " + childBatchPlantId + " is in " + childLIMSBatchStatus + " status."));
            } else {
                // Getting Parent details
                // Read Parent/Ingredient SAP Batch, Material, Plant , Material Qty and Material Qty unit
                parentSAPBatch = SAPUtil.getColumnValue(dsPayload, __ENTITY_COMPONENT, __SAP_BATCH);
                parentSAPMat = SAPUtil.getColumnValue(dsPayload, __ENTITY_COMPONENT, __SAP_MAT_NUM);
                parentSAPPlant = SAPUtil.getColumnValue(dsPayload, __ENTITY_COMPONENT, __SAP_PLANT);
                parentBatchQty = SAPUtil.getColumnValue(dsPayload, __ENTITY_COMPONENT, __MAT_QANTITY);
                parentBatchQtyUnit = SAPUtil.getColumnValue(dsPayload, __ENTITY_COMPONENT, __MAT_UNIT);
                // Splitting the SAP Parent Batch, Material and Plant
                arrParentSAPBatch = StringUtil.split(parentSAPBatch, ";");
                arrParentSAPMat = StringUtil.split(parentSAPMat, ";");
                arrParentSAPPlant = StringUtil.split(parentSAPPlant, ";");
                arrParentBatchQty = StringUtil.split(parentBatchQty, ";");
                arrParentBatchQtyUnit = StringUtil.split(parentBatchQtyUnit, ";");
                // DataSet for current genealogy
                DataSet dsCurrentIngredients = checkExistingIngredients(childLIMSBatchId);

                // Check if Ingredients/Parent Batch is blank/Null.
                if (checkMandatoryFields(parentSAPBatch)) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + " For field: " + "Parent SAP Batch Id. \n"));
                } else if (checkMandatoryFields(parentSAPMat)) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + " For field: " + "Parent SAP Material. \n"));
                } else if (checkMandatoryFields(parentSAPPlant)) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + " For field: " + "Parent SAP Plant. \n"));
                } else if (getRawMaterialComponentCount(arrParentSAPMat) == arrParentSAPMat.length) {
                    // Todo Remove After Phase 1 Release 2
                    // Check if payload does not contains any other parent batch information
                    // Apart from raw material batch (Start with "3")
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.ONLY_RAW_MATERIAL_PARENT_BATCH));
                } else {
                    // Checking Parent SAP Batch / Material / Plant is same or not
                    if (arrParentSAPBatch.length != arrParentSAPMat.length || arrParentSAPBatch.length != arrParentSAPPlant.length || arrParentSAPMat.length != arrParentSAPPlant.length) {
                        throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate("Aborting transaction. Number of Parent SAP Batch, SAP Material and SAP Plant are not same."));
                    } else {
                        // Checking cyclic genealogy
                        // If no cyclic genealogy then TRUE
                        if (checkCyclicGenealogy(childBatch, childBatchMatId, childBatchPlantId, arrParentSAPBatch, arrParentSAPMat, arrParentSAPPlant)) {
                            // Validating wheather Parent LIMS Batch exists or not ?
                            DataSet dsParentBatch;
                            for (int parentBatchCount = 0; parentBatchCount < arrParentSAPBatch.length; parentBatchCount++) {

                                // Check if Ingredients/Parent Batch is blank/Null.
                                if (checkMandatoryFields(arrParentSAPBatch[parentBatchCount])) {
                                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + " For field: " + "Parent SAP Batch Id. \n"));
                                } else if (checkMandatoryFields(arrParentSAPMat[parentBatchCount])) {
                                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + " For field: " + "Parent SAP Material. \n"));
                                } else if (checkMandatoryFields(arrParentSAPPlant[parentBatchCount])) {
                                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + " For field: " + "Parent SAP Plant. \n"));
                                } else if (arrParentSAPMat[parentBatchCount].startsWith("3")) {
                                    // Todo Remove After Phase 1 Release 2
                                    // If component (parents) raw material is started with '3'
                                    // then ignore that component set came in the payload
                                    continue;
                                } else {
                                    dsParentBatch = sapLotBatchExists(arrParentSAPBatch[parentBatchCount], arrParentSAPPlant[parentBatchCount], arrParentSAPMat[parentBatchCount]);
                                    // If no LIMS batch found
                                    if (dsParentBatch.getRowCount() == 0) {
                                        // set the processing status to PENDING
                                        processingstatus = __STATUS_PENDING_LOT;
                                        break;
                                    } else if (__BATCH_STATUS_CANCELLED.equalsIgnoreCase(dsParentBatch.getValue(0, __LIMS_BATCH_STATUS, ""))) {
                                        // set the processing status to PENDING
                                        processingstatus = __STATUS_PENDING_LOT;
                                        break;
                                    } else {
                                        // If has ingredients and ingredients already exists
                                        if (dsCurrentIngredients.getRowCount() > 0 && checkCurrentIngredients(dsCurrentIngredients, arrParentSAPBatch[parentBatchCount], arrParentSAPMat[parentBatchCount], arrParentSAPPlant[parentBatchCount])) {
                                            continue;
                                        } else {
                                            // Creating semicolon separated Child LIMS Batch Ids.
                                            strChildLIMSBatchIds = strChildLIMSBatchIds + childLIMSBatchId + ";";
                                            strchildLIMSBatchStatus = strchildLIMSBatchStatus + childLIMSBatchStatus + ";";
                                            strchildLIMSBatchTypes = strchildLIMSBatchTypes + childLIMSBatchType + ";";
                                            // Creating semicolon separated Parent LIMS Batch product and product version details.
                                            parentLIMSBatchIds = parentLIMSBatchIds + dsParentBatch.getValue(0, __LIMS_BATCH_ID, "") + ";";
                                            parentBatchProduct = parentBatchProduct + dsParentBatch.getValue(0, __LIMS_BATCH_PRODUCT_ID, "") + ";";
                                            parentBatchProductVerId = parentBatchProductVerId + dsParentBatch.getValue(0, __LIMS_BATCH_PRODUCT_VER_ID, "") + ";";
                                            finalParentBatchQty = finalParentBatchQty + arrParentBatchQty[parentBatchCount] + ";";
                                            finalParentBatchQtyUnit = finalParentBatchQtyUnit + arrParentBatchQtyUnit[parentBatchCount] + ";";
                                        }
                                    }
                                }

                            }
                            // Check if not pending
                            if (!processingstatus.equalsIgnoreCase(__STATUS_PENDING_LOT)) {
                                if (!"".equalsIgnoreCase(strChildLIMSBatchIds)) {
                                    // Adding Batch genealogy information
                                    addGenealogy(strChildLIMSBatchIds.substring(0, strChildLIMSBatchIds.length() - 1), strchildLIMSBatchTypes.substring(0, strchildLIMSBatchTypes.length() - 1), strchildLIMSBatchStatus.substring(0, strchildLIMSBatchStatus.length() - 1), parentLIMSBatchIds.substring(0, parentLIMSBatchIds.length() - 1), parentBatchProduct.substring(0, parentBatchProduct.length() - 1), parentBatchProductVerId.substring(0, parentBatchProductVerId.length() - 1), finalParentBatchQty.substring(0, finalParentBatchQty.length() - 1), finalParentBatchQtyUnit.substring(0, finalParentBatchQtyUnit.length() - 1));
                                }

                                // Set the processing status to complete
                                processingstatus = __STATUS_COMPLETE;
                            }
                        } else {
                            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Cyclic genealogy - same LIMS batch and ingredient information found"));
                        }
                    }

                }

            }


        }

        // Updating Transaction item with LIMS Batch id values.
        properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, "".

                equalsIgnoreCase(childLIMSBatchId) ? "" : childLIMSBatchId);
        properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, processingstatus);
    }

    /*****
     * This method is to count number of rawmaterial batch information found in current payload
     * @param arrParentMaterial Array of parent materials
     * @return Returns count of raw material parent batch present in current payload
     * @throws SapphireException OOB Sapphire exception
     *****/
    private int getRawMaterialComponentCount(String[] arrParentMaterial) {
        logger.info("Processing " + ID + ". (Action) : Inside getRawMaterialComponentCount (method)");
        int countRawMaterial = 0;
        for (int count = 0; count < arrParentMaterial.length; count++) {
            if (arrParentMaterial[count].startsWith("3")) {
                countRawMaterial++;
            }
        }
        return countRawMaterial;
    }

    /**
     * This method is used to check presence of ingredinets
     *
     * @param dsIngredients     dataSet of existing ingredients
     * @param parentSAPBatch    SAP Batch for parent
     * @param parentSAPMaterial SAP Material for parent
     * @param parentSAPPlant    SAP plant for parent
     * @return TRUE or FALSE
     * @throws SapphireException OOB Sapphire Exception
     */

    private boolean checkCurrentIngredients(DataSet dsIngredients, String parentSAPBatch, String parentSAPMaterial, String parentSAPPlant) {
        logger.info("Processing " + ID + ". (Action) : Inside checkCurrentIngredients (method)");
        PropertyList plFilter = new PropertyList();
        boolean retVal = false;
        // Find if ingredients already exists
        plFilter.setProperty(__SAP_BATCH.toLowerCase(), parentSAPBatch);
        plFilter.setProperty(__SAP_MAT_NUM.toLowerCase(), parentSAPMaterial);
        plFilter.setProperty(__SAP_PLANT.toLowerCase(), parentSAPPlant);
        if (dsIngredients.findRow(plFilter) != -1) {
            retVal = true;
        }
        return retVal;
    }

    /**
     * This method is used to check exsting ingredinets for a give LIMS batch
     *
     * @param childLIMSBatch Child LIMS Batch Id.
     * @return DataSet containing Ingredients details
     * @throws SapphireException
     */
    private DataSet checkExistingIngredients(String childLIMSBatch) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkExistingIngredients (method)");
        boolean retVal = false;
        String strSql = "SELECT s_batchgenealogy.s_batchid batchid, s_batchgenealogy.parentbatchid parentbatchid, s_batch.u_mesordersapbatch1 batch, s_batch.u_sapmatnumber material, s_batch.u_sapplant plant\n" +
                "FROM s_batchgenealogy INNER JOIN s_batch\n" +
                "ON s_batchgenealogy.parentbatchid = s_batch.s_batchid\n" +
                "WHERE s_batchgenealogy.s_batchid = ?";
        DataSet dsHasIngredients = getQueryProcessor().getPreparedSqlDataSet(strSql, new Object[]{childLIMSBatch});
        if (null == dsHasIngredients) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_DATASET_FOUND) + " While executing query  for checking existing ingredients present or not? \n");
        }
        return dsHasIngredients;
    }

    /**
     * This method is used to create batch genealogy
     *
     * @param limsBatchId        Semicolon separated child LIMS batch ids
     * @param batchType          Semicolon separated child LIMS batch type
     * @param batchStatus        Semicolon separated child LIMS batch status
     * @param parentLIMSBatch    Semicolon separated parent LIMS batch ids.
     * @param parentProductId    Semicolon separated parent product ids.
     * @param parentProductVerId Semicolon separated parent product version ids.
     * @param parentBatchQty     Semicolon separated parent batch quantity
     * @param parentBatchQtyUnit Semicolon separated parent batch quantity unit
     * @throws SapphireException OOB Sapphire exception
     */
    private void addGenealogy(String limsBatchId, String batchType, String batchStatus, String parentLIMSBatch, String parentProductId, String parentProductVerId, String parentBatchQty, String parentBatchQtyUnit) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside addGenealogy (method)");
        StringBuilder errMsg = new StringBuilder().append(" ");
        // Setting
        PropertyList plGenealogy = new PropertyList();
        plGenealogy.setProperty("sdcid", "Batch");
        plGenealogy.setProperty("s_batchid", limsBatchId);
        plGenealogy.setProperty("batchtype", batchType);
        plGenealogy.setProperty("batchstatus", batchStatus);
        plGenealogy.setProperty("parentbatchid", parentLIMSBatch);
        plGenealogy.setProperty("parentproductid", parentProductId);
        plGenealogy.setProperty("parentproductversionid", parentProductVerId);
        plGenealogy.setProperty("amountactual", parentBatchQty);
        plGenealogy.setProperty("amountactualtext", parentBatchQty);
        plGenealogy.setProperty("amountunits", parentBatchQtyUnit);
        plGenealogy.setProperty("propsmatch", "Y");
        plGenealogy.setProperty("u_issapflag", "Y");
        plGenealogy.setProperty("linkid", "batch genealogy");
        try {
            getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, plGenealogy);
        } catch (Exception ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.FAILED_TO_EXECUTE_GENEALOGY, ex.getMessage())));
        }
    }


    /**
     * This method is used to check cyclic genealogy(Parent and Child batch is same).
     *
     * @param childSAPBatch     Child SAP Batch
     * @param childSAPMat       Child SAP Material
     * @param childSAPPlant     Child SAP Plant
     * @param arrParentSAPBatch Array of Parent SAP Batch(s)
     * @param arrParentSAPMat   Array of Parent SAP Material(s)
     * @param arrParentSAPPlant Array of Parent SAP Plant(s)
     * @return Returns TRUE or FALSE
     * @throws SapphireException OOB Sapphire Exception
     */
    private boolean checkCyclicGenealogy(String childSAPBatch, String childSAPMat, String childSAPPlant, String[] arrParentSAPBatch, String[] arrParentSAPMat, String[] arrParentSAPPlant) {
        logger.info("Processing " + ID + ". (Action) : Inside checkCyclicGenealogy(method)");
        boolean retVal = true;
        // Looping through Parent SAP Batch/Material/Plant
        for (int parentNo = 0; parentNo < arrParentSAPBatch.length; parentNo++) {
            retVal = !(childSAPBatch).equalsIgnoreCase(arrParentSAPBatch[parentNo]) || !(childSAPMat).equalsIgnoreCase(SAPUtil.removeLeadingZeroes(arrParentSAPMat[parentNo])) || !(childSAPPlant).equalsIgnoreCase(arrParentSAPPlant[parentNo]);
            // If Parent and Child Batch is same
            if (retVal != true) {
                return retVal;
            }
        }
        return retVal;
    }

    /**
     * This method is used to check mandatory values.
     *
     * @param colValue Value to check.
     * @return True/False
     * @throws SapphireException
     */

    private boolean checkMandatoryFields(String colValue) {
        logger.info("Processing " + ID + ". (Action) : Inside checkMandatoryFields(method)");
        boolean retVal = false;
        if (colValue == null || "".equalsIgnoreCase(colValue)) {
            retVal = true;
        }
        return retVal;
    }

    /**
     * This method is used to check whether LIMS Batch already exist or not.
     * Only SAP created batch is considered.
     *
     * @param strSAPBatchId SAP Batch Number.
     * @param strSAPPlant   SAP Plant code.
     * @param strMatNum     SAP Material Number.
     * @return DataSet of LIMS Batch Id iif exists.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet sapLotBatchExists(String strSAPBatchId, String strSAPPlant, String strMatNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside sapLotBatchExists (method)");
        // method variables
        String limsBatch = "";
        StringBuilder errMsg = new StringBuilder().append("");
        String sqlText = "SELECT " +
                "    s_batch.s_batchid          batchid, " +
                "    s_batch.batchstatus        batchstatus, " +
                "    s_batch.batchtype          batchtype, " +
                "    s_batch.productid          productid, " +
                "    s_batch.productversionid   productversionid, " +
                "    s_batch.createdt           createdt " +
                "FROM " +
                "    s_batch " +
                "    JOIN s_prodvariant ON s_batch.prodvariantid = s_prodvariant.s_prodvariantid " +
                "WHERE " +
                "    s_batch.u_mesordersapbatch1 = ? " +
                "    AND s_batch.u_sapmatnumber = ? " +
                "    AND ( s_batch.u_sapplant = ? " +
                "          OR s_prodvariant.securitydepartment IN ( " +
                "        SELECT " +
                "            department.departmentid " +
                "        FROM " +
                "            department " +
                "            INNER JOIN u_sites ON department.u_siteid = u_sites.u_sitesid " +
                "        WHERE " +
                "            u_sites.sapplant = ? " +
                "    ) ) " +
                "    AND s_batch.u_issapflag = 'Y' ";

        DataSet dslimsBatch = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{strSAPBatchId, strMatNum, strSAPPlant, strSAPPlant});
        if (null == dslimsBatch) {
            errMsg = errMsg.append("").append(ErrorMessageUtil.NULL_SQL_VALUE).append("  While retriving LIMS Batch Id for SAP Batch Id: ").append(strSAPBatchId).append("\n");
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(errMsg.toString()));
        }
        // Sorting to get the latest on top if LIMS Batch found
        if (dslimsBatch.getRowCount() > 0) {
            dslimsBatch.sort("createdt D");
        }
        return dslimsBatch;
    }

}
