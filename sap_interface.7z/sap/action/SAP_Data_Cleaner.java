package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.sap.util.ErrorMessageUtil;
import sapphire.SapphireException;
import sapphire.action.AddToDoListEntry;
import sapphire.action.BaseAction;
import sapphire.action.DeleteSDI;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
/**
 * $Author: GHOSHKA1 $
 * $Date: 2022-01-04 18:04:26 +0530 (Tue, 04 Jan 2022) $
 * $Revision: 697 $
 */

/********************************************************************************************
 * $Revision: 697 $
 * Description:
 * This class is for cleaning SAP garbage data
 * @author Kaushik Ghosh
 * @version 1
 *******************************************************************************************/

public class SAP_Data_Cleaner extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 697 $";
    public static final String ID = "SAP_Data_Cleaner";
    public static final String VERSIONID = "1";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.debug("Started processing action " + ID);
        String purgeOffset = properties.getProperty("purgeoffset", "60");
        if (null == purgeOffset) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(" Aborting transaction. Invalid number of days supplied."));
        }
        // cleaning NO DATA RECEIVED transactions from SAP
        cleanSAPMessageStage(purgeOffset);
        // Cleaning inactive messages
        cleanInactiveMessages(purgeOffset);
        logger.debug("End processing action " + ID);
    }

    /************************
     * This method is used to clean NO_DATA_FOUND message stage ids.
     * @param purgeOffset Days interval
     * @throws SapphireException
     ************************/
    private void cleanSAPMessageStage(String purgeOffset) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside cleanSAPMessageStage (method)");
        String sqlText = " delete  u_intftrans where status='NO_DATA_RECEIVED' and transdirection='INBOUND' and TRUNC(createdt) <= TRUNC(SYSDATE - " + purgeOffset + ") ";
        database.executeUpdate(sqlText);
    }

    /**********************
     * This method is used to clean inactive messages
     * @param purgeOffset Days interval
     * @throws SapphireException
     **********************/
    private void cleanInactiveMessages(String purgeOffset) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside cleanInactiveMessages (method)");
        String sqlText = " delete u_saplvmessagestage where  NVL(activeflag,'Y')='N' AND TRUNC(createdt) <= TRUNC(SYSDATE - "+purgeOffset+") ";
        database.executeUpdate(sqlText);
    }
}
