package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.ddt.IntfTransItem;
import labvantage.custom.alcon.sap.util.ErrorMessageUtil;
import labvantage.custom.alcon.sap.util.SAPPlants;
import labvantage.custom.alcon.sap.util.SAPUtil;
import labvantage.custom.alcon.util.AlconUtil;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.HashMap;
/**
 * @author Kaushik Ghosh
 * @version 1
 * $Author: BAGCHAN1 $
 * $Date: 2022-02-07 23:42:32 +0530 (Mon, 07 Feb 2022) $
 * $Revision: 717 $
 */

/********************************************************************************************
 * $Revision: 717 $
 * Description:
 * This class is for Vision Care Raw Material LOT RECEIPT Service.
 * This service is responsible for creation of LIMS Batch based upon the SAP Inspection Lot.
 *******************************************************************************************/

public class VisionCare_Lot_Receipt extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 717 $";
    //Action details
    public static final String ID = "VisionCare_Lot_Receipt";
    public static final String VERSIONID = "1";
    // SAP Interface specific variables
    public static final String VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "SAP_INTERFACE";
    private static final String _PROPS_TRANSITEMID = "u_intftransitemid";
    private static final String _PROPS_ITEMDATA = "itemdata";
    private static final String _PROPS_TRANSITEM_SDCID = "IntfTransItem";
    // For Mandatory Key missing
    private String ___KEY_NOT_FOUND = "KEY_NOT_FOUND";
    // Batch creation properties
    private static final String __PROPS_COUNT_RULE = "countrule";
    private static final String __PROPS_BATCH_SDCID = "Batch";
    private static final String __PROPS_SAMPLE_SDCID = "Sample";
    private static final String __PROPS_NEW_KEYID1 = "newkeyid1";
    private static final String __PROPS_LIMS_BATCH_STATUS = "batchstatus";
    private static final String __PROPS_LIMS_BATCH_ID = "s_batchid";
    private static final String __PROPS_LIMS_SAMPLE_ID = "s_sampleid";
    private static final String __PROPS_LIMS_SAMPLE_STATUS = "samplestatus";
    private static final String __PROPS_CREATE_DATE = "createdt";
    private static final String __PROPS_BATCH_PRODUCTID = "productid";
    private static final String __PROPS_BATCH_PRODUCT_VERSIONID = "productversionid";
    private static final String __PROPS_BATCH_PRODUCT_DESC = "productdesc";
    private static final String __PROPS_BATCH_PRODUCT_SUB_TYPE = "u_prodsubtypeid";
    private static final String __PROPS_BATCH_PRODUCT_VARIANTID = "prodvariantid";
    private static final String __PROPS_PRODUCT_VARIANTID = "s_prodvariantid";
    private static final String __PROPS_SAMPLING_PLAN_ID = "s_samplingplanid";
    private static final String __PROPS_SAMPLING_PLAN_VERSION_ID = "s_samplingplanversionid";
    private static final String __PROPS_PRODUCT_VARIANTTYPE = "prodvarianttype";
    private static final String __PROPS_BATCH_PRODUCT_INSPECTIONLOT = "u_sapinspectionlot";
    private static final String __PROPS_PRODUCT_INSPECTIONLOT_STATUS = "sapinspectionlotstatus";
    private static final String __PROPS_BATCH_SAP_BATCH = "u_sapbatchnumber";
    private static final String __PROPS_BATCH_MAT_NUMBER = "u_sapmatnumber";
    private static final String __PROPS_BATCH_INSPECTION_LOT_ORIGIN = "u_inspectionorigin";
    private static final String __PROPS_BATCH_INSPECTION_TYPE = "u_inspectiontype";
    private static final String __PROPS_BATCH_VENDOR_NAME = "u_sapvendorname";
    private static final String __PROPS_BATCH_MATERIAL_DESC = "u_sapmaterialdesc";
    private static final String __PROPS_BATCH_SUPPLIER_ADDRESS_TYPE = "supplieraddresstype";
    private static final String __PROPS_BATCH_SUPPLIER_ADDRESS_ID = "supplieraddressid";
    private static final String __PROPS_BATCH_MANUFACTURER_ADDRESS_TYPE = "manufactureraddresstype";
    private static final String __PROPS_BATCH_MANUFACTURER_ADDRESS_ID = "manufactureraddressid";
    private static final String __PROPS_BATCH_SECURITY_USER = "securityuser";
    private static final String __PROPS_BATCH_SECURITY_DEPT = "securitydepartment";
    private static final String __PROPS_BATCH_MES_ORDER_SAP_BATCH1 = "u_mesordersapbatch1";
    private static final String __PROPS_BATCH_MES_ORDER_SAP_BATCH2 = "u_mesordersapbatch2";
    private static final String __PROPS_BATCH_TOOL_ID = "u_toolid";
    private static final String __PROPS_BATCH_LOCAL_MAT_CODE = "u_locmatcode";
    private static final String __PROPS_BATCH_SAP_VENDOR_STATUS = "u_sapvendorstatus";
    private static final String __PROPS_BATCH_DESC = "batchdesc";
    private static final String __PROPS_BATCH_PRODUCT_SUBTYPE_ID = "u_productsubtypeid";
    private static final String __PROPS_BATCH_SAP_SUBSYSTEM = "u_sapsubsystem";
    private static final String __PROPS_BATCH_TEMPLATE_FLAG = "templateflag";
    private static final String __PROPS_BATCH_ACTIVE_FLAG = "activeflag";
    private static final String __PROPS_BATCH_RESULT_UPLOAD_FLAG = "u_resultsuploaded";
    private static final String __PROPS_BATCH_SAP_VENDOR_NUM = "u_sapvendornum";
    private static final String __PROPS_BATCH_TEMPLATE_ID = "templateid";
    private static final String __PROPS_STAGE_TEMPLATE_KEYID_ID = "templatekeyid1";
    private static final String __PROPS_BATCH_TYPE = "batchtype";
    private static final String __PROPS_BATCH_CATCODEGROUP_PASS = "u_catcodegrouppass";
    private static final String __PROPS_BATCH_CATCODEGROUP_FAIL = "u_catcodegroupfail";
    private static final String __PROPS_BATCH_CATCODE_PASS = "u_catcodepass";
    private static final String __PROPS_BATCH_CATCODE_FAIL = "u_catcodefail";
    private static final String __PROPS_BATCH_IS_SAP_FLAG = "u_issapflag";
    private static final String __PROPS_BATCH_SAP_PLANT = "u_sapplant";
    private static final String __PROPS_BATCH_SIZE = "batchsize";
    private static final String __PROPS_BATCH_SIZE_UNITS = "batchsizeunits";
    private static final String __PROPS_BATCH_INSPECTION_START_DATE = "u_sapinspectionstartdt";
    private static final String __PROPS_BATCH_INSPECTION_END_DATE = "u_sapinspectionenddt";
    private static final String __PROPS_MARS_CODE_ATTR = "mars_code";
    private static final String __PROPS_BATCH_SAP_PARENT_BATCH = "u_originalbatchid";
    private static final String __PROPS_BATCH_SAP_PARENT_MATERIAL = "u_origsapmat";
    private static final String __PROPS_BATCH_CREATED_BY = "u_sapbatchcreateby";
    private static final String __PROPS_PROCESS_STAGE_LABEL = "label";
    private static final String __PROPS_PROCESS_STAGE_LEVEL_ID = "levelid";
    private static final String __PROPS_PROCESS_STAGE_SOURCE_LABEL = "sourcelabel";
    private static final String __PROPS_PROCESS_STAGE_TYPE = "u_stagetype";
    private static final String __PROPS_BATCH_STAGE_ID = "s_batchstageid";
    private static final String __PROPS_PROCESS_STAGE_ID = "s_processstageid";
    private static final String __PROPS_BATCH_STAGE_PROCESS_STAGE_ID = "processstageid";
    private static final String __PROPS_VENDOR_BATCH_NUMBER = "prodvariantlotreference";
    private static final String __PROPS_BATCH_SELECTEDSET = "u_sapselectedset";
    private static final String __PROPS_BATCH_SAP_LAB_CONF_NUM = "u_saplabconfnum";
    private static final String __PROPS_BATCH_RESULT_UPLOAD_RESTRICTION_FLAG = "u_resultuploadrestrictionflag";


    // Added for Shipment Types ( Required while adding samples to stage )
    private static final String __PROPS_PRE_SHIPMENT = "PRESHIPMENT";
    private static final String __PROPS_FIRST_SHIPMENT = "FIRSTSHIPMENT";
    private static final String __PROPS_REPEAT_SHIPMENT = "REPEATSHIPMENT";
    private static final String __PROPS_RETEST = "RETEST";

    // Added for different  batch status
    private static final String __PROPS_STATUS_INITIAL = "Initial";
    private static final String __PROPS_STATUS_RECEIVED = "Received";
    private static final String __PROPS_STATUS_CANCELLED = "Cancelled";
    private static final String __PROPS_STATUS_REJECTED = "Rejected";
    private static final String __PROPS_STATUS_RELEASED = "Released";
    private static final String __PROPS_STATUS_PENDING_RELEASED = "Pending Release";
    // Added for SAP Table names
    private static final String __PROPS_ENTITY_QAIVC = "QAIVC";
    private static final String __PROPS_ENTITY_QAIMV = "QAIMV";
    private static final String __PROPS_ENTITY_QAICA = "QAICA";
    // Added for SAP Keys fields
    private static final String __PROPS_SAP_KEY_CODEGRUPPE = "CODEGRUPPE";
    private static final String __PROPS_SAP_KEY_CODE = "CODE";
    private static final String __PROPS_SAP_KEY_PRUEFLOS = "PRUEFLOS";
    private static final String __PROPS_SAP_KEY_PRUEFSTAT = "PRUEFSTAT";
    private static final String __PROPS_SAP_KEY_CHARG = "CHARG";
    private static final String __PROPS_SAP_KEY_MATNR = "MATNR";
    private static final String __PROPS_SAP_KEY_HERKUNFT = "HERKUNFT";
    private static final String __PROPS_SAP_KEY_ART = "ART";
    private static final String __PROPS_SAP_KEY_KTEXTMAT = "KTEXTMAT";
    private static final String __PROPS_SAP_KEY_SWUSERD1 = "SWUSERD1";
    private static final String __PROPS_SAP_KEY_SWUSERC1 = "SWUSERC1";
    private static final String __PROPS_SAP_KEY_SUBSYS = "SUBSYS";
    private static final String __PROPS_SAP_KEY_WERK = "WERK";
    private static final String __PROPS_SAP_KEY_SWTPLNR = "SWTPLNR";
    private static final String __PROPS_SAP_KEY_SWPHYNR = "SWPHYNR";
    private static final String __PROPS_SAP_KEY_LOSMENGE = "LOSMENGE";
    private static final String __PROPS_SAP_KEY_MENGENEINH = "MENGENEINH";
    private static final String __PROPS_SAP_KEY_PASTRTERM = "PASTRTERM";
    private static final String __PROPS_SAP_KEY_PAENDTERM = "PAENDTERM";
    private static final String __PROPS_SAP_KEY_SWUSERC2 = "SWUSERC2";
    private static final String __PROPS_SAP_KEY_LICHN = "LICHN";
    private static final String __PROPS_SAP_KEY_LIFNR = "LIFNR";
    private static final String __PROPS_SAP_KEY_NAME1LIF = "NAME1LIF";
    private static final String __PROPS_SAP_KEY_AUSWMENGE1 = "AUSWMENGE1";
    private static final String __PROPS_SAP_KEY_RUECKMELNR = "RUECKMELNR";
    private static final String __PROPS_SAP_BATCH_TYPE = "u_sapbatchtype";
    private static final String __PROPS_SAP_ART_RETEST = "Z8CM09";
    // Added for Batch Master Reprocessing
    private static final String __REPROCESS_DATE = "reprocessdate";
    // Hashmap for mandatory fileds
    private static HashMap<String, String> hmMandatoryFields = null;

    // Mandatory fileds. If any new fields need to check then
    // just add  in this hashmap
    static {
        hmMandatoryFields = new PropertyList();
        hmMandatoryFields.put(__PROPS_PRODUCT_INSPECTIONLOT_STATUS, "PRUEFSTAT(Inspection Lot Status)");
        hmMandatoryFields.put(__PROPS_BATCH_PRODUCT_INSPECTIONLOT, "PRUEFLOS(Inspection Lot)");
        hmMandatoryFields.put(__PROPS_BATCH_SAP_BATCH, "CHARG(SAP Batch #)");
        hmMandatoryFields.put(__PROPS_BATCH_SAP_PLANT, "WERK(SAP Plant)");
        hmMandatoryFields.put(__PROPS_BATCH_MAT_NUMBER, "MATNR(SAP Material #)");
        hmMandatoryFields.put(__PROPS_BATCH_INSPECTION_LOT_ORIGIN, "HERKUNFT(Inspection Lot Origin)");
        hmMandatoryFields.put(__PROPS_BATCH_INSPECTION_TYPE, "ART(SAP Inspection Type)");
    }

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("=============== Start Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
        String strDataPayload = properties.getProperty(_PROPS_ITEMDATA, "");
        if ("".equalsIgnoreCase(strDataPayload)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.INVALID_SAP_DATA_PAYLOAD));
        }
        DataSet dsSAPDataPayload = SAPUtil.getDataSetFromXMLString(strDataPayload);
        logger.info("------------ VisionCare RM Lot Receipt SAP payload ------------" + "\n" + dsSAPDataPayload.toJSONString());
        logger.info("------------ Start processing LIMS Batch creation for Vision Care RM -------------");
        // ******** Start processing VIsionCare RM Batch processing
        String[] limsBatchDetails = processRMBatch(dsSAPDataPayload);
        // Getting SAP Batch , SAP Material Number , SAP Plant and LIMS Batch Id
        String limsBatchId = limsBatchDetails[0];
        String sapBatchNum = limsBatchDetails[1];
        String sapMatNum = limsBatchDetails[2];
        String sapPlant = limsBatchDetails[3];
        // Setting transaction status
        if (!"".equalsIgnoreCase(limsBatchId)) {
            properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, limsBatchId);
            properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, IntfTransItem.TRANS_ITEM_STATUS_COMPLETE);
        }
        // ********* Reprocess PENDING Batch Master Transaction Items
        reprocessBatchMaster(sapBatchNum, sapMatNum, sapPlant);
        logger.info("------------ End processing LIMS Batch creation for Vision Care RM -------------");
        logger.info("=============== End Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
    }

    /*********
     * This method is for processing raw material batch for JCM.
     * @param dsSAPPayload
     * @throws SapphireException
     *********/
    private String[] processRMBatch(DataSet dsSAPPayload) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside processRMBatch (method)");
        String curSamplingPlanId = "";
        String curSamplingPlanVersionId = "";
        String limsBatchId = "";
        String[] limsBatchDetails = new String[4];
        // Creating batch data from SAP Payload
        DataSet dsBatchDetails = getBatchDataFromSAPPayload(dsSAPPayload);

        // Checking mandatory fields
        // If any of the mandatory fields defined in PL is BLANK
        // Throw an ERROR
        checkMandatoryFields(dsBatchDetails, hmMandatoryFields);
        // Getting SAP Batch, Material# and Plant
        String sapBatch = dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_BATCH, "");
        String sapInspectionLotNum = dsBatchDetails.getValue(0, __PROPS_BATCH_PRODUCT_INSPECTIONLOT, "");
        String sapMaterialNum = dsBatchDetails.getValue(0, __PROPS_BATCH_MAT_NUMBER, "");
        String sapPlant = dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PLANT, "");
        String sapInspectionLotStatus = dsBatchDetails.getValue(0, __PROPS_PRODUCT_INSPECTIONLOT_STATUS, "");
        String inspectionType = dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_TYPE, "");
        String inspectionLotOrigin = dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_LOT_ORIGIN, "");
        String vendorSAPBatch = dsBatchDetails.getValue(0, __PROPS_VENDOR_BATCH_NUMBER, "");

        // **** If Inspection Lot Origin is 01 (Procurement) then LICHN ( SAP Vendor Batch ) is mandatory ****
        if ("01".equalsIgnoreCase(inspectionLotOrigin)) {
            if (___KEY_NOT_FOUND.equalsIgnoreCase(vendorSAPBatch)) {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00000, "LICHN(SAP Vendor Batch # )")));
            } else if ("".equalsIgnoreCase(vendorSAPBatch)) {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00001, "LICHN(SAP Vendor Batch # )")));
            }
        }

        if (checkCancelledBatch(sapInspectionLotStatus, sapBatch, sapMaterialNum, sapPlant)) {
            // Cancelling samples and returning Batch Id
            limsBatchId = processCancelRequest(sapInspectionLotNum);

        } else {
            //****** Boolean flag to identify - whether LIMS Batch found by SAP Batch or SAP Vendor Batch
            boolean checkByVendorBatch = false;
            // Standard RM lot request
            // ******** Check for existing Batch
            // ******** Batch status should not be Cancelled
            DataSet dsExistingLIMSBatch = sapLotBatchExists(sapBatch, sapMaterialNum, sapPlant);
            // ******** If LIMS Batch not found by SAP Batch + Material # + Plant
            // ******** Then check if Batch exists with Vendor SAP Batch + Material # + Plant
            // ******** Changed as a part of MDLIMS 1197 - Skip Vendor Lot check for Batam in IRIS interface
            if (dsExistingLIMSBatch.getRowCount() == 0 && !SAPPlants.PROPS_VISION_CARE_PLANT_ID01.equalsIgnoreCase(sapPlant)) {
                dsExistingLIMSBatch.clear();
                // ******** Getting LIMS Batch by Vendor SAP Batch # + Material # + Plant
                dsExistingLIMSBatch = sapLotBatchExists(vendorSAPBatch, sapMaterialNum, sapPlant);
                // ****** Setting flag to true if checked by SAP Vendor Batch
                checkByVendorBatch = true;
            }
            // ******** Checking if LIMS batch already exists or not ??
            // ******** Either by ( SAP Batch + Material # + Plant ) OR ( Vendor SAP Batch + Material # + Plant )
            if (dsExistingLIMSBatch.getRowCount() > 0) {
                // Left wing of flow chart
                // Sorting the existing batch details to get the latest on top of DataSet
                dsExistingLIMSBatch.sort(__PROPS_CREATE_DATE + " D");
                // Getting LIMS batch id
                limsBatchId = dsExistingLIMSBatch.getValue(0, __PROPS_LIMS_BATCH_ID, "");
                String limsBatcDesc = dsExistingLIMSBatch.getValue(0, __PROPS_BATCH_DESC, "");
                // Geting the status of existing LIMS Batch
                String limsBatchStatus = dsExistingLIMSBatch.getValue(0, __PROPS_LIMS_BATCH_STATUS);
                // Getting current version of product
                String currentProductId = dsExistingLIMSBatch.getValue(0, __PROPS_BATCH_PRODUCTID, "");
                String currentProdVerId = dsExistingLIMSBatch.getValue(0, __PROPS_BATCH_PRODUCT_VERSIONID, "");
                // Getting product varinat id
                String prodVariantId = dsExistingLIMSBatch.getValue(0, __PROPS_BATCH_PRODUCT_VARIANTID);
                // Getting current Sampling Plan details
                DataSet dsCurrentSPDetails = getCurrentSamplingPlanByPV(prodVariantId);
                if (dsCurrentSPDetails.getRowCount() == 0) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00024, prodVariantId)));
                }
                curSamplingPlanId = dsCurrentSPDetails.getValue(0, __PROPS_SAMPLING_PLAN_ID);
                curSamplingPlanVersionId = dsCurrentSPDetails.getValue(0, __PROPS_SAMPLING_PLAN_VERSION_ID);
                // Getting process Stage details
                DataSet processStageDetails = getProcessStageDetails(curSamplingPlanId, curSamplingPlanVersionId);
                // If any of the Pre Shipment / First Shipment / repeat Shipment stage type exists in current SP
                if (validateStageTypeInCurrentSP(processStageDetails)) {
                    // ************ Update LIMS Batch
                    updateLIMSBatch(limsBatchId, dsBatchDetails);
                    // Adding new samples to Pre shipment / First Shipment / Repeat Shipment stage
                    addSamplesToExistingLIMSBatch(limsBatchId, limsBatchStatus, limsBatcDesc, curSamplingPlanId, curSamplingPlanVersionId, processStageDetails, currentProductId, currentProdVerId, prodVariantId, inspectionType);
                } else {
                    // If batch is closed batch and department --> MES order restriction = N then create new LIMS batch
                    if (__PROPS_STATUS_RELEASED.equalsIgnoreCase(limsBatchStatus) || __PROPS_STATUS_REJECTED.equalsIgnoreCase(limsBatchStatus)) {

                        if ("N".equalsIgnoreCase(getMESOrderRestrigtionFlag(prodVariantId))) {
                            // create new LIMS batch
                            limsBatchId = createNewRMBatch(dsBatchDetails, sapBatch, sapMaterialNum, sapPlant);
                        } else {
                            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.RM_ERR_00007));
                        }
                    } else {
                        throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00008, limsBatchId, (checkByVendorBatch ? "SAP Vendor Batch: " + vendorSAPBatch : "SAP Batch: " + sapBatch), sapMaterialNum, sapPlant)));
                    }

                }
            } else {
                // Right wing of Flow chart
                // creating new LIMS batch
                limsBatchId = createNewRMBatch(dsBatchDetails, sapBatch, sapMaterialNum, sapPlant);
            }
        }

        limsBatchDetails[0] = limsBatchId;
        limsBatchDetails[1] = sapBatch;
        limsBatchDetails[2] = sapMaterialNum;
        limsBatchDetails[3] = sapPlant;

        return limsBatchDetails;
    }

    /************
     * This method is used to remove the locking on BatchStage.
     * @param limsBatchId
     * @throws SapphireException
     ************/

    private void unlockBatchStage(String limsBatchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside unlockBatchStage (method)");
        String sql = " SELECT " +
                "    rsetid " +
                "FROM " +
                "    rsetitems " +
                "WHERE " +
                "    sdcid = 'LV_BatchStage' " +
                "    AND keyid1 = ? " +
                "    AND keyid2 = '(null)' " +
                "    AND keyid3 = '(null)' ";

        DataSet dsBatchStageRset = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{limsBatchId});
        if (null == dsBatchStageRset) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        }
        // If there are any open RsetIds . Clease those before proceeding
        if (dsBatchStageRset.getRowCount() > 0) {
            getDAMProcessor().clearRSet(dsBatchStageRset.getColumnValues("rsetid", ";"));
        }

    }

    /************
     * This method is used to clear RSet ids to avoid RSet locking.
     * @param sampleIds
     * @throws SapphireException
     ************/
    private void clearAllSampleRSET(String sampleIds) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside clearAllSampleRSET (method)");
        // Getting all RSetIds for the given Samples
        String sqlText = " SELECT rsetid  " +
                "FROM rsetitems " +
                "WHERE sdcid = 'Sample' " +
                "AND keyid1 IN('" + StringUtil.replaceAll(sampleIds, ";", "','") + "')" +
                "AND keyid2 = '(null)' " +
                "AND keyid3 = '(null)' ";

        DataSet dsRSetIds = getQueryProcessor().getSqlDataSet(sqlText);
        if (null == dsRSetIds) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        }
        // If there are any open RsetIds . Clease those before proceeding
        if (dsRSetIds.getRowCount() > 0) {
            getDAMProcessor().clearRSet(dsRSetIds.getColumnValues("rsetid", ";"));
        }
    }

    /**********
     * This method is used to reprocess Batch master awaiting lots.
     * @param sapBatch
     * @param sapMat
     * @param sapPlant
     * @throws SapphireException
     **********/
    private void reprocessBatchMaster(String sapBatch, String sapMat, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside reporcessBatchMaster (method)");
        // Getting all Pending Lot Batch Master transactions sorted on Transaction Itema nd Created Date in descending order.
        DataSet dsPendingLotBM = isBatchMasterPresent(sapBatch, sapMat, sapPlant);
        // Check if any pending lot BM
        if (dsPendingLotBM.size() > 0) {
            // reprovcessing transaction items
            reprocessTransactionItem(dsPendingLotBM);
        }
    }

    /*****
     * This method is used to reprocess PENDING transaction item Ids.
     * @param dsTransactionItemData DataSet containing transaction item Ids
     * @throws SapphireException OOB Sapphire exception
     */
    private void reprocessTransactionItem(DataSet dsTransactionItemData) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside reprocessTransactionItem (method)");
        PropertyList plReprocessItemPl = new PropertyList();
        plReprocessItemPl.clear();
        plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, EditSDI.ID);
        plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, EditSDI.VERSIONID);
        plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);
        plReprocessItemPl.setProperty(EditSDI.PROPERTY_SDCID, _PROPS_TRANSITEM_SDCID);
        plReprocessItemPl.setProperty(EditSDI.PROPERTY_KEYID1, dsTransactionItemData.getColumnValues(_PROPS_TRANSITEMID, ";"));
        plReprocessItemPl.setProperty(__REPROCESS_DATE, StringUtil.repeat("n", dsTransactionItemData.getRowCount(), ";"));
        try {
            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, plReprocessItemPl);
        } catch (Exception ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
        }
    }

    /**
     * This method is used to check whether there is any BATCH MASTER payload awaiting LOT RECEIPT service.
     *
     * @param sapBatch  SAP Batch Number.
     * @param sapPlant  SAP plant Information.
     * @param sapMatNum SAP material Number.
     * @return DataSet containing transaction details of BATCH MASTER service.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet isBatchMasterPresent(String sapBatch, String sapMatNum, String sapPlant) throws SapphireException {

        logger.debug("Processing " + ID + ". (Action) : Inside isBatchMasterPresent (method)");
        // For Pending items transaction items having either pending lot flag = Y or Status = PENDING check is given
        // Status = COMPLETE filter given for batch for which earlier a batch is cancelled.
        String sqlText = "select u_intftransitemid,status,createdt  from u_intfTransItem " +
                " where key1value = ?  and key2value= ? and plant = ? " +
                " and transname = 'BATCH_MASTER' and (pendinglotflag = 'Y'  OR  status = 'COMPLETE' OR status = 'PENDING' ) ";

        DataSet dsItemData = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{sapBatch, sapMatNum, sapPlant}, true);

        if (dsItemData == null) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        }

        if (dsItemData.size() > 0) {
            dsItemData.sort("createdt, u_intftransitemid");
        }

        return dsItemData;
    }

    /************
     * This method is used to Release the LIMS batch after cancelling Samples.
     * @param limsBatchId
     * @throws SapphireException
     ************/
    private void releaseLIMSBatch(String limsBatchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside releaseLIMSBatch (method)");
        // ************ If Batch status PendingRelease
        String sql = " SELECT batchstatus " +
                "FROM s_batch " +
                "WHERE s_batchid = ? ";
        DataSet dsBatchStatus = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{limsBatchId});
        if (null == dsBatchStatus) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        }
        // Getting Batch status
        String batchStatus = dsBatchStatus.getValue(0, __PROPS_LIMS_BATCH_STATUS, "");
        // ************* Checking if Batch status is Pending Release
        if (batchStatus.equalsIgnoreCase(__PROPS_STATUS_PENDING_RELEASED)) {
            // ************ Checking if all samples are Cancelled
            PropertyList plFilter = new PropertyList();
            // Getting Samples by LIMS Batch Id
            DataSet dsSamplesByBatch = getSamplesFromBatch(limsBatchId);
            // Getting Samples having Cancelled batch
            plFilter.setProperty(__PROPS_LIMS_SAMPLE_STATUS, __PROPS_STATUS_CANCELLED);
            DataSet dsCancelledSamples = dsSamplesByBatch.getFilteredDataSet(plFilter);
            PropertyList plBatchStatusChanged = new PropertyList();
            // ************** Checking if all Samples in Batch are in Cancelled Status
            // ************** Then Cancel the Batch
            if (dsSamplesByBatch.getRowCount() == dsCancelledSamples.getRowCount()) {
                plBatchStatusChanged.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
                plBatchStatusChanged.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
                plBatchStatusChanged.setProperty(__PROPS_LIMS_BATCH_STATUS, __PROPS_STATUS_CANCELLED);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plBatchStatusChanged);
                } catch (SapphireException e) {
                    throw new SapphireException(e.getMessage());
                }
            } else {
                // ****** Set SAP Result Upload restriction flag to YES
                // ****** Otherwise it tries to upload result in case of Cancellation request as well.
                setResultUploadRestrictionFlag(limsBatchId, "Y");
                //************ Else Release the batch
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_KEYID1, limsBatchId);
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_KEYID2, "(null)");
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_KEYID3, "(null)");
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_APPROVALSTEP, "Approve");
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_AUDITREASON, "Approved by SAP-LIMS Interface.");
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_APPROVALFLAG, "P");  //P Pass, F Fail, U Pending
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_APPROVALFLAG, "Y");
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_APPROVALSTEPINSTANCE, "1");
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_AUDITACTIVITY, "SDI Approval");
                plBatchStatusChanged.setProperty(ApproveSDIStep.PROPERTY_APPROVALTYPEID, "QA");
                try {
                    getActionProcessor().processAction(ApproveSDIStep.ID, ApproveSDIStep.VERSIONID, plBatchStatusChanged);
                } catch (SapphireException e) {
                    throw new SapphireException(e.getMessage());
                }
            }
        }


    }

    /**************
     * This method is used to flag on and off result upload restriction flag.
     * @param limsBatchId
     * @param YesNoFlag
     * @throws SapphireException
     ***************/
    private void setResultUploadRestrictionFlag(String limsBatchId, String YesNoFlag) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside setResultUploadRestrictionFlag (method)");
        PropertyList plResultUploadRestriction = new PropertyList();
        plResultUploadRestriction.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
        plResultUploadRestriction.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
        plResultUploadRestriction.setProperty(__PROPS_BATCH_RESULT_UPLOAD_RESTRICTION_FLAG, YesNoFlag);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plResultUploadRestriction);
        } catch (SapphireException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
        }
    }

    /******************
     * This method is used to process cancel Batch request from SAP
     * @param inspectionLotNum
     * @throws SapphireException
     ******************/
    private String processCancelRequest(String inspectionLotNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside processCancelRequest (method)");
        // Cancelled RM lot request
        // ******** Check for existing Batch
        // ******** Batch status should not be Cancelled
        PropertyList plFilter = new PropertyList();
        PropertyList plReceivedFilter = new PropertyList();
        DataSet dsInitialOrReceivedSamples = null;
        String limsBatchId = "";
        // Getting Sample(s) against inspection lot number
        String sqlText = " SELECT  s_sampleid,batchid,samplestatus " +
                "FROM s_sample " +
                "WHERE u_inspectionlot = ? " +
                "AND samplestatus <> 'Cancelled' ";
        DataSet dsSamplesByInspectionLot = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{inspectionLotNum});
        if (null == dsSamplesByInspectionLot) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        } else if (dsSamplesByInspectionLot.getRowCount() == 0) {
            // If no sample(s) found against Inspection lot number then ERROR
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00023, inspectionLotNum)));
        } else {
            // Getting LIMS Batch Id
            limsBatchId = dsSamplesByInspectionLot.getValue(0, "batchid", "");
            // Filter for initial status
            plFilter.setProperty(__PROPS_LIMS_SAMPLE_STATUS, __PROPS_STATUS_INITIAL);
            // Filter for Received status
            plReceivedFilter.setProperty(__PROPS_LIMS_SAMPLE_STATUS, __PROPS_STATUS_RECEIVED);

            // ******* Filtering Samples to get Sample Id's having Initial Status
            dsInitialOrReceivedSamples = dsSamplesByInspectionLot.getFilteredDataSet(plFilter);
            // ******* Adding all samples having Received status with samples having Initial status
            dsInitialOrReceivedSamples.copyRow(dsSamplesByInspectionLot.getFilteredDataSet(plReceivedFilter), -1, 1);
            PropertyList plCancelSample = new PropertyList();
            // If Samples by Inspection Lot having only Initial Or Received status
            if (dsInitialOrReceivedSamples.getRowCount() == dsSamplesByInspectionLot.getRowCount()) {
                // Getting all samples of Batch
                DataSet dsSamplesByBatch = getSamplesFromBatch(limsBatchId);
                if (null == dsSamplesByBatch) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
                }
                // Getting all samples from Batch having Initial status
                DataSet dsInitialOrReceivedSamplesByBatch = dsSamplesByBatch.getFilteredDataSet(plFilter);
                // Adding all samples having Received status with samples having Initial status
                dsInitialOrReceivedSamplesByBatch.copyRow(dsSamplesByBatch.getFilteredDataSet(plReceivedFilter), -1, 1);
                // *************** If all samples in Batch are in Initial / Received status
                if (dsSamplesByBatch.getRowCount() == dsInitialOrReceivedSamplesByBatch.getRowCount()) {
                    // ************ Check for PENDING RSet and clear all before Cancellation
                    clearAllSampleRSET(dsSamplesByBatch.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
                    // ************* Cancel samples and cancel batch
                    plCancelSample.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
                    plCancelSample.setProperty(EditSDI.PROPERTY_KEYID1, dsSamplesByBatch.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
                    plCancelSample.setProperty(__PROPS_LIMS_SAMPLE_STATUS, StringUtil.repeat(__PROPS_STATUS_CANCELLED, dsSamplesByBatch.getRowCount(), ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plCancelSample);
                    // ************* Cancel the batch
                    releaseLIMSBatch(limsBatchId);

                } else {
                    // ************ Check for PENDING RSet and clear all before Cancellation
                    clearAllSampleRSET(dsInitialOrReceivedSamples.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
                    // ************* Cancel Inspection lot initial samples
                    plCancelSample.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
                    plCancelSample.setProperty(EditSDI.PROPERTY_KEYID1, dsInitialOrReceivedSamples.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
                    plCancelSample.setProperty(__PROPS_LIMS_SAMPLE_STATUS, StringUtil.repeat(__PROPS_STATUS_CANCELLED, dsInitialOrReceivedSamples.getRowCount(), ";"));
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plCancelSample);
                    // ************* Release the batch
                    releaseLIMSBatch(limsBatchId);
                }

            } else {
                // If Sample(s) having any other status other than Initial --> Mark for cancellation
                plCancelSample.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
                plCancelSample.setProperty(EditSDI.PROPERTY_KEYID1, dsSamplesByInspectionLot.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
                plCancelSample.setProperty("u_markedforcancel", StringUtil.repeat("Y", dsSamplesByInspectionLot.getRowCount(), ";"));
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plCancelSample);
            }
        }
        // Returning LIMS Batch Id for updating Interface Transaction Item
        return dsSamplesByInspectionLot.getRowCount() > 0 ? dsSamplesByInspectionLot.getValue(0, "batchid", "") : "";
    }


    /*************
     * This method is used get MES Order restriction(Y/N) defined in Department SDC
     * @param prodVariantId
     * @return
     * @throws SapphireException
     */
    private String getMESOrderRestrigtionFlag(String prodVariantId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getMESOrderRestrigtionFlag (method)");
        String sqlText = "SELECT " +
                "    department.u_mesorderrestriction " +
                "FROM " +
                "    department " +
                "    JOIN s_prodvariant ON s_prodvariant.securitydepartment = department.departmentid " +
                "WHERE " +
                "    s_prodvariant.s_prodvariantid = ? ";
        DataSet dsMESOrderResttrtiction = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{prodVariantId});
        if (null == dsMESOrderResttrtiction) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        }
        return dsMESOrderResttrtiction.getValue(0, "u_mesorderrestriction", "N");
    }

    /*************
     * This method is used to create new raw material batch
     * @param dsBatchDetails
     * @param sapBatch
     * @param sapMaterialNum
     * @param sapPlant
     * @throws SapphireException
     *************/
    private String createNewRMBatch(DataSet dsBatchDetails, String sapBatch, String sapMaterialNum, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside createNewRMBatch (method)");
        String limsBatchId = "";
        // Getting product variant details
        String vendorNum = ___KEY_NOT_FOUND.equalsIgnoreCase(dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, "")) ? "" : dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, "");
        // **** Vendor Number check is only for New RM Batch creation
        /*if ("".equalsIgnoreCase(___KEY_NOT_FOUND.equalsIgnoreCase(vendorNum) ? "" : vendorNum)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00001, "LIFNR(SAP Vendor #)")));
        }*/
        // Getting PV details
        getRMProdVariant(dsBatchDetails, sapBatch, sapMaterialNum, sapPlant, vendorNum);

        // Getting PV ID
        String prodVariantId = dsBatchDetails.getValue(0, __PROPS_PRODUCT_VARIANTID, "");
        String samplingPlanId = "";
        String samplingPlanVersionId = "";
        // Checking if PV has Current version of SP or not ?
        if ("".equalsIgnoreCase(dsBatchDetails.getValue(0, "samplingplanversionid", ""))) {
            // Getting current sampling plan id and version
            DataSet dsCurrentSPDetails = getCurrentSamplingPlanByPV(prodVariantId);
            samplingPlanId = dsCurrentSPDetails.getValue(0, __PROPS_SAMPLING_PLAN_ID);
            samplingPlanVersionId = dsCurrentSPDetails.getValue(0, __PROPS_SAMPLING_PLAN_VERSION_ID);
        } else {
            // Getting logged in version of Sampling plan
            samplingPlanId = dsBatchDetails.getValue(0, "samplingplanid", "");
            samplingPlanVersionId = dsBatchDetails.getValue(0, "samplingplanversionid", "");
        }

        // Getting Process stage details
        DataSet dsProcessStageDetails = getProcessStageDetails(samplingPlanId, samplingPlanVersionId);
        // Getting stage id
        String stageId = checkStageType(dsProcessStageDetails, __PROPS_PRE_SHIPMENT);
        // Check for Pre Shipment stage
        if (!"".equalsIgnoreCase(stageId)) {
            // if pre shipment stage exist in PV
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(String.format(String.format(ErrorMessageUtil.RM_ERR_00025, sapBatch, sapMaterialNum, sapPlant))));
        } else {
            //if pre shipment stage doesn't exits in PV
            // Get Batch Type from Product Variant type
            String batchType = dsBatchDetails.getValue(0, __PROPS_PRODUCT_VARIANTTYPE);
            // Setting batch type / product variant type in batch details DataSet
            if (!dsBatchDetails.isValidColumn(__PROPS_BATCH_TYPE)) {
                dsBatchDetails.addColumn(__PROPS_BATCH_TYPE, DataSet.STRING);
            }
            dsBatchDetails.setValue(0, __PROPS_BATCH_TYPE, batchType);
            // Getting batch template from Policy
            String batchTemplateId = getBatchTemplate(batchType);
            // Setting batch template id in batch details DataSet
            if (!dsBatchDetails.isValidColumn(__PROPS_BATCH_TEMPLATE_ID)) {
                dsBatchDetails.addColumn(__PROPS_BATCH_TEMPLATE_ID, DataSet.STRING);
            }
            dsBatchDetails.setValue(0, __PROPS_BATCH_TEMPLATE_ID, batchTemplateId);
            // Creating LIMS batch
            limsBatchId = createRMLIMSBatch(dsBatchDetails);
            // Checking if Mars Code is present or not
            String marsCode = dsBatchDetails.getValue(0, __PROPS_MARS_CODE_ATTR, "");
            // Checking if MARS CODE is Blank
            if (!"".equalsIgnoreCase(marsCode)) {
                // Check if Batch is having MARS Code Attribute?
                String marsCodeAttrPresent = isMarsCodeAttrPresentInBatch(limsBatchId);
                if ("Y".equalsIgnoreCase(marsCodeAttrPresent)) {
                    // Editting MARS CODE
                    setMarsCode(limsBatchId, marsCode);
                }
            }
            //
            // If Site is configured to auto receive batch
            if ("Y".equalsIgnoreCase(getAutoreceiveFlag(sapPlant))) {
                // If yes the receive
                receiveBatch(limsBatchId);
            }


        }

        return limsBatchId;
    }

    /******************
     * This method is used to add samples to existing batch stages(Pre Shipment / First Shipment / Repeat Shipment)
     * @param limsBatchId
     * @param limsBatchStatus
     * @param curSamplingPlanVersionId
     * @param curSamplingPlanId
     * @param dsProcessStageDetails
     * @param curProductId
     * @param curProductVerId
     * @param limsBatcDesc
     * @param prodVariantId
     * @throws SapphireException
     *******************/
    private void addSamplesToExistingLIMSBatch(String limsBatchId, String limsBatchStatus, String limsBatcDesc, String curSamplingPlanId, String curSamplingPlanVersionId, DataSet dsProcessStageDetails, String curProductId, String curProductVerId, String prodVariantId, String inspectionType) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside addSamplesToExistingLIMSBatch (method)");
        // Right wing of Flow chart
        DataSet dsLIMSBatchSamples;
        DataSet dsSamplesByProcessStage = null;
        DataSet dsLevelSampleDetails;
        DataSet dsLevelSampleLoggedVerSPDetails;
        String processStageId = "";
        PropertyList plFilter = new PropertyList();
        // getting list of samples from Batch
        dsLIMSBatchSamples = getSamplesFromBatch(limsBatchId);

        // ******** If Batch status is Release - Rejected
        if (__PROPS_STATUS_REJECTED.equalsIgnoreCase(limsBatchStatus)) {
            // Flag all samples(sample --> u_payloadrejectedflag ='Y')
            if (dsLIMSBatchSamples.getRowCount() > 0) {
                // ******** Update samples with u_payloadrejectedflag = Y
                updateSamplesRejectedByPayloadFlag(dsLIMSBatchSamples.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
            }
        }
        // Getting process stage id
        processStageId = checkStageType(dsProcessStageDetails, __PROPS_PRE_SHIPMENT);
        // ********** Check for Pre Shipment stage
        if (!"".equalsIgnoreCase(processStageId)) {
            // if pre shipment stage exist in PV
            plFilter.setProperty(__PROPS_LIMS_SAMPLE_STATUS, __PROPS_STATUS_CANCELLED);
            // Filtering the Sample dataset exclusing samples having Cancelled status
            dsSamplesByProcessStage = dsLIMSBatchSamples.getFilteredDataSet(plFilter, true);
            // if pre shipment samples does not exists
            if (dsSamplesByProcessStage.findRow(__PROPS_BATCH_STAGE_PROCESS_STAGE_ID, processStageId) == -1) {
                // ********** If NO pre shipment samples having status not equals to Cancelled
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00002, limsBatchId, prodVariantId, curSamplingPlanId, curSamplingPlanVersionId)));
            }
        }
        // ********* First Shipment stage present ?? and First shipment samples exist ? (Status not cancelled)
        // ********* stage if of first shipment stage
        processStageId = checkStageType(dsProcessStageDetails, __PROPS_FIRST_SHIPMENT);
        // ********* If First Shipment stage do not exist in SP
        // ********* Then ERROR
        if ("".equalsIgnoreCase(processStageId)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.RM_ERR_00003));
        } else {
            plFilter.clear();
            plFilter.setProperty(__PROPS_LIMS_SAMPLE_STATUS, __PROPS_STATUS_CANCELLED);
            // To avoid null pointer exception
            if (null != dsSamplesByProcessStage) {
                dsSamplesByProcessStage.clear();
            }
            // Filtering the Sample dataset exclusing samples having Cancelled status
            dsSamplesByProcessStage = dsLIMSBatchSamples.getFilteredDataSet(plFilter, true);
            // Getting Level Sample details from current
            dsLevelSampleDetails = getLevelSamples(curSamplingPlanId, curSamplingPlanVersionId);
            // Getting Level Sample Details from logged in version SP
            dsLevelSampleLoggedVerSPDetails = getLevelSamplesFromLoggedVerSP(limsBatchId);
            // ************* if first shipment does not samples exists
            if (dsSamplesByProcessStage.findRow(__PROPS_BATCH_STAGE_PROCESS_STAGE_ID, processStageId) == -1) {
                // Check if the batch is released
                if (__PROPS_STATUS_RELEASED.equalsIgnoreCase(limsBatchStatus) || __PROPS_STATUS_REJECTED.equalsIgnoreCase(limsBatchStatus)) {
                    addSamplesToStage(limsBatchId, limsBatcDesc, limsBatchStatus, prodVariantId, processStageId, __PROPS_FIRST_SHIPMENT, dsLevelSampleLoggedVerSPDetails, dsLevelSampleDetails, curSamplingPlanId, curSamplingPlanVersionId, curProductId, curProductVerId);
                } else {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00004, limsBatchStatus, limsBatchId)));
                }

            } else {
                // Check if the batch is released
                if (__PROPS_STATUS_RELEASED.equalsIgnoreCase(limsBatchStatus) || __PROPS_STATUS_REJECTED.equalsIgnoreCase(limsBatchStatus)) {

                    // ********* Check if Inspection type = Z8CM09 Then RETEST
                    if (__PROPS_SAP_ART_RETEST.equalsIgnoreCase(inspectionType)) {
                        processStageId = checkStageType(dsProcessStageDetails, __PROPS_RETEST);
                        // ********* If RETEST stage type exists in current SP
                        if ("".equalsIgnoreCase(processStageId)) {
                            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00026, curSamplingPlanId, curSamplingPlanVersionId)));
                        } else {
                            addSamplesToStage(limsBatchId, limsBatcDesc, limsBatchStatus, prodVariantId, processStageId, __PROPS_RETEST, dsLevelSampleLoggedVerSPDetails, dsLevelSampleDetails, curSamplingPlanId, curSamplingPlanVersionId, curProductId, curProductVerId);
                        }
                    } else {

                        //********** Repeat shipemnt stage type exists ?
                        processStageId = checkStageType(dsProcessStageDetails, __PROPS_REPEAT_SHIPMENT);
                        // ********* If Repeat shipment stage type exists in current SP
                        if ("".equalsIgnoreCase(processStageId)) {
                            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00005, curSamplingPlanId, curSamplingPlanVersionId)));
                        } else {
                            addSamplesToStage(limsBatchId, limsBatcDesc, limsBatchStatus, prodVariantId, processStageId, __PROPS_REPEAT_SHIPMENT, dsLevelSampleLoggedVerSPDetails, dsLevelSampleDetails, curSamplingPlanId, curSamplingPlanVersionId, curProductId, curProductVerId);
                        }
                    }
                } else {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00006, (__PROPS_SAP_ART_RETEST.equalsIgnoreCase(inspectionType) ? "retest" : "repeat-shipment"), limsBatchStatus, limsBatchId)));
                }
            }
        }
    }

    /**********
     * This method is used to update LIMS Batch.
     * @param limsbatch
     * @param dsBatchDetails
     * @throws SapphireException
     **********/
    private void updateLIMSBatch(String limsbatch, DataSet dsBatchDetails) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside updateLIMSBatch (method)");
        // ***** Getting Start and End Date of Inspection Lot
        String inspectionStartDate = SAPUtil.checkNullDate(dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_START_DATE, ""));
        inspectionStartDate = SAPUtil.getDateWithProperFormat(inspectionStartDate, connectionInfo);
        String inspectionEndDate = SAPUtil.checkNullDate(dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_END_DATE, ""));
        inspectionEndDate = SAPUtil.getDateWithProperFormat(inspectionEndDate, connectionInfo);

        PropertyList plUpdateBatch = new PropertyList();
        plUpdateBatch.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
        plUpdateBatch.setProperty(EditSDI.PROPERTY_KEYID1, limsbatch);
        plUpdateBatch.setProperty(__PROPS_BATCH_IS_SAP_FLAG, "Y");
        plUpdateBatch.setProperty(__PROPS_BATCH_MES_ORDER_SAP_BATCH1, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_BATCH, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_MES_ORDER_SAP_BATCH2, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_BATCH, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_SAP_BATCH, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_BATCH, ""));
        plUpdateBatch.setProperty(__PROPS_SAP_BATCH_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_TYPE, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_PRODUCT_INSPECTIONLOT, dsBatchDetails.getValue(0, __PROPS_BATCH_PRODUCT_INSPECTIONLOT, ""));
        plUpdateBatch.setProperty(__PROPS_VENDOR_BATCH_NUMBER, dsBatchDetails.getValue(0, __PROPS_VENDOR_BATCH_NUMBER, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_CATCODEGROUP_PASS, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODEGROUP_PASS, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_CATCODEGROUP_FAIL, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODEGROUP_FAIL, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_CATCODE_PASS, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODE_PASS, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_CATCODE_FAIL, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODE_FAIL, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_SELECTEDSET, dsBatchDetails.getValue(0, __PROPS_BATCH_SELECTEDSET, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_SAP_LAB_CONF_NUM, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_LAB_CONF_NUM, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_SAP_PARENT_BATCH, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PARENT_BATCH, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_SAP_PARENT_MATERIAL, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PARENT_MATERIAL, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_SAP_SUBSYSTEM, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_SUBSYSTEM, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_LOCAL_MAT_CODE, dsBatchDetails.getValue(0, __PROPS_BATCH_LOCAL_MAT_CODE, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_INSPECTION_LOT_ORIGIN, dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_LOT_ORIGIN, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_INSPECTION_START_DATE, inspectionStartDate);
        plUpdateBatch.setProperty(__PROPS_BATCH_INSPECTION_END_DATE, inspectionEndDate);
        plUpdateBatch.setProperty(__PROPS_BATCH_VENDOR_NAME, dsBatchDetails.getValue(0, __PROPS_BATCH_VENDOR_NAME, ""));
        // **** Here value KEY_NOT_FOUND is replace with BLANK bacause for Repeat Shipment LIFNR will be missing
        plUpdateBatch.setProperty(__PROPS_BATCH_SAP_VENDOR_NUM, ___KEY_NOT_FOUND.equalsIgnoreCase(dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, "")) ? "" : dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, ""));
        plUpdateBatch.setProperty(__PROPS_VENDOR_BATCH_NUMBER, ___KEY_NOT_FOUND.equalsIgnoreCase(dsBatchDetails.getValue(0, __PROPS_VENDOR_BATCH_NUMBER, "")) ? "" : dsBatchDetails.getValue(0, __PROPS_VENDOR_BATCH_NUMBER, ""));

        plUpdateBatch.setProperty(__PROPS_BATCH_SAP_VENDOR_STATUS, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_STATUS, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_SIZE, dsBatchDetails.getValue(0, __PROPS_BATCH_SIZE, ""));
        plUpdateBatch.setProperty(__PROPS_BATCH_SIZE_UNITS, dsBatchDetails.getValue(0, __PROPS_BATCH_SIZE_UNITS, ""));
        // ******* Added for result upload. In case of cancel this will be marked as Y to restrict result upload.
        plUpdateBatch.setProperty(__PROPS_BATCH_RESULT_UPLOAD_RESTRICTION_FLAG, "N");


        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plUpdateBatch);
        } catch (SapphireException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
        }
    }

    /*************
     * This method is used to get level sample details from logged in version of SP
     * @param limsBatchId
     * @return
     * @throws SapphireException
     ************/
    private DataSet getLevelSamplesFromLoggedVerSP(String limsBatchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getLevelSamplesFromLoggedVerSP (method)");
        String sqlText = " SELECT " +
                "    s_batchstage.s_batchstageid, " +
                "    sstage.s_processstageid, " +
                "    sstage.label, " +
                "    sdetail.levelid, " +
                "    sdetail.sourcelabel, " +
                "    sdetail.templatekeyid1, " +
                "    sdetail.defaultdepartmentid " +
                "FROM " +
                "    s_samplingplan   splan " +
                "    INNER JOIN s_processstage   sstage ON splan.s_samplingplanid = sstage.s_samplingplanid " +
                "                                        AND splan.s_samplingplanversionid = sstage.s_samplingplanversionid " +
                "    INNER JOIN s_spdetail       sdetail ON sdetail.s_samplingplanid = sstage.s_samplingplanid " +
                "                                     AND sdetail.s_samplingplanversionid = sstage.s_samplingplanversionid " +
                "                                     AND sstage.s_processstageid = sdetail.processstageid " +
                "    INNER JOIN s_batch          sb ON sb.samplingplanid = splan.s_samplingplanid " +
                "                             AND sb.samplingplanversionid = splan.s_samplingplanversionid " +
                "    INNER JOIN s_batchstage ON s_batchstage.batchid = sb.s_batchid " +
                "                               AND s_batchstage.samplingplanid = splan.s_samplingplanid " +
                "                               AND s_batchstage.samplingplanversionid = splan.s_samplingplanversionid " +
                "                               AND s_batchstage.processstageid = sstage.s_processstageid " +
                "WHERE " +
                "    sb.s_batchid = ? ";
        DataSet dsLevelSampleDetails = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{limsBatchId});
        if (null == dsLevelSampleDetails) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        } else if (dsLevelSampleDetails.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.RM_ERR_00012));
        } else {
            return dsLevelSampleDetails;
        }
    }

    /****************
     * This method is used to get level sample details from current SP
     * @param samplingPlanId
     * @param samplingPlanVersionId
     * @return
     * @throws SapphireException
     *****************/
    private DataSet getLevelSamples(String samplingPlanId, String samplingPlanVersionId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getLevelSamples (method)");
        String sqlText = "SELECT " +
                "    s_processstage.s_processstageid, " +
                "    s_processstage.label, " +
                "    s_spdetail.levelid, " +
                "    s_spdetail.sourcelabel, " +
                "    s_spdetail.countrule, " +
                "    s_spdetail.templatekeyid1, " +
                "    s_spdetail.defaultdepartmentid " +
                "FROM " +
                "    s_samplingplan " +
                "    INNER JOIN s_processstage ON s_samplingplan.s_samplingplanid = s_processstage.s_samplingplanid " +
                "                                 AND s_samplingplan.s_samplingplanversionid = s_processstage.s_samplingplanversionid " +
                "    INNER JOIN s_spdetail ON s_spdetail.s_samplingplanid = s_samplingplan.s_samplingplanid " +
                "                             AND s_spdetail.s_samplingplanversionid = s_samplingplan.s_samplingplanversionid " +
                "                             AND s_spdetail.processstageid = s_processstage.s_processstageid " +
                "WHERE " +
                "s_samplingplan.s_samplingplanid = ? " +
                "AND s_samplingplan.s_samplingplanversionid = ? ";
        DataSet dsCurrentSPLevel = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{samplingPlanId, samplingPlanVersionId});
        if (null == dsCurrentSPLevel) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        } else if (dsCurrentSPLevel.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00012, samplingPlanId)));
        } else {
            return dsCurrentSPLevel;
        }

    }

    /*************
     * This method is used to add samples to stages.
     * @param limsBatchId
     * @param limsBatchDesc
     * @param processStageId
     * @param dsLevelDetailsForLoggedSP
     * @param dsLevelDetailsForCurSP
     * @param curSP
     * @param curSPVer
     * @param curProdId
     * @param curProdVer
     * @throws SapphireException
     **************/
    private void addSamplesToStage(String limsBatchId, String limsBatchDesc, String limsBatchStatus, String prodVariantId, String processStageId, String stageType, DataSet dsLevelDetailsForLoggedSP, DataSet dsLevelDetailsForCurSP, String curSP, String curSPVer, String curProdId, String curProdVer) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside addSamplesToStage (method)");
        PropertyList plFilter = new PropertyList();
        PropertyList plAddSDI = new PropertyList();
        String label = "";
        String sourcelabel = "";
        String levelid = "";
        String batchStageId = "";
        String templateId = "";
        String spSecurityDept = "";
        String securityDept = "";
        int userSequence;
        String newSampleId = "";
        String uniqueLevelId[];
        plFilter.setProperty(__PROPS_PROCESS_STAGE_ID, processStageId);
        // Getting filtered dataset by process stage id
        DataSet dsFilteredLevelSampleDetailsByProcessStage = dsLevelDetailsForCurSP.getFilteredDataSet(plFilter);
        // Check if level details found against process stage id
        if (dsFilteredLevelSampleDetailsByProcessStage.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00015, __PROPS_FIRST_SHIPMENT)));
        } else {
            // Getting unique list of level ids
            uniqueLevelId = StringUtil.split(AlconUtil.getUniqueList(dsFilteredLevelSampleDetailsByProcessStage.getColumnValues(__PROPS_PROCESS_STAGE_LEVEL_ID, ";"), ";", false), ";");
            // Check if level id is unique. If not the throw an error
            if (uniqueLevelId.length > 1) {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00014, limsBatchId, prodVariantId, curSP, curSPVer, __PROPS_FIRST_SHIPMENT)));
            }
            // Getting max sample user sequence value
            userSequence = Integer.parseInt(getUserSequence(limsBatchId));
            // Getting Current Sampling Plan Item(WorkItem + Spec) details
            DataSet dsSPItems = getSamplingPlanItemDetails(curSP, curSPVer);
            if (userSequence == 0) {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00017, limsBatchId)));
            }
            // ********* unrelease/UnReject the batch
            unreleaseLIMSBatch(limsBatchId, limsBatchStatus);
            int count = 0;
            // start looping level sample details for each level id
            for (int rowCount = 0; rowCount < dsFilteredLevelSampleDetailsByProcessStage.getRowCount(); rowCount++) {
                // Check If First /Repeat Shipment sample count not equals zero
                // If yes the throw an ERROR
                count = Integer.parseInt(dsFilteredLevelSampleDetailsByProcessStage.getValue(rowCount, __PROPS_COUNT_RULE));
                if (count != 0) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00013, stageType)));
                }
                // Getting lebel,sourcelebel and levelid from current SP againts processstageid
                label = dsFilteredLevelSampleDetailsByProcessStage.getValue(rowCount, __PROPS_PROCESS_STAGE_LABEL);
                sourcelabel = dsFilteredLevelSampleDetailsByProcessStage.getValue(rowCount, __PROPS_PROCESS_STAGE_SOURCE_LABEL);
                levelid = dsFilteredLevelSampleDetailsByProcessStage.getValue(rowCount, __PROPS_PROCESS_STAGE_LEVEL_ID);
                // Filtering level sample of logged in version of SP to get the batch stage id
                plFilter.clear();
                plFilter.setProperty(__PROPS_PROCESS_STAGE_LABEL, label);
                plFilter.setProperty(__PROPS_PROCESS_STAGE_SOURCE_LABEL, sourcelabel);
                plFilter.setProperty(__PROPS_PROCESS_STAGE_LEVEL_ID, levelid);
                // Getting Batch Stage Id from logged in version of SP
                batchStageId = dsLevelDetailsForLoggedSP.getFilteredDataSet(plFilter).getValue(0, __PROPS_BATCH_STAGE_ID, "");
                if ("".equalsIgnoreCase(batchStageId)) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00009, curSP, curSPVer, label, sourcelabel, levelid)));
                } else {
                    templateId = dsLevelDetailsForLoggedSP.getFilteredDataSet(plFilter).getValue(0, __PROPS_STAGE_TEMPLATE_KEYID_ID, "");
                    securityDept = dsLevelDetailsForLoggedSP.getFilteredDataSet(plFilter).getValue(0, __PROPS_BATCH_SECURITY_DEPT, "");
                    spSecurityDept = dsLevelDetailsForLoggedSP.getFilteredDataSet(plFilter).getValue(0, "defaultdepartmentid", "");
                    // *************** Check if any existing RSet is locking in
                    // *************** Clear any LOCKED RSET for Batch Stage
                    unlockBatchStage(batchStageId);
                    // *************** Adding samples to First/Repeat Shipment stage based upon the Rule
                    plAddSDI.setProperty(AddSDI.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
                    plAddSDI.setProperty("batchid", limsBatchId);
                    plAddSDI.setProperty("batchstageid", batchStageId);
                    plAddSDI.setProperty("productversionid", curProdVer);
                    plAddSDI.setProperty("sourcespid", curSP);
                    plAddSDI.setProperty("sourcespversionid", curSPVer);
                    plAddSDI.setProperty("sampledesc", limsBatchDesc);
                    plAddSDI.setProperty("productid", curProdId);
                    plAddSDI.setProperty("sourcespsourcelabel", sourcelabel);
                    plAddSDI.setProperty("sourcesplevelid", levelid);
                    plAddSDI.setProperty("templateid", templateId);
                    plAddSDI.setProperty("securitydepartment", ("".equalsIgnoreCase(securityDept)) ? spSecurityDept : securityDept);
                    plAddSDI.setProperty("usersequence", String.valueOf(userSequence));
                    // **** Flagging Samples to SAP created ****
                    plAddSDI.setProperty("u_issapsampleflag", "Y");
                    try {
                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plAddSDI);
                        newSampleId = plAddSDI.getProperty(__PROPS_NEW_KEYID1, "");
                    } catch (SapphireException ex) {
                        throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
                    }

                    plFilter.clear();
                    plFilter.setProperty("processstageid", processStageId);
                    plFilter.setProperty(__PROPS_PROCESS_STAGE_SOURCE_LABEL, sourcelabel);
                    plFilter.setProperty(__PROPS_PROCESS_STAGE_LEVEL_ID, levelid);
                    plFilter.setProperty("itemsdcid", "WorkItem");

                    // Getting workitems to be applied
                    DataSet dsSPItemWorkItem = dsSPItems.getFilteredDataSet(plFilter);
                    if (dsSPItemWorkItem.getRowCount() > 0) {
                        // AddSDIWorkItem
                        PropertyList plAddWorkItem = new PropertyList();
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_KEYID1, StringUtil.repeat(newSampleId, dsSPItemWorkItem.size(), ";"));
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMID, dsSPItemWorkItem.getColumnValues("itemkeyid1", ";"));
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMVERSIONID, dsSPItemWorkItem.getColumnValues("itemkeyid2", ";"));
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_APPLYWORKITEM, "Y");
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_PROPSMATCH, "Y");

                        try {
                            getActionProcessor().processAction(AddSDIWorkItem.ID, AddSDIWorkItem.VERSIONID, plAddWorkItem);
                        } catch (SapphireException ex) {
                            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Failed to call  AddSDIWorkItem. Error is \n" + ex.getMessage()));
                        }
                    }

                    plFilter.clear();
                    plFilter.setProperty("processstageid", processStageId);
                    plFilter.setProperty(__PROPS_PROCESS_STAGE_SOURCE_LABEL, sourcelabel);
                    plFilter.setProperty(__PROPS_PROCESS_STAGE_LEVEL_ID, levelid);
                    plFilter.setProperty("itemsdcid", "SpecSDC");

                    // Getting spec to be applied
                    DataSet dsSPItemSpec = dsSPItems.getFilteredDataSet(plFilter);
                    if (dsSPItemSpec.getRowCount() > 0) {
                        // AddSDISpec
                        PropertyList plAddSDISpec = new PropertyList();
                        plAddSDISpec.setProperty(AddSDISpec.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
                        plAddSDISpec.setProperty(AddSDISpec.PROPERTY_KEYID1, StringUtil.repeat(newSampleId, dsSPItemSpec.size(), ";"));
                        plAddSDISpec.setProperty(AddSDISpec.PROPERTY_SPECID, dsSPItemSpec.getColumnValues("itemkeyid1", ";"));
                        plAddSDISpec.setProperty(AddSDISpec.PROPERTY_SPECVERSIONID, dsSPItemSpec.getColumnValues("itemkeyid2", ";"));
                        try {
                            getActionProcessor().processAction(AddSDISpec.ID, AddSDISpec.VERSIONID, plAddSDISpec);
                        } catch (SapphireException ex) {
                            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Failed to call  AddSDISpec. Error is : \n " + ex.getMessage()));
                        }
                    }

                }
                // Incrementing user sequence variable to avoid querying DB multiple times
                userSequence++;
            }

        }
    }

    /************
     * This  method is used to get workitem and spec details of current sampling plan
     * @param curSPId
     * @param curSPVerId
     * @return
     * @throws SapphireException
     *************/
    private DataSet getSamplingPlanItemDetails(String curSPId, String curSPVerId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getSamplingPlanItemDetails (method)");
        String sqlText = " SELECT " +
                "    sp.processstageid, " +
                "    sp.s_samplingplanid, " +
                "    sp.s_samplingplanversionid, " +
                "    sp.levelid, " +
                "    sp.sourcelabel, " +
                "    spitems.itemsdcid, " +
                "    spitems.itemkeyid1, " +
                "    spitems.itemkeyid2, " +
                "    spitems.itemkeyid3, " +
                "    sp.templatesdcid, " +
                "    sp.templatekeyid1, " +
                "    sp.templatekeyid2, " +
                "    sp.templatekeyid3, " +
                "    sp.defaultdepartmentid, " +
                "    sp.usersequence, " +
                "    spitems.usersequence spitemusersequence " +
                "FROM " +
                "    s_spdetail       sp, " +
                "    s_spitem         spitems, " +
                "    s_spdetailitem   spdetailitems, " +
                "    s_samplingplan   splan " +
                "WHERE " +
                "    sp.s_samplingplanid = splan.s_samplingplanid " +
                "    AND sp.s_samplingplanversionid = splan.s_samplingplanversionid " +
                "    AND spitems.s_samplingplanid = sp.s_samplingplanid " +
                "    AND spitems.s_samplingplanversionid = sp.s_samplingplanversionid " +
                "    AND spdetailitems.s_samplingplanid = sp.s_samplingplanid " +
                "    AND spdetailitems.s_samplingplanversionid = sp.s_samplingplanversionid " +
                "    AND spdetailitems.s_samplingplandetailno = sp.s_samplingplandetailno " +
                "    AND spdetailitems.s_samplingplanitemno = spitems.s_samplingplanitemno " +
                "    AND splan.s_samplingplanid = ? " +
                "    AND splan.s_samplingplanversionid = ? ";
        DataSet dsSPItems = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{curSPId, curSPVerId});
        if (null == dsSPItems) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        } else {
            dsSPItems.sort("usersequence");
            return dsSPItems;
        }

    }

    /****************
     * This method is used to get maximum sample user sequence in batch
     * @param limsBatchId
     * @return
     * @throws SapphireException
     ****************/
    private String getUserSequence(String limsBatchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getUserSequence (method)");
        String sqlText = "SELECT to_char(max(usersequence)) maxusersequence FROM s_sample WHERE batchid = ?";
        DataSet dsMaxUserSequence = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{limsBatchId});
        if (null == dsMaxUserSequence) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        } else {
            // Todo check what it's returning
            return dsMaxUserSequence.getValue(0, "maxusersequence", "0");
        }
    }

    /********
     * This method is used to validate whether pre-shipment/first-shipment/repeat-shipment stage type present in current sampling plan or not.
     * @param dsStageDetails
     * @return
     * @throws SapphireException
     **********/
    private boolean validateStageTypeInCurrentSP(DataSet dsStageDetails) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside validateStageTypeInCurrentSP (method)");
        boolean validStageExist = false;
        // Check if any of the stage type exists in,current SP
        if (dsStageDetails.findRow(__PROPS_PROCESS_STAGE_TYPE, __PROPS_PRE_SHIPMENT) != -1 || dsStageDetails.findRow(__PROPS_PROCESS_STAGE_TYPE, __PROPS_FIRST_SHIPMENT) != -1 ||
                dsStageDetails.findRow(__PROPS_PROCESS_STAGE_TYPE, __PROPS_REPEAT_SHIPMENT) != -1) {
            validStageExist = true;
        }
        return validStageExist;
    }

    /*********
     * This method is used to unrealse a batch
     * @param limsBatchId
     * @throws SapphireException
     *********/
    private void unreleaseLIMSBatch(String limsBatchId, String limsBatchStatus) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside unreleaseLIMSBatch (method)");
        PropertyList plUnrelease = new PropertyList();
        plUnrelease.setProperty(UndoSDIColumnValue.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
        plUnrelease.setProperty(UndoSDIColumnValue.PROPERTY_KEYID1, limsBatchId);
        plUnrelease.setProperty("statuscolumn", __PROPS_LIMS_BATCH_STATUS);
        plUnrelease.setProperty("defaultvalue", __PROPS_STATUS_PENDING_RELEASED);
        plUnrelease.setProperty("validatestatuscolumnvalue", __PROPS_STATUS_RELEASED.equalsIgnoreCase(limsBatchStatus) ? __PROPS_STATUS_RELEASED : __PROPS_STATUS_REJECTED);
        plUnrelease.setProperty("auditactivity", __PROPS_STATUS_RELEASED.equalsIgnoreCase(limsBatchStatus) ? "Un" + __PROPS_STATUS_RELEASED : "Un" + __PROPS_STATUS_REJECTED);
        plUnrelease.setProperty("auditreason", __PROPS_STATUS_RELEASED.equalsIgnoreCase(limsBatchStatus) ? __PROPS_STATUS_RELEASED + " by SAP-INTERFACE" : __PROPS_STATUS_REJECTED + " by SAP-INTERFACE");
        getActionProcessor().processAction(UndoSDIColumnValue.ID, UndoSDIColumnValue.VERSIONID, plUnrelease);
    }


    /************
     * This method is used to mark samples whic are rejected.
     * @throws SapphireException
     ************/
    // If not allowing then exeute update
    private void updateSamplesRejectedByPayloadFlag(String sampleids) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside updateSamplesRejectedByPayloadFlag (method)");
        PropertyList propsToUpdate = new PropertyList();
        propsToUpdate.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
        propsToUpdate.setProperty(EditSDI.PROPERTY_KEYID1, sampleids);
        propsToUpdate.setProperty("u_payloadrejectedbatchflag", "Y");
        // Made new transaction to commit even if there is an exception
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, propsToUpdate, true);
    }


    /***********
     * This method is used to get samples of LIMS batch.
     * @param limsBatchId
     * @return
     * @throws SapphireException
     ***********/
    private DataSet getSamplesFromBatch(String limsBatchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getSamplesFromBatch (method)");
        String sqlText = "SELECT " +
                "    s_batchstage.processstageid, " +
                "    s_sample.s_sampleid, " +
                "    s_sample.samplestatus " +
                "FROM " +
                "    s_sample " +
                "    INNER JOIN s_batchstage ON s_sample.batchstageid = s_batchstage.s_batchstageid " +
                "WHERE " +
                "    s_sample.batchid = ? ";
        DataSet dsSamples = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{limsBatchId});
        if (null == dsSamples) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        } else {
            return dsSamples;
        }
    }

    /***************
     * This method is used to get auto receive flag is turned ON or OFF
     * @param sapPlant
     * @return
     * @throws SapphireException
     ***************/
    private String getAutoreceiveFlag(String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getAutoreceiveFlag (method)");
        String sqltext = "SELECT " +
                "    autoreceiverawmatflag " +
                "FROM " +
                "    u_sites " +
                "WHERE " +
                "    sapplant = ? ";
        DataSet dsAutoReceive = getQueryProcessor().getPreparedSqlDataSet(sqltext, new Object[]{sapPlant});
        if (null == dsAutoReceive) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        } else if (dsAutoReceive.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_NO_PLANT_FOUND, sapPlant)));
        } else {
            return dsAutoReceive.getValue(0, "autoreceiverawmatflag", "N");
        }
    }

    /*************
     * This method is used get LIMS Batch status.
     * @param batchId LIMS Batch Id.
     * @return Returns the Batch status.
     * @throws SapphireException Throws OOB Sapphire exception.
     *************/
    private String getBatchStatus(String batchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getBatchStatus (method)");
        StringBuilder errMsg = new StringBuilder().append(" ");
        String strBatchStatus = "";
        String sqlText = "select batchstatus from s_batch where s_batchid = ?";
        DataSet dsBatchStatus = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{batchId});
        if (dsBatchStatus == null) {
            errMsg.append(ErrorMessageUtil.NULL_SQL_VALUE).append(" For LIMS batch Id: ").append(batchId);
            throw new SapphireException(errMsg.toString());
        }
        if (dsBatchStatus.getRowCount() == 0) {
            errMsg.append(ErrorMessageUtil.NO_ROW_FOUND).append(" For LIMS batch Id: ").append(batchId);
            throw new SapphireException(errMsg.toString());
        }
        strBatchStatus = dsBatchStatus.getValue(0, "batchstatus");
        return strBatchStatus;
    }

    /***********
     * This method is used to Receive LIMS Batch.
     *
     * @param limsBatchId Newly created LIMS Batch Id.
     * @throws SapphireException Throws OOB Sapphire exception.
     ************/
    private void receiveBatch(String limsBatchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside receiveBatch (method)");

        PropertyList plEditSDI = new PropertyList();
        plEditSDI.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
        plEditSDI.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
        plEditSDI.setProperty("operation", "Receive");
        plEditSDI.setProperty("batchstatus", getBatchStatus(limsBatchId));
        plEditSDI.setProperty("receivedby", VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

        try {
            this.getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plEditSDI);
        } catch (SapphireException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE
                    , this.getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_FAILED_RECEIVE_BATCH, limsBatchId)));
        }
    }

    /***************
     * This method is used to edit and set the MARS CODE attribute.
     *
     * @param batchId  LIMS Batch ID.
     * @param marsCode MARS CODE value.
     * @throws SapphireException Throws OOB Sapphire exception.
     ***************/
    private void setMarsCode(String batchId, String marsCode) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside setMarsCode (method)");
        PropertyList plEditAttr = new PropertyList();
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_KEYID1, batchId);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTEID, __PROPS_MARS_CODE_ATTR);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTEINSTANCE, "1");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTESDCID, __PROPS_BATCH_SDCID);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_VALUE, marsCode);
        try {
            getActionProcessor().processAction(EditSDIAttribute.ID, EditSDIAttribute.VERSIONID, plEditAttr);
        } catch (SapphireException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Unable to execute EditSDIAttribute. Please contact your system adminstration."));
        }
    }

    /****************
     * This method is used to check whether mars_code attribute is attached to Batch or not.
     *
     * @param batchId LIMS Batch Id.
     * @return Returns "Y" or "N" based on availability of mars_code attribute.
     * @throws SapphireException Throws OOB Sapphire exception.
     ****************/
    private String isMarsCodeAttrPresentInBatch(String batchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside isMarsCodeAttrPresentInBatch (method)");
        String retVal = "Y";
        String rsetId = "";
        String sqlText = "";
        DataSet dsSDIAttribute;
        try {
            rsetId = getDAMProcessor().createRSet("Batch", batchId, "(null)", "(null)");
            sqlText = "select sdiattr.keyid1 from sdiattribute sdiattr, rsetitems rsi " +
                    "where sdiattr.sdcid = 'Batch' " +
                    "and sdiattr.attributeid = 'mars_code' " +
                    "and sdiattr.sdcid = rsi.sdcid " +
                    "and sdiattr.keyid1= rsi.keyid1 " +
                    "and sdiattr.keyid2 = rsi.keyid2 " +
                    "and sdiattr.keyid3 = rsi.keyid3 " +
                    "and rsi.keyid1 = ? " +
                    "and rsi.rsetid = ?";
            dsSDIAttribute = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{batchId, rsetId});
        } catch (SapphireException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Unable to execute query."));
        } finally {
            if (!"".equals(rsetId)) {
                getDAMProcessor().clearRSet(rsetId);
            }
        }
        if (dsSDIAttribute.getRowCount() == 0) {
            retVal = "N";
        }
        return retVal;
    }

    /**************
     * This method is used to get Batch Template information.
     *
     * @param batchType Batch Type (Raw Material, Finished, Semi-Fin, Expiry Product, Stock transfer)
     * @return
     * @throws SapphireException Throws OOB Sapphire exception.
     **************/
    private String getBatchTemplate(String batchType) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getBatchTemplate (method)");
        String templateId = "";

        PropertyList plBatchTemplate = getConfigurationProcessor().getPolicy("SAPInterfacePolicy", "Custom");
        PropertyListCollection plBatchTemplateCol = plBatchTemplate.getCollection("BatchTemplate");
        for (int row = 0; row < plBatchTemplateCol.size(); row++) {
            String policyBatchType = plBatchTemplateCol.getPropertyList(row).getProperty("BatchType");
            if ((policyBatchType).equalsIgnoreCase(batchType)) {
                templateId = plBatchTemplateCol.getPropertyList(row).getProperty("BatchTemplate");
                return templateId;
            }
        }
        if (("").equalsIgnoreCase(templateId)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_BATCH_TEMPLATE_NOT_FOUND, batchType, "SAPInterfacePolicy")));
        }
        return templateId;
    }

    /***************
     * This method is responsible for creating LIMS RM batch
     * @param dsBatchDetails
     * @throws SapphireException
     ***************/
    private String createRMLIMSBatch(DataSet dsBatchDetails) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside createRMLIMSBatch (method)");
        // method variables
        String strBatchId = "";
        String inspectionStartDate = SAPUtil.checkNullDate(dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_START_DATE, ""));
        inspectionStartDate = SAPUtil.getDateWithProperFormat(inspectionStartDate, connectionInfo);
        String inspectionEndDate = SAPUtil.checkNullDate(dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_END_DATE, ""));
        inspectionEndDate = SAPUtil.getDateWithProperFormat(inspectionEndDate, connectionInfo);

        PropertyList plBatchDetails = new PropertyList();
        plBatchDetails.setProperty(AddSDI.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
        plBatchDetails.setProperty(__PROPS_BATCH_PRODUCTID, dsBatchDetails.getValue(0, "s_" + __PROPS_BATCH_PRODUCTID, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_PRODUCT_VERSIONID, dsBatchDetails.getValue(0, "s_" + __PROPS_BATCH_PRODUCT_VERSIONID, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_PRODUCT_VARIANTID, dsBatchDetails.getValue(0, "s_" + __PROPS_BATCH_PRODUCT_VARIANTID, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_PRODUCT_INSPECTIONLOT, dsBatchDetails.getValue(0, __PROPS_BATCH_PRODUCT_INSPECTIONLOT, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_BATCH, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_BATCH, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_SAP_BATCH_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_MAT_NUMBER, dsBatchDetails.getValue(0, __PROPS_BATCH_MAT_NUMBER, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_INSPECTION_LOT_ORIGIN, dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_LOT_ORIGIN, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_INSPECTION_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_VENDOR_NUM, ___KEY_NOT_FOUND.equalsIgnoreCase(dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, "")) ? "" : dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_VENDOR_NAME, dsBatchDetails.getValue(0, __PROPS_BATCH_VENDOR_NAME, ""));
        plBatchDetails.setProperty(__PROPS_VENDOR_BATCH_NUMBER, ___KEY_NOT_FOUND.equalsIgnoreCase(dsBatchDetails.getValue(0, __PROPS_VENDOR_BATCH_NUMBER, "")) ? "" : dsBatchDetails.getValue(0, __PROPS_VENDOR_BATCH_NUMBER, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_MATERIAL_DESC, dsBatchDetails.getValue(0, __PROPS_BATCH_MATERIAL_DESC, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SUPPLIER_ADDRESS_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_SUPPLIER_ADDRESS_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SUPPLIER_ADDRESS_ID, dsBatchDetails.getValue(0, __PROPS_BATCH_SUPPLIER_ADDRESS_ID, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_MANUFACTURER_ADDRESS_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_MANUFACTURER_ADDRESS_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_MANUFACTURER_ADDRESS_ID, dsBatchDetails.getValue(0, __PROPS_BATCH_MANUFACTURER_ADDRESS_ID, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SECURITY_USER, dsBatchDetails.getValue(0, __PROPS_BATCH_SECURITY_USER, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SECURITY_DEPT, dsBatchDetails.getValue(0, __PROPS_BATCH_SECURITY_DEPT, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_PARENT_BATCH, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PARENT_BATCH, ""));// Need to discuss with Client what will be the actual value.
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_PARENT_MATERIAL, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PARENT_MATERIAL, ""));// Need to discuss with Client what will be the actual value.
        plBatchDetails.setProperty(__PROPS_BATCH_MES_ORDER_SAP_BATCH1, dsBatchDetails.getValue(0, __PROPS_BATCH_MES_ORDER_SAP_BATCH1, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_MES_ORDER_SAP_BATCH2, dsBatchDetails.getValue(0, __PROPS_BATCH_MES_ORDER_SAP_BATCH2, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_TOOL_ID, dsBatchDetails.getValue(0, __PROPS_BATCH_TOOL_ID));
        plBatchDetails.setProperty(__PROPS_BATCH_LOCAL_MAT_CODE, dsBatchDetails.getValue(0, __PROPS_BATCH_LOCAL_MAT_CODE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_VENDOR_STATUS, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_STATUS, ""));

        plBatchDetails.setProperty(__PROPS_BATCH_DESC, dsBatchDetails.getValue(0, __PROPS_BATCH_PRODUCT_DESC, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_PRODUCT_SUBTYPE_ID, dsBatchDetails.getValue(0, __PROPS_BATCH_PRODUCT_SUB_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_SUBSYSTEM, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_SUBSYSTEM, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_TEMPLATE_FLAG, "N");
        plBatchDetails.setProperty(__PROPS_BATCH_ACTIVE_FLAG, "Y");
        plBatchDetails.setProperty(__PROPS_BATCH_RESULT_UPLOAD_FLAG, "N");
        plBatchDetails.setProperty(__PROPS_BATCH_TEMPLATE_ID, dsBatchDetails.getValue(0, __PROPS_BATCH_TEMPLATE_ID));
        //plBatchDetails.setProperty(__PROPS_BATCH_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_TEMPLATE_ID));
        plBatchDetails.setProperty(__PROPS_BATCH_CATCODEGROUP_PASS, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODEGROUP_PASS, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_CATCODE_PASS, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODE_PASS, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_CATCODEGROUP_FAIL, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODEGROUP_FAIL, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_CATCODE_FAIL, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODE_FAIL, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_IS_SAP_FLAG, "Y");
        plBatchDetails.setProperty(__PROPS_BATCH_RESULT_UPLOAD_RESTRICTION_FLAG, "N");
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_PLANT, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PLANT, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SELECTEDSET, dsBatchDetails.getValue(0, __PROPS_BATCH_SELECTEDSET, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_LAB_CONF_NUM, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_LAB_CONF_NUM, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SIZE, dsBatchDetails.getValue(0, __PROPS_BATCH_SIZE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SIZE_UNITS, dsBatchDetails.getValue(0, __PROPS_BATCH_SIZE_UNITS, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_INSPECTION_START_DATE, inspectionStartDate);
        plBatchDetails.setProperty(__PROPS_BATCH_INSPECTION_END_DATE, inspectionEndDate);
        plBatchDetails.setProperty(__PROPS_BATCH_CREATED_BY, "(system)".equalsIgnoreCase(connectionInfo.getSysuserId()) ? VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID : connectionInfo.getSysuserId());
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plBatchDetails);

        strBatchId = plBatchDetails.getProperty(__PROPS_NEW_KEYID1);
        return strBatchId;

    }

    /************
     * This method is used to check whether Pre Shipment required or not ?
     * @param dsStageDetails
     * @return
     * @throws SapphireException
     ************/
    private String checkStageType(DataSet dsStageDetails, String stageType) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkPreSshipmentStageType (method)");
        String processStageId = "";
        DataSet dsProcessStageId;
        PropertyList plPreShipmentFilter = new PropertyList();
        plPreShipmentFilter.setProperty(__PROPS_PROCESS_STAGE_TYPE, stageType);
        dsProcessStageId = dsStageDetails.getFilteredDataSet(plPreShipmentFilter);
        if (dsProcessStageId.getRowCount() > 0) {
            processStageId = dsProcessStageId.getValue(0, __PROPS_PROCESS_STAGE_ID, "");
        }
        return processStageId;
    }

    /**************
     * This method is used to get current version of the Sampling plan by PV
     * @param prodVariantId
     * @return
     * @throws SapphireException
     **************/
    private DataSet getCurrentSamplingPlanByPV(String prodVariantId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getCurrentSamplingPlanByPV (method)");
        String sqlText = " SELECT " +
                "    s_samplingplan.s_samplingplanid, " +
                "    s_samplingplan.s_samplingplanversionid " +
                "FROM " +
                "    s_samplingplan " +
                "    INNER JOIN s_prodvariant ON s_samplingplan.s_samplingplanid = s_prodvariant.samplingplanid " +
                "WHERE " +
                "    s_samplingplan.versionstatus = 'C' " +
                "    AND s_prodvariant.s_prodvariantid = ? ";
        DataSet dsCurrentSamplingPlan = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{prodVariantId});
        if (null == dsCurrentSamplingPlan) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        } else {
            return dsCurrentSamplingPlan;
        }
    }

    /*****************
     * This method is used to get PV--> Sampling Plan(Current Version) --> Process Stage details
     *@param samplingPlanId
     * @param samplingPlanVersionId
     * @return
     * @throws SapphireException
     *****************/
    private DataSet getProcessStageDetails(String samplingPlanId, String samplingPlanVersionId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getProcessStageDetails (method)");
        String sqlText = " SELECT " +
                "    s_processstage.s_processstageid, " +
                "    s_processstage.label, " +
                "    s_processstage.repeatcount, " +
                "    s_processstage.u_stagetype " +
                "FROM " +
                "    s_samplingplan " +
                "    JOIN s_processstage ON s_samplingplan.s_samplingplanid = s_processstage.s_samplingplanid " +
                "                           AND s_samplingplan.s_samplingplanversionid = s_processstage.s_samplingplanversionid " +
                "WHERE " +
                "    s_samplingplan.s_samplingplanid = ? " +
                "    AND s_samplingplan.s_samplingplanversionid = ? " +
                "    AND s_processstage.repeatcount <> 0 "; // Not considering process stages having repeat count zero
        DataSet dsProcessStageDetails = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{samplingPlanId, samplingPlanVersionId});
        if (null == dsProcessStageDetails) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        } else if (dsProcessStageDetails.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00011, samplingPlanId, samplingPlanVersionId)));
        } else {
            return dsProcessStageDetails;
        }
    }

    /*******************************
     * This method is used to dynamically check mandatory values
     * @param dsBatchDetails
     * @param plMandatoryFields
     * @throws SapphireException
     ********************************/
    private void checkMandatoryFields(DataSet dsBatchDetails, HashMap<String, String> plMandatoryFields) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkMandatoryFields (method)");
        String key = "";
        String value = "";
        // Looping thorugh the Batch details DataSet
        for (int colNum = 0; colNum < dsBatchDetails.getColumnCount(); colNum++) {
            // If Mandatory key found in Batch Details DS
            if (hmMandatoryFields.containsKey(dsBatchDetails.getColumnId(colNum))) {
                // Check if key is SAP Vendor Batch Key present
                key = dsBatchDetails.getColumnId(colNum);
                value = dsBatchDetails.getValue(0, key, "");
                // Check if mandatory value is blank
                if ("".equalsIgnoreCase(value)) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00001, plMandatoryFields.get(key))));
                }
            }
        }
    }

    /********************
     * This method is used to check whether LIMS Batch already exist or not.
     *
     * @param strSAPBatchId SAP Batch Number.
     * @param strSAPPlant   SAP Plant code.
     * @param strMatNum     SAP Material Number.
     * @return Returns array containing LIMS Batch Id iif exists.
     * @throws SapphireException Throws OOB Sapphire exception.
     ********************/
    private DataSet sapLotBatchExists(String strSAPBatchId, String strMatNum, String strSAPPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside sapLotBatchExists (method)");
        // SAP Plant & SAP Batch is a newly added field and not exposed to the Batch maint page while creating LIMS Batch Manually.
        // SAP Batch and MES ORDER NUMBER are same for a LIMS Batch and is a mandatory field while creating a Batch.
        // Hence instead of direct SAP Batch # and Plant #, check for existing LIMS Batch is done on MES ORDER NUMBER 1 field
        // AND Batch's PV Security Department(which is having the plant id associated) respectively.
        String sqlText = "SELECT " +
                "    s_batch.s_batchid, " +
                "    s_batch.batchdesc, " +
                "    s_batch.productid, " +
                "    s_batch.productversionid, " +
                "    s_batch.batchstatus, " +
                "    s_batch.createdt, " +
                "    s_batch.prodvariantid, " +
                "    s_batch.samplingplanid, " +
                "    s_batch.samplingplanversionid " +
                "FROM " +
                "    s_batch " +
                "    JOIN s_prodvariant ON s_batch.prodvariantid = s_prodvariant.s_prodvariantid " +
                "WHERE " +
                "    ( s_batch.u_mesordersapbatch1 = ? " +
                "    OR s_batch.prodvariantlotreference = ? ) " +
                "    AND s_batch.u_sapmatnumber = ? " +
                "    AND ( s_batch.u_sapplant = ? " +
                "          OR s_prodvariant.securitydepartment IN ( " +
                "        SELECT " +
                "            department.departmentid " +
                "        FROM " +
                "            department " +
                "            INNER JOIN u_sites ON department.u_siteid = u_sites.u_sitesid " +
                "        WHERE " +
                "            u_sites.sapplant = ? " +
                "    ) ) " +
                "    AND s_batch.batchstatus <> 'Cancelled' ";
        DataSet dslimsBatch = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{strSAPBatchId, strSAPBatchId, strMatNum, strSAPPlant, strSAPPlant});
        if (null == dslimsBatch) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE + String.format(ErrorMessageUtil.RM_FOR_FIELDS, strSAPBatchId, strMatNum, strSAPPlant)));
        } else {
            return dslimsBatch;

        }
    }

    /**************
     * This method is used to check whether the Lot Rceipt payload is for cancel Batch or not.
     *
     * @param inspectionLotStatus SAP Inspection Lot status.
     * @param strSAPBatch
     * @param strSAPMaterial
     * @param strSAPPlant
     * @return Returns True if Cancel Batch False.
     * @throws SapphireException Throws OOB Sapphire exception.
     **************/
    private boolean checkCancelledBatch(String inspectionLotStatus, String strSAPBatch, String strSAPMaterial, String strSAPPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkCancelledBatch (method)");
        boolean status = false;
        if ("".equalsIgnoreCase(inspectionLotStatus)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + String.format(ErrorMessageUtil.RM_FOR_FIELDS, strSAPBatch, strSAPMaterial, strSAPPlant)));
        } else if ("D".equalsIgnoreCase(inspectionLotStatus) || "C".equalsIgnoreCase(inspectionLotStatus)) {
            status = true;
        }
        return status;
    }

    /*******
     * This method is used to get RM product variant details
     * @param dsBatchDetails
     * @param sapBatch
     * @param sapMaterial
     * @param sapPlant
     * @param vendorNum
     * @return
     * @throws SapphireException
     ********/
    private void getRMProdVariant(DataSet dsBatchDetails, String sapBatch, String sapMaterial, String sapPlant, String vendorNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getRMProdVariant (method)");
        // Getting active product, PV variant details
        DataSet dsActivePV = getActiveProductVariant(sapBatch, sapMaterial, sapPlant, vendorNum);
        // Final PV details
        DataSet dsFinalPV = new DataSet(connectionInfo);
        // Filter criteria
        PropertyList plFilter = new PropertyList();
        // If more than one PV found
        if (dsActivePV.getRowCount() > 1) {
            // If Vendor number is NOT BLANK
            if (!"".equalsIgnoreCase(vendorNum)) {
                plFilter.setProperty(__PROPS_BATCH_SAP_VENDOR_NUM, vendorNum);
                dsFinalPV = dsActivePV.getFilteredDataSet(plFilter);
                if (dsFinalPV.getRowCount() == 0) {
                    // Check for default PV( Vendor number is BLANK) if no vendor number matching PV found
                    for (int dsRow = 0; dsRow < dsActivePV.getRowCount(); dsRow++) {
                        if ("".equalsIgnoreCase(dsActivePV.getValue(dsRow, __PROPS_BATCH_SAP_VENDOR_NUM, ""))) {
                            dsFinalPV.copyRow(dsActivePV, dsRow, 1);
                        }
                    }
                    // If  default PV not found
                    if (dsFinalPV.getRowCount() == 0) {
                        throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00019, sapBatch, sapMaterial, sapPlant)));
                    } else if (dsFinalPV.getRowCount() > 1) {
                        // If more than one default PV found
                        throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00020, sapBatch, sapMaterial, sapPlant)));
                    }
                } else if (dsFinalPV.getRowCount() > 1) {
                    // If multiple Vendor matched PV found
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00021, vendorNum)));
                }
            } else if ("".equalsIgnoreCase(vendorNum)) {
                //********** JIRA Ticket 1152 : Checking if Single PV is having vendor number or not ?
                for (int dsRow = 0; dsRow < dsActivePV.getRowCount(); dsRow++) {
                    if ("".equalsIgnoreCase(dsActivePV.getValue(dsRow, __PROPS_BATCH_SAP_VENDOR_NUM, ""))) {
                        dsFinalPV.copyRow(dsActivePV, dsRow, 1);
                    }
                }

                if (dsFinalPV.getRowCount() == 0) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00019, sapBatch, sapMaterial, sapPlant)));
                } else if (dsFinalPV.getRowCount() > 1) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00020, sapBatch, sapMaterial, sapPlant)));
                }

            } else {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00018, sapBatch, sapMaterial, sapPlant, vendorNum)));
            }
        } else {
            //******** If Vendor number LIFNR present in SAP Payload
            if (!"".equalsIgnoreCase(vendorNum)) {
                // If Single PV found.
                // Check if PV is having Matching vendor number
                if (vendorNum.equalsIgnoreCase(dsActivePV.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, ""))) {
                    dsFinalPV = dsActivePV;
                } else if ("".equalsIgnoreCase(dsActivePV.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, ""))) {
                    // If Matching PV not found
                    // Then check if PV vendor num is BLANK or not ?
                    dsFinalPV = dsActivePV;
                } else {
                    // If NOT( BLANK / Vendor Number) Matching
                    // Throw Error
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00018, sapBatch, sapMaterial, sapPlant, vendorNum)));
                }
            } else {
                //******** If Vendor number LIFNR NOT present in SAP Payload
                // Create the LIMS Batch with PV having any vendor number
                dsFinalPV = dsActivePV;
            }

        }
        // Inserting PV data to Batch details
        for (int col = 0; col < dsFinalPV.getColumnCount(); col++) {
            // If Column Name is vendor number the skip
            // This checking is added here because we need to take payload vendor number value no LIMS PV--> Vendor Num
            if (!__PROPS_BATCH_SAP_VENDOR_NUM.equalsIgnoreCase(dsFinalPV.getColumnId(col))) {
                dsBatchDetails.addColumn(dsFinalPV.getColumnId(col), dsFinalPV.getColumnType(dsFinalPV.getColumnId(col)));
                dsBatchDetails.setValue(0, dsFinalPV.getColumnId(col), dsFinalPV.getValue(0, dsFinalPV.getColumnId(col), ""));
            }
        }

    }

    /*****************
     * This method is sued to get Product Varinat having product version as CURRENT.
     *
     * @param sapMatNumber SAP Material Number.
     * @param sapPlant     SAP plant code.
     * @return DataSet containg active Product varint details.
     * @throws SapphireException Throws OOB Sapphire exception.
     ******************/
    private DataSet getActiveProductVariant(String sapBatch, String sapMatNumber, String sapPlant, String vendorNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getActiveProductVariant (method)");
        String sqlText = "";
        sqlText = "SELECT " +
                "     p.s_productid, " +
                "    p.s_productversionid, " +
                "    p.productdesc, " +
                "    p.u_prodsubtypeid, " +
                "    pv.prodvarianttype, " +
                "    pv.u_sapvendornum, " +
                "    pv.s_prodvariantid, " +
                "    pv.supplieraddresstype, " +
                "    pv.supplieraddressid, " +
                "    pv.manufactureraddresstype, " +
                "    pv.u_sapmanufacturernum, " +
                "    pv.manufactureraddressid, " +
                "    pv.securityuser, " +
                "    pv.securitydepartment, " +
                "    pv.samplingplanid, " +
                "    pv.samplingplanversionid " +
                "FROM " +
                "    s_product       p, " +
                "    s_prodvariant   pv " +
                "WHERE " +
                "    p.s_productid = pv.productid " +
                "    AND pv.u_sapmatnumber = ? " +
                "    AND pv.u_sapplant = ? " +
                "    AND pv.productversionid = p.s_productversionid " +
                "    AND p.versionstatus = 'C' " +
                "    AND nvl(pv.activeflag, 'Y') = 'Y'";
        DataSet dsPVDetails = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{sapMatNumber, sapPlant});
        if (null == dsPVDetails) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.FAILED_EXECUTING_PROD_VAR + String.format(ErrorMessageUtil.RM_FOR_FIELDS, sapBatch, sapMatNumber, sapPlant)));
        } else if (dsPVDetails.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00018, sapBatch, sapMatNumber, sapPlant, vendorNum)));
        } else {
            return dsPVDetails;
        }
    }

    /**********
     * This method is for getting and creating batch details from SAP data payload.
     * @param dsItemPayLoad
     * @return
     * @throws SapphireException
     **********/
    private DataSet getBatchDataFromSAPPayload(DataSet dsItemPayLoad) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside processRMBatch (method)");
        DataSet dsBatchDetailsFromSAP = new DataSet();
        // Adding SAP columns
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_CATCODEGROUP_PASS, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_CATCODE_PASS, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_CATCODEGROUP_FAIL, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_CATCODE_FAIL, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_PRODUCT_INSPECTIONLOT, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_PRODUCT_INSPECTIONLOT_STATUS, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_BATCH, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_MAT_NUMBER, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_INSPECTION_LOT_ORIGIN, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_INSPECTION_TYPE, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_VENDOR_NUM, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_VENDOR_NAME, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_MATERIAL_DESC, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_MES_ORDER_SAP_BATCH1, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_MES_ORDER_SAP_BATCH2, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_TOOL_ID, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_LOCAL_MAT_CODE, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_VENDOR_STATUS, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_SUBSYSTEM, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_PLANT, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_PARENT_BATCH, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_PARENT_MATERIAL, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SIZE, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SIZE_UNITS, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_INSPECTION_START_DATE, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_INSPECTION_END_DATE, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_MARS_CODE_ATTR, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_VENDOR_BATCH_NUMBER, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SELECTEDSET, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_LAB_CONF_NUM, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_LAB_CONF_NUM, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_LAB_CONF_NUM, DataSet.STRING);
        // Adding a row
        int rowId = dsBatchDetailsFromSAP.addRow();
        // Adding values to DataSet
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_CATCODEGROUP_PASS, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAICA, __PROPS_SAP_KEY_CODEGRUPPE)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_CATCODE_PASS, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAICA, __PROPS_SAP_KEY_CODE)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_CATCODEGROUP_FAIL, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAICA, __PROPS_SAP_KEY_CODEGRUPPE)), ";")[1]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_CATCODE_FAIL, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAICA, __PROPS_SAP_KEY_CODE)), ";")[1]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_PRODUCT_INSPECTIONLOT, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_PRUEFLOS)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_PRODUCT_INSPECTIONLOT_STATUS, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_PRUEFSTAT)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_BATCH, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_CHARG)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_MAT_NUMBER, SAPUtil.removeLeadingZeroes(StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_MATNR)), ";")[0]));
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_INSPECTION_LOT_ORIGIN, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_HERKUNFT)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_INSPECTION_TYPE, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_ART)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_VENDOR_NUM, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_LIFNR)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_VENDOR_NAME, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_NAME1LIF)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_MATERIAL_DESC, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_KTEXTMAT)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_MES_ORDER_SAP_BATCH1, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_CHARG)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_MES_ORDER_SAP_BATCH2, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_CHARG)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_TOOL_ID, "(null)");// Force fully setting this to (Null)
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_LOCAL_MAT_CODE, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWUSERD1)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_VENDOR_STATUS, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWUSERC1)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_SUBSYSTEM, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SUBSYS)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_PLANT, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_WERK)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_PARENT_BATCH, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWTPLNR)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_PARENT_MATERIAL, SAPUtil.removeLeadingZeroes(StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWPHYNR)), ";")[0]));
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SIZE, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_LOSMENGE)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SIZE_UNITS, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_MENGENEINH)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_INSPECTION_START_DATE, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_PASTRTERM)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_INSPECTION_END_DATE, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_PAENDTERM)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_MARS_CODE_ATTR, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWUSERC2)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_VENDOR_BATCH_NUMBER, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_LICHN)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SELECTEDSET, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIMV, __PROPS_SAP_KEY_AUSWMENGE1)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_LAB_CONF_NUM, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIMV, __PROPS_SAP_KEY_RUECKMELNR)), ";")[0]);

        return dsBatchDetailsFromSAP;

    }
}
