package labvantage.custom.alcon.sap.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

import java.net.HttpURLConnection;
import java.net.URL;

public class RESTClient extends BaseAction {
    public static String ENDPOINT = "";
    public static String USER_NAME="";
    public static String PASSWORD ="";
    public void processAction(PropertyList properties) throws SapphireException{

        try{
            URL connURL = new URL(ENDPOINT);
            HttpURLConnection conn=(HttpURLConnection)connURL.openConnection();
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
            

        }catch(Exception ex){


        }


}
}
