package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.sap.util.SAPUtil;
import org.json.JSONException;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.LinkedHashMap;
/**
 * $Author: BAGCHAN1 $
 * $Date: 2021-10-06 18:20:26 -0500 (Wed, 06 Oct 2021) $
 * $Revision: 618 $
 */

/***********************************************
 * $Revision: 618 $
 * The action requests Inspection Lot from SAP.
 *
 * @author Soumen Mitra
 * @version 1
 ************************************************/

public class LotRequest extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 618 $";

    public static final String ACTION_ID = "LotRequest";
    public static final String ACTION_VERSION_ID = "1";

    public static final String BATCH_STATUS_RELEASED = "Released";
    public static final String BATCH_STATUS_CANCELLED = "Cancelled";
    public static final String PROPERTY_SERVICE_NAME = "transname";
    public static final String PROPERTY_SERVICE_VALUE = "LOT_REQUEST";
    public static final String PROPERTY_ITEM_DATA = "itempayloadtranstable";

    /**
     * Description: processAction is an OOB LabVantage method. This is the main method where execution starts.
     *
     * @param properties
     * @throws SapphireException
     */

    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        logger.debug("================== Processing LOT Request action. ==========================================");
        //Checking for mandatory fields
        checkMandatoryFields(properties);
        //Getting the properties
        String pruefstat = "".equals(properties.getProperty("PRUEFSTAT")) ? properties.getProperty("pruefstat") : properties.getProperty("PRUEFSTAT");
        String maxlosanz = "".equals(properties.getProperty("MAXLOSANZ")) ? properties.getProperty("maxlosanz") : properties.getProperty("MAXLOSANZ");
        String satzart = "".equals(properties.getProperty("SATZART")) ? properties.getProperty("satzart") : properties.getProperty("SATZART");
        String iindtransfercharcodes = "".equals(properties.getProperty("IINDTRANSFERCHARCODES")) ? properties.getProperty("iindtransfercharcodes") : properties.getProperty("IINDTRANSFERCHARCODES");
        String iindmultitransferpossible = "".equals(properties.getProperty("I_IND_MULTI_TRANSFER_POSSIBLE")) ? properties.getProperty("i_ind_multi_transfer_possible") : properties.getProperty("I_IND_MULTI_TRANSFER_POSSIBLE"); // Valid only for CancelLot request
        String iindsortascendingtodate = "".equals(properties.getProperty("I_IND_SORT_ASCENDING_TO_DATE")) ? properties.getProperty("i_ind_sort_ascending_to_date") : properties.getProperty("I_IND_SORT_ASCENDING_TO_DATE");
        String siteIdClause = "".equals(properties.getProperty("SITEIDCLAUSE")) ? properties.getProperty("siteidclause") : properties.getProperty("SITEIDCLAUSE");
        String switchForLog = "".equals(properties.getProperty("LOG_SWITCH")) ? properties.getProperty("log_switch") : properties.getProperty("LOG_SWITCH");
        String manualInvoke = "".equals(properties.getProperty("MANUAL_INVOKE")) ? properties.getProperty("manual_invoke") : properties.getProperty("MANUAL_INVOKE");

        if (siteIdClause.startsWith("[") && siteIdClause.endsWith("]")) {
            siteIdClause = "";
        }

        if ("Y".equalsIgnoreCase(manualInvoke)) {
            switchForLog = "ON";
        }

        //-- Set default values ---//
        if ("".equals(pruefstat)) {
            pruefstat = "A";
        }
        if ("".equals(maxlosanz)) {
            maxlosanz = "20";
        }
        if ("".equals(satzart)) {
            satzart = "Q41";
        }
        if ("".equals(iindtransfercharcodes)) {
            iindtransfercharcodes = "X";
        }
        if ("".equals(iindmultitransferpossible)) {
            iindmultitransferpossible = "X";
        }
        if ("".equals(iindsortascendingtodate)) {
            iindsortascendingtodate = "X";
        }
        if ("".equals(switchForLog)) {
            switchForLog = "ON";
        }


        DataSet dsData = prepareData(siteIdClause);
        for (int row = 0; row < dsData.size(); row++) {

            String plantId = dsData.getValue(row, "sapplant", "");
            SAPUtil.validateSystemService(getQueryProcessor(), plantId, PROPERTY_SERVICE_VALUE);
        }

        PropertyList props = new PropertyList();
        dsData.sort("u_intfsystemid,u_sitesid");
        ArrayList arrDataSet = dsData.getGroupedDataSets("u_intfsystemid,u_sitesid");

        //Multiple set of system may come here.
        PropertyList p = new PropertyList();
        for (int i = 0; i < arrDataSet.size(); i++) {
            p.clear();
            DataSet dsEach = (DataSet) arrDataSet.get(i);
            if (dsEach == null || dsEach.size() == 0) {
                continue;
            }
            //Making the JSON payload
            String jsonString = null;
            try {
                jsonString = getJSON(dsEach, pruefstat, maxlosanz, satzart, iindtransfercharcodes, iindmultitransferpossible, iindsortascendingtodate);
            } catch (JSONException e) {
                throw new SapphireException(e);
            }
            String sapplantId = dsEach.getValue(0, "sapplant", "");
            p.setProperty(SAPLVOutbound.PROPERTY_SAP_PLANT, sapplantId);

            p.setProperty(SAPLVOutbound.PROPERTY_JSON_STRING, jsonString);
            p.setProperty(PROPERTY_SERVICE_NAME, PROPERTY_SERVICE_VALUE);
            p.setProperty(SAPLVOutbound.PROPERTY_LOGGER_SWITCH, switchForLog);

            //for each set there will be one web service request.So calling the webservice in a loop
            getActionProcessor().processAction("SAPLVOutbound", "1", p, true);
        }

    }

    /**
     * Description: This method is used to prepare the payload for sending lot request
     *
     * @return
     * @throws SapphireException
     */

    private DataSet prepareData(String siteIdClause) throws SapphireException {

        String sql = "select s.u_intfsystemid,s.sysstatus,st.u_sitesid,st.sitename,st.sitecode,st.sapsubsystem,st.sapplant" +
                " from u_intfsystem s,u_intfsystemsites ss,u_sites st " +
                " where s.u_intfsystemid = ss.u_intfsystemid and ss.siteid = st.u_sitesid  and s.sysstatus='ACTIVE'" + siteIdClause +
                " order by s.u_intfsystemid,st.u_sitesid";

        DataSet ds = getQueryProcessor().getSqlDataSet(sql);
        if (ds == null) {
            String error = "Wrong query: " + sql;
            logger.error(error);
            throw new SapphireException(error);
        }
        if (ds.getRowCount() == 0) {
            String error = "No master data available in below table(s). Please check Lab Admin > System interfacing tables.";
            logger.error(error);
            throw new SapphireException(error);
        }

        return ds;

    }


    private final String JSON_DOUBLE_QUOTE = "\"";

    private final String JSON_E = JSON_DOUBLE_QUOTE + "ns0:QIRF_SEND_REQUIRMENTS_GET_DAT2" + JSON_DOUBLE_QUOTE + ": {";

    /**
     * Description: This method is used to create a JSON structure for the payload.
     *
     * @param dsEach
     * @param pruefstat
     * @param maxlosanz
     * @param satzart
     * @param iindtransfercharcodes
     * @param iindmultitransferpossible
     * @param iindsortascendingtodate
     * @return
     * @throws SapphireException
     * @throws JSONException
     */

    private String getJSON(DataSet dsEach, String pruefstat, String maxlosanz, String satzart, String iindtransfercharcodes, String iindmultitransferpossible, String iindsortascendingtodate) throws SapphireException, JSONException {
        String jsonString = "";

        JSONObject innerObj = getSortedJSONObject();
        innerObj.put("SATZART", satzart);
        innerObj.put("MAXLOSANZ", maxlosanz);
        innerObj.put("SUBSYS", dsEach.getValue(0, "SAPSUBSYSTEM"));
        innerObj.put("PRUEFSTAT", pruefstat);


        JSONObject outerObj = getSortedJSONObject();
        outerObj.put("I_IND_TRANSFER_CHAR_CODES", iindtransfercharcodes);

        //******** Handle for Cancel Lot request only ***********/
        if ("C".equalsIgnoreCase(pruefstat)) {
            outerObj.put("I_IND_MULTI_TRANSFER_POSSIBLE", iindmultitransferpossible);
        }
        //******** Handle for Cancel Lot request only ***********/

        outerObj.put("I_IND_SORT_ASCENDING_TO_DATE", iindsortascendingtodate);

        outerObj.put("I_QAILS", innerObj);
        outerObj.put("T_QAICATAB", "");
        outerObj.put("T_QAIMVTAB", "");
        outerObj.put("T_QAIVCTAB", "");
        outerObj.put("T_QIERRTAB", "");
        outerObj.put("-xmlns:ns0", "urn:sap-com:document:sap:rfc:functions");

        JSONObject finalObj = new JSONObject();
        finalObj.put("ns0:QIRF_SEND_REQUIRMENTS_GET_DAT2", outerObj);

        String formattedJSONString = finalObj.toString(3); // Indentation is taken care. Similar to Pretty print
        return formattedJSONString;

    }

    /**
     * Description: This method is used to validate mandatory fields.
     *
     * @param mandatoryProps
     * @throws SapphireException
     */

    private void checkMandatoryFields(PropertyList mandatoryProps) throws SapphireException {
        logger.debug("----- Inside Service: " + PROPERTY_SERVICE_VALUE + " , Inside: checkMandatoryFields ------");

        String maxlosanz = "".equals(mandatoryProps.getProperty("MAXLOSANZ")) ? mandatoryProps.getProperty("maxlosanz") : mandatoryProps.getProperty("MAXLOSANZ"); //MAXLOSANZ
        String satzart = "".equals(mandatoryProps.getProperty("SATZART")) ? mandatoryProps.getProperty("satzart") : mandatoryProps.getProperty("SATZART"); //SATZART
        String pruefstat = "".equals(mandatoryProps.getProperty("PRUEFSTAT")) ? mandatoryProps.getProperty("pruefstat") : mandatoryProps.getProperty("PRUEFSTAT"); //PRUEFSTAT

        String errMsg = "Mandatory field(s) are not passed from Task Property.\n";
        String errPropName = "";
        if (maxlosanz.equals("")) {
            errPropName = ";" + "MAXLOSANZ ";
        }
        if (satzart.equals("")) {
            errPropName = ";" + "SATZART ";
        }
        if (pruefstat.equals("")) {
            errPropName = ";" + "PRUEFSTAT ";
        }

        if (!errPropName.equals("")) {
            errPropName = errPropName.substring(1);
            throw new SapphireException(errMsg + errPropName);
        }
    }

    /**
     * Description:
     * Returns a JSONObject after the map is changed from HashMap to LinkedHashMap.
     * Reflection of a class is used to achieve the sorted behavior. Otherwise the sequnce pattern of objects is random.
     *
     * @return Sorted JSonObject
     * @throws SapphireException
     */
    public JSONObject getSortedJSONObject() throws SapphireException {

        JSONObject jsonObjectSorted;
        try {
            jsonObjectSorted = new JSONObject();
            java.lang.reflect.Field changeMap = jsonObjectSorted.getClass().getDeclaredField("myHashMap");
            changeMap.setAccessible(true);
            changeMap.set(jsonObjectSorted, new LinkedHashMap<>());
            changeMap.setAccessible(false);
        } catch (IllegalAccessException | NoSuchFieldException e) {
            throw new SapphireException("General error", ErrorDetail.TYPE_FAILURE, "Error while constructing sorted Json object. Error message : " + e.getMessage());
        }
        return jsonObjectSorted;

    }
}

