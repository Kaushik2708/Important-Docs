package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.ddt.IntfTransItem;
import labvantage.custom.alcon.sap.util.ErrorMessageUtil;
import labvantage.custom.alcon.sap.util.SAPPlants;
import labvantage.custom.alcon.sap.util.SAPUtil;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.util.Calendar;
import java.util.HashMap;

/**
 * $Author: GHOSHKA1 $
 * $Date: 2021-11-30 03:11:06 -0600 (Tue, 30 Nov 2021) $
 * $Revision: 684 $
 */

/********************************************************************************************
 * $Revision: 684 $
 * Description:
 * This class is for Aspetic Raw Material LOT RECEIPT Service.
 * This service is responsible for creation of Raw Material LIMS Batch based upon the SAP Inspection Lot.
 *
 * @author Kaushik Ghosh
 * @version 1
 *******************************************************************************************/

public class Aseptic_RM_Lot_Receipt extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 684 $";
    public static final String ID = "Aseptic_RM_Lot_Receipt";
    public static final String VERSIONID = "1";

    // SAP Interface specific variables
    public static final String VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "SAP_INTERFACE";
    private static final String _PROPS_ITEMDATA = "itemdata";
    private static final String _PROPS_TRANSITEM_SDCID = "IntfTransItem";
    private static final String _PROPS_TRANSITEMID = "u_intftransitemid";
    // For Mandatory Key missing
    private String ___KEY_NOT_FOUND = "KEY_NOT_FOUND";
    // Batch creation properties
    private static final String __PROPS_BATCH_SDCID = "Batch";
    private static final String __PROPS_NEW_KEYID1 = "newkeyid1";
    private static final String __PROPS_LIMS_BATCH_STATUS = "batchstatus";
    private static final String __PROPS_LIMS_BATCH_ID = "s_batchid";
    private static final String __PROPS_CREATE_DATE = "createdt";
    private static final String __PROPS_BATCH_PRODUCTID = "productid";
    private static final String __PROPS_BATCH_PRODUCT_VERSIONID = "productversionid";
    private static final String __PROPS_BATCH_PRODUCT_DESC = "productdesc";
    private static final String __PROPS_BATCH_PRODUCT_SUB_TYPE = "u_prodsubtypeid";
    private static final String __PROPS_BATCH_PRODUCT_VARIANTID = "prodvariantid";
    private static final String __PROPS_PRODUCT_VARIANTTYPE = "prodvarianttype";
    private static final String __PROPS_BATCH_PRODUCT_INSPECTIONLOT = "u_sapinspectionlot";
    private static final String __PROPS_PRODUCT_INSPECTIONLOT_STATUS = "sapinspectionlotstatus";
    private static final String __PROPS_BATCH_SAP_BATCH = "u_sapbatchnumber";
    private static final String __PROPS_BATCH_MAT_NUMBER = "u_sapmatnumber";
    private static final String __PROPS_BATCH_INSPECTION_LOT_ORIGIN = "u_inspectionorigin";
    private static final String __PROPS_BATCH_INSPECTION_TYPE = "u_inspectiontype";
    private static final String __PROPS_BATCH_VENDOR_NAME = "u_sapvendorname";
    private static final String __PROPS_BATCH_MATERIAL_DESC = "u_sapmaterialdesc";
    private static final String __PROPS_BATCH_SUPPLIER_ADDRESS_TYPE = "supplieraddresstype";
    private static final String __PROPS_BATCH_SUPPLIER_ADDRESS_ID = "supplieraddressid";
    private static final String __PROPS_BATCH_MANUFACTURER_ADDRESS_TYPE = "manufactureraddresstype";
    private static final String __PROPS_BATCH_MANUFACTURER_ADDRESS_ID = "manufactureraddressid";
    private static final String __PROPS_BATCH_SECURITY_USER = "securityuser";
    private static final String __PROPS_BATCH_SECURITY_DEPT = "securitydepartment";
    private static final String __PROPS_BATCH_MES_ORDER_SAP_BATCH1 = "u_mesordersapbatch1";
    private static final String __PROPS_BATCH_MES_ORDER_SAP_BATCH2 = "u_mesordersapbatch2";
    private static final String __PROPS_BATCH_TOOL_ID = "u_toolid";
    private static final String __PROPS_BATCH_LOCAL_MAT_CODE = "u_locmatcode";
    private static final String __PROPS_BATCH_SAP_VENDOR_STATUS = "u_sapvendorstatus";
    private static final String __PROPS_BATCH_DESC = "batchdesc";
    private static final String __PROPS_BATCH_PRODUCT_SUBTYPE_ID = "u_productsubtypeid";
    private static final String __PROPS_BATCH_SAP_SUBSYSTEM = "u_sapsubsystem";
    private static final String __PROPS_BATCH_TEMPLATE_FLAG = "templateflag";
    private static final String __PROPS_BATCH_ACTIVE_FLAG = "activeflag";
    private static final String __PROPS_BATCH_RESULT_UPLOAD_FLAG = "u_resultsuploaded";
    private static final String __PROPS_BATCH_SAP_VENDOR_NUM = "u_sapvendornum";
    private static final String __PROPS_BATCH_TEMPLATE_ID = "templateid";
    private static final String __PROPS_BATCH_TYPE = "batchtype";
    private static final String __PROPS_BATCH_CATCODEGROUP_PASS = "u_catcodegrouppass";
    private static final String __PROPS_BATCH_CATCODEGROUP_FAIL = "u_catcodegroupfail";
    private static final String __PROPS_BATCH_CATCODE_PASS = "u_catcodepass";
    private static final String __PROPS_BATCH_CATCODE_FAIL = "u_catcodefail";
    private static final String __PROPS_BATCH_IS_SAP_FLAG = "u_issapflag";
    private static final String __PROPS_BATCH_SAP_PLANT = "u_sapplant";
    private static final String __PROPS_BATCH_SIZE = "batchsize";
    private static final String __PROPS_BATCH_SIZE_UNITS = "batchsizeunits";
    private static final String __PROPS_BATCH_INSPECTION_START_DATE = "u_sapinspectionstartdt";
    private static final String __PROPS_BATCH_INSPECTION_END_DATE = "u_sapinspectionenddt";
    private static final String __PROPS_MARS_CODE_ATTR = "mars_code";
    private static final String __PROPS_BATCH_SAP_PARENT_BATCH = "u_originalbatchid";
    private static final String __PROPS_BATCH_SAP_PARENT_MATERIAL = "u_origsapmat";
    private static final String __PROPS_BATCH_CREATED_BY = "u_sapbatchcreateby";
    private static final String __PROPS_VENDOR_BATCH_NUMBER = "prodvariantlotreference";
    private static final String __PROPS_BATCH_SELECTEDSET = "u_sapselectedset";
    private static final String __PROPS_BATCH_SAP_LAB_CONF_NUM = "u_saplabconfnum";
    private static final String __PROPS_BATCH_SAP_PO_NUM_ATTR = "purchase_order";
    private static final String __PROPS_BATCH_RESULT_UPLOAD_RESTRICTION_FLAG = "u_resultuploadrestrictionflag";

    // Added for different  batch status
    private static final String __PROPS_STATUS_INITIAL = "Initial";
    private static final String __PROPS_STATUS_RECEIVED = "Received";
    private static final String __PROPS_STATUS_CANCELLED = "Cancelled";
    private static final String __PROPS_STATUS_REJECTED = "Rejected";
    private static final String __PROPS_STATUS_RELEASED = "Released";
    private static final String __PROPS_STATUS_PENDING_RELEASED = "Pending Release";
    // Added for SAP Table names
    private static final String __PROPS_ENTITY_QAIVC = "QAIVC";
    private static final String __PROPS_ENTITY_QAIMV = "QAIMV";
    private static final String __PROPS_ENTITY_QAICA = "QAICA";
    // Added for SAP Keys fields
    private static final String __PROPS_SAP_KEY_CODEGRUPPE = "CODEGRUPPE";
    private static final String __PROPS_SAP_KEY_CODE = "CODE";
    private static final String __PROPS_SAP_KEY_PRUEFLOS = "PRUEFLOS";
    private static final String __PROPS_SAP_KEY_PRUEFSTAT = "PRUEFSTAT";
    private static final String __PROPS_SAP_KEY_CHARG = "CHARG";
    private static final String __PROPS_SAP_KEY_MATNR = "MATNR";
    private static final String __PROPS_SAP_KEY_HERKUNFT = "HERKUNFT";
    private static final String __PROPS_SAP_KEY_ART = "ART";
    private static final String __PROPS_SAP_KEY_KTEXTMAT = "KTEXTMAT";
    private static final String __PROPS_SAP_KEY_SWUSERD1 = "SWUSERD1";
    private static final String __PROPS_SAP_KEY_SWUSERC1 = "SWUSERC1";
    private static final String __PROPS_SAP_KEY_SUBSYS = "SUBSYS";
    private static final String __PROPS_SAP_KEY_WERK = "WERK";
    private static final String __PROPS_SAP_KEY_SWTPLNR = "SWTPLNR";
    private static final String __PROPS_SAP_KEY_SWPHYNR = "SWPHYNR";
    private static final String __PROPS_SAP_KEY_LOSMENGE = "LOSMENGE";
    private static final String __PROPS_SAP_KEY_MENGENEINH = "MENGENEINH";
    private static final String __PROPS_SAP_KEY_PASTRTERM = "PASTRTERM";
    private static final String __PROPS_SAP_KEY_PAENDTERM = "PAENDTERM";
    private static final String __PROPS_SAP_KEY_SWUSERC2 = "SWUSERC2";
    private static final String __PROPS_SAP_KEY_LICHN = "LICHN";
    private static final String __PROPS_SAP_KEY_LIFNR = "LIFNR";
    private static final String __PROPS_SAP_KEY_NAME1LIF = "NAME1LIF";
    private static final String __PROPS_SAP_KEY_AUSWMENGE1 = "AUSWMENGE1";
    private static final String __PROPS_SAP_KEY_RUECKMELNR = "RUECKMELNR";
    private static final String __PROPS_SAP_EBELN = "EBELN";

    private static final String __PROPS_SAP_BATCH_TYPE = "u_sapbatchtype";
    // Added for Batch Master Reprocessing
    private static final String __REPROCESS_DATE = "reprocessdate";
    // Hashmap for mandatory fileds
    private static HashMap<String, String> hmMandatoryFields = null;

    // For additional mandatory checks
    // Just add an entry in this HashMap --> hmMandatoryFields

    static {
        hmMandatoryFields = new PropertyList();
        hmMandatoryFields.put(__PROPS_PRODUCT_INSPECTIONLOT_STATUS, "PRUEFSTAT(Inspection Lot Status)");
        hmMandatoryFields.put(__PROPS_BATCH_PRODUCT_INSPECTIONLOT, "PRUEFLOS(Inspection Lot)");
        hmMandatoryFields.put(__PROPS_BATCH_SAP_BATCH, "CHARG(SAP Batch #)");
        hmMandatoryFields.put(__PROPS_BATCH_SAP_PLANT, "WERK(SAP Plant)");
        hmMandatoryFields.put(__PROPS_BATCH_MAT_NUMBER, "MATNR(SAP Material #)");
        hmMandatoryFields.put(__PROPS_BATCH_INSPECTION_LOT_ORIGIN, "HERKUNFT(Inspection Lot Origin)");
        hmMandatoryFields.put(__PROPS_VENDOR_BATCH_NUMBER, "LICHN(SAP Vendor Batch #)");
        hmMandatoryFields.put(__PROPS_BATCH_INSPECTION_TYPE, "ART(SAP Inspection Type)");
    }

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.debug("=============== Start Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
        String strDataPayload = properties.getProperty(_PROPS_ITEMDATA, "");
        if ("".equalsIgnoreCase(strDataPayload)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.INVALID_SAP_DATA_PAYLOAD));
        }
        // Creating DataSet from XML payload
        DataSet dsSAPDataPayload = SAPUtil.getDataSetFromXMLString(strDataPayload);
        logger.debug("------------ Aseptic RM Lot Receipt SAP payload ------------" + "\n" + dsSAPDataPayload.toJSONString());
        logger.info("------------ Start processing LIMS Batch creation for Aseptic RM -------------");
        // ******** Start processing Aseptic RM Batch processing
        String[] limsBatchDetails = processAsepticRMBatch(dsSAPDataPayload);
        // Getting SAP Batch , SAP Material Number , SAP Plant and LIMS Batch Id
        String limsBatchId = limsBatchDetails[0];
        String sapBatchNum = limsBatchDetails[1];
        String sapMatNum = limsBatchDetails[2];
        String sapPlant = limsBatchDetails[3];
        // Setting transaction status
        if (!"".equalsIgnoreCase(limsBatchId)) {
            properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, limsBatchId);
            properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, IntfTransItem.TRANS_ITEM_STATUS_COMPLETE);
        }
        // ********* Reprocess PENDING Batch Master Transaction Items
        reprocessBatchMaster(sapBatchNum, sapMatNum, sapPlant);
        logger.info("------------ End processing LIMS Batch creation for Aseptic RM -------------");
        logger.debug("=============== End Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
    }

    private String[] processAsepticRMBatch(DataSet dsSAPDataPayload) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside processAsepticRMBatch (method)");
        String[] limsBatchDetails = new String[4];
        String limsBatchId = "";
        String limsBatchStatus = "";
        // Creating batch data from SAP Payload
        DataSet dsBatchDetails = getBatchDataFromSAPPayload(dsSAPDataPayload);
        // Checking mandatory fields. If any of the mandatory fields defined in PL is BLANK throw an ERROR
        checkMandatoryFields(dsBatchDetails, hmMandatoryFields);
        // Getting SAP Batch, Material# and Plant
        String sapBatch = dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_BATCH);
        String sapInspectionLotNum = dsBatchDetails.getValue(0, __PROPS_BATCH_PRODUCT_INSPECTIONLOT);
        String sapMaterialNum = dsBatchDetails.getValue(0, __PROPS_BATCH_MAT_NUMBER);
        String sapPlant = dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PLANT);
        String sapInspectionLotStatus = dsBatchDetails.getValue(0, __PROPS_PRODUCT_INSPECTIONLOT_STATUS);
        String vendorSAPBatch = dsBatchDetails.getValue(0, __PROPS_VENDOR_BATCH_NUMBER);
        String inspectionType = dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_TYPE);
        // ******** Checking if Cancel Lot request
        if (checkCancelledBatchRequest(sapInspectionLotStatus)) {
            // Cancelling samples and returning Batch Id
            limsBatchId = processCancelBatch(sapInspectionLotNum, sapBatch, sapMaterialNum, sapPlant);

        } else {
            // ******** Standard RM lot request
            // ******** Check for existing Batch. Batch status should not be Cancelled
            DataSet dsExistingLIMSBatch = sapLotBatchExists(sapBatch, sapMaterialNum, sapPlant);
            if (dsExistingLIMSBatch.getRowCount() > 0) {
                dsExistingLIMSBatch.sort(__PROPS_CREATE_DATE + " D," + __PROPS_LIMS_BATCH_ID + " D");
                limsBatchId = dsExistingLIMSBatch.getValue(0, __PROPS_LIMS_BATCH_ID, "");
                limsBatchStatus = dsExistingLIMSBatch.getValue(0, __PROPS_LIMS_BATCH_STATUS, "");
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.ASEPTIC_RM_ERR_00002, limsBatchId, limsBatchStatus, sapBatch, sapMaterialNum, sapPlant)));
            } else {
                // ******** Creating new RM Batch
                // Getting Vendor Number for determining PV
                String vendorNum = ___KEY_NOT_FOUND.equalsIgnoreCase(dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, "")) ? "" : dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, "");
                // ******** Getting PV details
                getRMProdVariant(dsBatchDetails, sapBatch, sapMaterialNum, sapPlant, vendorNum);
                // ******** Getting Batch Type. If Batch Type is BLANK then set the value to Raw Material
                String batchType = "".equalsIgnoreCase(dsBatchDetails.getValue(0, __PROPS_PRODUCT_VARIANTTYPE, "")) ? "Raw Material" : dsBatchDetails.getValue(0, __PROPS_PRODUCT_VARIANTTYPE, "");
                // Setting batch type / product variant type in batch details DataSet
                if (!dsBatchDetails.isValidColumn(__PROPS_BATCH_TYPE)) {
                    dsBatchDetails.addColumn(__PROPS_BATCH_TYPE, DataSet.STRING);
                }
                dsBatchDetails.setValue(0, __PROPS_BATCH_TYPE, batchType);
                // Determing Batch Template and Setting it in Batch Details DataSet
                String batchTemplateId = getBatchTemplate(batchType);
                // Setting batch template id in batch details DataSet
                if (!dsBatchDetails.isValidColumn(__PROPS_BATCH_TEMPLATE_ID)) {
                    dsBatchDetails.addColumn(__PROPS_BATCH_TEMPLATE_ID, DataSet.STRING);
                }
                dsBatchDetails.setValue(0, __PROPS_BATCH_TEMPLATE_ID, batchTemplateId);
                // ******** Creating new Aseptic RM Batch
                limsBatchId = createRMLIMSBatch(dsBatchDetails);
                // Getting all Batch attributes

                DataSet dsBatchAttributes = getBatchAttributes(limsBatchId);
                if (dsBatchAttributes.getRowCount() > 0) {
                    PropertyList plAttrFilter = new PropertyList();
                    // Checking if Mars Code is present or not
                    String marsCode = dsBatchDetails.getValue(0, __PROPS_MARS_CODE_ATTR, "");
                    // Checking if MARS CODE is Blank
                    if (!"".equalsIgnoreCase(marsCode)) {
                        // Check if Batch is having MARS Code Attribute ?
                        plAttrFilter.setProperty("attributeid", __PROPS_MARS_CODE_ATTR);
                        // If attribute found
                        if (dsBatchAttributes.findRow(plAttrFilter) != -1) {
                            // Setting MARS CODE
                            setAttributeValue(limsBatchId, __PROPS_MARS_CODE_ATTR, marsCode);
                        }
                        plAttrFilter.clear();
                    }
                    // Checking if PO NUmber is present or not ?
                    String poNumber = dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PO_NUM_ATTR, "");
                    // Checking if PO# is Blank ?
                    if (!"".equalsIgnoreCase(poNumber)) {
                        // Check if Batch is having PO Number Attribute?
                        plAttrFilter.setProperty("attributeid", __PROPS_BATCH_SAP_PO_NUM_ATTR);
                        // If attribute found
                        if (dsBatchAttributes.findRow(plAttrFilter) != -1) {
                            // Setting PO Number
                            setAttributeValue(limsBatchId, __PROPS_BATCH_SAP_PO_NUM_ATTR, poNumber);
                        }
                        plAttrFilter.clear();
                    }
                }

                // ******** check if auto receive flag is configured to Yes in Site/Plant and product variant is not null
                if (!"".equalsIgnoreCase(dsBatchDetails.getValue(0, "s_" + __PROPS_BATCH_PRODUCT_VARIANTID, ""))
                        && "Y".equalsIgnoreCase(getAutoreceiveFlag(sapPlant))) {
                    // ***** Receive Batch
                    receiveBatch(limsBatchId);
                    // Call the Result Set up action
                    if (SAPPlants.PROPS_ASEPTIC_PLANT_SG20.equalsIgnoreCase(sapPlant)) {
                        String sapBatchType = dsBatchDetails.getValue(0, __PROPS_BATCH_TYPE, "");
                        String sapLabConfNum = dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_LAB_CONF_NUM, "");
                        String sapSelectedSet = dsBatchDetails.getValue(0, __PROPS_BATCH_SELECTEDSET, "");
                        //********* calling the action to set SAP selected set and sap lab conf number to SDIDataItem
                        callAsepticRM_Set_SAPResults(limsBatchId, batchType, sapPlant, sapSelectedSet, sapLabConfNum);
                    }

                }
            }
        }
        limsBatchDetails[0] = limsBatchId;
        limsBatchDetails[1] = sapBatch;
        limsBatchDetails[2] = sapMaterialNum;
        limsBatchDetails[3] = sapPlant;
        return limsBatchDetails;
    }

    /*********************
     * This method is used to set SAP Lab Conf Number and SAP Selected Set to SDIDataItem
     * @param limsBatchId
     * @param batchType
     * @param sapPlant
     * @param sapSelectedSet
     * @param sapLabConfNum
     * @throws SapphireException
     *********************/
    private void callAsepticRM_Set_SAPResults(String limsBatchId, String batchType, String sapPlant, String sapSelectedSet, String sapLabConfNum) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside callAsepticRM_Set_SAPResults (method)");
        PropertyList plSAPResultsParam = new PropertyList();
        plSAPResultsParam.setProperty(__PROPS_LIMS_BATCH_ID, limsBatchId);
        plSAPResultsParam.setProperty(__PROPS_BATCH_SAP_PLANT, sapPlant);
        plSAPResultsParam.setProperty(__PROPS_BATCH_TYPE, batchType);
        plSAPResultsParam.setProperty(__PROPS_BATCH_SELECTEDSET, sapSelectedSet);
        plSAPResultsParam.setProperty(__PROPS_BATCH_SAP_LAB_CONF_NUM, sapLabConfNum);
        getActionProcessor().processAction("Aseptic_RM_SetSAPResults", "1", plSAPResultsParam);

    }


    /*******
     * This method is used to get Batch template from
     * @param batchType
     * @return
     * @throws SapphireException
     */
    private String getBatchTemplate(String batchType) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getBatchTemplate (method)");
        // private variable
        StringBuilder errMsg = new StringBuilder().append("");
        String templateId = "";

        PropertyList plBatchTemplate = getConfigurationProcessor().getPolicy("SAPInterfacePolicy", "Custom");
        PropertyListCollection plBatchTemplateCol = plBatchTemplate.getCollection("BatchTemplate");
        for (int row = 0; row < plBatchTemplateCol.size(); row++) {
            String policyBatchType = plBatchTemplateCol.getPropertyList(row).getProperty("BatchType");
            if ((policyBatchType).equalsIgnoreCase(batchType)) {
                templateId = plBatchTemplateCol.getPropertyList(row).getProperty("BatchTemplate");
                return templateId;
            }
        }
        if (("").equalsIgnoreCase(templateId)) {
            errMsg = errMsg.append(" Error::: ").append(ErrorMessageUtil.INVALID_BATCH_TYPE);
            logger.error(errMsg.toString());
            throw new SapphireException(errMsg.toString());
        }
        return templateId;
    }

    /***************
     * This method is used to edit and set the MARS CODE attribute.
     *
     * @param batchId  LIMS Batch ID.
     * @param attributeId Batch Attribute Id.
     * @param attributeValue Batch attribute value.
     * @throws SapphireException Throws OOB Sapphire exception.
     ***************/
    private void setAttributeValue(String batchId, String attributeId, String attributeValue) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside setMarsCode (method)");
        PropertyList plEditAttr = new PropertyList();
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_KEYID1, batchId);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTEID, attributeId);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTEINSTANCE, "1");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTESDCID, __PROPS_BATCH_SDCID);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_VALUE, attributeValue);
        try {
            getActionProcessor().processAction(EditSDIAttribute.ID, EditSDIAttribute.VERSIONID, plEditAttr);
        } catch (SapphireException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Unable to execute EditSDIAttribute. Please contact your system adminstration."));
        }
    }

    /****************
     * This method is used to check whether mars_code attribute is attached to Batch or not.
     *
     * @param batchId LIMS Batch Id.
     * @return Returns "Y" or "N" based on availability of mars_code attribute.
     * @throws SapphireException Throws OOB Sapphire exception.
     ****************/
    private DataSet getBatchAttributes(String batchId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside isMarsCodeAttrPresentInBatch (method)");
        String rsetId = "";
        String sqlText = "";
        DataSet dsSDIAttribute;
        try {
            rsetId = getDAMProcessor().createRSet("Batch", batchId, "(null)", "(null)");
            sqlText = "select sdiattr.attributeid from sdiattribute sdiattr, rsetitems rsi " +
                    "where sdiattr.sdcid = 'Batch' " +
                    "and sdiattr.sdcid = rsi.sdcid " +
                    "and sdiattr.keyid1= rsi.keyid1 " +
                    "and sdiattr.keyid2 = rsi.keyid2 " +
                    "and sdiattr.keyid3 = rsi.keyid3 " +
                    "and rsi.keyid1 = ? " +
                    "and rsi.rsetid = ?";
            dsSDIAttribute = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{batchId, rsetId});
        } catch (SapphireException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Unable to execute query."));
        } finally {
            if (!"".equals(rsetId)) {
                getDAMProcessor().clearRSet(rsetId);
            }
        }
        return dsSDIAttribute;
    }

    /********************************************
     * This method is used to Receive LIMS Batch.
     *
     * @param limsBatchId Newly created LIMS Batch Id.
     * @throws SapphireException Throws OOB Sapphire exception.
     ********************************************/
    private void receiveBatch(String limsBatchId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside receiveBatch (method)");

        PropertyList plEditSDI = new PropertyList();
        plEditSDI.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
        plEditSDI.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
        plEditSDI.setProperty("operation", "Receive");
        plEditSDI.setProperty(__PROPS_LIMS_BATCH_STATUS, getBatchStatus(limsBatchId));
        plEditSDI.setProperty("receivedby", VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

        try {
            this.getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plEditSDI);
        } catch (SapphireException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE
                    , this.getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_FAILED_RECEIVE_BATCH, limsBatchId)));
        }
    }

    /*************
     * This method is used get LIMS Batch status.
     * @param batchId LIMS Batch Id.
     * @return Returns the Batch status.
     * @throws SapphireException Throws OOB Sapphire exception.
     *************/
    private String getBatchStatus(String batchId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getBatchStatus (method)");
        StringBuilder errMsg = new StringBuilder().append(" ");
        String strBatchStatus = "";
        String sqlText = "SELECT " + __PROPS_LIMS_BATCH_STATUS + " FROM s_batch WHERE " + __PROPS_LIMS_BATCH_ID + " = ?";
        DataSet dsBatchStatus = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{batchId});
        if (dsBatchStatus == null) {
            errMsg.append(ErrorMessageUtil.NULL_SQL_VALUE).append(" For LIMS batch Id: ").append(batchId);
            throw new SapphireException(errMsg.toString());
        }
        if (dsBatchStatus.getRowCount() == 0) {
            errMsg.append(ErrorMessageUtil.NO_ROW_FOUND).append(" For LIMS batch Id: ").append(batchId);
            throw new SapphireException(errMsg.toString());
        }
        strBatchStatus = dsBatchStatus.getValue(0, __PROPS_LIMS_BATCH_STATUS);
        return strBatchStatus;
    }

    /***************
     * This method is used to get auto receive flag is turned ON or OFF
     * @param sapPlant
     * @return
     * @throws SapphireException
     ***************/
    private String getAutoreceiveFlag(String sapPlant) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getAutoreceiveFlag (method)");
        String retVal = "";
        String sqltext = " SELECT nvl(autoreceiverawmatflag,'N') autoreceiverawmatflag FROM u_sites WHERE sapplant = ? ";
        DataSet dsAutoReceive = getQueryProcessor().getPreparedSqlDataSet(sqltext, new Object[]{sapPlant});
        if (null == dsAutoReceive) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        } else if (dsAutoReceive.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_NO_PLANT_FOUND, sapPlant)));
        } else {
            return dsAutoReceive.getValue(0, "autoreceiverawmatflag");
        }
    }

    /***************
     * This method is responsible for creating LIMS RM batch
     * @param dsBatchDetails
     * @throws SapphireException
     ***************/
    private String createRMLIMSBatch(DataSet dsBatchDetails) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside createRMLIMSBatch (method)");
        // method variables
        String strBatchId = "";
        String inspectionStartDate = SAPUtil.checkNullDate(dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_START_DATE, ""));
        inspectionStartDate = SAPUtil.getDateWithProperFormat(inspectionStartDate, connectionInfo);
        String inspectionEndDate = SAPUtil.checkNullDate(dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_END_DATE, ""));
        inspectionEndDate = SAPUtil.getDateWithProperFormat(inspectionEndDate, connectionInfo);

        PropertyList plBatchDetails = new PropertyList();
        plBatchDetails.setProperty(AddSDI.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
        plBatchDetails.setProperty(__PROPS_BATCH_PRODUCTID, dsBatchDetails.getValue(0, "s_" + __PROPS_BATCH_PRODUCTID, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_PRODUCT_VERSIONID, dsBatchDetails.getValue(0, "s_" + __PROPS_BATCH_PRODUCT_VERSIONID, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_PRODUCT_VARIANTID, dsBatchDetails.getValue(0, "s_" + __PROPS_BATCH_PRODUCT_VARIANTID, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_PRODUCT_INSPECTIONLOT, dsBatchDetails.getValue(0, __PROPS_BATCH_PRODUCT_INSPECTIONLOT, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_BATCH, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_BATCH, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_SAP_BATCH_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_MAT_NUMBER, dsBatchDetails.getValue(0, __PROPS_BATCH_MAT_NUMBER, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_INSPECTION_LOT_ORIGIN, dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_LOT_ORIGIN, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_INSPECTION_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_INSPECTION_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_VENDOR_NUM, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_NUM, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_VENDOR_NAME, dsBatchDetails.getValue(0, __PROPS_BATCH_VENDOR_NAME, ""));
        plBatchDetails.setProperty(__PROPS_VENDOR_BATCH_NUMBER, dsBatchDetails.getValue(0, __PROPS_VENDOR_BATCH_NUMBER, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_MATERIAL_DESC, dsBatchDetails.getValue(0, __PROPS_BATCH_MATERIAL_DESC, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SUPPLIER_ADDRESS_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_SUPPLIER_ADDRESS_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SUPPLIER_ADDRESS_ID, dsBatchDetails.getValue(0, __PROPS_BATCH_SUPPLIER_ADDRESS_ID, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_MANUFACTURER_ADDRESS_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_MANUFACTURER_ADDRESS_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_MANUFACTURER_ADDRESS_ID, dsBatchDetails.getValue(0, __PROPS_BATCH_MANUFACTURER_ADDRESS_ID, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SECURITY_USER, dsBatchDetails.getValue(0, __PROPS_BATCH_SECURITY_USER, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SECURITY_DEPT, dsBatchDetails.getValue(0, __PROPS_BATCH_SECURITY_DEPT, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_PARENT_BATCH, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PARENT_BATCH, ""));// Need to discuss with Client what will be the actual value.
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_PARENT_MATERIAL, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PARENT_MATERIAL, ""));// Need to discuss with Client what will be the actual value.
        plBatchDetails.setProperty(__PROPS_BATCH_MES_ORDER_SAP_BATCH1, dsBatchDetails.getValue(0, __PROPS_BATCH_MES_ORDER_SAP_BATCH1, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_MES_ORDER_SAP_BATCH2, dsBatchDetails.getValue(0, __PROPS_BATCH_MES_ORDER_SAP_BATCH2, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_TOOL_ID, dsBatchDetails.getValue(0, __PROPS_BATCH_TOOL_ID));
        plBatchDetails.setProperty(__PROPS_BATCH_LOCAL_MAT_CODE, dsBatchDetails.getValue(0, __PROPS_BATCH_LOCAL_MAT_CODE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_VENDOR_STATUS, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_VENDOR_STATUS, ""));

        plBatchDetails.setProperty(__PROPS_BATCH_DESC, dsBatchDetails.getValue(0, __PROPS_BATCH_PRODUCT_DESC, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_PRODUCT_SUBTYPE_ID, dsBatchDetails.getValue(0, __PROPS_BATCH_PRODUCT_SUB_TYPE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_SUBSYSTEM, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_SUBSYSTEM, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_TEMPLATE_FLAG, "N");
        plBatchDetails.setProperty(__PROPS_BATCH_ACTIVE_FLAG, "Y");
        plBatchDetails.setProperty(__PROPS_BATCH_RESULT_UPLOAD_FLAG, "N");
        plBatchDetails.setProperty(__PROPS_BATCH_TEMPLATE_ID, dsBatchDetails.getValue(0, __PROPS_BATCH_TEMPLATE_ID));
        //plBatchDetails.setProperty(__PROPS_BATCH_TYPE, dsBatchDetails.getValue(0, __PROPS_BATCH_TEMPLATE_ID));
        plBatchDetails.setProperty(__PROPS_BATCH_CATCODEGROUP_PASS, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODEGROUP_PASS, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_CATCODE_PASS, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODE_PASS, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_CATCODEGROUP_FAIL, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODEGROUP_FAIL, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_CATCODE_FAIL, dsBatchDetails.getValue(0, __PROPS_BATCH_CATCODE_FAIL, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_IS_SAP_FLAG, "Y");
        plBatchDetails.setProperty(__PROPS_BATCH_RESULT_UPLOAD_RESTRICTION_FLAG, "N");
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_PLANT, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_PLANT, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SELECTEDSET, dsBatchDetails.getValue(0, __PROPS_BATCH_SELECTEDSET, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SAP_LAB_CONF_NUM, dsBatchDetails.getValue(0, __PROPS_BATCH_SAP_LAB_CONF_NUM, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SIZE, dsBatchDetails.getValue(0, __PROPS_BATCH_SIZE, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_SIZE_UNITS, dsBatchDetails.getValue(0, __PROPS_BATCH_SIZE_UNITS, ""));
        plBatchDetails.setProperty(__PROPS_BATCH_INSPECTION_START_DATE, inspectionStartDate);
        plBatchDetails.setProperty(__PROPS_BATCH_INSPECTION_END_DATE, inspectionEndDate);
        plBatchDetails.setProperty(__PROPS_BATCH_CREATED_BY, "(system)".equalsIgnoreCase(connectionInfo.getSysuserId()) ? VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID : connectionInfo.getSysuserId());
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plBatchDetails);

        strBatchId = plBatchDetails.getProperty(__PROPS_NEW_KEYID1);
        return strBatchId;

    }

    /*******
     * This method is used to get RM product variant details
     * @param dsBatchDetails
     * @param sapBatch
     * @param sapMaterial
     * @param sapPlant
     * @param vendorNum
     * @return
     * @throws SapphireException
     ********/
    private void getRMProdVariant(DataSet dsBatchDetails, String sapBatch, String sapMaterial, String sapPlant, String vendorNum) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getRMProdVariant (method)");
        // Getting active product, PV variant details
        DataSet dsActivePV = getActiveProductVariant(sapBatch, sapMaterial, sapPlant, vendorNum);
        // Final PV details
        DataSet dsFinalPV = new DataSet(connectionInfo);
        // Filter criteria
        PropertyList plFilter = new PropertyList();
        // ******* If more than one PV found
        if (dsActivePV.getRowCount() > 1) {
            // ****** try to find the PV by matching  vendor #
            plFilter.setProperty(__PROPS_BATCH_SAP_VENDOR_NUM, vendorNum);
            dsFinalPV = dsActivePV.getFilteredDataSet(plFilter);
            // ***** If no PV matching vendor # found
            if (dsFinalPV.getRowCount() == 0) {
                // ****** Getting the default Vendor PV
                for (int dsRow = 0; dsRow < dsActivePV.getRowCount(); dsRow++) {
                    if ("".equalsIgnoreCase(dsActivePV.getValue(dsRow, __PROPS_BATCH_SAP_VENDOR_NUM, ""))) {
                        dsFinalPV.copyRow(dsActivePV, dsRow, 1);
                    }
                }
                // ************ If ASM Plant then throw ERROR
                if (dsFinalPV.getRowCount() == 0 && SAPPlants.PROPS_ASEPTIC_PLANT_SG20.equalsIgnoreCase(sapPlant)) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.ASEPTIC_RM_ERR_00004, sapBatch, sapMaterial, sapPlant)));
                } else if (dsFinalPV.getRowCount() > 1) {
                    //Multiple Default PV detected with blank Vendor Number
                    if (SAPPlants.PROPS_ASEPTIC_PLANT_SG20.equalsIgnoreCase(sapPlant)) {
                        throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.ASEPTIC_RM_ERR_00005, sapBatch, sapMaterial, sapPlant)));
                    } else {
                        //Blank out Product, Version and PV ID
                        dsFinalPV.setValue(-1, "s_" + __PROPS_BATCH_PRODUCT_VARIANTID, "");
                        dsFinalPV.setValue(-1, "s_" + __PROPS_BATCH_PRODUCTID, "");
                        dsFinalPV.setValue(-1, "s_" + __PROPS_BATCH_PRODUCT_VERSIONID, "");
                        dsFinalPV.setValue(-1, __PROPS_BATCH_SUPPLIER_ADDRESS_ID, "");
                        dsFinalPV.setValue(-1, __PROPS_BATCH_SUPPLIER_ADDRESS_TYPE, "");
                        dsFinalPV.setValue(-1, __PROPS_BATCH_MANUFACTURER_ADDRESS_ID, "");
                        dsFinalPV.setValue(-1, __PROPS_BATCH_MANUFACTURER_ADDRESS_TYPE, "");
                    }
                }
            } else if (dsFinalPV.getRowCount() > 1) {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.ASEPTIC_RM_ERR_00006, vendorNum, sapBatch, sapMaterial, sapPlant)));
            }
        } else {
            // ****** If Single PV found.
            dsFinalPV = dsActivePV;
        }
        // ******* If any PV details found then adding the details from PV to batch dataset
        if (dsFinalPV.getRowCount() > 0) {
            // Inserting PV data to Batch details
            for (int col = 0; col < dsFinalPV.getColumnCount(); col++) {
                // If Column Name is vendor number the skip
                // This checking is added here because we need to take payload vendor number value no LIMS PV--> Vendor Num
                if (!__PROPS_BATCH_SAP_VENDOR_NUM.equalsIgnoreCase(dsFinalPV.getColumnId(col))) {
                    dsBatchDetails.addColumn(dsFinalPV.getColumnId(col), dsFinalPV.getColumnType(dsFinalPV.getColumnId(col)));
                    dsBatchDetails.setValue(0, dsFinalPV.getColumnId(col), dsFinalPV.getValue(0, dsFinalPV.getColumnId(col), ""));
                }
            }
        }
    }

    /*****************
     * This method is sued to get Product Varinat having product version as CURRENT.
     *
     * @param sapMatNumber SAP Material Number.
     * @param sapPlant     SAP plant code.
     * @return DataSet containg active Product varint details.
     * @throws SapphireException Throws OOB Sapphire exception.
     ******************/
    private DataSet getActiveProductVariant(String sapBatch, String sapMatNumber, String sapPlant, String vendorNum) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getActiveProductVariant (method)");
        String sqlText = "SELECT " +
                "     p.s_productid, " +
                "    p.s_productversionid, " +
                "    p.productdesc, " +
                "    p.u_prodsubtypeid, " +
                "    pv.prodvarianttype, " +
                "    pv.u_sapvendornum, " +
                "    pv.s_prodvariantid, " +
                "    pv.supplieraddresstype, " +
                "    pv.supplieraddressid, " +
                "    pv.manufactureraddresstype, " +
                "    pv.u_sapmanufacturernum, " +
                "    pv.manufactureraddressid, " +
                "    pv.securityuser, " +
                "    pv.securitydepartment, " +
                "    pv.samplingplanid, " +
                "    pv.samplingplanversionid " +
                "FROM " +
                "    s_product       p, " +
                "    s_prodvariant   pv " +
                "WHERE " +
                "    p.s_productid = pv.productid " +
                "    AND pv.u_sapmatnumber = ? " +
                "    AND pv.u_sapplant = ? " +
                "    AND pv.productversionid = p.s_productversionid " +
                "    AND p.versionstatus = 'C' " +
                "    AND nvl(pv.activeflag, 'Y') = 'Y'";
        DataSet dsPVDetails = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{sapMatNumber, sapPlant});
        if (null == dsPVDetails) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.FAILED_EXECUTING_PROD_VAR + String.format(ErrorMessageUtil.RM_FOR_FIELDS, sapBatch, sapMatNumber, sapPlant)));
        } else if (dsPVDetails.getRowCount() == 0) {
            // ********* For all site if there are no PV found then ERROR
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.ASEPTIC_RM_ERR_00003, sapBatch, sapMatNumber, sapPlant, vendorNum)));
        } else {
            return dsPVDetails;
        }
    }

    /*****************
     * This method is used to check if any existing LIMS Batch is present or not.
     * @param strSAPBatchId
     * @param strMatNum
     * @param strSAPPlant
     * @return
     * @throws SapphireException
     *****************/
    private DataSet sapLotBatchExists(String strSAPBatchId, String strMatNum, String strSAPPlant) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside sapLotBatchExists (method)");
        String sqlText = "SELECT " +
                "    s_batch." + __PROPS_LIMS_BATCH_ID + "," +
                "    s_batch." + __PROPS_LIMS_BATCH_STATUS + "," +
                "    s_batch." + __PROPS_CREATE_DATE +
                " FROM " +
                "    s_batch " +
                "    JOIN s_prodvariant ON s_batch.prodvariantid = s_prodvariant.s_prodvariantid " +
                " WHERE " +
                "    s_batch.u_mesordersapbatch1 = ? " +
                "    AND s_batch.u_sapmatnumber = ? " +
                "    AND ( s_batch.u_sapplant = ? " +
                "          OR s_prodvariant.securitydepartment IN ( " +
                "        SELECT " +
                "            department.departmentid " +
                "        FROM " +
                "            department " +
                "            INNER JOIN u_sites ON department.u_siteid = u_sites.u_sitesid " +
                "        WHERE " +
                "            u_sites.sapplant = ? " +
                "    ) ) " +
                "    AND s_batch.batchstatus <> 'Released' " +
                "    AND s_batch.batchstatus <> 'Cancelled' " +
                "    AND s_batch.batchstatus <> 'Rejected'";
        DataSet dslimsBatch = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{strSAPBatchId, strMatNum, strSAPPlant, strSAPPlant});

        if (dslimsBatch.size() == 0) {
            sqlText = "SELECT     s_batch.s_batchid,    s_batch.batchstatus,    s_batch.createdt FROM     s_batch " +
                    " WHERE     s_batch.u_mesordersapbatch1 = ? AND s_batch.u_sapmatnumber = ? AND s_batch.u_sapplant = ? " +
                    " AND s_batch.batchstatus <> 'Released'     AND s_batch.batchstatus <> 'Cancelled'     AND s_batch.batchstatus <> 'Rejected' ";

            dslimsBatch = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{strSAPBatchId, strMatNum, strSAPPlant});

        }

        return dslimsBatch;
    }

    /**
     * This method is used to handle Cancel Batch request.
     *
     * @param inspectionLot SAP Inspection Lot Number.
     * @param sapBatch      SAP Batch Number.
     * @param sapPlant      SAP Plant Code.
     * @param sapMaterial   SAP Material Number.
     * @return Returns LIMS Batch Id.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String processCancelBatch(String inspectionLot, String sapBatch, String sapMaterial, String sapPlant) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside processCancelBatch (method)");
        String limsBatchId = "";
        DataSet dsExistinglimsBatch = sapLotBatchExists(sapBatch, sapMaterial, sapPlant);
        if (dsExistinglimsBatch.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.ASEPTIC_RM_ERR_00007, inspectionLot, sapBatch, sapMaterial, sapPlant)));
        } else {
            limsBatchId = dsExistinglimsBatch.getValue(0, __PROPS_LIMS_BATCH_ID, "");
            String batchStatus = dsExistinglimsBatch.getValue(0, __PROPS_LIMS_BATCH_STATUS);
            if (__PROPS_STATUS_INITIAL.equalsIgnoreCase(batchStatus) || __PROPS_STATUS_RECEIVED.equalsIgnoreCase(batchStatus)) {
                PropertyList plBatchUpdate = new PropertyList();
                plBatchUpdate.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
                plBatchUpdate.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
                plBatchUpdate.setProperty(__PROPS_LIMS_BATCH_STATUS, __PROPS_STATUS_CANCELLED);
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plBatchUpdate);
                } catch (SapphireException ex) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.ASEPTIC_RM_ERR_00008, limsBatchId, ex.getMessage())));
                }
            } else {
                PropertyList plBatchUpdate = new PropertyList();
                plBatchUpdate.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
                plBatchUpdate.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
                plBatchUpdate.setProperty("u_markedforcancel", "Y");
                try {
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plBatchUpdate);
                } catch (SapphireException ex) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.ASEPTIC_RM_ERR_00009, limsBatchId, ex.getMessage())));
                }

            }
        }
        return limsBatchId;
    }

    /************************
     * This method is used to determine cancel request or not.
     * @param inspectionLotStatus
     * @return
     * @throws SapphireException
     *************************/
    private boolean checkCancelledBatchRequest(String inspectionLotStatus) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside checkCancelledBatchRequest (method)");
        boolean status = false;
        if ("D".equalsIgnoreCase(inspectionLotStatus) || "C".equalsIgnoreCase(inspectionLotStatus)) {
            status = true;
        }
        return status;
    }


    /**********
     * This method is used to reprocess Batch master awaiting lots.
     * @param sapBatch
     * @param sapMat
     * @param sapPlant
     * @throws SapphireException
     **********/
    private void reprocessBatchMaster(String sapBatch, String sapMat, String sapPlant) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside reprocessBatchMaster (method)");
        // Getting all Pending Lot Batch Master transactions sorted on Transaction Itema nd Created Date in descending order.
        DataSet dsPendingLotBM = isBatchMasterPresent(sapBatch, sapMat, sapPlant);
        // Check if any pending lot BM
        if (dsPendingLotBM.size() > 0) {
            // reprovcessing transaction items
            reprocessTransactionItem(dsPendingLotBM);
        }
    }

    /*****
     * This method is used to reprocess PENDING transaction item Ids.
     * @param dsTransactionItemData DataSet containing transaction item Ids
     * @throws SapphireException OOB Sapphire exception
     */
    private void reprocessTransactionItem(DataSet dsTransactionItemData) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside reprocessTransactionItem (method)");
        PropertyList plReprocessItemPl = new PropertyList();
        plReprocessItemPl.clear();
        plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, EditSDI.ID);
        plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, EditSDI.VERSIONID);
        plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

        //######## - START: TodoList entry processing duedt is set as currenttime+10 sec. This is needed to provide enough time ofr Batch to be commited before Batch Master process starts.
        //plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_DUEDATE, getDueDate(10));
        //######## - END: TodoList entry processing duedt is set as currenttime+10 sec. This is needed to provide enough time ofr Batch to be commited before Batch Master process starts.

        plReprocessItemPl.setProperty(EditSDI.PROPERTY_SDCID, _PROPS_TRANSITEM_SDCID);
        plReprocessItemPl.setProperty(EditSDI.PROPERTY_KEYID1, dsTransactionItemData.getColumnValues(_PROPS_TRANSITEMID, ";"));
        plReprocessItemPl.setProperty(__REPROCESS_DATE, StringUtil.repeat("n", dsTransactionItemData.getRowCount(), ";"));
        try {
            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, plReprocessItemPl);
        } catch (Exception ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
        }
    }


    /**
     * This method is used to check whether there is any BATCH MASTER payload awaiting LOT RECEIPT service.
     *
     * @param sapBatch  SAP Batch Number.
     * @param sapPlant  SAP plant Information.
     * @param sapMatNum SAP material Number.
     * @return DataSet containing transaction details of BATCH MASTER service.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private DataSet isBatchMasterPresent(String sapBatch, String sapMatNum, String sapPlant) throws SapphireException {

        logger.debug("Processing " + ID + ". (Action) : Inside isBatchMasterPresent (method)");
        // For Pending items transaction items having either pending lot flag = Y or Status = PENDING check is given
        // Status = COMPLETE filter given for batch for which earlier a batch is cancelled.
        String sqlText = "select u_intftransitemid,status,createdt  from u_intfTransItem " +
                " where key1value = ?  and key2value= ? and plant = ? " +
                " and transname = 'BATCH_MASTER' and (pendinglotflag = 'Y'  OR  status = 'COMPLETE' OR status = 'PENDING' ) ";

        DataSet dsItemData = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{sapBatch, sapMatNum, sapPlant}, true);

        if (dsItemData == null) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        }

        if (dsItemData.size() > 0) {
            dsItemData.sort("createdt, u_intftransitemid");
        }

        return dsItemData;
    }

    /*******************************
     * This method is used to dynamically check mandatory values
     * @param dsBatchDetails
     * @param plMandatoryFields
     * @throws SapphireException
     ********************************/
    private void checkMandatoryFields(DataSet dsBatchDetails, HashMap<String, String> plMandatoryFields) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside checkMandatoryFields (method)");
        String key = "";
        String value = "";
        // Looping thorugh the Batch details DataSet
        for (int colNum = 0; colNum < dsBatchDetails.getColumnCount(); colNum++) {
            // If Mandatory key found in Batch Details DS
            if (hmMandatoryFields.containsKey(dsBatchDetails.getColumnId(colNum))) {
                // Check if key is SAP Vendor Batch Key present
                key = dsBatchDetails.getColumnId(colNum);
                value = dsBatchDetails.getValue(0, key, "");
                if (__PROPS_VENDOR_BATCH_NUMBER.equalsIgnoreCase(key) && ___KEY_NOT_FOUND.equalsIgnoreCase(value)) {
                    // Check if key is SAP Vendor Batch Key is not present
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(String.format(ErrorMessageUtil.ASEPTIC_RM_ERR_00000, plMandatoryFields.get(key))));
                }
                // Check if mandatory value is blank
                if ("".equalsIgnoreCase(dsBatchDetails.getValue(0, dsBatchDetails.getColumnId(colNum), ""))) {
                    throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(String.format(ErrorMessageUtil.ASEPTIC_RM_ERR_00001, plMandatoryFields.get(key))));
                }
            }
        }
    }

    /************************************
     * This method is for getting and creating batch details from SAP data payload.
     * @param dsItemPayLoad
     * @return
     * @throws SapphireException
     ************************************/
    private DataSet getBatchDataFromSAPPayload(DataSet dsItemPayLoad) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside processRMBatch (method)");
        DataSet dsBatchDetailsFromSAP = new DataSet();
        // Adding SAP columns
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_CATCODEGROUP_PASS, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_CATCODE_PASS, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_CATCODEGROUP_FAIL, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_CATCODE_FAIL, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_PRODUCT_INSPECTIONLOT, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_PRODUCT_INSPECTIONLOT_STATUS, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_BATCH, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_MAT_NUMBER, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_INSPECTION_LOT_ORIGIN, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_INSPECTION_TYPE, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_VENDOR_NUM, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_VENDOR_NAME, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_MATERIAL_DESC, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_MES_ORDER_SAP_BATCH1, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_MES_ORDER_SAP_BATCH2, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_TOOL_ID, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_LOCAL_MAT_CODE, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_VENDOR_STATUS, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_SUBSYSTEM, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_PLANT, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_PARENT_BATCH, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_PARENT_MATERIAL, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SIZE, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SIZE_UNITS, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_INSPECTION_START_DATE, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_INSPECTION_END_DATE, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_MARS_CODE_ATTR, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_VENDOR_BATCH_NUMBER, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SELECTEDSET, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_LAB_CONF_NUM, DataSet.STRING);
        dsBatchDetailsFromSAP.addColumn(__PROPS_BATCH_SAP_PO_NUM_ATTR, DataSet.STRING);

        // Adding a row
        int rowId = dsBatchDetailsFromSAP.addRow();
        // Adding values to DataSet
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_CATCODEGROUP_PASS, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAICA, __PROPS_SAP_KEY_CODEGRUPPE)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_CATCODE_PASS, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAICA, __PROPS_SAP_KEY_CODE)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_CATCODEGROUP_FAIL, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAICA, __PROPS_SAP_KEY_CODEGRUPPE)), ";")[1]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_CATCODE_FAIL, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAICA, __PROPS_SAP_KEY_CODE)), ";")[1]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_PRODUCT_INSPECTIONLOT, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_PRUEFLOS)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_PRODUCT_INSPECTIONLOT_STATUS, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_PRUEFSTAT)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_BATCH, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_CHARG)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_MAT_NUMBER, SAPUtil.removeLeadingZeroes(StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_MATNR)), ";")[0]));
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_INSPECTION_LOT_ORIGIN, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_HERKUNFT)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_INSPECTION_TYPE, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_ART)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_VENDOR_NUM, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_LIFNR)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_VENDOR_NAME, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_NAME1LIF)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_MATERIAL_DESC, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_KTEXTMAT)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_MES_ORDER_SAP_BATCH1, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_CHARG)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_MES_ORDER_SAP_BATCH2, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_CHARG)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_TOOL_ID, "(null)");// Force fully setting this to (Null)
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_LOCAL_MAT_CODE, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWUSERD1)), ";")[0]);
        //dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_VENDOR_STATUS, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWUSERC1)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_VENDOR_STATUS, SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWUSERC1) == null ? "" : SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWUSERC1));
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_SUBSYSTEM, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SUBSYS)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_PLANT, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_WERK)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_PARENT_BATCH, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWTPLNR)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_PARENT_MATERIAL, SAPUtil.removeLeadingZeroes(StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWPHYNR)), ";")[0]));
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SIZE, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_LOSMENGE)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SIZE_UNITS, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_MENGENEINH)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_INSPECTION_START_DATE, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_PASTRTERM)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_INSPECTION_END_DATE, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_PAENDTERM)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_MARS_CODE_ATTR, null == SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWUSERC2) ? "" : SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_SWUSERC2));
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_VENDOR_BATCH_NUMBER, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_KEY_LICHN)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SELECTEDSET, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIMV, __PROPS_SAP_KEY_AUSWMENGE1)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_LAB_CONF_NUM, StringUtil.split(SAPUtil.replaceInvalidValuewithBlank(SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIMV, __PROPS_SAP_KEY_RUECKMELNR)), ";")[0]);
        dsBatchDetailsFromSAP.setValue(rowId, __PROPS_BATCH_SAP_PO_NUM_ATTR, null == SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_EBELN) ? "" : SAPUtil.getColumnValue(dsItemPayLoad, __PROPS_ENTITY_QAIVC, __PROPS_SAP_EBELN));

        return dsBatchDetailsFromSAP;

    }

    /**
     * This method is used to get delay in seconds
     *
     * @param buffer Seconds to delay
     * @return Calender seconds in seconds
     * @throws SapphireException OOB Sapphire Exception
     */
    private String getDueDate(int buffer) {
        DataSet dsDate = new DataSet(connectionInfo);
        dsDate.addColumn("mydate", DataSet.DATE);
        Calendar cl = Calendar.getInstance();
        cl.add(Calendar.SECOND, buffer);
        int row = dsDate.addRow();
        dsDate.setDate(row, "mydate", cl);

        return dsDate.getValue(row, "mydate", "");
    }
}
