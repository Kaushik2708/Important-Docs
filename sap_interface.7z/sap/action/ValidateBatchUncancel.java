package labvantage.custom.alcon.sap.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

/**
 * $Author: MITRASO1 $
 * $Date: 2021-04-19 05:17:29 -0500 (Mon, 19 Apr 2021) $
 * $Revision: 262 $
 */
/*******************************************************************
 * $Revision: 262 $
 * Description: Uncancel the batch.
 *
 *******************************************************************/
public class ValidateBatchUncancel extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 262 $";
    public static final String ID = "ValidateBatchUncancel";
    public static final String VERSIONID = "1";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.debug("=============== Start Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
        String sapBatchNum = properties.getProperty("sapbatchnum", "");
        String sapMatNum = properties.getProperty("sapmatnum", "");
        String sapPlant = properties.getProperty("sapplant", "");
        String limsbatchid = properties.getProperty("limsbatchid", "");
        // checking open LIMS batch exist or not ?
        int openBatchCount = hasOpenBatch(sapBatchNum, sapMatNum, sapPlant, limsbatchid);
        if (openBatchCount > 0) {
            throw new SapphireException("Batch Uncancel Validation", ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate("Aborting Uncancel operation. There is already an Open LIMS Batch for the following combination - \n" +
                    "SAP Batch# : " + sapBatchNum + " SAP Material# :" + sapMatNum + " and SAP Plant: " + sapPlant)
            );
        }
        logger.debug("=============== End Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
    }

    /**
     * Check for an existing open Batch (batchstatus = Initial, Received, Active, PendingRelease) for the given combination of SAP Batch, Material Number, Plant
     *
     * @param sapBatchNum
     * @param sapMatNum
     * @param sapPlant
     * @return
     * @throws SapphireException
     */
    private int hasOpenBatch(String sapBatchNum, String sapMatNum, String sapPlant, String limsbatchid) throws SapphireException {
        logger.debug("=============== Inside Service: " + ID + " , Inside: hasOpenBatch ================");
        int openBatchCount = 0;
        String sqlText = "SELECT s_batchid,batchstatus FROM s_batch WHERE u_sapbatchnumber = ? and u_sapmatnumber = ? and u_sapplant = ? AND batchstatus not in ('Released','Cancelled','Rejected') AND s_batchid <> ?";
        DataSet dsOpenBatch = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{sapBatchNum, sapMatNum, sapPlant, limsbatchid});
        if (dsOpenBatch == null) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Unable to execute query for retriving Open LIMS Batch details."));
        } else {
            openBatchCount = dsOpenBatch.getRowCount();
        }
        return openBatchCount;
    }
}
