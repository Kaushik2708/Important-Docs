package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.ddt.IntfTransItem;
import labvantage.custom.alcon.sap.util.ErrorMessageUtil;
import labvantage.custom.alcon.sap.util.SAPPlants;
import labvantage.custom.alcon.sap.util.SAPUtil;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.math.BigDecimal;
import java.util.HashMap;


/**
 * $Author: GHOSHKA1 $
 * $Date: 2022-04-26 11:56:11 -0500 (Tue, 26 Apr 2022) $
 * $Revision: 770 $
 */

/*****************************************************************************************************
 * $Revision: 770 $
 * Description:
 * This class is used to update a LIMS batch based on data sent through BatchMaster service from SAP.
 *
 * @author Soumen Mitra
 * @version 1
 ******************************************************************************************************/

public class BatchMaster extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 770 $";

    public static final String ACTION_ID = "BatchMaster";
    public static final String ACTION_VERSION_ID = "1";

    public static final String BATCH_STATUS_PENDING_RELEASE = "Pending Release";
    public static final String BATCH_STATUS_RELEASED = "Released";
    public static final String BATCH_STATUS_REJECTED = "Rejected";
    public static final String BATCH_STATUS_CANCELLED = "Cancelled";

    public static final String PROP_VALUE_CHAR = "VALUE_CHAR";
    public static final String PROP_VALUE_FROM = "VALUEFROM";
    public static final String BATCH_MASTER_DATE_FORMAT = "yyyyMMdd";
    public static final String BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR = "E1BP3060_VALUATION_CHAR";
    public static final String BATCH_MASTER_ENTITY_E1BP3060_VALUATION_NUM = "E1BP3060_VALUATION_NUM";
    public static final String BATCH_MASTER_ENTITY_E1BP3060_ALLOCATION = "E1BP3060_ALLOCATION";
    public static final String BATCH_MASTER_ENTITY_E1BPBATCHATT = "E1BPBATCHATT";
    public static final String BATCH_MASTER_INDICATOR_COLID_CHARACT = "CHARACT";
    public static final String BATCH_MASTER_INDICATOR_COLID_VALUEFROM = "VALUEFROM";
    public static final String BATCH_MASTER_ATTRIBUTE_ID = "attributeid";


    /**
     * Description: processAction is an OOB LabVantage method. This is the main method where execution starts.
     *
     * @param properties
     * @throws SapphireException
     */

    @Override
    public void processAction(PropertyList properties) throws SapphireException {


        Logger.logInfo("================== Processing BatchMaster action. ==========================================");
        //All input will come as a String with header='itemdata'
        String strItemData = properties.getProperty("itemdata", "");

        if (strItemData == null || strItemData.equals("")) {
            //Do not proceed from here
            logger.info("Input data for Batch Master is null or blank. No Data supplied to process Batch Master.");
            String err = "No payload data provided to Batch Master.";
            throw new SapphireException(err);
        }
        DataSet dsInputData = new DataSet(strItemData);
        String sapBatchId = SAPUtil.getColumnValue(dsInputData, "Batch", "BATCH");
        String sapPlantId = SAPUtil.getColumnValue(dsInputData, "Batch", "PLANT");
        String sapMatNum = SAPUtil.getColumnValue(dsInputData, "Batch", "MATERIAL");

        DataSet dsBatch = getLIMSBatchId(sapBatchId, sapMatNum, sapPlantId);

        if (dsBatch.size() == 0) {
            //Business Notes: Batch Master called before LOT creation ( Inspection Lot). Need to update the TransItem status as "Pending".
            // When Lot Receipt will be invoked the status will be updated accordingly.
            properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, IntfTransItem.TRANS_ITEM_STATUS_PENDING);
            return;
        }

        updateBatch(dsInputData, dsBatch, properties);

        //This Line will be always at the end of the line.
        String limsBatchStatus = dsBatch.getValue(0, "batchstatus", "");
        String limsBatchId = dsBatch.getValue(0, "s_batchid", "");


        properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, limsBatchId);

        //if payload status = PENDING then do not make it to COMPLETE.
        if (!(properties.getProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, "").equalsIgnoreCase(IntfTransItem.TRANS_ITEM_STATUS_PENDING))) {
            properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, IntfTransItem.TRANS_ITEM_STATUS_COMPLETE);
        }

    }

    /**
     * Description: This method is used to parse the UD code.
     *
     * @param udCode
     * @return
     */

    private String parseUDCode(String udCode) {

        // method variables
        StringBuffer parsedUD = new StringBuffer();
        char pos;

        // get position after UD
        int start = udCode.indexOf("UD");

        if (start == 0) start = start + 2;
        else start = 0;

        for (int i = start; i < udCode.length(); i++) {
            pos = udCode.charAt(i);
            if (pos == ' ') continue;
            else {
                parsedUD.append(String.valueOf(pos));
            }
        }

        return parsedUD.toString();
    }

    /**
     * Description: This method is used to fetch the UD code Value.
     *
     * @param udCode
     * @return
     * @throws SapphireException
     */

    private String getUDCodeValue(String udCode) throws SapphireException {
        logger.info("Starting getUDCodeValue method");
        if (udCode == null || udCode.equalsIgnoreCase("")) {
            return "";
        }

        // method variables
        String udValue = "";
        ;
        String sqlText = "SELECT refdisplayvalue " +
                "FROM RefValue " +
                "WHERE reftypeid = 'SAPUsageDecision' " +
                "AND refvalueid = '" + udCode + "'";

        DataSet dsResult = getQueryProcessor().getSqlDataSet(sqlText);
        if (dsResult == null) {
            String error = "Wrong query: " + sqlText;
            logger.error(error);
            throw new SapphireException(error);
        }

        if (dsResult.getRowCount() == 0) {
            String error = "Ref type 'SAPUsageDecision' missing in the system. " + sqlText;
            logger.error(error);
            throw new SapphireException(error);
        }
        //udValue = qResults.getString("refdisplayvalue");
        udValue = dsResult.getValue(0, "refdisplayvalue", "");

        return udValue;
    } // private String getUDCodeValue

    /**
     * Description: This method is used to update the batch using Edit SDI.
     *
     * @param dsInput
     * @param dsBatch
     * @throws SapphireException
     */


    public void updateBatch(DataSet dsInput, DataSet dsBatch, PropertyList properties) throws SapphireException {

        String limsBatchId = dsBatch.getValue(0, "s_batchid", "");


        //u_origsapbatch
        String parentsapbatchid = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR, BATCH_MASTER_INDICATOR_COLID_CHARACT, "Z8CG_ORIGINAL_BATCH", PROP_VALUE_CHAR);

        //u_origsapmat6
        String originalmaterial = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR, BATCH_MASTER_INDICATOR_COLID_CHARACT, "Z8CG_ORIGINAL_MATERIAL", PROP_VALUE_CHAR);

        //u_sapbatchtype
        String batchtype = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR, BATCH_MASTER_INDICATOR_COLID_CHARACT, "Z8CL_BATCH_TYPE", PROP_VALUE_CHAR);
        String sapplant = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR, BATCH_MASTER_INDICATOR_COLID_CHARACT, "Z8CG_INITIAL_PLANT", PROP_VALUE_CHAR);
        String udData = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR, BATCH_MASTER_INDICATOR_COLID_CHARACT, "LOBM_UDCODE", PROP_VALUE_CHAR);
        // ******* Added for Phase 2 RM, Aseptic
        String sterilizationDate = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_NUM, BATCH_MASTER_INDICATOR_COLID_CHARACT, "Z8CL_STERILIZATION_DATE", PROP_VALUE_FROM);
        // ******* Converting exponential to Integer & validating date string
        sterilizationDate = "".equalsIgnoreCase(sterilizationDate) ? "" : validateDateString(String.valueOf(getIntegerFromExponent(sterilizationDate)));

        sterilizationDate = SAPUtil.getDateWithProperFormat(sterilizationDate, connectionInfo);
        String ucode = parseUDCode(udData);

        //u_sapuduser
        String udUserData = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR, BATCH_MASTER_INDICATOR_COLID_CHARACT, "Z8CG_INITIAL_RELEASE_SITE", PROP_VALUE_CHAR);
        // Tool Id
        String attrToolId = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR, BATCH_MASTER_INDICATOR_COLID_CHARACT, "Z8CG_COMMENT", PROP_VALUE_CHAR);
        // Released Quantity
        String attrReleasedQty = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR, BATCH_MASTER_INDICATOR_COLID_CHARACT, "Z8CL_PRINTING_INFO1", PROP_VALUE_CHAR);

        String udDateString = checkNullDate(SAPUtil.getColumnValue(dsInput, BATCH_MASTER_ENTITY_E1BP3060_ALLOCATION, "KEYDATE"));
        udDateString = SAPUtil.getDateWithProperFormat(udDateString, connectionInfo);

        //Added on March 2022 : Set uddatetime as UD Date, if null then set KEYDATE as UD Date.
        String udDateTime = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR, BATCH_MASTER_INDICATOR_COLID_CHARACT, "Z8CL_TWS_PR", PROP_VALUE_CHAR);
        String formattedudDateTime = SAPUtil.getDateStringWithProperFormat(udDateTime, "yyyyMMdd_HHmmss", "UTC", connectionInfo);

        String mfgdate = checkNullDate(SAPUtil.getColumnValue(dsInput, BATCH_MASTER_ENTITY_E1BPBATCHATT, "PRODDATE"));
        mfgdate = SAPUtil.getDateWithProperFormat(mfgdate, connectionInfo);

        String batchDate = checkNullDate(SAPUtil.getColumnValue(dsInput, BATCH_MASTER_ENTITY_E1BPBATCHATT, "PRODDATE"));
        batchDate = SAPUtil.getDateWithProperFormat(batchDate, connectionInfo);

        String expiryDate = checkNullDate(SAPUtil.getColumnValue(dsInput, BATCH_MASTER_ENTITY_E1BPBATCHATT, "EXPIRYDATE"));
        expiryDate = SAPUtil.getDateWithProperFormat(expiryDate, connectionInfo);

        String vendorBatch = SAPUtil.getColumnValue(dsInput, BATCH_MASTER_ENTITY_E1BPBATCHATT, "VENDRBATCH"); //if the value is blank in payload then update blank in Database

        PropertyList pl = new PropertyList();
        pl.setProperty(EditSDI.PROPERTY_SDCID, "Batch");
        pl.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);

        handlingUDCode(pl, sapplant, ucode, udUserData, udDateTime.equalsIgnoreCase("")? udDateString : formattedudDateTime, dsBatch, properties, dsInput);

        pl.setProperty("manufacturedt", mfgdate);
        pl.setProperty("batchdt", batchDate);
        pl.setProperty("u_sapbatchtype", batchtype);
        pl.setProperty("expirydt", expiryDate);
        pl.setProperty("u_expirydate", expiryDate);
        pl.setProperty("prodvariantlotreference", vendorBatch);
        pl.setProperty("u_origsapmat", originalmaterial);
        pl.setProperty("u_origsapbatch", parentsapbatchid);
        pl.setProperty("u_originalbatchid", parentsapbatchid); // This column is exposed on Batch maintenance page

        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, pl);

        // ****** Aseptic RM, Phase 2 Release
        DataSet dsAttributeDetails = getBatchAttributeIds(limsBatchId);
        // Checking if attribute Sterilize_DT presents or not ?

        if (dsAttributeDetails.getRowCount() > 0 && !"".equalsIgnoreCase(sterilizationDate)) {
            PropertyList plAttrFilter = new PropertyList();
            plAttrFilter.clear();
            plAttrFilter.setProperty(BATCH_MASTER_ATTRIBUTE_ID, "Sterilize_DT");
            if (dsAttributeDetails.findRow(plAttrFilter) != -1) {
                setAttributeValue(limsBatchId, "Sterilize_DT", sterilizationDate);
            }
        }

        // Checking if attribute MFG_DT ( Manufacturing Date ) presents or not ?
        if (dsAttributeDetails.getRowCount() > 0 && !"".equalsIgnoreCase(mfgdate)) {
            PropertyList plAttrFilter = new PropertyList();
            plAttrFilter.clear();
            plAttrFilter.setProperty(BATCH_MASTER_ATTRIBUTE_ID, "MFG_DT");
            if (dsAttributeDetails.findRow(plAttrFilter) != -1) {
                setAttributeValue(limsBatchId, "MFG_DT", mfgdate);
            }
        }

        // Checking if attribute MFG_Exp_DT ( Expiration Date ) presents or not ?
        if (dsAttributeDetails.getRowCount() > 0 && !"".equalsIgnoreCase(expiryDate)) {
            PropertyList plAttrFilter = new PropertyList();
            plAttrFilter.clear();
            plAttrFilter.setProperty(BATCH_MASTER_ATTRIBUTE_ID, "MFG_Exp_DT");
            if (dsAttributeDetails.findRow(plAttrFilter) != -1) {
                setAttributeValue(limsBatchId, "MFG_Exp_DT", expiryDate);
            }
        }

        // Checking if attribute Tool_ID ( Tool Id ) presents or not ?
        if (dsAttributeDetails.getRowCount() > 0 && !"".equalsIgnoreCase(attrToolId)) {
            PropertyList plAttrFilter = new PropertyList();
            plAttrFilter.clear();
            plAttrFilter.setProperty(BATCH_MASTER_ATTRIBUTE_ID, "Tool_ID");
            if (dsAttributeDetails.findRow(plAttrFilter) != -1) {
                setAttributeValue(limsBatchId, "Tool_ID", attrToolId);
            }
        }

        // Checking if attribute release_quantity ( Released Quantity ) presents or not ?
        if (dsAttributeDetails.getRowCount() > 0 && !"".equalsIgnoreCase(attrReleasedQty)) {
            PropertyList plAttrFilter = new PropertyList();
            plAttrFilter.clear();
            plAttrFilter.setProperty(BATCH_MASTER_ATTRIBUTE_ID, "release_quantity");
            if (dsAttributeDetails.findRow(plAttrFilter) != -1) {
                setAttributeValue(limsBatchId, "release_quantity", attrReleasedQty);
            }
        }

    }

    /************************
     * This method is used to check valid date format
     * @param strDate
     * @return
     * @throws SapphireException
     ************************/
    private String validateDateString(String strDate) throws SapphireException {
        logger.debug("Processing " + ACTION_ID + ". (Action) : Inside validateDateString (method)");
        if (strDate.length() != 8 || strDate.equalsIgnoreCase("0") || strDate.equalsIgnoreCase("11111111") || strDate.equalsIgnoreCase("00000000")) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Sterilization Date is invalid. Input date is -" + strDate));
        }
        return strDate;
    }

    /***********************
     * This method is used to get Intger from exponent value
     * @param strExponent
     * @return
     * @throws SapphireException
     ***********************/
    private int getIntegerFromExponent(String strExponent) throws SapphireException {
        logger.debug("Processing " + ACTION_ID + ". (Action) : Inside getIntegerFromExponent (method)");
        int isterilizationDt = 0;
        BigDecimal sterilizationDt = new BigDecimal("0.0");
        if (strExponent == null) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Exponential date value either NULL."));
        }
        try {
            sterilizationDt = new BigDecimal(strExponent);
            isterilizationDt = sterilizationDt.intValueExact();
        } catch (ArithmeticException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Arithmetic exception - improper date value for conversion from BigDecimal value to Integer. BigDecimal date value is - " + sterilizationDt));
        } catch (Exception ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Exception is - " + ex.getMessage()));
        }
        return isterilizationDt;
    }

    /************
     * This method is used to clear RSet ids to avoid RSet locking.
     * @param limsBatchId
     * @throws SapphireException
     ************/
    private void clearBatchRSET(String limsBatchId) throws SapphireException {
        logger.debug("Processing " + ACTION_ID + ". (Action) : Inside clearBatchRSET (method)");
        // Getting all RSetIds for the given Samples
        String sqlText = " SELECT rsetid  " +
                "FROM rsetitems " +
                "WHERE sdcid = 'Batch' " +
                "AND keyid1 IN('" + StringUtil.replaceAll(limsBatchId, ";", "','") + "')" +
                "AND keyid2 = '(null)' " +
                "AND keyid3 = '(null)' ";

        DataSet dsRSetIds = getQueryProcessor().getSqlDataSet(sqlText);
        if (null == dsRSetIds) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_SQL_VALUE));
        }
        // If there are any open RsetIds . Clease those before proceeding
        if (dsRSetIds.getRowCount() > 0) {
            getDAMProcessor().clearRSet(dsRSetIds.getColumnValues("rsetid", ";"));
        }
    }

    /***************
     * This method is used to edit and set the MARS CODE attribute.
     *
     * @param batchId  LIMS Batch ID.
     * @param attributeId Batch Attribute Id.
     * @param attributeValue Batch attribute value.
     * @throws SapphireException Throws OOB Sapphire exception.
     ***************/
    private void setAttributeValue(String batchId, String attributeId, String attributeValue) throws SapphireException {
        logger.info("Processing " + ACTION_ID + ". (Action) : Inside setMarsCode (method)");
        //clearBatchRSET(batchId);
        PropertyList plEditAttr = new PropertyList();
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_SDCID, "Batch");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_KEYID1, batchId);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTEID, attributeId);
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTEINSTANCE, "1");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_ATTRIBUTESDCID, "Batch");
        plEditAttr.setProperty(EditSDIAttribute.PROPERTY_VALUE, attributeValue);
        try {
            getActionProcessor().processAction(EditSDIAttribute.ID, EditSDIAttribute.VERSIONID, plEditAttr);
        } catch (SapphireException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Unable to execute EditSDIAttribute. Please contact your system adminstration."));
        }
    }

    /*****************
     * This method is used to get attribute details of Batch.
     * @param limsBatchId
     * @return
     * @throws SapphireException
     ****************/
    private DataSet getBatchAttributeIds(String limsBatchId) throws SapphireException {
        String sqlText = "SELECT attributeid FROM sdiattribute WHERE sdcid = 'Batch' AND keyid1 = ? AND keyid2 = '(null)' AND keyid3 = '(null)'";
        DataSet dsAttributeIds = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{limsBatchId});
        if (null == dsAttributeIds) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Null DataSet Blank."));
        }
        return dsAttributeIds;
        /*String rsetId = "";
        String sqlText = "";
        DataSet dsSDIAttribute;
        try {
            rsetId = getDAMProcessor().createRSet("Batch", limsBatchId, "(null)", "(null)");
            sqlText = "select sdiattr.attributeid from sdiattribute sdiattr, rsetitems rsi " +
                    "where sdiattr.sdcid = 'Batch' " +
                    "and sdiattr.sdcid = rsi.sdcid " +
                    "and sdiattr.keyid1= rsi.keyid1 " +
                    "and sdiattr.keyid2 = rsi.keyid2 " +
                    "and sdiattr.keyid3 = rsi.keyid3 " +
                    "and rsi.keyid1 = ? " +
                    "and rsi.rsetid = ?";
            dsSDIAttribute = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{limsBatchId, rsetId});
        } catch (SapphireException ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Unable to execute query."));
        } finally {
            if (!"".equals(rsetId)) {
                getDAMProcessor().clearRSet(rsetId);
            }
        }
        return dsSDIAttribute;*/
    }


    /**
     * Description: This method is used to handle the UD Code.
     *
     * @param pl
     * @param ucode
     * @param udUser
     * @param udDate
     * @param dsBatch
     * @throws SapphireException
     */

    private void handlingUDCode(PropertyList pl, String sapplant, String ucode, String udUser, String udDate, DataSet dsBatch, PropertyList properties, DataSet dsInput) throws SapphireException {
        if (ucode == null || "".equalsIgnoreCase(ucode) || dsBatch == null || dsBatch.getRowCount() == 0) {
            return;
        }

        String limsBatchId = dsBatch.getValue(0, "s_batchid", "");
        String limsBatchStatus = dsBatch.getValue(0, "batchstatus", "");
        String limsBatchSyncCOACompleteFlag = dsBatch.getValue(0, "u_synccoacompleteflag", "N");
        //String udCodeDesc = getUDCodeDescription(ucode);

        //update - udcode , uddescription, uduser, uddate
        //--- Log entry in table - u_batchudlog ---//

        updateBatchUDLogTable(limsBatchId, ucode, udUser, udDate);

        pl.setProperty("u_sapudcode", ucode);
        pl.setProperty("u_sapuddate", udDate);
        pl.setProperty("u_sapuduser", udUser);

        //1. If current batch SAPPLANT NOT equals to U630, U636, U612, SG20 – No Sync COA, No Auto Batch Release
        //2. If current batch has no ingredient - call Batch Auto Release, No Sync COA
        //3. If current batch has multiple SAP created (s_batchgenealogy.u_issapflag) parent (Ingredients) having batchstatus NOT EQUAL Cancelled -->  No Auto Release, No Sync COA

        //Added on March 2022 : Set batch released date = uddatetime, if blank then set batch release date = current date.
        String udDateTime = SAPUtil.getValuationByName(dsInput, BATCH_MASTER_ENTITY_E1BP3060_VALUATION_CHAR, BATCH_MASTER_INDICATOR_COLID_CHARACT, "Z8CL_TWS_PR", PROP_VALUE_CHAR);;
        String formattedudDateTime = SAPUtil.getDateStringWithProperFormat(udDateTime, "yyyyMMdd_HHmmss", "UTC", connectionInfo);

        if (isSAPRegulatedPlant(sapplant)) {

            if (BATCH_STATUS_PENDING_RELEASE.equalsIgnoreCase(limsBatchStatus)) {

                //If current batch has no ingredient - call Batch Auto Release, and don't call Sync COA
                DataSet dsIngredient = getIngredients(limsBatchId);// Ingredients are only SAP created Parents

                //If no ingredient  or Multiple ingredients exists - No need to call Sync COA
                String parentBatchId = dsIngredient.getColumnValues("parentbatchid", ";");
                int parentCount = dsIngredient.getRowCount();

                //1. If current batch has multiple SAP created parent (Ingredients) having batchstatus NOT EQUAL Cancelled -->  No Auto Release, No Sync COA
                if (parentCount > 1) {
                    //Do nothing;
                    return;
                }
                //New function added to check if all the immediate valid parents (not cancelled) (from s_batchgenealogy table...
                //...(may be more than one parent) are Released/Rejected.
                boolean isPending = false;
                if (dsIngredient.size() == 1) {
                    isPending = checkAllParentBatchReleased(dsIngredient);
                }
                //if parent batch release is pending, then don't release the current batch.
                if (isPending) {
                    //Set the batch master payload status = 'PENDING'.
                    properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, IntfTransItem.TRANS_ITEM_STATUS_PENDING);
                    return;
                }

                // Go for SyncCOA, Batch Approval if condition is satisfied
                if (performSyncCOABatchApproval(ucode, limsBatchId, parentBatchId, parentCount, limsBatchSyncCOACompleteFlag, pl)) {
                    //Added on March 2022 : Set batch released date = uddatetime, if blank then set batch release date = current date.
                    PropertyList plUpdateReleaseDate = new PropertyList();
                    plUpdateReleaseDate.setProperty(EditSDI.PROPERTY_SDCID, "Batch");
                    plUpdateReleaseDate.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
                    if (udDateTime.equalsIgnoreCase("")){
                        plUpdateReleaseDate.setProperty("releaseddt", "n");
                    } else if (!udDateTime.equalsIgnoreCase("")){
                        plUpdateReleaseDate.setProperty("releaseddt", formattedudDateTime);
                    }
                    getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plUpdateReleaseDate);

                    //After batch release call this function to reprocess payload for the immediate child batches.
                    checkAnyChildBatchPending(limsBatchId);
                }

            }
        }
    }

    /**
     * Description : New function added to find all active child batches (not Cancelled, Released, Rejected)
     * of current Batch, if immediate child batch exist (from s_batchgenealogy table) ,
     * then search IntfTransItem table for those child Batches payload (search with SAP batch #) marked Pending Processing,
     * reprocess all of them.
     *
     * @param releasedBatchId
     * @throws SapphireException
     */
    private void checkAnyChildBatchPending(String releasedBatchId) throws SapphireException {

        //Find all active child batches (not Cancelled, Released, Rejected) of current Batch.
        String sql = " select s_batch.s_batchid, s_batch.u_sapbatchnumber, s_batch.u_sapmatnumber, u_sapplant, s_batch.batchstatus" +
                " from s_batch" +
                " inner join s_batchgenealogy" +
                " on s_batchgenealogy.s_batchid = s_batch.s_batchid" +
                " where s_batchgenealogy.parentbatchid = ?" +
                " and s_batch.batchstatus not in ('Cancelled','Released','Rejected')";

        DataSet dsChildBatches = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{releasedBatchId});
        if (dsChildBatches == null) {
            throw new SapphireException("SQL returns NULL result. Please contact System Administrator.");
        }

        //Check if any parent batch with not Released/Rejected/Cancelled state exists for the child. If yes just return.
        //todo : is this check required? as reprocessed payload will have this check again.
        /*String childBatchID = dsChildBatches.getColumnValues("s_batchid",";");
        String newChildBatchID = childBatchID.replaceAll(";","','");

        String sqlQuery = "select b.s_batchid parentbatchid,b.batchstatus from s_batch b where  b.batchstatus not in ('Cancelled','Released','Rejected')" +
                " and s_batchid in (select g.parentbatchid from s_batchgenealogy g where g.s_batchid in ('" + newChildBatchID + "') and g.u_issapflag='Y'" + ")";

        DataSet dsParentBatch = getQueryProcessor().getPreparedSqlDataSet(sqlQuery, new Object[]{});
        if (dsParentBatch == null) {
            throw new SapphireException("SQL returns NULL result. Please contact System Administrator.");
        }
        if(dsParentBatch.size()>0){
            return;
        }*/

        //if immediate child batch exist, search IntfTransItem table for those child Batches payload(search with SAP batch #)marked Pending Processing, reprocess all of them.
        String sapBatchNumber = dsChildBatches.getColumnValues("u_sapbatchnumber", ";");
        String sapMatNumber = dsChildBatches.getColumnValues("u_sapmatnumber", ";");
        String sapPlant = dsChildBatches.getColumnValues("u_sapplant", ";");

        String newSapBatchNumber = sapBatchNumber.replaceAll(";", "','");
        String newSapmatNumber = sapMatNumber.replaceAll(";", "','");
        String newSapPlant = sapPlant.replaceAll(";", "','");

        //Finding Batch Master Presence from u_intftransitem table where sapbatch , sapMat, plant from limsBatchId and status=PENDING.
        String sqlText = " select u_intftransitem.u_intftransitemid, u_intftransitem.createdt" +
                " from u_intftransitem" +
                " where transname = 'BATCH_MASTER'" +
                " and key1value in ('" + newSapBatchNumber + "') and key2value in ('" + newSapmatNumber + "') and plant in ('" + newSapPlant + "')" +
                " and status = 'PENDING'";
        DataSet dsPendingBatchMaster = getQueryProcessor().getSqlDataSet(sqlText);
        if (dsPendingBatchMaster == null) {
            throw new SapphireException("SQL returns NULL result. Please contact System Administrator.");
        }

        if (dsPendingBatchMaster.getRowCount() > 0) {
            //Sorted in ascending order to reprocess in an order of older to new payload.
            //Else new batch updates will be overridden by the old ones.
            dsPendingBatchMaster.sort("u_intftransitemid , createdt");
            reprocessTransactionItem(dsPendingBatchMaster);
        }

    }

    /**
     * Description : New function added  to check if all the immediate valid parents (not cancelled)
     * (from s_batchgenealogy table  (may be more than one parent) are Released/Rejected.
     *
     * @param dsParentBatches
     * @throws SapphireException
     */
    private boolean checkAllParentBatchReleased(DataSet dsParentBatches) throws SapphireException {
        boolean isPendingSet = false;
        //Check If not all of them are released/rejected then push the payload for current batch to Pending - break.
        String parentBatchStatus = "";
        for (int row = 0; row < dsParentBatches.size(); row++) {
            parentBatchStatus = dsParentBatches.getValue(row, "batchstatus");

            if (!(BATCH_STATUS_RELEASED.equalsIgnoreCase(parentBatchStatus)) && !(BATCH_STATUS_REJECTED.equalsIgnoreCase(parentBatchStatus))) {
                isPendingSet = true;
                break;
            }
        }
        return isPendingSet;
    }

    /*****
     * This method is used to reprocess PENDING transaction item Ids.
     * @param dsTransactionItemData DataSet containing transaction item Ids
     * @throws SapphireException OOB Sapphire exception
     */
    private void reprocessTransactionItem(DataSet dsTransactionItemData) throws SapphireException {
        PropertyList plReprocessItemPl = new PropertyList();
        plReprocessItemPl.clear();
        plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_ACTIONID, EditSDI.ID);
        plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_ACTIONVERSIONID, EditSDI.VERSIONID);
        plReprocessItemPl.setProperty(AddToDoListEntry.PROPERTY_PROCESSASSYSUSERID, "SAP_INTERFACE");
        plReprocessItemPl.setProperty(EditSDI.PROPERTY_SDCID, "IntfTransItem");
        plReprocessItemPl.setProperty(EditSDI.PROPERTY_KEYID1, dsTransactionItemData.getColumnValues("u_intftransitemid", ";"));
        plReprocessItemPl.setProperty("reprocessedby", "SAP_INTERFACE");
        plReprocessItemPl.setProperty("reprocessdate", StringUtil.repeat("n", dsTransactionItemData.getRowCount(), ";"));
        try {
            getActionProcessor().processAction(AddToDoListEntry.ID, AddToDoListEntry.VERSIONID, plReprocessItemPl);
        } catch (Exception ex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
        }
    }

    /**
     * New flag against Batch - u_synccoacompleteflag (Yes/No) will be set to Y when the action is complete.
     *
     * @param pl
     * @throws SapphireException
     */
    private void markSyncCOAComplete(PropertyList pl) throws SapphireException {
        //PropertyList pl is the PropertyList of EditSDi of Batch SDC - Setting the pl with proper  value.
        pl.setProperty("u_synccoacompleteflag", "Y");
    }


    /**
     * SAP Permitted plant list
     *
     * @param sapplant
     * @return
     * @throws SapphireException
     */
    private boolean isSAPRegulatedPlant(String sapplant) throws SapphireException {
        if (SAPPlants.PROPS_ASEPTIC_PLANT_U630.equalsIgnoreCase(sapplant) ||
                SAPPlants.PROPS_ASEPTIC_PLANT_U636.equalsIgnoreCase(sapplant) ||
                SAPPlants.PROPS_ASEPTIC_PLANT_SG20.equalsIgnoreCase(sapplant)
                ) {

            return true;

        }

        return false;
    }

    /**
     * Adds the sync samples for the ingridents/ parent batchs
     *
     * @param childBatchId
     * @param parentBatchId
     * @throws SapphireException
     */
    private void callSyncCOA(String childBatchId, String parentBatchId, PropertyList plBatchUpdate) throws SapphireException {

        //Check if Parent BatchID is in Rejected Status - then throw exception in the dashboard
        checkParentBatchStatus(parentBatchId);

        //check if ParentLotSample already populated then do nothing. ( Very Important validation)
        boolean syncSampleExists = isSyncSampleAlreadyExists(childBatchId, parentBatchId);
        if (syncSampleExists) {
            logger.info("Sync Sample already exists for parent batch:" + parentBatchId + ", Child batch:" + childBatchId);
            return;
        }

        String sql = " select s.s_sampleid parentsampleid,s.samplestatus parentsamplestatus, s.batchid parentbatchid,b.u_mesordersapbatch1," +
                " s.sourcespid, s.sourcespversionid, s.sourcesplevelid,s.sourcespsourcelabel" +
                " from s_sample s,s_batch b,s_spdetail sp ,s_batchstage bs  " +
                " where s.batchid = b.s_batchid " +
                " and s.sourcespid = sp.s_samplingplanid and s.sourcespversionid = sp.s_samplingplanversionid  " +

                //-- Phase 2 - The line is commented since in reality adhoc samples to stage can be added without level and sourcelabel
                //-- " and s.sourcesplevelid = sp.levelid and s.sourcespsourcelabel = sp.sourcelabel" +

                " and (s.sourcesplevelid = sp.levelid OR s.sourcesplevelid is null) and (s.sourcespsourcelabel = sp.sourcelabel OR s.sourcespsourcelabel is null)" +
                " and s.batchstageid=bs.s_batchstageid " +
                " and sp.s_samplingplanid=bs.samplingplanid and sp.s_samplingplanversionid=bs.samplingplanversionid " +
                " and sp.processstageid = bs.processstageid" +
                " and s.batchid = ? and s.samplestatus != ? " +
                " and sp.u_coaflag='Y' ";

        DataSet dsParentSampleInfo = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{parentBatchId, BATCH_STATUS_CANCELLED});

        if (dsParentSampleInfo == null || dsParentSampleInfo.size() == 0) {
            return;
        }


        //***********  Get distinct parent samples from the dataset ********************************//
        dsParentSampleInfo.addColumnValues("isduplicate", DataSet.STRING, StringUtil.repeat("N"
                , dsParentSampleInfo.getRowCount(), ";"), ";", "N");
        for (int indx = 0; indx < dsParentSampleInfo.getRowCount(); indx++) {
            String parentSampleId = dsParentSampleInfo.getValue(indx, "parentsampleid", "");
            String isDuplicate = dsParentSampleInfo.getValue(indx, "isduplicate", "");
            if (isDuplicate.equalsIgnoreCase("Y")) {
                continue;
            }
            for (int j = indx + 1; j < dsParentSampleInfo.getRowCount(); j++) {
                if (parentSampleId.equals(dsParentSampleInfo.getValue(j, "parentsampleid", ""))) {
                    dsParentSampleInfo.setValue(j, "isduplicate", "Y");
                }
            }
        }

        HashMap hm = new HashMap();
        hm.put("isduplicate", "N");
        DataSet dsFilter = dsParentSampleInfo.getFilteredDataSet(hm);

        String mesordersapbatch1 = dsFilter.getColumnValues("u_mesordersapbatch1", ";");
        String parentsampleid = dsFilter.getColumnValues("parentsampleid", ";");
        String childbatchid = StringUtil.repeat(childBatchId, dsFilter.getRowCount(), ";");
        String parentbatchid = dsFilter.getColumnValues("parentbatchid", ";");

        //Add SDI to ParentLotSamples.
        // if any error happen then needto bubble out upper method.
        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "ParentLotSamples");
        pl.setProperty(AddSDI.PROPERTY_COPIES, "" + dsFilter.getRowCount());
        pl.setProperty("mesordersapbatch1", mesordersapbatch1);
        pl.setProperty("parentsampleid", parentsampleid);
        pl.setProperty("childbatchid", childbatchid);
        pl.setProperty("parentbatchid", parentbatchid);

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

        } catch (SapphireException e) {
            String err = "Cannot process SAPErrorHandler. " + e.getMessage();
            logger.error(err);
            throw new SapphireException(err);
        }

        //Set SycnCOAFlag to complete
        markSyncCOAComplete(plBatchUpdate);

    }

    /**
     * Checks parent batch status - if Rejected - throws error in Inbound dashboard
     *
     * @param parentBatchId
     */
    private void checkParentBatchStatus(String parentBatchId) throws SapphireException {

        String sql = "select s_batchid, U_SAPMATNUMBER, U_MESORDERSAPBATCH1, U_SAPPLANT,  batchstatus from s_batch where s_batchid = ? ";
        DataSet dsSql = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{parentBatchId});

        if (dsSql == null || dsSql.size() == 0) {
            throw new SapphireException("Error while query - " + sql);
        }

        if (BATCH_STATUS_REJECTED.equalsIgnoreCase(dsSql.getValue(0, "batchstatus", ""))) {
            throw new SapphireException("Parent BatchId - " + parentBatchId + " is in Rejected status. SyncCOA of sample result not possible");
        }

    }

    /**
     * Check if Sync Sample exists.
     *
     * @param childBatchId
     * @param parentBatchId
     * @return
     * @throws SapphireException
     */
    private boolean isSyncSampleAlreadyExists(String childBatchId, String parentBatchId) throws SapphireException {
        String sql = " select  count(1) syncsamplecnt from u_parentlotsamples p, s_sample s" +
                " where p.childsampleid = s.s_sampleid and s.samplestatus!= 'Cancelled'" +
                " and p.childbatchid= ? ";
        DataSet dsSql = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{childBatchId});

        if (dsSql == null) {
            String str = "Something Wrong happend. Query reurns NULL.";
            throw new SapphireException(str);
        }

        if (Integer.parseInt(dsSql.getValue(0, "syncsamplecnt", "0")) > 0) {
            return true;
        }

        return false;


    }


    /**
     * Description: This method is used to update batch UD Code Log Table.
     *
     * @param limsBatchId
     * @param ucode
     * @param udUser
     * @param udDate
     * @throws SapphireException
     */

    private void updateBatchUDLogTable(String limsBatchId, String ucode, String udUser, String udDate) throws SapphireException {
        //ADDSDi Detail.
        PropertyList props = new PropertyList();
        props.setProperty(AddSDIDetail.PROPERTY_SDCID, "Batch");
        props.setProperty(AddSDIDetail.PROPERTY_KEYID1, limsBatchId);
        props.setProperty(AddSDIDetail.PROPERTY_LINKID, "batchudlog_link");

        props.setProperty("udcode", ucode);
        props.setProperty("uddate", udDate);
        props.setProperty("udby", udUser);

        getActionProcessor().processAction(AddSDIDetail.ID, AddSDIDetail.VERSIONID, props);

    }

    /**
     * Description: This method is used to fetch UD Code Description.
     *
     * @param ucode
     * @return
     * @throws SapphireException
     */

    private String getUDCodeDescription(String ucode) throws SapphireException {
        //select * from reftype where reftypeid='SAPUsageDecision';
        //select * from refvalue where reftypeid='SAPUsageDecision';
        logger.info("Starting getUDCodeDescription method");
        if (ucode == null || ucode.equalsIgnoreCase("")) {
            return "";
        }
        String udCodeDesc = "";
        String sqlText = "SELECT reftypeid,refvalueid,refdisplayvalue " +
                "FROM RefValue " +
                "WHERE reftypeid = 'SAPUsageDecision' ";

        DataSet dsResult = getQueryProcessor().getSqlDataSet(sqlText);
        if (dsResult == null) {
            String error = "Wrong query: " + sqlText;
            logger.error(error);
            throw new SapphireException(error);
        }
        if (dsResult.getRowCount() == 0) {
            String error = "Ref type 'SAPUsageDecision' missing in the system. " + sqlText;
            logger.error(error);
            throw new SapphireException(error);
        }
        HashMap filter = new HashMap();
        filter.clear();
        filter.put("refvalueid", ucode);
        DataSet dsFilter = dsResult.getFilteredDataSet(filter);
        if (dsFilter == null || dsFilter.getRowCount() < 1) {
            logger.error("UD Code value : " + ucode + "is not configured in SAPusagedecision");
            return "";
        }
        udCodeDesc = dsFilter.getValue(0, "refdisplayvalue", "");
        return udCodeDesc;
    }

    /**
     * Description: Auto Releases the Batches depending on UD Code value.
     *
     * @param udcodevalue
     * @param batchId
     * @param parentCount                  - Can be 0, 1 or more
     * @param limsBatchSyncCOACompleteFlag - Flag that indicates SyncCOA for batch is complete once
     * @param plBatchUpdate                - propertylist for batch fields update
     * @throws SapphireException
     */
    private boolean performSyncCOABatchApproval(String udcodevalue, String batchId, String parentBatchId, int parentCount, String limsBatchSyncCOACompleteFlag, PropertyList plBatchUpdate) throws SapphireException {

        if (!udcodevalue.equalsIgnoreCase("A") &&
                !udcodevalue.equalsIgnoreCase("C") &&
                !udcodevalue.equalsIgnoreCase("E") &&
                !udcodevalue.equalsIgnoreCase("S") &&
                !udcodevalue.equalsIgnoreCase("R")) {

            return false;

        }
        boolean releasesuccessful = false;

        //When single PARENT Batch identified
        //  AND syncCOA was not done before (Batch Released, Unreleased and now Pending Release),
        // AND Current batch status is not going to be Rejected
        // Then SyncCOASample

        if (parentCount == 1
                && !"Y".equalsIgnoreCase(limsBatchSyncCOACompleteFlag)
                && !udcodevalue.equalsIgnoreCase("R")
                ) {

            try {
                callSyncCOA(batchId, parentBatchId, plBatchUpdate);

            } catch (SapphireException e) {
                throw new SapphireException("Error", ErrorDetail.TYPE_FAILURE, "Failed to call SyncCOA Sample result. Error details - " + e.getMessage());
            }

        }

        // --- Batch Approval ---//
        String approvalFlag = "";
        if (udcodevalue.equalsIgnoreCase("A") ||
                udcodevalue.equalsIgnoreCase("C") ||
                udcodevalue.equalsIgnoreCase("E") ||
                udcodevalue.equalsIgnoreCase("S")) {
            approvalFlag = "P";

        } else if (udcodevalue.equalsIgnoreCase("R")) {
            approvalFlag = "F";

        } else {
            //Do nothing
            return false;
        }


        if (!"".equalsIgnoreCase(approvalFlag)) {
            PropertyList plApp = new PropertyList();
            plApp.setProperty("auditsignedflag", "Y");
            plApp.setProperty("approvalstep", "Approve");
            plApp.setProperty("auditreason", "Approved by SAP-LIMS Interface.");
            plApp.setProperty("approvalflag", approvalFlag);  //P Pass, F Fail, U Pending
            plApp.setProperty("sdcid", "Batch");
            plApp.setProperty("keyid1", batchId);
            plApp.setProperty("keyid2", "(null)");
            plApp.setProperty("keyid3", "(null)");
            plApp.setProperty("approvalstepinstance", "1");
            plApp.setProperty("auditactivity", "SDI Approval");
            //pl.setProperty("approvalnote", "Approved by SAP-LIMS Interface.");
            plApp.setProperty("approvaltypeid", "QA");

            try {
                getActionProcessor().processAction(ApproveSDIStep.ID, ApproveSDIStep.VERSIONID, plApp);
                releasesuccessful = true;
            } catch (SapphireException e) {
                logger.error("Error in performSyncCOABatchApproval() >>" + e.getMessage());
                throw new SapphireException(e.getMessage());
            }
        }
        return releasesuccessful;

    }


    /**
     * Returns Batch Ingredients
     *
     * @param limsBatchId
     * @return
     * @throws SapphireException
     */
    private DataSet getIngredients(String limsBatchId) throws SapphireException {
        String sql = "select b.s_batchid parentbatchid,b.batchstatus from s_batch b where  b.batchstatus!='Cancelled' and s_batchid in (" +
                "select g.parentbatchid from s_batchgenealogy g where g.s_batchid = ? and g.u_issapflag='Y'" + ")";

        DataSet dsParentBatch = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{limsBatchId});
        if (dsParentBatch == null) {
            throw new SapphireException("SQL returns NULL result. Please contact System Administrator.");
        }

        return dsParentBatch;

    }


    /**
     * Description:
     * The getLIMSBatchId method queries the LIMS batch table for a record with
     * the SAP batch and material numbers passed.
     *
     * @param sapBatchId
     * @param sapMatNum
     * @return String[]-   { LIMS batch id, batch status}
     * @throws SapphireException
     */
    private DataSet getLIMSBatchId(String sapBatchId, String sapMatNum, String sapPlantId) throws SapphireException {

        logger.debug("Starting getLIMSBatchId method");
        //  Batch Master service is only applicable for SAP Created batch (s_batch.u_issapflag=Y ) For Phase 2 implementation6
        String sqlText = "SELECT s_batchid, batchstatus,u_synccoacompleteflag, createdt " +
                " FROM s_Batch WHERE  batchstatus<> '" + BATCH_STATUS_CANCELLED + "' and u_issapflag='Y' and u_sapmatnumber = ?  and u_sapbatchnumber = ?  and  u_sapplant= ? ";

        DataSet dsBatchData = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{sapMatNum, sapBatchId, sapPlantId});

        if (dsBatchData == null) {
            String errorStr = "Error: Wrong query " + sqlText + " ( sapMatNum, sapBatchId, sapPlantId ) --> " + sapPlantId + " ," + sapBatchId + " ," + sapPlantId;
            throw new SapphireException(errorStr);
        }

        if (dsBatchData.size() > 0) {
            dsBatchData.sort("createdt D, s_batchid D");
        }

        return dsBatchData;

    }

    /**
     * Description: This method is used to check for null data.
     *
     * @param s
     * @return
     */

    public String checkNullDate(String s) {
        if (s.equalsIgnoreCase("00000000")) {
            return "(null)";
        }

        return s;
    }

}