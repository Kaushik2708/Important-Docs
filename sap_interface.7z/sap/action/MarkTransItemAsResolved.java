package labvantage.custom.alcon.sap.action;

import sapphire.SapphireException;
import sapphire.action.AddSDINote;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * $Author: $
 * $Date: $
 * $Revision: $
 */

/*****************************************************************************************************
 * $Revision: $
 * Description:
 * @author Kaushik Ghosh
 * @version 1
 ******************************************************************************************************/

public class MarkTransItemAsResolved extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: $";
    private static final String ID = "MarkTransItemAsResolved";
    private static final String VERSIONID = "1";
    private static final String __PROP_SDC_INTFTRANSITEM = "IntfTransItem";
    private static final String __PROP_KEYID1 = "keyid1";
    private static final String __PROP_NOTE_TYPE = "notetype";
    private static final String __PROP_NOTE = "note";
    private static final String __PROP_TRANSITEM_STAUS = "status";
    private static final String __STATUS_RESOLVED = "RESOLVED";
    private static final String __PROP_SEPARATOR = "%3B";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("=============== Start Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
        // ********* Getting all input property
        String keyid1 = properties.getProperty(__PROP_KEYID1);
        String noteType = properties.getProperty(__PROP_NOTE_TYPE);
        String notes = properties.getProperty(__PROP_NOTE);
        String[] arrTransItems = keyid1.split(__PROP_SEPARATOR);
        if (null == keyid1 || "".equalsIgnoreCase(keyid1)) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Aborting transaction. Transaction item can't be bull or blank."));
        }
        // ********* adding resolution notes
        addResolutionNotes(arrTransItems, noteType, notes);
        // ********* marking transaction item as Resolved
        markResolve(keyid1);
    }

    /***********************************************************
     * Description: This method is used to mark transaction items as resolved
     * @param keyid1 List of transaction items.
     * @throws SapphireException OOB Sapphire Exception
     ***********************************************************/
    private void markResolve(String keyid1) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside markResolve (method)");
        PropertyList plMarkResolved = new PropertyList();
        plMarkResolved.setProperty(EditSDI.PROPERTY_SDCID, __PROP_SDC_INTFTRANSITEM);
        plMarkResolved.setProperty(EditSDI.PROPERTY_KEYID1, StringUtil.replaceAll(keyid1, __PROP_SEPARATOR, ";"));
        plMarkResolved.setProperty(__PROP_TRANSITEM_STAUS, StringUtil.repeat(__STATUS_RESOLVED, keyid1.split(__PROP_SEPARATOR).length, ";"));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plMarkResolved);
        } catch (SapphireException ex) {
            throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Failed to execute Edit SDI for SDC - " + __PROP_SDC_INTFTRANSITEM));
        }
    }

    /*****************************************************************************************
     * Description: This method is used to add resolution notes to resolved transaction items.
     * @param arrTransItems Array of transaction items
     * @param noteType Notes type.
     * @param notes Resolution notes.
     * @throws SapphireException OOB Sapphire Exception.
     *******************************************************************************************/
    private void addResolutionNotes(String[] arrTransItems, String noteType, String notes) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside addResolutionNotes (method)");
        PropertyList plAddSDINotes = new PropertyList();
        // ********** Looping through transietems and adding resolution note
        // ********** Here loop is being used because multiple items can't be added to SDINote at once.

        for (int transItemCount = 0; transItemCount < arrTransItems.length; transItemCount++) {
            plAddSDINotes.setProperty(AddSDINote.PROPERTY_SDCID, __PROP_SDC_INTFTRANSITEM);
            plAddSDINotes.setProperty(AddSDINote.PROPERTY_KEYID1, arrTransItems[transItemCount]);
            plAddSDINotes.setProperty(AddSDINote.PROPERTY_NOTETYPE, noteType);
            plAddSDINotes.setProperty(AddSDINote.PROPERTY_NOTE, notes);

            try {
                getActionProcessor().processAction(AddSDINote.ID, AddSDINote.VERSIONID, plAddSDINotes);
            } catch (SapphireException ex) {
                logger.error(ex.getMessage());
                throw new SapphireException("General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Aborting transaction. Unable to execute AddSDINote."));
            }
        }

    }
}
