package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.sap.util.SAPUtil;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;


/**
 * $Author: BAGCHAN1 $
 * $Date: 2021-10-06 18:20:26 -0500 (Wed, 06 Oct 2021) $
 * $Revision: 618 $
 */

/***********************************************
 * $Revision: 618 $
 * The action is used as wrapper to request Inspection Lot from SAP based on user's access to department/site.
 *
 * @author Sayak Chatterjee
 * @version 1
 ************************************************/


public class EnhancedLotRequest extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 618 $";

    public static final String ACTION_ID = "Global_LotRequest_Regular+Cancelled";
    public static final String ACTION_VERSION_ID = "1";
    public static final String PROPS_SITE_WHERE_CLAUSE = "siteidclause";
    public static final String PROPS_MANUAL_INVOKE = "manual_invoke";


    @Override
    public void processAction(PropertyList properties) throws SapphireException {

        logger.debug("================== Processing Enhanced Lot Request action. ==========================================");

        String siteIdClause = "";
        String processassysuserid = properties.getProperty("processassysuserid", "");
        if (!(null == processassysuserid || processassysuserid.equalsIgnoreCase("") || processassysuserid.equalsIgnoreCase("SAP_INTERFACE"))) {

            //The additional where clause is being created to fetch only specific site id based on the user id calling the action
            siteIdClause = " AND (" + SAPUtil.formMultipleInWithOrForWhereClause("st.u_sitesid", fetchDistinctSiteId(processassysuserid), 500) + ")";
            properties.setProperty(PROPS_SITE_WHERE_CLAUSE, siteIdClause);
            properties.setProperty(PROPS_MANUAL_INVOKE, "Y");

        }
        getActionProcessor().processAction(ACTION_ID, ACTION_VERSION_ID, properties, false);
    }

    /**
     * Description: This method is used to prepare the site ids based on the current user calling the action
     *
     * @param processassysuserid
     * @return siteIds
     */
    private String fetchDistinctSiteId(String processassysuserid) throws SapphireException {

        String siteIds = "";
        String sql = "SELECT DISTINCT DEPT.U_SITEID SITEID FROM DEPARTMENT DEPT, DEPARTMENTSYSUSER DEPTUSR WHERE DEPT.DEPARTMENTID = DEPTUSR.DEPARTMENTID AND DEPTUSR.SYSUSERID = ?";
        DataSet dsSiteIds = getQueryProcessor().getPreparedSqlDataSet(sql, new Object[]{processassysuserid});
        if (dsSiteIds == null || dsSiteIds.getRowCount() == 0) {
            return null;
        } else {
            siteIds = dsSiteIds.getColumnValues("SITEID", ";");
        }
        return siteIds;
    }

}