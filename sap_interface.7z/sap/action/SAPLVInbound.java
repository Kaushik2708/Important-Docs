package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.sap.util.SAPUtil;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;

/**
 * $Author: GHOSHKA1 $
 * $Date: 2022-04-26 11:56:11 -0500 (Tue, 26 Apr 2022) $
 * $Revision: 770 $
 */

/*************************************************************************
 * $Revision: 770 $
 * Description:
 * This is an entry class, which will be triggered first after fetch SAP message.
 * This class is used to process different type of services sent by SAP.
 *
 * @author Soumen Mitra
 * @version 1
 ************************************************************************/
public class SAPLVInbound extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 770 $";
    public static final String ID = "SAPLVInbound";
    public static final String VERSIONID = "1";
    public static final String PROP_MSG_STAGE_ID = "msgstageid";
    public static final String PROP_PAY_LOAD = "payload";
    public static final String PROP_SERVICE_NAME = "servicename";
    public String newTransId;
    public boolean dataFoundFlag = true;
    public static final String INTF_TRANS_STATUS_SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE";
    public static final String PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "processassysuserid";
    public String VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "";
    private String ___KEY_NOT_FOUND = "KEY_NOT_FOUND";

    /**
     * Description: processAction is an OOB LabVantage method. This is the main method where execution starts.
     *
     * @param properties
     * @throws SapphireException
     */

    public void processAction(PropertyList properties) throws SapphireException {

        VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = properties.getProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, "");

        Map<String, Object> payloadMap = new HashMap<String, Object>();
        String msgStageId = properties.getProperty(PROP_MSG_STAGE_ID, ""); //FROM SAP
        String payloadData = properties.getProperty(PROP_PAY_LOAD, ""); //FROM SAP
        String servicename = properties.getProperty(PROP_SERVICE_NAME, ""); //FROM SAP
        validateInputData(payloadData, servicename);

        JSONObject inputJSONOBject = null;
        try {
            inputJSONOBject = new JSONObject(payloadData);
            payloadMap = jsonToMap(inputJSONOBject);
        } catch (JSONException e) {
            String err = "Error while reading payload data. Reason:" + e.getMessage();
            logger.error(err);
            throw new SapphireException(err);
        }

        try {
            if (servicename.equalsIgnoreCase(SAPProcessController.SERVICE_BATCH_MASTER)) {
                //-------------BatchMaster code ------------------
                //DataSet dsBatchMasterFull = convertDataSetForBatchMaster(payloadMap);
                loadTransItemDataForBatch(payloadMap, payloadData);
            } else if (servicename.equalsIgnoreCase(SAPProcessController.SERVICE_LOT_RECEIPT)) {
                //-------------Lot_Receipt code ------------------
                //DataSet dsLotReceiptFull = convertDataSetForLotReceipt(payloadMap);
                lotTableQAIVC(payloadMap, payloadData, msgStageId);
            } else if (servicename.equalsIgnoreCase(SAPProcessController.SERVICE_MATERIAL_MASTER)) {
                //serviceNotAvailable(SAPProcessController.SERVICE_MATERIAL_MASTER, payloadData);
                loadTransItemDataForMaterial(payloadMap, payloadData);
            } else if (servicename.equalsIgnoreCase(SAPProcessController.SERVICE_BATCH_CONSUMPTION)) {
                //serviceNotAvailable(SAPProcessController.SERVICE_BATCH_DATA, payloadData);
                loadTransItemDataForBatchConsumption(payloadMap, payloadData);
            } else {
                serviceNotAvailable(SAPProcessController.SERVICE_UNKNOWN, payloadData);
            }
        } catch (Exception e) {
            String error = "Error while reading Data Payload";
            error += e.getMessage();
            throw new SapphireException(ErrorDetail.TYPE_VALIDATION, error);
        }
    }

    /**
     * Description: Validating the input parameters from SAP
     *
     * @param payloadData
     * @param serviceName
     * @throws SapphireException
     */

    private void validateInputData(String payloadData, String serviceName) throws SapphireException {
        logger.info("================== SAP incoming parameters =======================================");
        logger.info("servicename: " + serviceName);
        //logger.info("pay load: "+payloadData); //TODO NOT SURE > TOO long string to print in log
        logger.info("================== SAP incoming parameters END =======================================");
        if (payloadData == null || "".equalsIgnoreCase(payloadData)) {
            String err = "Pay load is blank.";
            throw new SapphireException(err);
        }
        if (serviceName == null || "".equalsIgnoreCase(serviceName)) {
            String err = "Service name not provided.";
            throw new SapphireException(err);
        }
    }

    /**
     * Description: Creates a record in Transaction table for only unavailable services.
     *
     * @param serviceName
     * @param payloadData
     * @throws SapphireException
     */

    private void serviceNotAvailable(String serviceName, String payloadData) throws SapphireException {

        PropertyList props1 = new PropertyList();
        props1.setProperty(AddSDI.PROPERTY_SDCID, "IntfTrans");
        props1.setProperty(AddSDI.PROPERTY_COPIES, "1");
        props1.setProperty("status", INTF_TRANS_STATUS_SERVICE_UNAVAILABLE);
        props1.setProperty("transname", serviceName);
        props1.setProperty("transdata", payloadData);
        props1.setProperty("transdirection", "INBOUND");
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props1);

    }

    /**
     * @param batchConsumptionMap
     * @param payloadData
     */

    public void loadTransItemDataForBatchConsumption(Map<String, Object> batchConsumptionMap, String payloadData) throws SapphireException {

        final String header = "Header";
        final String component = "Component";

        for (Map.Entry<String, Object> batchConsumption : batchConsumptionMap.entrySet()) {
            if (batchConsumption.getValue() instanceof Map) {
                Map<String, Object> map1 = ((Map<String, Object>) batchConsumption.getValue());
                for (Map.Entry<String, Object> record : map1.entrySet()) {
                    if (record.getValue() instanceof ArrayList) {
                        ArrayList<Object> list1 = ((ArrayList<Object>) record.getValue());
                        for (int recordCount = 0; recordCount < list1.size(); recordCount++) { //Looping through multiple child batches.

                            DataSet dsBatchConsumptionItemData = new DataSet();
                            dsBatchConsumptionItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, DataSet.STRING);
                            dsBatchConsumptionItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, DataSet.STRING);
                            dsBatchConsumptionItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, DataSet.STRING);
                            dsBatchConsumptionItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_GROUP, DataSet.STRING);

                            Map<String, Object> eachRecord = ((Map<String, Object>) list1.get(recordCount));//Storing each record in a map.
                            for (Map.Entry<String, Object> entity : eachRecord.entrySet()) {
                                if (entity.getKey().equalsIgnoreCase(header)) {
                                    if (entity.getValue() instanceof Map) {
                                        Map<String, Object> headerMap = ((Map<String, Object>) entity.getValue());
                                        addToDataSet(dsBatchConsumptionItemData, "Header", "Material", SAPUtil.removeLeadingZeroes(stringCheck(headerMap.get("Material").toString())), "(null)");
                                        addToDataSet(dsBatchConsumptionItemData, "Header", "Plant", stringCheck(headerMap.get("Plant").toString()), "(null)");
                                        addToDataSet(dsBatchConsumptionItemData, "Header", "Batch", stringCheck(headerMap.get("Batch").toString()), "(null)");
                                    }
                                }
                            }
                            for (Map.Entry<String, Object> entity : eachRecord.entrySet()) {
                                if (entity.getKey().equalsIgnoreCase(component)) {
                                    if (entity.getValue() instanceof ArrayList) {
                                        ArrayList<Object> componentList = ((ArrayList<Object>) entity.getValue());

                                        String componentMaterials = "";
                                        String componentBatches = "";
                                        String componentPlants = "";

                                        for (int componentCount = 0; componentCount < componentList.size(); componentCount++) {//Looping through multiple parent batches in a child batch.

                                            Map<String, String> componentMap = ((Map<String, String>) componentList.get(componentCount));
                                            addToDataSet(dsBatchConsumptionItemData, "Component", "Material", SAPUtil.removeLeadingZeroes(stringCheck(componentMap.get("Material").toString())), "PARENT" + Integer.toString(componentCount + 1));
                                            addToDataSet(dsBatchConsumptionItemData, "Component", "Batch", stringCheck(componentMap.get("Batch").toString()), "PARENT" + Integer.toString(componentCount + 1));
                                            addToDataSet(dsBatchConsumptionItemData, "Component", "Plant", stringCheck(componentMap.get("Plant").toString()), "PARENT" + Integer.toString(componentCount + 1));
                                            addToDataSet(dsBatchConsumptionItemData, "Component", "Quantity", stringCheck(componentMap.get("Quantity").toString()), "PARENT" + Integer.toString(componentCount + 1));
                                            addToDataSet(dsBatchConsumptionItemData, "Component", "Unit", stringCheck(componentMap.get("Unit").toString()), "PARENT" + Integer.toString(componentCount + 1));

                                            if (componentCount == 0) {
                                                componentMaterials = SAPUtil.removeLeadingZeroes(stringCheck(componentMap.get("Material").toString()));
                                                componentBatches = stringCheck(componentMap.get("Batch").toString());
                                                componentPlants = stringCheck(componentMap.get("Plant").toString());
                                            } else {
                                                componentMaterials = componentMaterials + "," + SAPUtil.removeLeadingZeroes(stringCheck(componentMap.get("Material").toString()));
                                                componentBatches = componentBatches + "," + stringCheck(componentMap.get("Batch").toString());
                                                componentPlants = componentPlants + "," + stringCheck(componentMap.get("Plant").toString());
                                            }

                                        }
                                        addBatchConsumptionDataToTables(dsBatchConsumptionItemData, recordCount, payloadData, componentMaterials, componentBatches, componentPlants);
                                    } else if (entity.getValue() instanceof Map) {

                                        String componentMaterials = "";
                                        String componentBatches = "";
                                        String componentPlants = "";

                                        Map<String, String> componentMap = ((Map<String, String>) entity.getValue());
                                        addToDataSet(dsBatchConsumptionItemData, "Component", "Material", SAPUtil.removeLeadingZeroes(stringCheck(componentMap.get("Material").toString())), "(null)");
                                        addToDataSet(dsBatchConsumptionItemData, "Component", "Batch", stringCheck(componentMap.get("Batch").toString()), "(null)");
                                        addToDataSet(dsBatchConsumptionItemData, "Component", "Plant", stringCheck(componentMap.get("Plant").toString()), "(null)");
                                        addToDataSet(dsBatchConsumptionItemData, "Component", "Quantity", stringCheck(componentMap.get("Quantity").toString()), "(null)");
                                        addToDataSet(dsBatchConsumptionItemData, "Component", "Unit", stringCheck(componentMap.get("Unit").toString()), "(null)");

                                        componentMaterials = SAPUtil.removeLeadingZeroes(stringCheck(componentMap.get("Material").toString()));
                                        componentBatches = stringCheck(componentMap.get("Batch").toString());
                                        componentPlants = stringCheck(componentMap.get("Plant").toString());

                                        addBatchConsumptionDataToTables(dsBatchConsumptionItemData, recordCount, payloadData, componentMaterials, componentBatches, componentPlants);
                                    }
                                }
                            }


                        }
                    } else if (record.getValue() instanceof Map) {

                        DataSet dsBatchConsumptionItemData = new DataSet();
                        dsBatchConsumptionItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, DataSet.STRING);
                        dsBatchConsumptionItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, DataSet.STRING);
                        dsBatchConsumptionItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, DataSet.STRING);
                        dsBatchConsumptionItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_GROUP, DataSet.STRING);

                        Map<String, Object> eachRecord = ((Map<String, Object>) record.getValue());//Storing the one record in a map.
                        for (Map.Entry<String, Object> entity : eachRecord.entrySet()) {
                            if (entity.getKey().equalsIgnoreCase(header)) {
                                if (entity.getValue() instanceof Map) {
                                    Map<String, Object> headerMap = ((Map<String, Object>) entity.getValue());
                                    addToDataSet(dsBatchConsumptionItemData, "Header", "Material", SAPUtil.removeLeadingZeroes(stringCheck(headerMap.get("Material").toString())), "(null)");
                                    addToDataSet(dsBatchConsumptionItemData, "Header", "Plant", stringCheck(headerMap.get("Plant").toString()), "(null)");
                                    addToDataSet(dsBatchConsumptionItemData, "Header", "Batch", stringCheck(headerMap.get("Batch").toString()), "(null)");
                                }
                            }
                        }
                        for (Map.Entry<String, Object> entity : eachRecord.entrySet()) {
                            if (entity.getKey().equalsIgnoreCase(component)) {
                                if (entity.getValue() instanceof ArrayList) {
                                    ArrayList<Object> componentList = ((ArrayList<Object>) entity.getValue());
                                    String componentMaterials = "";
                                    String componentBatches = "";
                                    String componentPlants = "";

                                    for (int componentCount = 0; componentCount < componentList.size(); componentCount++) {//Looping through multiple parent batches in a child batch.

                                        Map<String, String> componentMap = ((Map<String, String>) componentList.get(componentCount));
                                        addToDataSet(dsBatchConsumptionItemData, "Component", "Material", SAPUtil.removeLeadingZeroes(stringCheck(componentMap.get("Material").toString())), "PARENT" + Integer.toString(componentCount + 1));
                                        addToDataSet(dsBatchConsumptionItemData, "Component", "Batch", stringCheck(componentMap.get("Batch").toString()), "PARENT" + Integer.toString(componentCount + 1));
                                        addToDataSet(dsBatchConsumptionItemData, "Component", "Plant", stringCheck(componentMap.get("Plant").toString()), "PARENT" + Integer.toString(componentCount + 1));
                                        addToDataSet(dsBatchConsumptionItemData, "Component", "Quantity", stringCheck(componentMap.get("Quantity").toString()), "PARENT" + Integer.toString(componentCount + 1));
                                        addToDataSet(dsBatchConsumptionItemData, "Component", "Unit", stringCheck(componentMap.get("Unit").toString()), "PARENT" + Integer.toString(componentCount + 1));

                                        if (componentCount == 0) {
                                            componentMaterials = SAPUtil.removeLeadingZeroes(stringCheck(componentMap.get("Material").toString()));
                                            componentBatches = stringCheck(componentMap.get("Batch").toString());
                                            componentPlants = stringCheck(componentMap.get("Plant").toString());
                                        } else {
                                            componentMaterials = componentMaterials + "," + SAPUtil.removeLeadingZeroes(stringCheck(componentMap.get("Material").toString()));
                                            componentBatches = componentBatches + "," + stringCheck(componentMap.get("Batch").toString());
                                            componentPlants = componentPlants + "," + stringCheck(componentMap.get("Plant").toString());
                                        }
                                    }
                                    addBatchConsumptionDataToTables(dsBatchConsumptionItemData, 0, payloadData, componentMaterials, componentBatches, componentPlants);
                                } else if (entity.getValue() instanceof Map) {

                                    String componentMaterials = "";
                                    String componentBatches = "";
                                    String componentPlants = "";

                                    Map<String, String> componentMap = ((Map<String, String>) entity.getValue());
                                    addToDataSet(dsBatchConsumptionItemData, "Component", "Material", SAPUtil.removeLeadingZeroes(stringCheck(componentMap.get("Material").toString())), "(null)");
                                    addToDataSet(dsBatchConsumptionItemData, "Component", "Batch", stringCheck(componentMap.get("Batch").toString()), "(null)");
                                    addToDataSet(dsBatchConsumptionItemData, "Component", "Plant", stringCheck(componentMap.get("Plant").toString()), "(null)");
                                    addToDataSet(dsBatchConsumptionItemData, "Component", "Quantity", stringCheck(componentMap.get("Quantity").toString()), "(null)");
                                    addToDataSet(dsBatchConsumptionItemData, "Component", "Unit", stringCheck(componentMap.get("Unit").toString()), "(null)");

                                    componentMaterials = SAPUtil.removeLeadingZeroes(stringCheck(componentMap.get("Material").toString()));
                                    componentBatches = stringCheck(componentMap.get("Batch").toString());
                                    componentPlants = stringCheck(componentMap.get("Plant").toString());

                                    addBatchConsumptionDataToTables(dsBatchConsumptionItemData, 0, payloadData, componentMaterials, componentBatches, componentPlants);
                                }
                            }
                        }

                    }
                }
            }
        }
    }

    /**
     * @param dsbatchData
     * @param recordCount
     * @param payloadData
     * @param materials
     * @param batches
     * @param plants
     * @throws SapphireException
     */

    public void addBatchConsumptionDataToTables(DataSet dsbatchData, int recordCount, String payloadData, String materials, String batches, String plants) throws SapphireException {

        PropertyList props = new PropertyList();

        //Inserting into IntfTrans
        //Transaction record creation only once.
        if (recordCount == 0) {
            props.clear();
            props.setProperty(AddSDI.PROPERTY_SDCID, "IntfTrans");
            props.setProperty(AddSDI.PROPERTY_COPIES, Integer.toString(1));
            props.setProperty("status", "CREATED");
            props.setProperty("transdata", payloadData);
            props.setProperty("transname", SAPProcessController.SERVICE_BATCH_CONSUMPTION);
            props.setProperty("transdirection", "INBOUND");
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            newTransId = props.getProperty("newkeyid1");
        }

        //Inserting  to IntfTransItem
        props.clear();
        props.setProperty(AddSDI.PROPERTY_SDCID, "IntfTransItem");
        props.setProperty(AddSDI.PROPERTY_COPIES, Integer.toString(1));
        props.setProperty("key1name", "SAP Batch");
        props.setProperty("key1value", SAPUtil.getColumnValue(dsbatchData, "Header", "BATCH"));
        props.setProperty("key2name", "Material Number");
        props.setProperty("key2value", SAPUtil.getColumnValue(dsbatchData, "Header", "MATERIAL"));
        props.setProperty("itemdata", dsbatchData.toXML());
        props.setProperty("status", "CREATED");
        props.setProperty("limskeyname", "");
        props.setProperty("limskeyvalue", "");
        props.setProperty("intftransid", newTransId);
        props.setProperty("transname", "BATCH_CONSUMPTION");
        props.setProperty("plant", SAPUtil.getColumnValue(dsbatchData, "Header", "PLANT"));
        props.setProperty("sapparentbatch", batches);//component batches within a record.
        props.setProperty("sapparentmat", materials);//component materials within a record.
        props.setProperty("sapparentplant", plants);//component plants within a record.

        props.setProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        String newTransItemId = props.getProperty("newkeyid1");
    }

    /**
     * Description : This method converts the BatchMaster payload into LabVantage dataset and then converts it into a XML string and also updates the intftrans and intftransitem SDCs.
     *
     * @param batchMasterMap
     * @throws SapphireException
     */

    public void loadTransItemDataForBatch(Map<String, Object> batchMasterMap, String payloadData) throws SapphireException {
        String batchId;
        String matNum;
        String plant;

        //Added on March 2022 : For processing batch payloads based on UD Date.
        DataSet dsDatetime = new DataSet();
        dsDatetime.addColumn("uddatetime", DataSet.STRING);

        final String Z1Z8CQBATMAS = "Z1Z8CQBATMAS";
        final String E1BPBATCHATT = "E1BPBATCHATT";
        final String E1BPMGVMATNR = "E1BPMGVMATNR";
        final String E1BP3060ALLOCATION = "E1BP3060_ALLOCATION";
        final String E1BP3060VALUATIONCHAR = "E1BP3060_VALUATION_CHAR";
        final String E1BP3060VALUATIONNUM = "E1BP3060_VALUATION_NUM";
        final String udDateCharact = "Z8CL_TWS_PR";

        DataSet dsTransItem = new DataSet();
        dsTransItem.addColumn("key1name", DataSet.STRING);
        dsTransItem.addColumn("key1value", DataSet.STRING);
        dsTransItem.addColumn("key2name", DataSet.STRING);
        dsTransItem.addColumn("key2value", DataSet.STRING);
        dsTransItem.addColumn("status", DataSet.STRING);
        dsTransItem.addColumn("itempayload", DataSet.STRING);
        dsTransItem.addColumn("transdesc", DataSet.STRING);
        dsTransItem.addColumn("itempayloadtranstable", DataSet.STRING);
        dsTransItem.addColumn("limskeyname", DataSet.STRING);
        dsTransItem.addColumn("limskeyvalue", DataSet.STRING);
        dsTransItem.addColumn("plant", DataSet.STRING);
        dsTransItem.addColumn("transdirection", DataSet.STRING);
        dsTransItem.addColumn("batchcount", DataSet.STRING);
        dsTransItem.addColumn("uddatetime", DataSet.DATE); //Added on March 2022 : For processing batch payloads based on UD Date.

        for (Map.Entry<String, Object> retrieveBatchMaster : batchMasterMap.entrySet()) {
            if (retrieveBatchMaster.getValue() instanceof Map) {
                Map<String, Object> map2 = ((Map<String, Object>) retrieveBatchMaster.getValue());
                for (Map.Entry<String, Object> arg0 : map2.entrySet()) {
                    if (arg0.getValue() instanceof Map) {
                        Map<String, Object> map3 = ((Map<String, Object>) arg0.getValue());
                        for (Map.Entry<String, Object> IDOC : map3.entrySet()) {
                            if (IDOC.getValue() instanceof ArrayList) {
                                ArrayList<Object> list0 = (ArrayList<Object>) IDOC.getValue();
                                for (int i = 0; i < list0.size(); i++) { //Total number of batch information. Example: Batch 1, Batch 2 etc.

                                    DataSet dsBatchMasterItemData = new DataSet();
                                    dsBatchMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, DataSet.STRING);
                                    dsBatchMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, DataSet.STRING);
                                    dsBatchMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, DataSet.STRING);
                                    dsBatchMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_GROUP, DataSet.STRING);

                                    Map<String, Object> firstBatch = ((Map<String, Object>) list0.get(i));
                                    for (Map.Entry<String, Object> tables : firstBatch.entrySet()) {
                                        if (tables.getKey().equalsIgnoreCase(Z1Z8CQBATMAS)) {
                                            if (tables.getValue() instanceof Map) {
                                                Map<String, Object> map4 = ((Map<String, Object>) tables.getValue());
                                                batchId = stringCheck(map4.get("BATCH").toString());
                                                matNum = stringCheck(map4.get("MATERIAL").toString());
                                                plant = stringCheck(map4.get("PLANT").toString());
                                                addToDataSet(dsBatchMasterItemData, "Batch", "batch", stringCheck(map4.get("BATCH").toString()), "(null)");
                                                addToDataSet(dsBatchMasterItemData, "Batch", "material", stringCheck(map4.get("MATERIAL").toString()), "(null)");
                                                addToDataSet(dsBatchMasterItemData, "Batch", "plant", stringCheck(map4.get("PLANT").toString()), "(null)");
                                                for (Map.Entry<String, Object> mainTables : map4.entrySet()) {
                                                    if (mainTables.getKey().equalsIgnoreCase(E1BPBATCHATT)) {
                                                        if (mainTables.getValue() instanceof Map) {
                                                            Map<String, String> map5 = ((Map<String, String>) mainTables.getValue());
                                                            addToDataSet(dsBatchMasterItemData, E1BPBATCHATT, "expirydate", map5.get("EXPIRYDATE"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BPBATCHATT, "proddate", map5.get("PROD_DATE"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BPBATCHATT, "vendrbatch", map5.get("VENDRBATCH"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BPBATCHATT, "nextinspec", map5.get("NEXTINSPEC"), "(null)");
                                                        }
                                                    }
                                                }
                                                for (Map.Entry<String, Object> mainTables : map4.entrySet()) {
                                                    if (mainTables.getKey().equalsIgnoreCase(E1BPMGVMATNR)) {
                                                        if (mainTables.getValue() instanceof Map) {
                                                            Map<String, String> map6 = ((Map<String, String>) mainTables.getValue());
                                                            addToDataSet(dsBatchMasterItemData, E1BPMGVMATNR, "materialext", map6.get("MATERIAL_EXT"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BPMGVMATNR, "materialvers", "(null)", "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BPMGVMATNR, "materialguid", map6.get("MATERIAL_GUID"), "(null)");
                                                        }
                                                    }
                                                }
                                                for (Map.Entry<String, Object> mainTables : map4.entrySet()) {
                                                    if (mainTables.getKey().equalsIgnoreCase(E1BP3060ALLOCATION)) {
                                                        if (mainTables.getValue() instanceof Map) {
                                                            Map<String, String> map7 = ((Map<String, String>) mainTables.getValue());
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "class_type", map7.get("CLASS_TYPE"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "classnum", map7.get("CLASSNUM"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "classtype", map7.get("CLASSTYPE"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "object", map7.get("OBJECT"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "objectkey", map7.get("OBJECTKEY"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "objtyp", map7.get("OBJTYP"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "objecttable", map7.get("OBJECTTABLE"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "clobjectkey", map7.get("CLOBJECTKEY"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "changenumber", "null", "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "keydate", map7.get("KEYDATE"), "(null)");
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "status", map7.get("STATUS"), "(null)");
                                                        }
                                                    }
                                                }
                                                for (Map.Entry<String, Object> mainTables : map4.entrySet()) {
                                                    if (mainTables.getKey().equalsIgnoreCase(E1BP3060VALUATIONCHAR)) {
                                                        if (mainTables.getValue() instanceof ArrayList) {
                                                            ArrayList<Object> list1 = (ArrayList<Object>) mainTables.getValue();
                                                            for (int j = 0; j < list1.size(); j++) {
                                                                Map<String, String> map8 = ((Map<String, String>) list1.get(j));

                                                                //Added on March 2022 :dsDatetime For processing batch payloads based on UD Date.
                                                                if (map8.get("CHARACT").equalsIgnoreCase(udDateCharact)) {
                                                                    int dateRow = dsDatetime.addRow();
                                                                    dsDatetime.setValue(dateRow, "uddatetime", map8.get("VALUE_CHAR").toString());
                                                                }

                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "classtype", map8.get("CLASS_TYPE"), "group" + Integer.toString(j + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "objectkey", map8.get("OBJECTKEY"), "group" + Integer.toString(j + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "objecttable", map8.get("OBJECTTABLE"), "group" + Integer.toString(j + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "clobjectkey", map8.get("CLOBJECTKEY"), "group" + Integer.toString(j + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "changenumber", "(null)", "group" + Integer.toString(j + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "keydate", map8.get("KEYDATE"), "group" + Integer.toString(j + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "charact", map8.get("CHARACT"), "group" + Integer.toString(j + 1));
                                                                //addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "valuechar", map8.get("VALUE_NEUTRAL"), "group" + Integer.toString(i + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "value_char", map8.get("VALUE_CHAR"), "group" + Integer.toString(j + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "inherited", "(null)", "group" + Integer.toString(j + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "instance", map8.get("INSTANCE"), "group" + Integer.toString(j + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "value_neutral", map8.get("VALUE_NEUTRAL"), "group" + Integer.toString(j + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "charact_descr", map8.get("CHARACT_DESCR"), "group" + Integer.toString(j + 1));
                                                            }
                                                        }
                                                    }
                                                }
                                                for (Map.Entry<String, Object> mainTables : map4.entrySet()) {
                                                    if (mainTables.getKey().equalsIgnoreCase(E1BP3060VALUATIONNUM)) {
                                                        if (mainTables.getValue() instanceof ArrayList) {
                                                            ArrayList<Object> list2 = (ArrayList<Object>) mainTables.getValue();
                                                            for (int k = 0; k < list2.size(); k++) {
                                                                Map<String, String> map9 = ((Map<String, String>) list2.get(k));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "classtype", map9.get("CLASS_TYPE"), "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "objectkey", map9.get("OBJECTKEY"), "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "objecttable", map9.get("OBJECTTABLE"), "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "clobjectkey", map9.get("CLOBJECTKEY"), "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "changenumber", "(null)", "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "keydate", map9.get("KEYDATE"), "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "charact", map9.get("CHARACT"), "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "valuefrom", map9.get("VALUE_FROM"), "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "valueto", map9.get("VALUE_TO"), "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "inherited", "(null)", "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "instance", map9.get("INSTANCE"), "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "unitfrom", "(null)", "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "unitto", "(null)", "group" + Integer.toString(k + 1));
                                                                addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "charactdescr", map9.get("CHARACT_DESCR"), "group" + Integer.toString(k + 1));

                                                            }
                                                        }
                                                    }
                                                }
                                                int row = dsTransItem.addRow();
                                                dsTransItem.setValue(row, "key1name", "SAP Batch");
                                                dsTransItem.setValue(row, "key1value", batchId);
                                                dsTransItem.setValue(row, "status", "CREATED");
                                                dsTransItem.setValue(row, "transdesc", SAPProcessController.SERVICE_BATCH_MASTER);
                                                dsTransItem.setValue(row, "key2name", "SAP Material Number");
                                                dsTransItem.setValue(row, "key2value", matNum);
                                                dsTransItem.setValue(row, "itempayload", dsBatchMasterItemData.toXML());
                                                dsTransItem.setValue(row, "itempayloadtranstable", payloadData);
                                                dsTransItem.setValue(row, "limskeyname", "LIMS Batch");
                                                dsTransItem.setValue(row, "limskeyvalue", "Batch Number");
                                                dsTransItem.setValue(row, "plant", plant);
                                                dsTransItem.setValue(row, "transdirection", "INBOUND");
                                                dsTransItem.setValue(row, "batchcount", Integer.toString(i + 1));
                                                //Added on March 2022 : For processing batch payloads based on UD Date.
                                                // Changed to catch Invalid Date format
                                                try {
                                                    dsTransItem.setDate(row, "uddatetime", SAPUtil.getDateStringWithProperFormat(dsDatetime.getValue(0, "uddatetime", ""), "yyyyMMdd_HHmmss", "UTC", connectionInfo));
                                                } catch (SapphireException ex) {
                                                    logger.error(" Aborting transaction. Invalid date problem. Error is :" + ex.getMessage());
                                                    //return;
                                                    throw new SapphireException(" General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Aborting transaction. Invalid date - " + ex.getMessage()));
                                                }

                                                dsDatetime.clear();
                                            }
                                        }
                                    }
                                }
                            } else if (IDOC.getValue() instanceof Map) {
                                DataSet dsBatchMasterItemData = new DataSet();
                                dsBatchMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, DataSet.STRING);
                                dsBatchMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, DataSet.STRING);
                                dsBatchMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, DataSet.STRING);
                                dsBatchMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_GROUP, DataSet.STRING);

                                Map<String, Object> firstBatch = ((Map<String, Object>) IDOC.getValue());
                                for (Map.Entry<String, Object> tables : firstBatch.entrySet()) {
                                    if (tables.getKey().equalsIgnoreCase(Z1Z8CQBATMAS)) {
                                        if (tables.getValue() instanceof Map) {
                                            Map<String, Object> map4 = ((Map<String, Object>) tables.getValue());
                                            batchId = stringCheck(map4.get("BATCH").toString());
                                            matNum = stringCheck(map4.get("MATERIAL").toString());
                                            plant = stringCheck(map4.get("PLANT").toString());
                                            addToDataSet(dsBatchMasterItemData, "Batch", "batch", stringCheck(map4.get("BATCH").toString()), "(null)");
                                            addToDataSet(dsBatchMasterItemData, "Batch", "material", stringCheck(map4.get("MATERIAL").toString()), "(null)");
                                            addToDataSet(dsBatchMasterItemData, "Batch", "plant", stringCheck(map4.get("PLANT").toString()), "(null)");
                                            for (Map.Entry<String, Object> mainTables : map4.entrySet()) {
                                                if (mainTables.getKey().equalsIgnoreCase(E1BPBATCHATT)) {
                                                    if (mainTables.getValue() instanceof Map) {
                                                        Map<String, String> map5 = ((Map<String, String>) mainTables.getValue());
                                                        addToDataSet(dsBatchMasterItemData, E1BPBATCHATT, "expirydate", map5.get("EXPIRYDATE"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BPBATCHATT, "proddate", map5.get("PROD_DATE"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BPBATCHATT, "vendrbatch", map5.get("VENDRBATCH"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BPBATCHATT, "nextinspec", map5.get("NEXTINSPEC"), "(null)");
                                                    }
                                                }
                                            }
                                            for (Map.Entry<String, Object> mainTables : map4.entrySet()) {
                                                if (mainTables.getKey().equalsIgnoreCase(E1BPMGVMATNR)) {
                                                    if (mainTables.getValue() instanceof Map) {
                                                        Map<String, String> map6 = ((Map<String, String>) mainTables.getValue());
                                                        addToDataSet(dsBatchMasterItemData, E1BPMGVMATNR, "materialext", map6.get("MATERIAL_EXT"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BPMGVMATNR, "materialvers", "(null)", "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BPMGVMATNR, "materialguid", map6.get("MATERIAL_GUID"), "(null)");
                                                    }
                                                }
                                            }
                                            for (Map.Entry<String, Object> mainTables : map4.entrySet()) {
                                                if (mainTables.getKey().equalsIgnoreCase(E1BP3060ALLOCATION)) {
                                                    if (mainTables.getValue() instanceof Map) {
                                                        Map<String, String> map7 = ((Map<String, String>) mainTables.getValue());
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "class_type", map7.get("CLASS_TYPE"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "classnum", map7.get("CLASSNUM"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "classtype", map7.get("CLASSTYPE"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "object", map7.get("OBJECT"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "objectkey", map7.get("OBJECTKEY"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "objtyp", map7.get("OBJTYP"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "objecttable", map7.get("OBJECTTABLE"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "clobjectkey", map7.get("CLOBJECTKEY"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "changenumber", "null", "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "keydate", map7.get("KEYDATE"), "(null)");
                                                        addToDataSet(dsBatchMasterItemData, E1BP3060ALLOCATION, "status", map7.get("STATUS"), "(null)");
                                                    }
                                                }
                                            }
                                            for (Map.Entry<String, Object> mainTables : map4.entrySet()) {
                                                if (mainTables.getKey().equalsIgnoreCase(E1BP3060VALUATIONCHAR)) {
                                                    if (mainTables.getValue() instanceof ArrayList) {
                                                        ArrayList<Object> list1 = (ArrayList<Object>) mainTables.getValue();
                                                        for (int j = 0; j < list1.size(); j++) {
                                                            Map<String, String> map8 = ((Map<String, String>) list1.get(j));

                                                            //Added on March 2022 : For processing batch payloads based on UD Date.
                                                            if (map8.get("CHARACT").equalsIgnoreCase(udDateCharact)) {
                                                                int dateRow = dsDatetime.addRow();
                                                                dsDatetime.setValue(dateRow, "uddatetime", map8.get("VALUE_CHAR").toString());
                                                            }

                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "classtype", map8.get("CLASS_TYPE"), "group" + Integer.toString(j + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "objectkey", map8.get("OBJECTKEY"), "group" + Integer.toString(j + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "objecttable", map8.get("OBJECTTABLE"), "group" + Integer.toString(j + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "clobjectkey", map8.get("CLOBJECTKEY"), "group" + Integer.toString(j + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "changenumber", "(null)", "group" + Integer.toString(j + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "keydate", map8.get("KEYDATE"), "group" + Integer.toString(j + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "charact", map8.get("CHARACT"), "group" + Integer.toString(j + 1));
                                                            //addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "valuechar", map8.get("VALUE_NEUTRAL"), "group" + Integer.toString(i + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "value_char", map8.get("VALUE_CHAR"), "group" + Integer.toString(j + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "inherited", "(null)", "group" + Integer.toString(j + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "instance", map8.get("INSTANCE"), "group" + Integer.toString(j + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "value_neutral", map8.get("VALUE_NEUTRAL"), "group" + Integer.toString(j + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONCHAR, "charact_descr", map8.get("CHARACT_DESCR"), "group" + Integer.toString(j + 1));
                                                        }
                                                    }
                                                }
                                            }
                                            for (Map.Entry<String, Object> mainTables : map4.entrySet()) {
                                                if (mainTables.getKey().equalsIgnoreCase(E1BP3060VALUATIONNUM)) {
                                                    if (mainTables.getValue() instanceof ArrayList) {
                                                        ArrayList<Object> list2 = (ArrayList<Object>) mainTables.getValue();
                                                        for (int k = 0; k < list2.size(); k++) {
                                                            Map<String, String> map9 = ((Map<String, String>) list2.get(k));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "classtype", map9.get("CLASS_TYPE"), "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "objectkey", map9.get("OBJECTKEY"), "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "objecttable", map9.get("OBJECTTABLE"), "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "clobjectkey", map9.get("CLOBJECTKEY"), "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "changenumber", "(null)", "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "keydate", map9.get("KEYDATE"), "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "charact", map9.get("CHARACT"), "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "valuefrom", map9.get("VALUE_FROM"), "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "valueto", map9.get("VALUE_TO"), "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "inherited", "(null)", "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "instance", map9.get("INSTANCE"), "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "unitfrom", "(null)", "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "unitto", "(null)", "group" + Integer.toString(k + 1));
                                                            addToDataSet(dsBatchMasterItemData, E1BP3060VALUATIONNUM, "charactdescr", map9.get("CHARACT_DESCR"), "group" + Integer.toString(k + 1));

                                                        }
                                                    }
                                                }
                                            }
                                            int row = dsTransItem.addRow();
                                            dsTransItem.setValue(row, "key1name", "SAP Batch");
                                            dsTransItem.setValue(row, "key1value", batchId);
                                            dsTransItem.setValue(row, "status", "CREATED");
                                            dsTransItem.setValue(row, "transdesc", SAPProcessController.SERVICE_BATCH_MASTER);
                                            dsTransItem.setValue(row, "key2name", "SAP Material Number");
                                            dsTransItem.setValue(row, "key2value", matNum);
                                            dsTransItem.setValue(row, "itempayload", dsBatchMasterItemData.toXML());
                                            dsTransItem.setValue(row, "itempayloadtranstable", payloadData);
                                            dsTransItem.setValue(row, "limskeyname", "LIMS Batch");
                                            dsTransItem.setValue(row, "limskeyvalue", "Batch Number");
                                            dsTransItem.setValue(row, "plant", plant);
                                            dsTransItem.setValue(row, "transdirection", "INBOUND");
                                            dsTransItem.setValue(row, "batchcount", Integer.toString(1));
                                            //Added on March 2022 : For processing batch payloads based on UD Date.
                                            // Changed to catch Invalid Date format
                                            try {
                                                dsTransItem.setDate(row, "uddatetime", SAPUtil.getDateStringWithProperFormat(dsDatetime.getValue(0, "uddatetime", ""), "yyyyMMdd_HHmmss", "UTC", connectionInfo));
                                            } catch (SapphireException ex) {
                                                logger.error(" Aborting transaction. Invalid date problem. Error is :" + ex.getMessage());
                                                //return;
                                                throw new SapphireException(" General Error", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Aborting transaction. Invalid date - " + ex.getMessage()));
                                            }
                                            dsDatetime.clear();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        //filtering the dataset based on batchCount field in dsTransitem dataset
        PropertyList props1 = new PropertyList();
        PropertyList props = new PropertyList();
        dsTransItem.sort("uddatetime, batchcount");
        ArrayList arrDataSet = dsTransItem.getGroupedDataSets("batchcount");

        //Multiple batch will come that's why firing the action in a loop
        for (int i = 0; i < arrDataSet.size(); i++) {
            DataSet dsEach = (DataSet) arrDataSet.get(i);
            if (dsEach == null || dsEach.size() == 0) {
                continue;
            }

            //Inserting into IntfTrans
            if (i == 0) {
                props1.clear();
                props1.setProperty(AddSDI.PROPERTY_SDCID, "IntfTrans");
                props1.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsEach.size()));
                //props1.setProperty("keyname", dsEach.getColumnValues("key1name", ";"));
                //props1.setProperty("keyvalue", dsEach.getColumnValues("key1value", ";"));
                props1.setProperty("status", dsEach.getColumnValues("status", ";"));
                props1.setProperty("transdata", dsEach.getColumnValues("itempayloadtranstable", ";"));
                //props1.setProperty("limskeyname", dsEach.getColumnValues("limskeyname", ";"));
                //props1.setProperty("limskeyvalue", dsEach.getColumnValues("limskeyvalue", ";"));
                props1.setProperty("transname", dsEach.getColumnValues("transdesc", ";"));
                props1.setProperty("transdirection", dsEach.getColumnValues("transdirection", ";"));
                getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props1);
                newTransId = props1.getProperty("newkeyid1");
            }

            //Inserting  to IntfTransItem
            props.clear();
            props.setProperty(AddSDI.PROPERTY_SDCID, "IntfTransItem");
            props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsEach.size()));
            props.setProperty("key1name", dsEach.getColumnValues("key1name", ";"));
            props.setProperty("key1value", dsEach.getColumnValues("key1value", ";"));
            props.setProperty("key2name", dsEach.getColumnValues("key2name", ";"));
            props.setProperty("key2value", dsEach.getColumnValues("key2value", ";"));
            props.setProperty("itemdata", dsEach.getColumnValues("itempayload", ";"));
            props.setProperty("status", dsEach.getColumnValues("status", ";"));
            props.setProperty("limskeyname", dsEach.getColumnValues("limskeyname", ";"));
            props.setProperty("limskeyvalue", dsEach.getColumnValues("limskeyvalue", ";"));
            props.setProperty("intftransid", newTransId);
            props.setProperty("transname", dsEach.getColumnValues("transdesc", ";"));
            props.setProperty("plant", dsEach.getColumnValues("plant", ";"));

            props.setProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            String newTransItemId = props.getProperty("newkeyid1");

        }
    }

    /**
     * @param materialMasterMap
     * @param payloadData
     * @throws SapphireException
     */

    public void loadTransItemDataForMaterial(Map<String, Object> materialMasterMap, String payloadData) throws SapphireException {

        final String EDI_DC40 = "EDI_DC40";
        final String E1MARAM = "E1MARAM";
        final String E1MAKTM = "E1MAKTM";
        final String E1MARCM = "E1MARCM";
        final String Z18CMMARCM = "Z18CMMARCM";

        for (Map.Entry<String, Object> retrieveMaterialMaster : materialMasterMap.entrySet()) {
            if (retrieveMaterialMaster.getValue() instanceof Map) {
                Map<String, Object> map2 = ((Map<String, Object>) retrieveMaterialMaster.getValue());
                for (Map.Entry<String, Object> arg0 : map2.entrySet()) {
                    if (arg0.getValue() instanceof Map) {
                        Map<String, Object> map3 = ((Map<String, Object>) arg0.getValue());
                        for (Map.Entry<String, Object> IDOC : map3.entrySet()) {
                            PropertyList plDelRow = new PropertyList();
                            if (IDOC.getValue() instanceof ArrayList) {
                                ArrayList<Object> list0 = (ArrayList<Object>) IDOC.getValue();
                                for (int idocCount = 0; idocCount < list0.size(); idocCount++) {
                                    DataSet dsMaterialMasterItemData = new DataSet();
                                    dsMaterialMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, DataSet.STRING);
                                    dsMaterialMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, DataSet.STRING);
                                    dsMaterialMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, DataSet.STRING);
                                    dsMaterialMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_GROUP, DataSet.STRING);

                                    Map<String, Object> firstMaterial = ((Map<String, Object>) list0.get(idocCount));
                                    for (Map.Entry<String, Object> entities : firstMaterial.entrySet()) {
                                        if (entities.getKey().equalsIgnoreCase(EDI_DC40)) {
                                            Map<String, String> map4 = ((Map<String, String>) entities.getValue());
                                            addToDataSet(dsMaterialMasterItemData, "EDI_DC40", "DOCNUM", stringCheck(map4.containsKey("DOCNUM") ? map4.get("DOCNUM").toString() : ___KEY_NOT_FOUND), "(null)");
                                        }
                                    }
                                    for (Map.Entry<String, Object> entities : firstMaterial.entrySet()) {
                                        if (entities.getKey().equalsIgnoreCase(E1MARAM)) {
                                            if (entities.getValue() instanceof Map) {
                                                Map<String, Object> map5 = ((Map<String, Object>) entities.getValue());
                                                addToDataSet(dsMaterialMasterItemData, "E1MARAM", "MATNR", stringCheck(map5.containsKey("MATNR") ? map5.get("MATNR").toString() : ___KEY_NOT_FOUND), "(null)");
                                                addToDataSet(dsMaterialMasterItemData, "E1MARAM", "MTART", stringCheck(map5.containsKey("MTART") ? map5.get("MTART").toString() : ___KEY_NOT_FOUND), "(null)");
                                                addToDataSet(dsMaterialMasterItemData, "E1MARAM", "BISMT", stringCheck(map5.containsKey("BISMT") ? map5.get("BISMT").toString() : ___KEY_NOT_FOUND), "(null)");
                                                addToDataSet(dsMaterialMasterItemData, "E1MARAM", "EAN11", stringCheck(map5.containsKey("EAN11") ? map5.get("EAN11").toString() : ___KEY_NOT_FOUND), "(null)");
                                                /*************************
                                                 * Added for MDLIMS -908 : Alcon CoA report date format
                                                 * Added By : KG
                                                 * Added on : 31-Aug-2021
                                                 *************************/
                                                for (Map.Entry<String, Object> subEntityZ18CMOCLFM : map5.entrySet()) {
                                                    if (subEntityZ18CMOCLFM.getKey().equalsIgnoreCase("Z18CMOCLFM")) {
                                                        if (subEntityZ18CMOCLFM.getValue() instanceof Map) {
                                                            Map<String, Object> mapZ18CMOCLFM = ((Map<String, Object>) subEntityZ18CMOCLFM.getValue());
                                                            for (Map.Entry<String, Object> subEntityZ18CMAUSPM : mapZ18CMOCLFM.entrySet()) {
                                                                if (subEntityZ18CMAUSPM.getKey().equalsIgnoreCase("Z18CMAUSPM")) {
                                                                    // If segment is an Array
                                                                    if (subEntityZ18CMAUSPM.getValue() instanceof ArrayList) {
                                                                        ArrayList<Object> alZ18CMAUSPM = (ArrayList<Object>) subEntityZ18CMAUSPM.getValue();
                                                                        boolean isKeyFound = false;
                                                                        for (int listCount = 0; listCount < alZ18CMAUSPM.size(); listCount++) {
                                                                            // Getting each segment in a Map object
                                                                            Map<String, Object> mapZ18CMAUSPM = ((Map<String, Object>) alZ18CMAUSPM.get(listCount));
                                                                            if (mapZ18CMAUSPM.get("ATNAM").toString().equalsIgnoreCase("Z8C_PRODUCT_LBL_DATE_FORMAT")) {
                                                                                // Checking if ATFLV key exists in current segment / Map object
                                                                                // If yes store the row number +1
                                                                                // Else NO_KEY_FOUND
                                                                                addToDataSet(dsMaterialMasterItemData, "Z18CMAUSPM", "ATFLV", stringCheck(mapZ18CMAUSPM.containsKey("ATFLV") ? String.valueOf(new BigDecimal(mapZ18CMAUSPM.get("ATFLV").toString()).intValue()) : ___KEY_NOT_FOUND), "(null)");
                                                                                isKeyFound = true;
                                                                            }
                                                                        }
                                                                        if (isKeyFound == false) {
                                                                            addToDataSet(dsMaterialMasterItemData, "Z18CMAUSPM", "ATFLV", ___KEY_NOT_FOUND, "(null)");
                                                                        }

                                                                    } else if (subEntityZ18CMAUSPM.getValue() instanceof Map) {
                                                                        // If segment is an sinle segment
                                                                        // Getting each segment in a Map object
                                                                        Map<String, Object> mapZ18CMAUSPM = ((Map<String, Object>) subEntityZ18CMAUSPM.getValue());
                                                                        if (mapZ18CMAUSPM.get("ATNAM").toString().equalsIgnoreCase("Z8C_PRODUCT_LBL_DATE_FORMAT")) {
                                                                            // Checking if ATFLV key exists in current segment / Map object
                                                                            // If yes store the row number +1
                                                                            // Else NO_KEY_FOUND
                                                                            addToDataSet(dsMaterialMasterItemData, "Z18CMAUSPM", "ATFLV", stringCheck(mapZ18CMAUSPM.containsKey("ATFLV") ? Integer.toString(1) : ___KEY_NOT_FOUND), "(null)");
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }

                                                for (Map.Entry<String, Object> subEntity : map5.entrySet()) {
                                                    if (subEntity.getKey().equalsIgnoreCase(E1MAKTM)) {
                                                        if (subEntity.getValue() instanceof Map) {
                                                            Map<String, Object> map6 = ((Map<String, Object>) subEntity.getValue());
                                                            if (map6.containsKey("SPRAS")) {
                                                                if (map6.get("SPRAS").toString().equalsIgnoreCase("E")) {
                                                                    addToDataSet(dsMaterialMasterItemData, "E1MAKTM", "MAKTX", stringCheck(map6.containsKey("MAKTX") ? map6.get("MAKTX").toString() : ___KEY_NOT_FOUND), "(null)");
                                                                } else {
                                                                    addToDataSet(dsMaterialMasterItemData, "E1MAKTM", "MAKTX", ___KEY_NOT_FOUND, "(null)");
                                                                }
                                                            } else {
                                                                addToDataSet(dsMaterialMasterItemData, "E1MAKTM", "MAKTX", ___KEY_NOT_FOUND, "(null)");
                                                            }

                                                        } else if (subEntity.getValue() instanceof ArrayList) {
                                                            ArrayList<Object> newList = (ArrayList<Object>) subEntity.getValue();
                                                            int notFound = 0;//0 for notfound and 1 for found.
                                                            for (int listCount = 0; listCount < newList.size(); listCount++) {
                                                                Map<String, Object> map6 = ((Map<String, Object>) newList.get(listCount));
                                                                if (map6.containsKey("SPRAS")) {
                                                                    if (map6.get("SPRAS").toString().equalsIgnoreCase("E")) {
                                                                        addToDataSet(dsMaterialMasterItemData, "E1MAKTM", "MAKTX", stringCheck(map6.containsKey("MAKTX") ? map6.get("MAKTX").toString() : ___KEY_NOT_FOUND), "(null)");
                                                                        notFound = 1;
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                            if (notFound == 0) {
                                                                addToDataSet(dsMaterialMasterItemData, "E1MAKTM", "MAKTX", ___KEY_NOT_FOUND, "(null)");
                                                            }
                                                        }
                                                    }
                                                }
                                                for (Map.Entry<String, Object> subEntity : map5.entrySet()) {
                                                    if (subEntity.getKey().equalsIgnoreCase(E1MARCM)) {
                                                        if (subEntity.getValue() instanceof Map) {
                                                            Map<String, Object> map7 = ((Map<String, Object>) subEntity.getValue());
                                                            addToDataSet(dsMaterialMasterItemData, "E1MARCM", "WERKS", stringCheck(map7.containsKey("WERKS") ? map7.get("WERKS").toString() : ___KEY_NOT_FOUND), "(null)");

                                                            for (Map.Entry<String, Object> subEntityE1MARCM : map7.entrySet()) {
                                                                if (subEntityE1MARCM.getKey().equalsIgnoreCase(Z18CMMARCM)) {
                                                                    if (subEntityE1MARCM.getValue() instanceof Map) {
                                                                        Map<String, Object> map8 = ((Map<String, Object>) subEntityE1MARCM.getValue());
                                                                        addToDataSet(dsMaterialMasterItemData, "Z18CMMARCM", "ZZBISMT", stringCheck(map8.containsKey("ZZBISMT") ? map8.get("ZZBISMT").toString() : ___KEY_NOT_FOUND), stringCheck(map7.containsKey("WERKS") ? map7.get("WERKS").toString() : ___KEY_NOT_FOUND));
                                                                    }
                                                                }
                                                            }
                                                            addMaterialDataToTables(dsMaterialMasterItemData, idocCount, 0, payloadData);

                                                        } else if (subEntity.getValue() instanceof ArrayList) {
                                                            ArrayList<Object> list1 = (ArrayList<Object>) subEntity.getValue();
                                                            for (int i = 0; i < list1.size(); i++) {
                                                                Map<String, Object> map9 = ((Map<String, Object>) list1.get(i));
                                                                addToDataSet(dsMaterialMasterItemData, "E1MARCM", "WERKS", stringCheck(map9.containsKey("WERKS") ? map9.get("WERKS").toString() : ___KEY_NOT_FOUND), "(null)");
                                                                Map<String, Object> map10 = new HashMap<String, Object>();
                                                                for (Map.Entry<String, Object> subEntityE1MARCM : map9.entrySet()) {
                                                                    if (subEntityE1MARCM.getKey().equalsIgnoreCase(Z18CMMARCM)) {
                                                                        if (subEntityE1MARCM.getValue() instanceof Map) {
                                                                            map10 = ((Map<String, Object>) subEntityE1MARCM.getValue());
                                                                            addToDataSet(dsMaterialMasterItemData, "Z18CMMARCM", "ZZBISMT", stringCheck(map10.containsKey("ZZBISMT") ? map10.get("ZZBISMT").toString() : ___KEY_NOT_FOUND), stringCheck(map9.containsKey("WERKS") ? map9.get("WERKS").toString() : ___KEY_NOT_FOUND));
                                                                        }
                                                                    }
                                                                }
                                                                addMaterialDataToTables(dsMaterialMasterItemData, idocCount, i, payloadData);
                                                                // Deleting PLANT
                                                                plDelRow.clear();
                                                                plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, "E1MARCM");
                                                                plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, "WERKS");
                                                                plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, stringCheck(map9.containsKey("WERKS") ? map9.get("WERKS").toString() : ___KEY_NOT_FOUND));
                                                                dsMaterialMasterItemData.deleteRow(dsMaterialMasterItemData.findRow(plDelRow));
                                                                // Deleting Local Material Code
                                                                plDelRow.clear();
                                                                plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, "Z18CMMARCM");
                                                                plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, "ZZBISMT");
                                                                plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, stringCheck(map10.containsKey("ZZBISMT") ? map10.get("ZZBISMT").toString() : ___KEY_NOT_FOUND));
                                                                dsMaterialMasterItemData.deleteRow(dsMaterialMasterItemData.findRow(plDelRow));
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else if (IDOC.getValue() instanceof Map) {
                                DataSet dsMaterialMasterItemData = new DataSet();
                                dsMaterialMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, DataSet.STRING);
                                dsMaterialMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, DataSet.STRING);
                                dsMaterialMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, DataSet.STRING);
                                dsMaterialMasterItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_GROUP, DataSet.STRING);

                                Map<String, Object> firstMaterial = ((Map<String, Object>) IDOC.getValue());
                                for (Map.Entry<String, Object> entities : firstMaterial.entrySet()) {
                                    if (entities.getKey().equalsIgnoreCase(EDI_DC40)) {
                                        Map<String, String> map4 = ((Map<String, String>) entities.getValue());
                                        addToDataSet(dsMaterialMasterItemData, "EDI_DC40", "DOCNUM", stringCheck(map4.containsKey("DOCNUM") ? map4.get("DOCNUM").toString() : ___KEY_NOT_FOUND), "(null)");
                                    }
                                }
                                for (Map.Entry<String, Object> entities : firstMaterial.entrySet()) {
                                    if (entities.getKey().equalsIgnoreCase(E1MARAM)) {
                                        if (entities.getValue() instanceof Map) {
                                            Map<String, Object> map5 = ((Map<String, Object>) entities.getValue());
                                            addToDataSet(dsMaterialMasterItemData, "E1MARAM", "MATNR", stringCheck(map5.containsKey("MATNR") ? map5.get("MATNR").toString() : ___KEY_NOT_FOUND), "(null)");
                                            addToDataSet(dsMaterialMasterItemData, "E1MARAM", "MTART", stringCheck(map5.containsKey("MTART") ? map5.get("MTART").toString() : ___KEY_NOT_FOUND), "(null)");
                                            addToDataSet(dsMaterialMasterItemData, "E1MARAM", "BISMT", stringCheck(map5.containsKey("BISMT") ? map5.get("BISMT").toString() : ___KEY_NOT_FOUND), "(null)");
                                            addToDataSet(dsMaterialMasterItemData, "E1MARAM", "EAN11", stringCheck(map5.containsKey("EAN11") ? map5.get("EAN11").toString() : ___KEY_NOT_FOUND), "(null)");
                                            /*************************
                                             * Added for MDLIMS -908 : Alcon CoA report date format
                                             * Added By : KG
                                             * Added on : 31-Aug-2021
                                             *************************/
                                            for (Map.Entry<String, Object> subEntityZ18CMOCLFM : map5.entrySet()) {
                                                if (subEntityZ18CMOCLFM.getKey().equalsIgnoreCase("Z18CMOCLFM")) {
                                                    if (subEntityZ18CMOCLFM.getValue() instanceof Map) {
                                                        Map<String, Object> mapZ18CMOCLFM = ((Map<String, Object>) subEntityZ18CMOCLFM.getValue());
                                                        for (Map.Entry<String, Object> subEntityZ18CMAUSPM : mapZ18CMOCLFM.entrySet()) {
                                                            if (subEntityZ18CMAUSPM.getKey().equalsIgnoreCase("Z18CMAUSPM")) {
                                                                // If segment is an Array
                                                                if (subEntityZ18CMAUSPM.getValue() instanceof ArrayList) {
                                                                    ArrayList<Object> alZ18CMAUSPM = (ArrayList<Object>) subEntityZ18CMAUSPM.getValue();
                                                                    boolean isKeyFound = false;
                                                                    for (int listCount = 0; listCount < alZ18CMAUSPM.size(); listCount++) {
                                                                        // Getting each segment in a Map object
                                                                        Map<String, Object> mapZ18CMAUSPM = ((Map<String, Object>) alZ18CMAUSPM.get(listCount));
                                                                        if (mapZ18CMAUSPM.get("ATNAM").toString().equalsIgnoreCase("Z8C_PRODUCT_LBL_DATE_FORMAT")) {
                                                                            // Checking if ATFLV key exists in current segment / Map object
                                                                            // If yes store the row number +1
                                                                            // Else NO_KEY_FOUND
                                                                            addToDataSet(dsMaterialMasterItemData, "Z18CMAUSPM", "ATFLV", stringCheck(mapZ18CMAUSPM.containsKey("ATFLV") ? String.valueOf(new BigDecimal(mapZ18CMAUSPM.get("ATFLV").toString()).intValue()) : ___KEY_NOT_FOUND), "(null)");
                                                                            isKeyFound = true;
                                                                        }
                                                                    }
                                                                    if (isKeyFound == false) {
                                                                        addToDataSet(dsMaterialMasterItemData, "Z18CMAUSPM", "ATFLV", ___KEY_NOT_FOUND, "(null)");
                                                                    }

                                                                } else if (subEntityZ18CMAUSPM.getValue() instanceof Map) {
                                                                    // If segment is an sinle segment
                                                                    // Getting each segment in a Map object
                                                                    Map<String, Object> mapZ18CMAUSPM = ((Map<String, Object>) subEntityZ18CMAUSPM.getValue());
                                                                    if (mapZ18CMAUSPM.get("ATNAM").toString().equalsIgnoreCase("Z8C_PRODUCT_LBL_DATE_FORMAT")) {
                                                                        // Checking if ATFLV key exists in current segment / Map object
                                                                        // If yes store the row number +1
                                                                        // Else NO_KEY_FOUND
                                                                        addToDataSet(dsMaterialMasterItemData, "Z18CMAUSPM", "ATFLV", stringCheck(mapZ18CMAUSPM.containsKey("ATFLV") ? Integer.toString(1) : ___KEY_NOT_FOUND), "(null)");
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            for (Map.Entry<String, Object> subEntity : map5.entrySet()) {
                                                if (subEntity.getKey().equalsIgnoreCase(E1MAKTM)) {
                                                    if (subEntity.getValue() instanceof Map) {
                                                        Map<String, Object> map6 = ((Map<String, Object>) subEntity.getValue());
                                                        if (map6.containsKey("SPRAS")) {
                                                            if (map6.get("SPRAS").toString().equalsIgnoreCase("E")) {
                                                                addToDataSet(dsMaterialMasterItemData, "E1MAKTM", "MAKTX", stringCheck(map6.containsKey("MAKTX") ? map6.get("MAKTX").toString() : ___KEY_NOT_FOUND), "(null)");
                                                            } else {
                                                                addToDataSet(dsMaterialMasterItemData, "E1MAKTM", "MAKTX", ___KEY_NOT_FOUND, "(null)");
                                                            }
                                                        } else {
                                                            addToDataSet(dsMaterialMasterItemData, "E1MAKTM", "MAKTX", ___KEY_NOT_FOUND, "(null)");
                                                        }

                                                    } else if (subEntity.getValue() instanceof ArrayList) {
                                                        ArrayList<Object> newList = (ArrayList<Object>) subEntity.getValue();
                                                        int notFound = 0;//0 for notfound and 1 for found.
                                                        for (int listCount = 0; listCount < newList.size(); listCount++) {
                                                            Map<String, Object> map6 = ((Map<String, Object>) newList.get(listCount));
                                                            if (map6.containsKey("SPRAS")) {
                                                                if (map6.get("SPRAS").toString().equalsIgnoreCase("E")) {
                                                                    addToDataSet(dsMaterialMasterItemData, "E1MAKTM", "MAKTX", stringCheck(map6.containsKey("MAKTX") ? map6.get("MAKTX").toString() : ___KEY_NOT_FOUND), "(null)");
                                                                    notFound = 1;
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        if (notFound == 0) {
                                                            addToDataSet(dsMaterialMasterItemData, "E1MAKTM", "MAKTX", ___KEY_NOT_FOUND, "(null)");
                                                        }
                                                    }
                                                }
                                            }
                                            for (Map.Entry<String, Object> subEntity : map5.entrySet()) {
                                                if (subEntity.getKey().equalsIgnoreCase(E1MARCM)) {
                                                    if (subEntity.getValue() instanceof Map) {
                                                        Map<String, Object> map7 = ((Map<String, Object>) subEntity.getValue());
                                                        addToDataSet(dsMaterialMasterItemData, "E1MARCM", "WERKS", stringCheck(map7.containsKey("WERKS") ? map7.get("WERKS").toString() : ___KEY_NOT_FOUND), "(null)");

                                                        for (Map.Entry<String, Object> subEntityE1MARCM : map7.entrySet()) {
                                                            if (subEntityE1MARCM.getKey().equalsIgnoreCase(Z18CMMARCM)) {
                                                                if (subEntityE1MARCM.getValue() instanceof Map) {
                                                                    Map<String, Object> map8 = ((Map<String, Object>) subEntityE1MARCM.getValue());
                                                                    addToDataSet(dsMaterialMasterItemData, "Z18CMMARCM", "ZZBISMT", stringCheck(map8.containsKey("ZZBISMT") ? map8.get("ZZBISMT").toString() : ___KEY_NOT_FOUND), stringCheck(map7.containsKey("WERKS") ? map7.get("WERKS").toString() : ___KEY_NOT_FOUND));
                                                                }
                                                            }
                                                        }
                                                        addMaterialDataToTables(dsMaterialMasterItemData, 0, 0, payloadData);
                                                    } else if (subEntity.getValue() instanceof ArrayList) {
                                                        ArrayList<Object> list1 = (ArrayList<Object>) subEntity.getValue();
                                                        // Delete row HashMap
                                                        for (int i = 0; i < list1.size(); i++) {
                                                            Map<String, Object> map9 = ((Map<String, Object>) list1.get(i));
                                                            addToDataSet(dsMaterialMasterItemData, "E1MARCM", "WERKS", stringCheck(map9.containsKey("WERKS") ? map9.get("WERKS").toString() : ___KEY_NOT_FOUND), "(null)");
                                                            Map<String, Object> map10 = new HashMap<String, Object>();
                                                            for (Map.Entry<String, Object> subEntityE1MARCM : map9.entrySet()) {
                                                                if (subEntityE1MARCM.getKey().equalsIgnoreCase(Z18CMMARCM)) {
                                                                    if (subEntityE1MARCM.getValue() instanceof Map) {
                                                                        map10 = ((Map<String, Object>) subEntityE1MARCM.getValue());
                                                                        addToDataSet(dsMaterialMasterItemData, "Z18CMMARCM", "ZZBISMT", stringCheck(map10.containsKey("ZZBISMT") ? map10.get("ZZBISMT").toString() : ___KEY_NOT_FOUND), stringCheck(map9.containsKey("WERKS") ? map9.get("WERKS").toString() : ___KEY_NOT_FOUND));
                                                                    }
                                                                }
                                                                //
                                                            }
                                                            // Creating DataSet per PLANT level
                                                            addMaterialDataToTables(dsMaterialMasterItemData, 0, i, payloadData);
                                                            // Deleting PLANT
                                                            plDelRow.clear();
                                                            plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, "E1MARCM");
                                                            plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, "WERKS");
                                                            plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, stringCheck(map9.containsKey("WERKS") ? map9.get("WERKS").toString() : ___KEY_NOT_FOUND));
                                                            dsMaterialMasterItemData.deleteRow(dsMaterialMasterItemData.findRow(plDelRow));
                                                            // Deleting Local Material Code
                                                            plDelRow.clear();
                                                            plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, "Z18CMMARCM");
                                                            plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, "ZZBISMT");
                                                            plDelRow.setProperty(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, stringCheck(map10.containsKey("ZZBISMT") ? map10.get("ZZBISMT").toString() : ___KEY_NOT_FOUND));
                                                            dsMaterialMasterItemData.deleteRow(dsMaterialMasterItemData.findRow(plDelRow));


                                                        }
                                                        //addMaterialDataToTables(dsMaterialMasterItemData, 0, payloadData);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }

    /**
     * @param idocCount
     * @param plantCount
     * @param payloadData
     * @throws SapphireException
     */

    private void addTranData(int idocCount, int plantCount, String payloadData) throws SapphireException {
        PropertyList props = new PropertyList();
        // Below check is given because we want to restrict
        // Trnsaction record creation only once
        if (idocCount == 0 && plantCount == 0) {
            props.clear();
            props.setProperty(AddSDI.PROPERTY_SDCID, "IntfTrans");
            props.setProperty(AddSDI.PROPERTY_COPIES, Integer.toString(1));
            props.setProperty("status", "CREATED");
            props.setProperty("transdata", payloadData);
            props.setProperty("transname", SAPProcessController.SERVICE_MATERIAL_MASTER);
            props.setProperty("transdirection", "INBOUND");
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            newTransId = props.getProperty("newkeyid1");
        }
    }

    /**
     * @param dsMaterialMasterItemData
     */

    public void addMaterialDataToTables(DataSet dsMaterialMasterItemData, int idocCount, int plantCount, String payloadData) throws SapphireException {
        // Create Trnsaction Item if IDOC =0 and Plant# = 0
        addTranData(idocCount, plantCount, payloadData);
        // LIMS Key Name
        String key1Name = "Local Material Code";
        String key2Name = "Material Number";
        // LIMS Key Values
        String key1Value = (null == SAPUtil.getColumnValue(dsMaterialMasterItemData, "Z18CMMARCM", "ZZBISMT")) ? "" : SAPUtil.getColumnValue(dsMaterialMasterItemData, "Z18CMMARCM", "ZZBISMT");
        String key2Value = (null == SAPUtil.getColumnValue(dsMaterialMasterItemData, "E1MARAM", "MATNR")) ? "" : SAPUtil.getColumnValue(dsMaterialMasterItemData, "E1MARAM", "MATNR");
        // Data Payload
        String xmlDataPayload = (null == dsMaterialMasterItemData) ? "" : dsMaterialMasterItemData.toXML();
        //  Material Master can have multiple PLANT
        String[] plantIds = StringUtil.split(SAPUtil.getColumnValue(dsMaterialMasterItemData, "E1MARCM", "WERKS"), ";");
        String newTransItemId = "";
        PropertyList props = new PropertyList();
        // Looping through each PLANT
        for (int plantNo = 0; plantNo < plantIds.length; plantNo++) {
            //Inserting into IntfTransItem
            props.clear();
            props.setProperty(AddSDI.PROPERTY_SDCID, "IntfTransItem");
            props.setProperty(AddSDI.PROPERTY_COPIES, Integer.toString(1));
            props.setProperty("key1name", key1Name);
            props.setProperty("key1value", key1Value);
            props.setProperty("key2name", key2Name);
            props.setProperty("key2value", key2Value);
            props.setProperty("itemdata", xmlDataPayload);
            props.setProperty("status", "CREATED");
            props.setProperty("intftransid", newTransId);
            props.setProperty("transname", SAPProcessController.SERVICE_MATERIAL_MASTER);
            props.setProperty("plant", plantIds[plantNo]);

            props.setProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
            //newTransItemId = props.getProperty("newkeyid1");
        }
    }

    /**
     * Description : This method checks if a string value is null and if found null,updates it with a blank value and returns the string.
     *
     * @param check
     * @return
     */

    public String stringCheck(String check) {
        if (check.equals(null)) {
            check = "";
            return check;
        } else {
            return check;
        }
    }

    /**
     * Description : This method takes all the values as input and adds those values to a dataset.
     *
     * @param ds
     * @param entityname
     * @param column
     * @param value
     * @param group
     * @throws SapphireException
     */

    public void addToDataSet(DataSet ds, String entityname, String column, String value, String group) {
        int rowId = ds.addRow();
        ds.setValue(rowId, SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, entityname);
        ds.setValue(rowId, SAPUtil.INPUT_DATASET_COLUMN_COL_ID, column.toUpperCase());
        ds.setValue(rowId, SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, value);
        ds.setValue(rowId, SAPUtil.INPUT_DATASET_COLUMN_GROUP, group);
    }

    /**
     * Description : This method converts the Lot_Receipt payload into Labvantage dataset and then converts it into XML string and also updates the intftrans and intftransitem SDCs.
     *
     * @param inspLotId
     * @param batchId
     * @param dsLotReceiptItemData
     * @throws SapphireException
     */

    public void loadTransItemDataForLot(String inspLotId, String batchId, DataSet dsLotReceiptItemData, int i, String payloadData, String site) throws SapphireException {
        DataSet dsTransItem = new DataSet();
        dsTransItem.addColumn("key1name", DataSet.STRING);
        dsTransItem.addColumn("key1value", DataSet.STRING);
        dsTransItem.addColumn("key2name", DataSet.STRING);
        dsTransItem.addColumn("key2value", DataSet.STRING);
        dsTransItem.addColumn("status", DataSet.STRING);
        dsTransItem.addColumn("itempayload", DataSet.STRING);
        dsTransItem.addColumn("transdesc", DataSet.STRING);
        dsTransItem.addColumn("itempayloadtranstable", DataSet.STRING);
        dsTransItem.addColumn("limskeyname", DataSet.STRING);
        dsTransItem.addColumn("limskeyvalue", DataSet.STRING);
        dsTransItem.addColumn("site", DataSet.STRING);
        dsTransItem.addColumn("transdirection", DataSet.STRING);

        int row = dsTransItem.addRow();
        dsTransItem.setValue(row, "key1name", "Inspection Lot");
        dsTransItem.setValue(row, "key1value", inspLotId);
        dsTransItem.setValue(row, "status", "CREATED");
        dsTransItem.setValue(row, "transdesc", SAPProcessController.SERVICE_LOT_RECEIPT);
        dsTransItem.setValue(row, "key2name", "SAP Batch");
        dsTransItem.setValue(row, "key2value", batchId);
        dsTransItem.setValue(row, "itempayload", dsLotReceiptItemData.toXML());
        dsTransItem.setValue(row, "itempayloadtranstable", payloadData);//todo json string or object
        dsTransItem.setValue(row, "limskeyname", "LIMS Batch");
        dsTransItem.setValue(row, "limskeyvalue", "");
        dsTransItem.setValue(row, "site", site);
        dsTransItem.setValue(row, "transdirection", "INBOUND");

        //Inserting into IntfTrans
        if (i == 0) {
            PropertyList props1 = new PropertyList();
            props1.setProperty(AddSDI.PROPERTY_SDCID, "IntfTrans");
            props1.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsTransItem.size()));
            //props1.setProperty("keyname", dsTransItem.getColumnValues("key1name", ";"));
            //props1.setProperty("keyvalue", dsTransItem.getColumnValues("key1value", ";"));
            props1.setProperty("status", dsTransItem.getColumnValues("status", ";"));
            props1.setProperty("transdata", dsTransItem.getColumnValues("itempayloadtranstable", ";"));
            //props1.setProperty("limskeyname", dsTransItem.getColumnValues("limskeyname", ";"));
            //props1.setProperty("limskeyvalue", dsTransItem.getColumnValues("limskeyvalue", ";"));
            props1.setProperty("transname", dsTransItem.getColumnValues("transdesc", ";"));
            props1.setProperty("transdirection", dsTransItem.getColumnValues("transdirection", ";"));
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props1);
            newTransId = props1.getProperty("newkeyid1");
        }

        //Inserting into IntfTransItem
        PropertyList props = new PropertyList();
        props.setProperty(AddSDI.PROPERTY_SDCID, "IntfTransItem");
        props.setProperty(AddSDI.PROPERTY_COPIES, String.valueOf(dsTransItem.size()));
        props.setProperty("key1name", dsTransItem.getColumnValues("key2name", ";"));
        props.setProperty("key1value", dsTransItem.getColumnValues("key2value", ";"));
        props.setProperty("key2name", dsTransItem.getColumnValues("key1name", ";"));
        props.setProperty("key2value", dsTransItem.getColumnValues("key1value", ";"));
        props.setProperty("itemdata", dsTransItem.getColumnValues("itempayload", ";"));
        props.setProperty("status", dsTransItem.getColumnValues("status", ";"));
        props.setProperty("limskeyname", dsTransItem.getColumnValues("limskeyname", ";"));
        props.setProperty("limskeyvalue", dsTransItem.getColumnValues("limskeyvalue", ";"));
        props.setProperty("intftransid", newTransId);
        props.setProperty("transname", dsTransItem.getColumnValues("transdesc", ";"));
        props.setProperty("plant", dsTransItem.getColumnValues("site", ";"));//plant value is site
        props.setProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props);
        String newTransItemId = props.getProperty("newkeyid1");

    }

    /**
     * Description : This method loads the required data from the QAIVC lot table and passes all the values to the next function.
     *
     * @param lotMap
     * @throws SapphireException
     */

    public void lotTableQAIVC(Map<String, Object> lotMap, String payloadData, String msgStageId) throws SapphireException {
        dataFoundFlag = true; // resetting the datafound flag for QAIVC table.
        String T_QAIVCTAB = "T_QAIVCTAB";
        String inspLotId;
        String batchId;
        String fieldName;
        String fieldValue;
        String site;
        for (Map.Entry<String, Object> QIRF_SEND_REQUIRMENTS_GET_DAT2 : lotMap.entrySet()) {
            if (QIRF_SEND_REQUIRMENTS_GET_DAT2.getValue() instanceof Map) {
                Map<String, Object> tableMap = ((Map<String, Object>) QIRF_SEND_REQUIRMENTS_GET_DAT2.getValue());
                for (Map.Entry<String, Object> tables : tableMap.entrySet()) {
                    if (tables.getKey().equalsIgnoreCase(T_QAIVCTAB)) {
                        if (tables.getValue() == null || tables.getValue().equals("")) {
                            dataFoundFlag = false;
                            break;
                        }
                        if (tables.getValue() instanceof Map) {
                            Map<String, Object> itemMap = ((Map<String, Object>) tables.getValue());
                            for (Map.Entry<String, Object> items : itemMap.entrySet()) {
                                if (items.getValue() instanceof ArrayList) {
                                    ArrayList<Object> itemList = (ArrayList<Object>) items.getValue();
                                    for (int i = 0; i < itemList.size(); i++) {
                                        DataSet dsLotReceiptItemData = new DataSet();
                                        dsLotReceiptItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, DataSet.STRING);
                                        dsLotReceiptItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, DataSet.STRING);
                                        dsLotReceiptItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, DataSet.STRING);
                                        dsLotReceiptItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_GROUP, DataSet.STRING);
                                        Map<String, String> itemValues = (Map<String, String>) itemList.get(i);
                                        inspLotId = itemValues.get("PRUEFLOS");
                                        batchId = itemValues.get("CHARG");
                                        site = itemValues.get("WERK");

                                        for (Map.Entry<String, String> values : itemValues.entrySet()) {
                                            fieldName = values.getKey();
                                            fieldValue = values.getValue();
                                            addToDataSet(dsLotReceiptItemData, "QAIVC", fieldName, fieldValue, "(null)");
                                        }

                                        // *********** Release 2: Phase 1:::  Added for VisionCare RM Lot Receipt
                                        // *********** Below flag is to check whether LICHN --> SAP Batch Lot present ?
                                        if (dsLotReceiptItemData.findRow(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, "LICHN") == -1) {
                                            // ********* Adding LICHN / SAP Lot Batch # with Key Not Found value
                                            addToDataSet(dsLotReceiptItemData, "QAIVC", "LICHN", ___KEY_NOT_FOUND, "(null)");
                                        }
                                        if (dsLotReceiptItemData.findRow(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, "LIFNR") == -1) {
                                            // ********* Adding LICHN / SAP Lot Batch # with Key Not Found value
                                            addToDataSet(dsLotReceiptItemData, "QAIVC", "LIFNR", ___KEY_NOT_FOUND, "(null)");
                                        }
                                        lotTableQAIMV(lotMap, inspLotId, batchId, dsLotReceiptItemData, i, payloadData, site, msgStageId);
                                    }

                                } else if (items.getValue() instanceof Map) {
                                    DataSet dsLotReceiptItemData = new DataSet();
                                    dsLotReceiptItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_ENTITY_NAME, DataSet.STRING);
                                    dsLotReceiptItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, DataSet.STRING);
                                    dsLotReceiptItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_COL_VALUE, DataSet.STRING);
                                    dsLotReceiptItemData.addColumn(SAPUtil.INPUT_DATASET_COLUMN_GROUP, DataSet.STRING);

                                    Map<String, String> itemValues = (Map<String, String>) items.getValue();
                                    inspLotId = itemValues.get("PRUEFLOS");
                                    batchId = itemValues.get("CHARG");
                                    site = itemValues.get("WERK");
                                    for (Map.Entry<String, String> values : itemValues.entrySet()) {
                                        fieldName = values.getKey();
                                        fieldValue = values.getValue();
                                        addToDataSet(dsLotReceiptItemData, "QAIVC", fieldName, fieldValue, "(null)");
                                    }
                                    // *********** Release 2: Phase 1:::  Added for VisionCare RM Lot Receipt
                                    // *********** Below flag is to check whether LICHN --> SAP Batch Lot present ?
                                    if (dsLotReceiptItemData.findRow(SAPUtil.INPUT_DATASET_COLUMN_COL_ID, "LICHN") == -1) {
                                        // ********* Adding LICHN / SAP Lot Batch # with Key Not Found value
                                        addToDataSet(dsLotReceiptItemData, "QAIVC", "LICHN", ___KEY_NOT_FOUND, "(null)");
                                    }
                                    lotTableQAIMV(lotMap, inspLotId, batchId, dsLotReceiptItemData, 0, payloadData, site, msgStageId);
                                }
                            }

                        }
                    }
                }
            }
        }
        if (!dataFoundFlag) {
            PropertyList props1 = new PropertyList();
            props1.setProperty(AddSDI.PROPERTY_SDCID, "IntfTrans");
            props1.setProperty(AddSDI.PROPERTY_COPIES, Integer.toString(1));
            props1.setProperty("status", "NO_DATA_RECEIVED");
            props1.setProperty("transname", SAPProcessController.SERVICE_LOT_RECEIPT);
            props1.setProperty("transdirection", "INBOUND");
            props1.setProperty("saplvmessagestageid", msgStageId);
            props1.setProperty("activeflag", "N");
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props1);

            //--- Mark SAPLVMessageStagID Inactive ---//
            updateSAPLVMessageStageActiveFlag(msgStageId, "N");

        }

    }

    /**
     * Description : This method loads the required data from QAIMV lot table and passes all the values to the next function.
     *
     * @param lotMap
     * @param inspLotId
     * @param batchId
     * @param dsLotReceiptItemData
     * @throws SapphireException
     */

    public void lotTableQAIMV(Map<String, Object> lotMap, String inspLotId, String batchId, DataSet dsLotReceiptItemData, int i, String payloadData, String site, String msgStageId) throws SapphireException {
        String T_QAIMVTAB = "T_QAIMVTAB";
        String mvinspLotId;
        String fieldName;
        String fieldValue;
        for (Map.Entry<String, Object> QIRF_SEND_REQUIRMENTS_GET_DAT2 : lotMap.entrySet()) {
            if (QIRF_SEND_REQUIRMENTS_GET_DAT2.getValue() instanceof Map) {
                Map<String, Object> tableMap = ((Map<String, Object>) QIRF_SEND_REQUIRMENTS_GET_DAT2.getValue());
                for (Map.Entry<String, Object> tables : tableMap.entrySet()) {
                    if (tables.getKey().equalsIgnoreCase(T_QAIMVTAB)) {
                        if (tables.getValue() == null || tables.getValue().equals("")) {
                            dataFoundFlag = false;
                            break;
                        }
                        if (tables.getValue() instanceof Map) {
                            Map<String, Object> itemMap = ((Map<String, Object>) tables.getValue());
                            for (Map.Entry<String, Object> items : itemMap.entrySet()) {
                                if (items.getValue() instanceof ArrayList) {
                                    ArrayList<Object> itemList = (ArrayList<Object>) items.getValue();
                                    int count = 1;
                                    for (int j = 0; j < itemList.size(); j++) {
                                        Map<String, String> itemValues = (Map<String, String>) itemList.get(j);
                                        mvinspLotId = itemValues.get("PRUEFLOS");
                                        if (mvinspLotId.equals(inspLotId) == true) {
                                            for (Map.Entry<String, String> values : itemValues.entrySet()) {
                                                fieldName = values.getKey();
                                                fieldValue = values.getValue();
                                                addToDataSet(dsLotReceiptItemData, "QAIMV", fieldName, fieldValue, "group" + Integer.toString(count));
                                            }
                                            count++;
                                        } else continue;
                                    }
                                } else if (items.getValue() instanceof Map) {
                                    Map<String, String> itemValues = (Map<String, String>) items.getValue();
                                    mvinspLotId = itemValues.get("PRUEFLOS");
                                    if (mvinspLotId.equals(inspLotId) == true) {
                                        for (Map.Entry<String, String> values : itemValues.entrySet()) {
                                            fieldName = values.getKey();
                                            fieldValue = values.getValue();
                                            addToDataSet(dsLotReceiptItemData, "QAIMV", fieldName, fieldValue, "(null)");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (dataFoundFlag) {
            lotTableQAICA(lotMap, inspLotId, batchId, dsLotReceiptItemData, i, payloadData, site, msgStageId);
        } else {
            PropertyList props1 = new PropertyList();
            props1.setProperty(AddSDI.PROPERTY_SDCID, "IntfTrans");
            props1.setProperty(AddSDI.PROPERTY_COPIES, Integer.toString(1));
            props1.setProperty("status", "NO_DATA_RECEIVED");
            props1.setProperty("transname", SAPProcessController.SERVICE_LOT_RECEIPT);
            props1.setProperty("transdirection", "INBOUND");
            props1.setProperty("saplvmessagestageid", msgStageId);
            props1.setProperty("activeflag", "N");
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props1);
            dataFoundFlag = true;

            //--- Mark SAPLVMessageStagID Inactive ---//
            updateSAPLVMessageStageActiveFlag(msgStageId, "N");

        }
    }

    /**
     * Description : This method loads the required values from the QAICA lot table and passes all the values into loadTransItemDataForLot function.
     *
     * @param lotMap
     * @param inspLotId
     * @param batchId
     * @param dsLotReceiptItemData
     * @throws SapphireException
     */

    public void lotTableQAICA(Map<String, Object> lotMap, String inspLotId, String batchId, DataSet dsLotReceiptItemData, int i, String payloadData, String site, String msgStageId) throws SapphireException {
        String T_QAICATAB = "T_QAICATAB";
        String fieldName;
        String fieldValue;
        for (Map.Entry<String, Object> QIRF_SEND_REQUIRMENTS_GET_DAT2 : lotMap.entrySet()) {
            if (QIRF_SEND_REQUIRMENTS_GET_DAT2.getValue() instanceof Map) {
                Map<String, Object> tableMap = ((Map<String, Object>) QIRF_SEND_REQUIRMENTS_GET_DAT2.getValue());
                for (Map.Entry<String, Object> tables : tableMap.entrySet()) {
                    if (tables.getKey().equalsIgnoreCase(T_QAICATAB)) {
                        if (tables.getValue() == null || tables.getValue().equals("")) {
                            dataFoundFlag = false;
                            break;
                        }
                        if (tables.getValue() instanceof Map) {
                            Map<String, Object> itemMap = ((Map<String, Object>) tables.getValue());
                            for (Map.Entry<String, Object> items : itemMap.entrySet()) {
                                if (items.getValue() instanceof ArrayList) {
                                    ArrayList<Object> itemList = (ArrayList<Object>) items.getValue();
                                    for (int k = 0; k < itemList.size(); k++) {
                                        Map<String, String> itemValues = (Map<String, String>) itemList.get(k);
                                        for (Map.Entry<String, String> values : itemValues.entrySet()) {
                                            fieldName = values.getKey();
                                            fieldValue = values.getValue();
                                            addToDataSet(dsLotReceiptItemData, "QAICA", fieldName, fieldValue, "group" + Integer.toString(k + 1));
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (dataFoundFlag) {
            loadTransItemDataForLot(inspLotId, batchId, dsLotReceiptItemData, i, payloadData, site);
        } else {
            PropertyList props1 = new PropertyList();
            props1.setProperty(AddSDI.PROPERTY_SDCID, "IntfTrans");
            props1.setProperty(AddSDI.PROPERTY_COPIES, Integer.toString(1));
            props1.setProperty("status", "NO_DATA_RECEIVED");
            props1.setProperty("transname", SAPProcessController.SERVICE_LOT_RECEIPT);
            props1.setProperty("transdirection", "INBOUND");
            props1.setProperty("saplvmessagestageid", msgStageId);
            props1.setProperty("activeflag", "N");
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, props1);
            dataFoundFlag = true;

            //--- Mark SAPLVMessageStagID Inactive ---//
            updateSAPLVMessageStageActiveFlag(msgStageId, "N");

        }
    }

    /**
     * Description : This method takes the lotReceipt JSON hashmap as input and converts it into Labvantage dataset.
     *
     * @param map
     * @return
     */

    public static DataSet convertDataSetForLotReceipt(Map<String, Object> map) {
        DataSet ds = new DataSet();
        ds.addColumn("EntityName", DataSet.STRING);
        ds.addColumn("ColName", DataSet.STRING);
        ds.addColumn("ColValue", DataSet.STRING);
        ds.addColumn("Group", DataSet.STRING);
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (entry.getValue() instanceof Map) {
                Map<String, Object> map1 = ((Map<String, Object>) entry.getValue());
                for (Map.Entry<String, Object> entry1 : map1.entrySet()) {
                    if (entry1.getValue() instanceof Map) {
                        Map<String, ArrayList<Object>> map2 = ((Map<String, ArrayList<Object>>) entry1.getValue());
                        for (Map.Entry<String, ArrayList<Object>> entry2 : map2.entrySet()) {
                            if (entry2.getValue() instanceof ArrayList) {
                                ArrayList<Object> list1 = entry2.getValue();
                                for (int i = 0, j = 1; i < list1.size(); i++, j++) {
                                    String group = Integer.toString(j);
                                    Map<String, String> map3 = (Map<String, String>) list1.get(i);
                                    for (Map.Entry<String, String> entry3 : map3.entrySet()) {
                                        int row1 = ds.addRow();
                                        ds.setValue(row1, "EntityName", entry1.getKey());
                                        ds.setValue(row1, "Group", "group" + group);
                                        ds.setValue(row1, "ColName", entry3.getKey());
                                        ds.setValue(row1, "ColValue", entry3.getValue());
                                    }
                                }
                            }
                        }
                    }
                }

            }
        }
        //ds.showData();
        return ds;
    }

    /**
     * Description : This method takes the BatchMaster JSON hashmap as input and converts it into Labvantage dataset.
     *
     * @param map
     * @return
     */

    public static DataSet convertDataSetForBatchMaster(Map<String, Object> map) {
        DataSet ds = new DataSet();
        ds.addColumn("EntityName", DataSet.STRING);
        ds.addColumn("ColName", DataSet.STRING);
        ds.addColumn("ColValue", DataSet.STRING);
        ds.addColumn("Group", DataSet.STRING);
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (entry.getValue() instanceof Map) {
                Map<String, Object> map1 = ((Map<String, Object>) entry.getValue());
                for (Map.Entry<String, Object> entry1 : map1.entrySet()) {
                    if (entry1.getValue() instanceof Map) {
                        Map<String, Object> map2 = ((Map<String, Object>) entry1.getValue());
                        for (Map.Entry<String, Object> entry2 : map2.entrySet()) {
                            if (entry2.getValue() instanceof Map) {
                                Map<String, Object> map3 = ((Map<String, Object>) entry2.getValue());
                                for (Map.Entry<String, Object> entry3 : map3.entrySet()) {
                                    if (entry3.getValue() instanceof Map) {
                                        Map<String, Object> map4 = ((Map<String, Object>) entry3.getValue());
                                        for (Map.Entry<String, Object> entry4 : map4.entrySet()) {
                                            if (entry4.getValue() instanceof Map) {
                                                Map<String, Object> map5 = ((Map<String, Object>) entry4.getValue());
                                                for (Map.Entry<String, Object> entry5 : map5.entrySet()) {
                                                    int row1 = ds.addRow();
                                                    ds.setValue(row1, "EntityName", entry4.getKey());
                                                    ds.setValue(row1, "ColName", entry5.getKey());
                                                    ds.setValue(row1, "ColValue", entry5.getValue().toString());
                                                    ds.setValue(row1, "Group", "null");
                                                }
                                            } else if (entry4.getValue() instanceof ArrayList) {
                                                ArrayList<Object> list1 = (ArrayList<Object>) entry4.getValue();
                                                for (int i = 0, j = 1; i < list1.size(); i++, j++) {
                                                    String group = Integer.toString(j);
                                                    Map<String, String> map6 = (Map<String, String>) list1.get(i);
                                                    for (Map.Entry<String, String> entry6 : map6.entrySet()) {
                                                        int row1 = ds.addRow();
                                                        ds.setValue(row1, "EntityName", entry4.getKey());
                                                        ds.setValue(row1, "ColName", entry6.getKey());
                                                        ds.setValue(row1, "ColValue", entry6.getValue().toString());
                                                        ds.setValue(row1, "Group", "group" + j);
                                                    }
                                                }

                                            } else {
                                                int row1 = ds.addRow();
                                                ds.setValue(row1, "EntityName", entry3.getKey());
                                                ds.setValue(row1, "ColName", entry4.getKey());
                                                ds.setValue(row1, "ColValue", entry4.getValue().toString());
                                                ds.setValue(row1, "Group", "null");
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        // ds.showData();
        // ds.toXML();
        return ds;

    }

    /**
     * Description : This method converts the incoming JSON payload into a hashmap.
     *
     * @param json
     * @return
     * @throws JSONException
     */

    public static Map<String, Object> jsonToMap(JSONObject json) throws JSONException {
        Map<String, Object> retMap = new HashMap<String, Object>();

        if (json != JSONObject.NULL) {
            retMap = toMap(json);
        }
        return retMap;
    }

    /**
     * Description : This method adds the JSON objects into a hashmap.
     *
     * @param object
     * @return
     * @throws JSONException
     */

    public static Map<String, Object> toMap(JSONObject object) throws JSONException {
        Map<String, Object> map = new HashMap<String, Object>();
        Iterator<String> keysItr = object.keys();
        while (keysItr.hasNext()) {
            String key = keysItr.next();
            Object value = object.get(key);
            if (value instanceof JSONArray) {
                value = toList((JSONArray) value);
            } else if (value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            map.put(key, value);
        }
        return map;

    }

    /**
     * Description : This method adds the JSON arrays into a arraylist.
     *
     * @param array
     * @return
     * @throws JSONException
     */

    public static List<Object> toList(JSONArray array) throws JSONException {
        List<Object> list = new ArrayList<Object>();
        for (int i = 0; i < array.length(); i++) {
            Object value = array.get(i);
            if (value instanceof JSONArray) {
                value = toList((JSONArray) value);
            } else if (value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            list.add(value);
        }
        return list;
    }

    /**
     * Update activeflag column of SAPLVMessageStage table - to hide rows from list page for data status "NO_DATA_RECEIVED"
     *
     * @param msgStageId
     * @param activeFlag
     * @throws SapphireException
     */
    private void updateSAPLVMessageStageActiveFlag(String msgStageId, String activeFlag) throws SapphireException {
        String updateSql = "update u_saplvmessagestage set activeflag='N' where u_saplvmessagestageid = ?";

        PreparedStatement psMsgUpdate = database.prepareStatement(updateSql.toString());
        try {
            psMsgUpdate.setString(1, msgStageId);
            psMsgUpdate.addBatch();
        } catch (SQLException ex) {
            throw new SapphireException("Unable to set Prepared Statement:Reason:" + ex.getMessage());
        }

        try {
            psMsgUpdate.executeBatch();
            psMsgUpdate.clearParameters();
            psMsgUpdate.clearBatch();
            psMsgUpdate.close();
        } catch (SQLException e) {
            throw new SapphireException("Failed to execute Staging update:Reason:" + e.getMessage());
        } finally {
            try {
                psMsgUpdate.close();
            } catch (SQLException e) {
//                        e.printStackTrace();
            }
        }
    }

}



