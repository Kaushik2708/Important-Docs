package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.ddt.IntfTransItem;
import labvantage.custom.alcon.sap.util.ErrorMessageUtil;
import labvantage.custom.alcon.sap.util.SAPUtil;
import sapphire.SapphireException;
import sapphire.action.AddOrEditSDI;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

/**
 * $Author: GHOSHKA1 $
 * $Date: 2021-09-01 08:27:25 -0500 (Wed, 01 Sep 2021) $
 * $Revision: 537 $
 */

/********************************************************************************************
 * $Revision: 537 $
 * Description:
 * This class is for Material Master Service.
 * This service is responsible for creation of Materials.
 *
 * @author Kaushik Ghosh
 * @version 1
 *******************************************************************************************/

public class MaterialMaster extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 537 $";
    public static final String ID = "MaterialMaster";
    public static final String VERSIONID = "1";
    // Entity Names
    private static final String __ENTITY_E1MARAM = "E1MARAM";
    private static final String __ENTITY_E1MAKTM = "E1MAKTM";
    private static final String __ENTITY_Z18CMMARCM = "Z18CMMARCM";
    private static final String __ENTITY_Z18CMAUSPM = "Z18CMAUSPM";
    // Col Names
    private static final String __SAPMATERIALNUMBER = "MATNR";
    private static final String __SAPMATERIALTYPE = "MTART";
    private static final String __OLDMATERIALCODE = "BISMT";
    private static final String __MATERIALDESC = "MAKTX";
    private static final String __SAPDATEFORMATSEQUENCE = "ATFLV";
    private static final String __SAPPLANT = "plantid";
    private static final String __LOCALMATERIALCODE = "ZZBISMT";
    private static final String __IANCODE = "EAN11";
    private static final String __PROP_MAT_SDC = "Material";
    private static final String __PROP_MAT_SITE_SDC = "MaterialSite";
    private String ___KEY_NOT_FOUND = "KEY_NOT_FOUND";

    /**
     * This is the main processing method.
     *
     * @param properties PropertyList containing all properties.
     * @throws SapphireException Throws OOB Sapphire exceptions.
     */
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("=============== Start Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
        String strDatapayload = properties.getProperty("itemdata", "");
        if ("".equals(strDatapayload)) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(ErrorMessageUtil.INVALID_SAP_DATA_PAYLOAD));
        }
        DataSet dsPayload = SAPUtil.getDataSetFromXMLString(strDatapayload);
        if (null == dsPayload) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_DATASET_FOUND) + " While creating DataSet from Material Master XML payload \n");
        }
        // Removing Leading zeros from SAP Material Numbers
        String strSAPMaterialNum = SAPUtil.removeLeadingZeroes(SAPUtil.getColumnValue(dsPayload, __ENTITY_E1MARAM, __SAPMATERIALNUMBER));
        String strSAPMaterialType = SAPUtil.getColumnValue(dsPayload, __ENTITY_E1MARAM, __SAPMATERIALTYPE);
        String strOldMaterialCode = SAPUtil.getColumnValue(dsPayload, __ENTITY_E1MARAM, __OLDMATERIALCODE);
        // Description may come as an array. Always taking the first element
        String strMaterialDesc = StringUtil.split(SAPUtil.getColumnValue(dsPayload, __ENTITY_E1MAKTM, __MATERIALDESC), ";")[0];
        // Geting sapdateformatsequence
        // If the sequence number i KEY_NOT_FOUND then replace that with 0 (Zero)
        String strSAPDateFormatSequence = SAPUtil.getColumnValue(dsPayload, __ENTITY_Z18CMAUSPM, __SAPDATEFORMATSEQUENCE);
        // Plant Id is taken from properties otherwise all plant id will come
        String strSAPPlant = properties.getProperty(__SAPPLANT, "");
        String strLocalMaterialCode = SAPUtil.getColumnValue(dsPayload, __ENTITY_Z18CMMARCM, __LOCALMATERIALCODE);
        String strIAN = SAPUtil.getColumnValue(dsPayload, __ENTITY_E1MARAM, __IANCODE);
        // Mandatory Field Checking
        if (___KEY_NOT_FOUND.equalsIgnoreCase(strSAPMaterialNum)) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(String.format(ErrorMessageUtil.MANDATORY_KEY_NOT_FOUND, "MATNR(Material Number)")));
        } else if (___KEY_NOT_FOUND.equalsIgnoreCase(strSAPMaterialType)) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(String.format(ErrorMessageUtil.MANDATORY_KEY_NOT_FOUND, "MTART(Material Type)")));
        } else if (___KEY_NOT_FOUND.equalsIgnoreCase(strMaterialDesc)) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(String.format(ErrorMessageUtil.MANDATORY_KEY_NOT_FOUND_FOR_EN_LANG, "MAKTX(Material Description)")));
        } else if (___KEY_NOT_FOUND.equalsIgnoreCase(strSAPPlant)) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.MANDATORY_KEY_NOT_FOUND, "WERK(SAP Plant)")));
        }
        // Checking for Null/Blank value
        if (null == strSAPMaterialNum || ("").equalsIgnoreCase(strSAPMaterialNum)) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.NULL_OR_BlANK_VALUE, "MATNR(SAP Material#).")));
        } else if (null == strSAPMaterialType || ("").equalsIgnoreCase(strSAPMaterialType)) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.NULL_OR_BlANK_VALUE, "MTART(SAP Material Type).")));
        } else if (null == strOldMaterialCode) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.NULL_VALUE_FOUND, "BISMT(Old Material Code)")));
        } else if (null == strMaterialDesc || ("").equalsIgnoreCase(strMaterialDesc)) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.NULL_OR_BlANK_VALUE, "MAKTX(SAP Material Description).")));
        } else if (null == strSAPPlant || ("").equalsIgnoreCase(strSAPPlant)) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.NULL_OR_BlANK_VALUE, "WERK(SAP Plant).")));
        } else if (null == strLocalMaterialCode) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.NULL_VALUE_FOUND, "ZZBISMT(Local Material Code).")));
        } else if (null == strIAN) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(ErrorMessageUtil.NULL_VALUE_FOUND, "EAN11(International Article Number).")));
        }

        String strLIMSMatId = "";
        // Check if LIMS Material Id is null or Blank or not
        if (strSAPMaterialNum == null || ("").equalsIgnoreCase(strSAPMaterialNum)) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.BlANK_VALUE + " For SAP Material"));
        } else {
            // If LIMS material doesn't exist, the create new one
            strLIMSMatId = addOrEditLIMSMaterial(strSAPMaterialNum, strMaterialDesc, strSAPMaterialType, strOldMaterialCode, strIAN,strSAPDateFormatSequence);
            // Check if LIMS Mat Id is blank or not (In case of EditSDI it will be BLANK)
            // If Yes the SAP Material Id Else LIMS Material Id Bcoz both are same
            strLIMSMatId = ("").equalsIgnoreCase(strLIMSMatId) ? strSAPMaterialNum : strLIMSMatId;
        }

        // If Plant + LIMS Mat Id Combination exists then Edit
        String limsMatSitesId = checkMaterialPlant(strLIMSMatId, strSAPPlant);
        if (!"".equalsIgnoreCase(limsMatSitesId)) {
            // Edit MaterialSites information
            addOrEditMaterialPlantDetails(limsMatSitesId, strLIMSMatId, strSAPPlant, strLocalMaterialCode, "edit");
        } else {
            // Adding Material plant information
            addOrEditMaterialPlantDetails("", strLIMSMatId, strSAPPlant, strLocalMaterialCode, "add");
        }
        // Updating Transaction item with LIMS Material id values.
        properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_LIMSKEYVALUE, strLIMSMatId);
        properties.setProperty(IntfTransItem.PROP_TRANS_ITEM_COL_STATUS, IntfTransItem.TRANS_ITEM_STATUS_COMPLETE);
    }

    /**
     * This method is used to get LIMS material id.
     *
     * @param sapMaterialId SAP Material Id.
     * @return Returns LIMS material id if exists.
     * @throws SapphireException Throws OOB Sapphire exception.
     */
    private String getLIMSMaterialID(String sapMaterialId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getLIMSMaterialID(method)");
        String limsMatId;
        String sqlText = "SELECT s_materialid FROM s_Material WHERE u_sapmatnumber = ?";
        DataSet dsMaterial = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{sapMaterialId});
        if (null == dsMaterial) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_DATASET_FOUND + ErrorMessageUtil.FAILED_EXECUTING_LIMS_MATERIALID + " For SAP Material Id: " + sapMaterialId));
        } else if (dsMaterial.getRowCount() > 1) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.MORE_THAN_ONE_LIMS_MATERIALID_FOUND + " For SAP Material Id: " + sapMaterialId));
        } else if (dsMaterial.getRowCount() == 0) {
            limsMatId = "";
        } else {
            limsMatId = dsMaterial.getValue(0, "s_materialid", "");
        }
        return limsMatId;
    }

    /**
     * This method is used to add or edit LIMS material.
     *
     * @param sapMaterialId   SAP Materid id.
     * @param sapMaterialDesc SAP Material description.
     * @param sapMaterialtype SAP Material type.
     * @param sapMatCode      SAP Material code.
     * @param ianCode         SAP Material International Article Number.
     * @param sapDateFormatSequence SAP Date Format Sequence
     * @return Returns LIMS material id.
     * @throws SapphireException Throws OOB Sapphire exceptions.
     */
    private String addOrEditLIMSMaterial(String sapMaterialId, String sapMaterialDesc, String sapMaterialtype, String sapMatCode, String ianCode, String sapDateFormatSequence) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside addLIMSMaterial(method)");
        PropertyList plMatProps = new PropertyList();
        plMatProps.setProperty(AddOrEditSDI.PROPERTY_SDCID, __PROP_MAT_SDC);
        //plMatProps.setProperty("s_materialid", sapMaterialId);
        plMatProps.setProperty(AddOrEditSDI.PROPERTY_KEYID1, sapMaterialId);
        plMatProps.setProperty("materialdesc", sapMaterialDesc);
        plMatProps.setProperty("u_sapmattype", sapMaterialtype);
        if (!(___KEY_NOT_FOUND).equalsIgnoreCase(sapDateFormatSequence)) {
            plMatProps.setProperty("u_sapdateformatsequence", sapDateFormatSequence);
        }
        // Check if SAP Material Code exist of not. If NOT FOUND Then Skip
        if (!(___KEY_NOT_FOUND).equalsIgnoreCase(sapMatCode)) {
            plMatProps.setProperty("u_sapmatcode", "".equalsIgnoreCase(sapMatCode) ? "(null)" : sapMatCode);
        }
        // Check if SAP International Article Number exist or not. If NOT FOUND Then Skip
        if (!(___KEY_NOT_FOUND).equalsIgnoreCase(ianCode)) {
            plMatProps.setProperty("u_iancode", "".equalsIgnoreCase(ianCode) ? "(null)" : ianCode);
        }
        plMatProps.setProperty("u_issapflag", "Y");
        try {
            getActionProcessor().processAction(AddOrEditSDI.ID, AddOrEditSDI.VERSIONID, plMatProps);
        } catch (Exception e) {
            throw new SapphireException(e.getMessage());
        }

        String limsMatId = plMatProps.getProperty(AddOrEditSDI.RETURN_NEWKEYID1);
        return limsMatId;
    }

    /**
     * This method is used to create material plant information.
     *
     * @param limsMatSitesId LIMS material site id.
     * @param limsMaterialId LIMS material id.
     * @param sapPlant       SAP Plant.
     * @param locMatCode     Plant local material code.
     * @param operation      Add/Edit.
     * @throws SapphireException Throws OOB Sapphire exceptions.
     */
    private void addOrEditMaterialPlantDetails(String limsMatSitesId, String limsMaterialId, String sapPlant, String locMatCode, String operation) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside addMaterialPlantDetails(method)");
        PropertyList plMatPlant = new PropertyList();
        plMatPlant.setProperty(("add").equalsIgnoreCase(operation) ? AddSDI.PROPERTY_SDCID : EditSDI.PROPERTY_SDCID, __PROP_MAT_SITE_SDC);
        if (("edit").equalsIgnoreCase(operation)) {
            plMatPlant.setProperty(EditSDI.PROPERTY_KEYID1, limsMatSitesId);
        }
        plMatPlant.setProperty("materialid", limsMaterialId);
        plMatPlant.setProperty("sapplant", sapPlant);
        if (!(___KEY_NOT_FOUND).equalsIgnoreCase(locMatCode)) {
            plMatPlant.setProperty("matcode", "".equalsIgnoreCase(locMatCode) ? "(null)" : locMatCode);
        }
        getActionProcessor().processAction(("add").equalsIgnoreCase(operation) ? AddSDI.ID : EditSDI.ID, ("add").equalsIgnoreCase(operation) ? AddSDI.VERSIONID : EditSDI.VERSIONID, plMatPlant);
    }

    /**
     * This method is used to check existing material plant.
     *
     * @param limsMaterialId LIMS material id.
     * @param sapPlant       SAP Plant.
     * @return Returns LIMS material id.
     * @throws SapphireException Throws OOB Sapphire exceptions.
     */
    private String checkMaterialPlant(String limsMaterialId, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside checkMaterialPlant(method)");
        String strMatSites = "";
        String sqlText = "SELECT u_materialsiteid FROM u_materialsite WHERE materialid = ? AND sapplant = ?";
        DataSet dsMatSite = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{limsMaterialId, sapPlant});
        if (null == dsMatSite) {
            throw new SapphireException("General Error:", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ErrorMessageUtil.NULL_DATASET_FOUND + " While executing query: \n" + sqlText));
        } else if (dsMatSite.getRowCount() > 0) {
            strMatSites = dsMatSite.getValue(0, "u_materialsiteid", "");
        } else {
            strMatSites = "";
        }
        return strMatSites;
    }
}
