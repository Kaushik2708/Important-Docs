package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.sap.util.ErrorMessageUtil;
import labvantage.custom.alcon.sap.util.SAPUtil;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.util.ArrayList;
import java.util.HashMap;

import static labvantage.custom.alcon.sap.util.SAPPlants.*;

/**
 * $Author: BAGCHAN1 $
 * $Date: 2022-01-02 23:05:04 +0530 (Sun, 02 Jan 2022) $
 * $Revision: 694 $
 */

/*************************************************************************************************
 * $Revision: 694 $
 * Description:
 * This class is for RESULT UPLOAD Service. This class is used to send the Result Data to SAP.
 *
 * @author Kaushik Ghosh
 * @version 1
 *************************************************************************************************/

public class SAPResultUpload extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 694 $";
    public static final String ID = "RESULT_UPLOAD";
    public static final String VERSIONID = "1";
    private static final String PROP_KEY_NAME = "SAP Batch";
    private static final String PROP_LIMS_KEY_NAME = "LIMS Batch";
    private static final String WORKCOMPLETE_PASS = "PASS";
    private static final String WORKCOMPLETE_FAIL = "FAIL";
    private static final String PROP_SAPPLANT = "u_sapplant";
    private static final String PROP_BATCH_ID = "batchid";
    private static final String PROP_CODE_GROUP_PASS = "u_catcodegrouppass";
    private static final String PROP_CODE_GROUP_FAIL = "u_catcodegroupfail";
    private static final String PROP_CAT_CODE_PASS = "u_catcodepass";
    private static final String PROP_CAT_CODE_FAIL = "u_catcodefail";
    private static final String PROP_INSPECTION_LOT = "u_sapinspectionlot";
    private static final String PROP_SAP_SUBSYSTEM = "u_sapsubsystem";
    private static final String PROP_BATCH_LAB_CONF_NUM = "u_saplabconfnum";
    private static final String PROP_BATCH_TYPE_FINISHED = "Finished";
    private static final String PROP_BATCH_TYPE_RAW_MATERIAL = "Raw Material";
    private static final String PROP_BATCH_TYPE_INTERMEDIATE = "Intermediate";
    private static final String PROP_BATCH_TYPE = "batchtype";
    private static final String PROP_BATCH_STATUS = "batchstatus";
    private static final String PROP_BATCH_DISPOSITION = "disposition";
    private static final String PROP_BATCH_SAP_CONF_NUM = "u_sapconfnum";
    private static final String PROP_BATCH_ENTERED_TEXT = "enteredtext";
    private static final String PROP_BATCH_STATUS_PENDING_RELEASE = "Pending Release";
    private static final String PROP_BATCH_STATUS_RELEASED = "Released";
    private static final String PROP_BATCH_STATUS_REJECTED = "Rejected";


    private static HashMap<String, String> hmPassFail = null;

    static {
        hmPassFail = new HashMap<String, String>();
        hmPassFail.put("PASS", WORKCOMPLETE_PASS);
        hmPassFail.put("CERT", WORKCOMPLETE_PASS);
        hmPassFail.put("PARTIAL", WORKCOMPLETE_PASS);
        hmPassFail.put("N/A", WORKCOMPLETE_PASS);
        hmPassFail.put("FAIL", WORKCOMPLETE_FAIL);
    }


    /**
     * Description: processAction is an OOB LabVantage method. This is the main method where execution starts.
     *
     * @param properties
     * @throws SapphireException
     */
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("----- Starting Service: " + ID + " , Version: " + VERSIONID + " ------");
        String resultPayloadJSON = "";
        String noResultFlag = "";
        String[] result = new String[2];
        boolean hasResult = false;

        //Getting the Properties
        String batchId = properties.getProperty(PROP_BATCH_ID, "");
        if ("".equalsIgnoreCase(batchId)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00001, "LIMS Batch Id ")));
        }
        // Getting Batch details
        DataSet dsBatchDetails = getBatchDetails(batchId);

        String codeGroupPass = dsBatchDetails.getValue(0, PROP_CODE_GROUP_PASS, "");
        String codeGroupFail = dsBatchDetails.getValue(0, PROP_CODE_GROUP_FAIL, "");
        String codePass = dsBatchDetails.getValue(0, PROP_CAT_CODE_PASS, "");
        String codeFail = dsBatchDetails.getValue(0, PROP_CAT_CODE_FAIL, "");
        String inspectionLot = dsBatchDetails.getValue(0, PROP_INSPECTION_LOT, "");
        String sapSubSystem = dsBatchDetails.getValue(0, PROP_SAP_SUBSYSTEM, "");
        String labConfSAPLabConfNo = dsBatchDetails.getValue(0, PROP_BATCH_LAB_CONF_NUM, "");
        String sapPlant = dsBatchDetails.getValue(0, PROP_SAPPLANT, "");
        String batchType = dsBatchDetails.getValue(0, PROP_BATCH_TYPE, "");
        String batchDispostion = dsBatchDetails.getValue(0, PROP_BATCH_DISPOSITION, "");
        String batchStatus = dsBatchDetails.getValue(0, PROP_BATCH_STATUS, "");

        //Checking Mandatory Fields
        checkMandatoryFields(dsBatchDetails, PROP_CODE_GROUP_PASS, PROP_CODE_GROUP_FAIL, PROP_CAT_CODE_PASS, PROP_CAT_CODE_FAIL, PROP_BATCH_LAB_CONF_NUM, PROP_BATCH_TYPE);


        // Checking batch type Finished
        if (PROP_BATCH_TYPE_FINISHED.equalsIgnoreCase(batchType)) {
            // Checking Aspetic plants
            if (PROPS_ASEPTIC_PLANT_U630.equalsIgnoreCase(sapPlant) || PROPS_ASEPTIC_PLANT_SG20.equalsIgnoreCase(sapPlant) || PROPS_ASEPTIC_PLANT_U636.equalsIgnoreCase(sapPlant)) {
                // Calling Aseptic FN Result Upload
                result = getAsepticFNResult(batchId, batchType, sapPlant, labConfSAPLabConfNo, codeGroupPass, codeGroupFail, codePass, codeFail, sapSubSystem);
                hasResult = true;
            }
        } else if (PROP_BATCH_TYPE_RAW_MATERIAL.equalsIgnoreCase(batchType) || PROP_BATCH_TYPE_INTERMEDIATE.equalsIgnoreCase(batchType)) {
            // If Vision Care plants
            if ((PROPS_VISION_CARE_PLANT_U612.equalsIgnoreCase(sapPlant)
                    || PROPS_VISION_CARE_PLANT_SG03.equalsIgnoreCase(sapPlant)
                    || PROPS_VISION_CARE_PLANT_ID01.equalsIgnoreCase(sapPlant)
                    || PROPS_VISION_CARE_PLANT_MY10.equalsIgnoreCase(sapPlant))
                    &&
                    (PROP_BATCH_STATUS_RELEASED.equalsIgnoreCase(batchStatus)
                            || PROP_BATCH_STATUS_REJECTED.equalsIgnoreCase(batchStatus))
                    ) {
                result = getVisionCareResults(codeGroupPass, codeGroupFail, codePass, codeFail, sapSubSystem, labConfSAPLabConfNo, batchDispostion);
                hasResult = true;
            } else if ((PROPS_ASEPTIC_PLANT_U630.equalsIgnoreCase(sapPlant)
                    || PROPS_ASEPTIC_PLANT_SG20.equalsIgnoreCase(sapPlant)
                    || PROPS_ASEPTIC_PLANT_U636.equalsIgnoreCase(sapPlant))
                    && PROP_BATCH_STATUS_PENDING_RELEASE.equalsIgnoreCase(batchStatus)
                    ) {
                // Calling Aseptic FN Result Upload
                result = getAsepticRMResult(batchId, batchType, sapPlant, labConfSAPLabConfNo, codeGroupPass, codeGroupFail, codePass, codeFail, sapSubSystem);
                hasResult = true;
            }
        } else {
            // For Future release and different batch type
            return;
        }

        if (hasResult) {
            // Getting Result JSON and No result Flag
            resultPayloadJSON = result[0];
            noResultFlag = result[1];

            // Creating Transaction Data
            callLVOutbound(resultPayloadJSON, ID, PROP_KEY_NAME, inspectionLot, PROP_LIMS_KEY_NAME, batchId, sapPlant);
            setBatchResultUploadFlag(batchId, noResultFlag);

        }
        logger.info("----- End of Processing Service: " + ID + ", Vesrion: " + VERSIONID + " ------");
    }

    /**************
     * This method is used to create VisionCare result upload data.
     * @param batchDispostion
     * @return
     * @throws SapphireException
     **************/
    private String[] getVisionCareResults(String codeGroupPass, String codeGroupFail, String codePass, String codeFail, String sapSubSystem, String labConfSAPLabConfNo, String batchDispostion) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: getVisionCareResults ------");
        String[] result = new String[2];
        String noResultFlag = "";
        // Final result set
        DataSet dsFinalResult = new DataSet();
        if ("".equalsIgnoreCase(batchDispostion)) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(" Aborting transaction. Batch disposition status is blank. \n"));
        }
        // Creating and adding SAP Lab Confirmation Number
        int rowNum = dsFinalResult.addRow();
        dsFinalResult.addColumn(PROP_BATCH_SAP_CONF_NUM, DataSet.STRING);
        dsFinalResult.setValue(rowNum, PROP_BATCH_SAP_CONF_NUM, labConfSAPLabConfNo);
        // Setting Code group and code details
        dsFinalResult.addColumn("catcodegroup", DataSet.STRING);
        dsFinalResult.addColumn("catcode", DataSet.STRING);
        if (batchDispostion.equalsIgnoreCase("Passed")) {
            // If Batch disposition status is Approved
            dsFinalResult.setValue(rowNum, "catcodegroup", codeGroupPass);
            dsFinalResult.setValue(rowNum, "catcode", codePass);

        } else if (batchDispostion.equalsIgnoreCase("Failed")) {
            // If Batch disposition status is Rejected
            dsFinalResult.setValue(rowNum, "catcodegroup", codeGroupFail);
            dsFinalResult.setValue(rowNum, "catcode", codeFail);
        }

        String resultPayloadJSON = "";
        // Creating JSON String
        try {
            resultPayloadJSON = processJSONString(dsFinalResult, sapSubSystem);
            result[0] = resultPayloadJSON;
            result[1] = noResultFlag;
        } catch (JSONException jex) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(jex.getMessage()));
        }

        return result;
    }

    /****************
     * This method is used to get LIMS Batch details by batch id.
     * @param limsBatchId
     * @return
     * @throws SapphireException
     ****************/
    private DataSet getBatchDetails(String limsBatchId) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: getBatchDetails ------");
        String sqlText = " SELECT " +
                "s_batch.u_catcodegrouppass, " +
                "s_batch.u_catcodegroupfail, " +
                "s_batch.u_catcodepass, " +
                "s_batch.u_catcodefail, " +
                "s_batch.u_sapinspectionlot, " +
                "s_batch.u_saplabconfnum, " +
                "s_batch.u_sapplant, " +
                "s_batch.batchtype, " +
                "s_batch.batchstatus, " +
                "s_batch.u_sapsubsystem, " +
                "s_batch.disposition " +
                "FROM s_batch " +
                "WHERE s_batch.s_batchid = ? ";
        DataSet dsBatchDetails = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{limsBatchId});
        if (null == dsBatchDetails) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" Failed to execute query for query: " + sqlText));
        } else if (dsBatchDetails.getRowCount() == 0) {
            throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(" No LIMS Batch details found for LIMS Batch Id: " + limsBatchId));
        } else {
            return dsBatchDetails;
        }
    }

    /***********
     * This method is used for Aseptic RM result upload data creation.
     * @param batchId
     * @param batchType
     * @param sapPlant
     * @param labConfSAPLabConfNo
     * @param codeGroupPass
     * @param codeGroupFail
     * @param codePass
     * @param codeFail
     * @param sapSubSystem
     * @return
     * @throws SapphireException
     *************/
    private String[] getAsepticRMResult(String batchId, String batchType, String sapPlant, String labConfSAPLabConfNo, String codeGroupPass, String codeGroupFail, String codePass, String codeFail, String sapSubSystem) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: getAsepticRMResult ------");
        String[] result = new String[2];
        String noResultFlag = "";
        //Getting PARAM resul ts
        DataSet dsSDIDataItemResult = getParamResult(batchId);
        // Set No Result flag
        if (dsSDIDataItemResult.getRowCount() == 0) {
            // Getting No Result flag
            noResultFlag = "Y";
        }
        //DataSet dsSDIDataItemResult = getParamResultTest(batchId);
        DataSet dsPreFinalResult = getOrderedData(dsSDIDataItemResult);
        // Adding Lab System Confirmation Number Result
        DataSet dsFinalResult = addLabSysConfNumResult(dsPreFinalResult, labConfSAPLabConfNo);
        // Checking if there any eligible results for upload
        if (dsFinalResult.getRowCount() > 0) {
            // Setting Catalog Details
            setCatlogData(dsFinalResult, codeGroupPass, codeGroupFail, codePass, codeFail);
            String resultPayloadJSON = "";
            // Creating JSON String
            try {
                resultPayloadJSON = processJSONString(dsFinalResult, sapSubSystem);
                result[0] = resultPayloadJSON;
                result[1] = noResultFlag;
            } catch (JSONException jex) {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(jex.getMessage()));
            }

        }


        return result;

    }

    /***********
     * This method is used for Aseptic result upload data creation.
     * @param batchId
     * @param batchType
     * @param sapPlant
     * @param labConfSAPLabConfNo
     * @param codeGroupPass
     * @param codeGroupFail
     * @param codePass
     * @param codeFail
     * @param sapSubSystem
     * @return
     * @throws SapphireException
     *************/
    private String[] getAsepticFNResult(String batchId, String batchType, String sapPlant, String labConfSAPLabConfNo, String codeGroupPass, String codeGroupFail, String codePass, String codeFail, String sapSubSystem) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: getAsepticFNResult ------");
        String[] result = new String[2];
        String noResultFlag = "";
        //Getting PARAM results
        DataSet dsSDIDataItemResult = getParamResult(batchId);
        // Set No Result flag
        if (dsSDIDataItemResult.getRowCount() == 0) {
            // Getting No Result flag
            noResultFlag = "Y";
        }
        //DataSet dsSDIDataItemResult = getParamResultTest(batchId);
        DataSet dsPreFinalResult = getOrderedData(dsSDIDataItemResult);
        // Adding Lab System Confirmation Number Result
        DataSet dsFinalResult = addLabSysConfNumResult(dsPreFinalResult, labConfSAPLabConfNo);
        // Checking if there any eligible results for upload
        if (dsFinalResult.getRowCount() > 0) {
            // Setting Catalog Details
            setCatlogData(dsFinalResult, codeGroupPass, codeGroupFail, codePass, codeFail);
            String resultPayloadJSON = "";
            // Creating JSON String
            try {
                resultPayloadJSON = processJSONString(dsFinalResult, sapSubSystem);
                result[0] = resultPayloadJSON;
                result[1] = noResultFlag;
            } catch (JSONException jex) {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(jex.getMessage()));
            }

        }


        return result;

    }

    /**
     * This method is used to get Result Data order by DataSet and Replicate Id in descending order.
     *
     * @param dsSDIDataItemResult Eligible Result Data.
     * @return Returns eligible Result Data order by DataSet instance and Replicate Id in descending order.
     * @throws SapphireException Throws OOB Sapphire Exception.
     */
    private DataSet getOrderedData(DataSet dsSDIDataItemResult) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: getOrderedData ------");
        DataSet dsPreFinalResult = new DataSet();
        if (!dsPreFinalResult.isValidColumn(PROP_BATCH_ENTERED_TEXT)) {
            dsPreFinalResult.addColumn(PROP_BATCH_ENTERED_TEXT, DataSet.STRING);
        }
        if (!dsPreFinalResult.isValidColumn(PROP_BATCH_SAP_CONF_NUM)) {
            dsPreFinalResult.addColumn(PROP_BATCH_SAP_CONF_NUM, DataSet.STRING);
        }
        int row;
        if (dsSDIDataItemResult.getRowCount() > 0) {
            dsSDIDataItemResult.sort("paramlistid,paramlistversionid,variantid");
            // Creating prefinal DataSet
            ArrayList<DataSet> alPlGroup = dsSDIDataItemResult.getGroupedDataSets("paramlistid,paramlistversionid,variantid");
            // Looping each ParamList + Version + Variant combination.
            for (DataSet dsPl : alPlGroup) {
                // Sorting bt Param, Paramtype
                dsPl.sort("paramid,paramtype");
                // Grouping based upon Param and Param type
                ArrayList<DataSet> alParamGroup = dsPl.getGroupedDataSets("paramid,paramtype");
                // Looping Param Group
                for (DataSet dsParam : alParamGroup) {
                    // Sorting Params by DataSet and Replicate Id
                    row = dsPreFinalResult.addRow();
                    dsParam.sort("dataset D,replicateid D");
                    dsPreFinalResult.setValue(row, PROP_BATCH_ENTERED_TEXT, dsParam.getValue(0, PROP_BATCH_ENTERED_TEXT, ""));
                    dsPreFinalResult.setValue(row, PROP_BATCH_SAP_CONF_NUM, dsParam.getValue(0, PROP_BATCH_SAP_CONF_NUM, ""));
                }
            }
        }

        return dsPreFinalResult;
    }

    /**
     * Description: This method is used to Add Lab System Confirmation Number Result
     *
     * @param dsSDIDataItemResults Parameter results selected for result upload.
     * @param labConfNum           SAP Lab Confirmation Number
     * @return DataSet of results.
     * @throws SapphireException OOB Sapphire exception.
     */

    private DataSet addLabSysConfNumResult(DataSet dsSDIDataItemResults, String labConfNum) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: addLabSysConfNumResult ------");
        DataSet dsFinalResult = dsSDIDataItemResults;
        boolean failResultFlag = false;
        // Adding Result Data for SAP Lab System Confirmation Number
        int rowNum = dsFinalResult.addRow();
        if (!dsFinalResult.isValidColumn(PROP_BATCH_ENTERED_TEXT)) {
            dsFinalResult.addColumn(PROP_BATCH_ENTERED_TEXT, DataSet.STRING);
        }
        // Looping through the result set and finding if FAIL exists or not
        for (int row = 0; row < dsSDIDataItemResults.getRowCount(); row++) {
            // If any FAIL result
            if (dsSDIDataItemResults.getValue(row, PROP_BATCH_ENTERED_TEXT).equalsIgnoreCase(WORKCOMPLETE_FAIL)) {
                // Setting the flag to TRUE and breaking the Loop
                failResultFlag = true;
                break;
            }
        }
        // Checking if FAIL flag is TRUE or FALSE
        if (failResultFlag) {
            dsFinalResult.setValue(rowNum, PROP_BATCH_ENTERED_TEXT, WORKCOMPLETE_FAIL);
        } else {
            dsFinalResult.setValue(rowNum, PROP_BATCH_ENTERED_TEXT, WORKCOMPLETE_PASS);
        }

        if (!dsFinalResult.isValidColumn(PROP_BATCH_SAP_CONF_NUM)) {
            dsFinalResult.addColumn(PROP_BATCH_SAP_CONF_NUM, DataSet.STRING);
        }
        dsFinalResult.setValue(rowNum, PROP_BATCH_SAP_CONF_NUM, labConfNum);
        // Creating unique DataSet
        DataSet dsUniqueResults = SAPUtil.getUniqueDataSet(connectionInfo, dsFinalResult, PROP_BATCH_SAP_CONF_NUM, PROP_BATCH_ENTERED_TEXT);
        return dsUniqueResults;
    }

    /**
     * Description: This method is used to set Batch Result Upload flag
     *
     * @param batchId LIMS Batch Id.
     * @throws SapphireException OOB Sapphire exception.
     */

    private void setBatchResultUploadFlag(String batchId, String noResultFlag) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: setBatchResultUploadFlag ------");
        PropertyList plResultUploadFlag = new PropertyList();
        plResultUploadFlag.setProperty(EditSDI.PROPERTY_SDCID, "Batch");
        plResultUploadFlag.setProperty(EditSDI.PROPERTY_KEYID1, batchId);
        plResultUploadFlag.setProperty("u_resultsuploaded", "Y");
        if (!"".equalsIgnoreCase(noResultFlag)) {
            plResultUploadFlag.setProperty("u_noresultflag", noResultFlag);
        }
        getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plResultUploadFlag);
    }

    /**
     * Description: This Method is used to create the Transaction data.
     *
     * @param inputJSONData JSON String
     * @param serviceName   Service name
     * @param keyName       key name
     * @param keyValue      Key value
     * @param limsKeyName   LIMS key name
     * @param limsKeyValue  LIMS key value
     * @throws SapphireException OOB Sapphire exception.
     */

    private void callLVOutbound(String inputJSONData, String serviceName, String keyName, String keyValue, String limsKeyName, String limsKeyValue, String sapPlant) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: callLVOutbound ------");
        PropertyList plTransaData = new PropertyList();
        plTransaData.setProperty(SAPLVOutbound.PROPERTY_JSON_STRING, inputJSONData);
        plTransaData.setProperty(SAPLVOutbound._SERVICE_NAME, serviceName);
        plTransaData.setProperty(SAPLVOutbound._KEY_NAME, keyName);
        plTransaData.setProperty(SAPLVOutbound._KEY_VALUE, keyValue);
        plTransaData.setProperty(SAPLVOutbound._LIMS_KEY_NAME, limsKeyName);
        plTransaData.setProperty(SAPLVOutbound._LIMS_KEY_VALUE, limsKeyValue);
        plTransaData.setProperty(SAPLVOutbound.PROPERTY_SAP_PLANT, sapPlant);

        getActionProcessor().processAction(SAPLVOutbound.ID, SAPLVOutbound.VERSIONID, plTransaData);
    }

    /**
     * Description: This method is used to set the catalog details.
     *
     * @param dsResultData Result data.
     * @param catCodePas   category pass
     * @param catCodeFail  category Fail
     * @param codePass     Code pass
     * @param codeFail     Code Fail
     */

    private void setCatlogData(DataSet dsResultData, String catCodePas, String catCodeFail, String codePass, String codeFail) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: setCatlogData ------");
        dsResultData.addColumn("catcodegroup", DataSet.STRING);
        dsResultData.addColumn("catcode", DataSet.STRING);
        for (int row = 0; row < dsResultData.size(); row++) {
            String limsResult = dsResultData.getValue(row, PROP_BATCH_ENTERED_TEXT);
            if (hmPassFail.containsKey(limsResult.toUpperCase())) {
                if (hmPassFail.get(limsResult.toUpperCase()).equalsIgnoreCase(WORKCOMPLETE_PASS)) {
                    dsResultData.setValue(row, "catcodegroup", catCodePas);
                    dsResultData.setValue(row, "catcode", codePass);
                } else {
                    dsResultData.setValue(row, "catcodegroup", catCodeFail);
                    dsResultData.setValue(row, "catcode", codeFail);
                }
            } else {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Entered value is not in PASS, FAIL, CERT, N/A, PARTIAL. Master Data is incorrect. Please contact Adminitrator."));
            }
        }
    }

    /*******************
     * Description: This method is used to check the Mandatory fields.
     *
     * @param dsmandatoryProps
     * @param mandatoryKeys
     * @throws SapphireException OOB Sapphire exception
     ********************/

    private void checkMandatoryFields(DataSet dsmandatoryProps, String... mandatoryKeys) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: checkMandatoryFields ------");
        for (String mandatoryKey : mandatoryKeys) {
            if ("".equalsIgnoreCase(dsmandatoryProps.getValue(0, mandatoryKey, ""))) {
                throw new SapphireException(ErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_VALIDATION, getTranslationProcessor().translate(String.format(ErrorMessageUtil.RM_ERR_00001, mandatoryKey)));
            }
        }
    }

    /**
     * Description: This method is used to get the param Result.
     *
     * @param batchIdParam LIMS Batch Id.
     * @return DataSet of parameter results.
     * @throws SapphireException OOB Sapphire exceptions.
     */
    private DataSet getParamResult(String batchIdParam) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: getParamResult ------");
        StringBuilder errMsg = new StringBuilder().append(" Error::");
        DataSet dsResults = new DataSet();
        String strRset = "";
        // Getting Sample Id List gainst the Batch Id.
        DataSet dsSampleList = getBatchSamples(batchIdParam);

        try {
            // Create RSET for Sample SDC and Sample List Ids.
            strRset = getDAMProcessor().createRSet("Sample", dsSampleList.getColumnValues("S_SAMPLEID", ";"), "(null)", "(null)");
            // Joining SDIData, SDIDataItem with RSetItem
            String sqlText = " SELECT sdi.enteredtext , sdi.u_sapconfnum, sdi.PARAMLISTID, sdi.PARAMLISTVERSIONID, sdi.VARIANTID, sdi.DATASET, sdi.PARAMID, sdi.PARAMTYPE, sdi.REPLICATEID " +
                    "FROM sdidataitem sdi, sdidata sd, rsetitems rs " +
                    "WHERE  " +
                    "rs.SDCID = 'Sample' " +
                    "AND sd.S_DATASETSTATUS <> 'Cancelled' " +
                    "AND sdi.U_ISSAPRESULT = 'Y' " +
                    "AND sdi.SDCID = 'Sample' AND sdi.KEYID1 = rs.KEYID1 " +
                    "AND sd.SDCID = 'Sample'  " +
                    "AND sd.KEYID1 = rs.KEYID1 " +
                    "AND sd.KEYID2 = '(null)' " +
                    "AND sd.KEYID3 = '(null)' " +
                    "AND sd.SDCID = sdi.SDCID " +
                    "AND sd.KEYID1 = sdi.KEYID1 " +
                    "AND sd.KEYID2 = sdi.KEYID2 " +
                    "AND sd.KEYID3 = sdi.KEYID3 " +
                    "AND sd.PARAMLISTID = sdi.PARAMLISTID " +
                    "AND sd.PARAMLISTVERSIONID = sdi.PARAMLISTVERSIONID " +
                    "AND sd.VARIANTID = sdi.VARIANTID " +
                    "AND sd.DATASET = sdi.DATASET " +
                    "AND rs.RSETID = ? " +
                    "AND sdi.u_sapconfnum IS NOT NULL";
            dsResults = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{strRset});
        } catch (SapphireException ex) {
            throw new SapphireException("General Error::", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.toString()));
        } finally {
            // If RSet is not blank then CLEAR it.
            if (!"".equals(strRset)) {
                getDAMProcessor().clearRSet(strRset);
            }
        }


        if (null == dsResults) {
            errMsg.append(" Failed to execute query for LIMS Result Upload.").append(" for LIMS Batch:").append(batchIdParam);
            logger.error(errMsg.toString());
            throw new SapphireException(errMsg.toString());
        } else {
            return dsResults;
        }
    }

    /**
     * Description: This method is used to get Samples againt Batch id passed.
     *
     * @param batchId LIMS Batch Id.
     * @return Returns DataSet containing sample Id list.
     * @throws SapphireException OOB Sapphire exception.
     */
    private DataSet getBatchSamples(String batchId) throws SapphireException {
        logger.info("----- Inside Service: " + ID + " , Inside: getBatchSamples ------");
        String sqlText = "SELECT S_SAMPLEID FROM S_SAMPLE WHERE SAMPLESTATUS <> 'Cancelled' AND BATCHID = ?";
        DataSet dsSampleList = getQueryProcessor().getPreparedSqlDataSet(sqlText, new Object[]{batchId});
        if (null == dsSampleList) {
            throw new SapphireException(" Failed to execute query for query id: " + sqlText);
        }
        return dsSampleList;
    }

    /**
     * Description: This method is used to create the JSON String.
     *
     * @param dsFinalResult Final result.
     * @param sapSubSystem  SAP Sub Sytem.
     * @return JSON String.
     * @throws JSONException JSON Exception
     */


    private String processJSONString(DataSet dsFinalResult, String sapSubSystem) throws JSONException {
        logger.info("----- Inside Service: " + ID + " , Inside: processJSONString ------");
        JSONArray resultArrayObj = new JSONArray();
        // Creating Array Object
        JSONObject itemObject = new JSONObject();
        // If Result Object is having more than 1 item, Hence Creating JSON Array
        if (dsFinalResult.size() > 1) {
            for (int row = 0; row < dsFinalResult.size(); row++) //Building JSON Object for JSON Array
            {
                JSONObject resultObj = new JSONObject();
                resultObj.put("SATZART", "Q72");
                resultObj.put("RUECKMELNR", dsFinalResult.getValue(row, PROP_BATCH_SAP_CONF_NUM));
                resultObj.put("GRUPPE1", dsFinalResult.getValue(row, "catcodegroup"));
                resultObj.put("CODE1", dsFinalResult.getValue(row, "catcode"));
                resultObj.put("ANZWERTG", "1");
                resultArrayObj.put(resultObj);
            }
            // Inserting Result JSON Array to Item JSON Object
            itemObject.put("item", resultArrayObj);
        } else {
            // Single Result object
            JSONObject resultObj = new JSONObject();
            resultObj.put("SATZART", "Q72");
            resultObj.put("RUECKMELNR", dsFinalResult.getValue(0, PROP_BATCH_SAP_CONF_NUM));
            resultObj.put("GRUPPE1", dsFinalResult.getValue(0, "catcodegroup"));
            resultObj.put("CODE1", dsFinalResult.getValue(0, "catcode"));
            resultObj.put("ANZWERTG", "1");
            itemObject.put("item", resultObj);
        }
        // Creating payload as JSON Object
        JSONObject payloadObj = new JSONObject();
        payloadObj.put("I_SUBSYS", sapSubSystem);
        payloadObj.put("T_QAIMRTAB", itemObject);
        payloadObj.put("T_QAISETAB", "");
        payloadObj.put("T_QAISRTAB", "");
        payloadObj.put("T_QIERRTAB", "");
        payloadObj.put("-xmlns:ns0", "urn:sap-com:document:sap:rfc:functions");

        // Creating final JSON Object
        JSONObject finalObj = new JSONObject();//final JSON
        finalObj.put("ns0:QIRF_GET_ALL_DATA_VALUES2", payloadObj);

        String finalJSON = finalObj.toString(); //final JSON String
        String formatJSON = getFormattedJSON(finalJSON);
        return formatJSON;

    }

    /**
     * Description: This method is used to format the JSON structure.
     *
     * @param finalJSON Final Result.
     * @return Formatted JSON String.
     */

    public String getFormattedJSON(String finalJSON) {
        logger.info("----- Inside Service: " + ID + " , Inside: getFormattedJSON ------");
        int j = 0;
        String newStr = "";
        String strAdd = "";
        for (int i = 0; i < finalJSON.length(); i++) {
            if (finalJSON.charAt(i) == '{' || i == (finalJSON.length() - 1) || finalJSON.charAt(i) == ',' || finalJSON.charAt(i) == '}' || finalJSON.charAt(i) == ']') {
                for (int k = j; k < i + 1; k++) {
                    strAdd = strAdd + finalJSON.charAt(k);
                }
                j = i + 1;
                newStr = newStr + "\r\n" + strAdd;
                strAdd = "";
            }
        }
        return newStr;
    }
}
