package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.ddt.IntfTransItem;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import javax.net.ssl.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

/**
 * $Author: GHOSHKA1 $
 * $Date: 2021-09-24 09:16:41 -0500 (Fri, 24 Sep 2021) $
 * $Revision: 577 $
 */

/*******************************************************************
 * $Revision: 577 $
 * Description:
 * This Class is used to communicate the SAP-IRIS for outbound services.
 *
 *******************************************************************/
public class SAPLVOutbound extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 577 $";
    public static final String ID = "SAPLVOutbound";
    public static final String VERSIONID = "1";
    public static final String PROPERTY_JSON_STRING = "itempayloadtranstable";
    public static final String _SERVICE_NAME = "transname";
    public static final String _KEY_NAME = "keyname";
    public static final String _KEY_VALUE = "keyvalue";
    public static final String _LIMS_KEY_NAME = "limskeyname";
    public static final String _LIMS_KEY_VALUE = "limskeyvalue";
    public static final String PROPERTY_SAP_PLANT = "sapplant";
    public static final String PROPERTY_SAP_INSPECTION_LOT = "inspectionlot";
    public static final String PROPERTY_LOGGER_SWITCH = "LOG_SWITCH";

    // (6/30):: Added by KG to populate LIMS Batch Id in Outbound List Page
    private static final String __PROPERTY_LIMS_BATCH_ID = "limsbatchid";


    public static final String SERVICE_NAME_RESULT_UPLOAD = "RESULT_UPLOAD";
    public static final String SERVICE_NAME_LOT_REQUEST = "LOT_REQUEST";

    public String outBoundURL = "";

    /***
     * Overloaded function to intiate the call process.
     * @param properties
     * @throws SapphireException
     */
    public void processAction(PropertyList properties) throws SapphireException {

        //--------- Do not change the sequence of method call --------
        outBoundURL = "";//restting

        String outMsg = "";
        HttpURLConnection conn = null;
        String inputData = "";
        String serviceName = "";
        String keyName = "";
        String keyValue = "";
        String limsKeyName = "";
        String limsKeyValue = "";
        String sapplant = "";
        String switchForLog = "";

        try {
            serviceName = properties.getProperty(_SERVICE_NAME, "");
            if (serviceName.equals("")) {
                String err = " No service name found.";
                throw new SapphireException(err);
            }

            turnOffCertificate();
            conn = establishConnection(serviceName);

            inputData = properties.getProperty(PROPERTY_JSON_STRING, "");
            sapplant = properties.getProperty(PROPERTY_SAP_PLANT, "");
            keyName = properties.getProperty(_KEY_NAME, "");
            keyValue = properties.getProperty(_KEY_VALUE, "");
            limsKeyName = properties.getProperty(_LIMS_KEY_NAME, "");
            limsKeyValue = properties.getProperty(_LIMS_KEY_VALUE, "");
            switchForLog = properties.getProperty(PROPERTY_LOGGER_SWITCH, "ON"); // Default if ON  ( Values ON/OFF)

            //checkMandatoryInput();

            outMsg = sendMessage(conn, inputData);

            // Creating Transaction Details in another transaction. When Error introduced. TODO  create a swich. Task Proerty Switch
            if (switchForLog.equalsIgnoreCase("ON")) {
                populateTransTable(inputData, serviceName, keyName, keyValue, IntfTransItem.TRANS_ITEM_STATUS_COMPLETE, sapplant, limsKeyValue);
            }


        } catch (Exception e) {
            logger.error(e.getMessage());
            String err = e.getMessage();
            String transId = populateTransTable(inputData, serviceName, keyName, keyValue, IntfTransItem.TRANS_ITEM_STATUS_ERROR, sapplant, limsKeyValue);
            populateTransErrorTable(transId, err, serviceName);
            if (serviceName.equalsIgnoreCase(SAPResultUpload.ID)) {
                throw new SapphireException(err);
            }

        } finally {
            closeConnection(conn);
            properties.setProperty("outmsg", outMsg);
        }

    }

    /**
     * Description: Populating the error table for log purpose.
     *
     * @param transId
     * @param errormsg
     * @param serviceName
     * @throws SapphireException
     */
    private void populateTransErrorTable(String transId, String errormsg, String serviceName) throws SapphireException {

        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "IntfError");
        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");
        pl.setProperty("intftransid", transId);
        //pl.setProperty("intftransitemid", transItemId);
        pl.setProperty("errormsg", errormsg);
        pl.setProperty("program", serviceName);
        try {
            getActionProcessor().processAction(SAPErrorHandler.ID, SAPErrorHandler.VERSIONID, pl, true);

        } catch (SapphireException e) {
            String err = "Cannot process SAPErrorHandler. " + e.getMessage();
            logger.error(err);
        }
    }

    /***
     * Populate the transaction table. This tracks the outbound data for communicating the SAP IRIS.
     * @param inputData Input data payload
     * @param serviceName Outbound service name
     * @param keyName key name
     * @param keyValue key value
     * @param status status of transaction
     * @param sapplant SAP plant
     * @param limsBatchId LIMS Batch Id
     * @return New transaction id
     * @throws SapphireException OOB Sapphire exception
     */
    private String populateTransTable(String inputData, String serviceName, String keyName, String keyValue, String status, String sapplant, String limsBatchId) throws SapphireException {

        //AddSDI to IntfTrans SDC
        String errMsg = "";
        //Adding data to transaction table
        PropertyList plTransData = new PropertyList();
        plTransData.setProperty(AddSDI.PROPERTY_SDCID, "IntfTrans");
        plTransData.setProperty("status", status);
        plTransData.setProperty("transname", serviceName);
        plTransData.setProperty("transdata", inputData);
        plTransData.setProperty("keyname", keyName);
        plTransData.setProperty("keyvalue", keyValue);
        // plTransData.setProperty("limskeyname", limsKeyName);
        //  plTransData.setProperty("limskeyvalue", limsKeyValue);
        plTransData.setProperty(__PROPERTY_LIMS_BATCH_ID, limsBatchId);
        plTransData.setProperty("transdirection", "OUTBOUND");
        plTransData.setProperty("transtype", "Web Service");
        plTransData.setProperty("outboundurl", outBoundURL);
        plTransData.setProperty("plant", sapplant);
        plTransData.setProperty("sapinspectionlot", keyValue);

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plTransData, true);

        return plTransData.getProperty("newkeyid1", "");

    }

    /**
     * Description: Get connection URL for outbound.
     *
     * @param serviceName
     * @return
     * @throws SapphireException
     */
    private HttpURLConnection establishConnection(String serviceName) throws SapphireException {

        HttpURLConnection conn = null;
        try {

            DataSet dsConnData = getConnectionData(serviceName);
            String https_url = dsConnData.getValue(0, "url", "");
            String username = dsConnData.getValue(0, "username", "");
            String password = dsConnData.getValue(0, "password", "");

            URL url = new URL(https_url);
            conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");

            //---- Authenticate by user/password ------------------
            byte[] message = (username + ":" + password).getBytes("UTF-8");
            String encoded = javax.xml.bind.DatatypeConverter.printBase64Binary(message);
            conn.setRequestProperty("Authorization", "Basic " + encoded);

        } catch (MalformedURLException e) {
            String err = "Error: Could not establish connection. Caused by: " + e.getMessage();
            logger.error(err);
            throw new SapphireException(err);
        } catch (IOException e) {
            String err = "Error: Could not establish connection. Caused by: " + e.getMessage();
            logger.error(err);
            throw new SapphireException(err);
        }

        return conn;
    }

    /**
     * Description: Close SAP-IRIS connection
     *
     * @param conn
     * @throws SapphireException
     */
    private void closeConnection(HttpURLConnection conn) throws SapphireException {
        conn.disconnect();
    }

    /**
     * Description: Turn off the certificate.
     *
     * @throws SapphireException
     */
    private void turnOffCertificate() throws SapphireException {
        //-------------------------------------Turn Off Certificate Validation in Java HTTPS Connections --------------------------------
        //1.  Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }

            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }
        };

        //2.  Install the all-trusting trust manager
        SSLContext sc = null;
        try {
            sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (NoSuchAlgorithmException e) {
            String err = "Error while turning off the certificate: " + e.getMessage();
            logger.error(err);
            throw new SapphireException(err);
        } catch (KeyManagementException e) {
            String err = "Error while turning off the certificate: " + e.getMessage();
            logger.error(err);
            throw new SapphireException(err);
        }
        //3. Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };
        //4. Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

    }

    /**
     * Description: Post the data to output stream.
     *
     * @param conn
     * @param input
     * @return
     * @throws SapphireException
     */
    private String sendMessage(HttpURLConnection conn, String input) throws SapphireException {

        String output = "";
        String outMsg = "";

        try {

            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();

            boolean connectionError = false;
            String connectionErrorMsg = "";
            switch (conn.getResponseCode()) {
                case HttpURLConnection.HTTP_OK:
                    logger.info("Good Connection. We can go ahead to send SAp message.");
                    break; // fine, go on
                case HttpURLConnection.HTTP_UNAUTHORIZED:
                    connectionErrorMsg = "Unauthorized User Name / password...";
                    connectionError = true;
                    break;

                case HttpURLConnection.HTTP_GATEWAY_TIMEOUT:
                    connectionErrorMsg = "gateway timeout...";
                    connectionError = true;
                    break;// retry
                case HttpURLConnection.HTTP_UNAVAILABLE:
                    //System.out.println(entries + "**unavailable**");
                    connectionErrorMsg = "Http service unavailable...";
                    connectionError = true;
                    break;// retry, server is unstable

            }
            if (connectionError) {
                throw new SapphireException(connectionErrorMsg);
            }

            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            logger.info("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
                outMsg = outMsg + output;
            }

            return outMsg;

        } catch (IOException e) {
            String err = "Error: fail to send message. Caused by: " + e.getMessage();
            logger.error(err);
            throw new SapphireException(err);
        } catch (Exception e) {
            logger.error(e.getMessage());
            throw new SapphireException(e.getMessage());
        }

    }

    /**
     * Description: Get connection URL from Policy.
     *
     * @param serviceName
     * @return
     * @throws SapphireException
     */
    private DataSet getConnectionData(String serviceName) throws SapphireException {
        //logger.info("Processing " + ACTION_ID + ". > getConnectionData method");
        // private variable
        DataSet dsConnData = new DataSet();
        dsConnData.addColumn("url", DataSet.STRING);
        dsConnData.addColumn("username", DataSet.STRING);
        dsConnData.addColumn("password", DataSet.STRING);

        String policyNodeName = "";

        if (serviceName.equalsIgnoreCase(SERVICE_NAME_LOT_REQUEST)) {
            policyNodeName = "lotrequestlvoutboundcollection";

        } else if (serviceName.equalsIgnoreCase(SERVICE_NAME_RESULT_UPLOAD)) {
            policyNodeName = "resultuploadlvoutboundcollection";

        } else {
            String err = "No outbound URL has setup in SAPInterfacePolicy.";
            throw new SapphireException(err);
        }

        PropertyList plBatchTemplate = getConfigurationProcessor().getPolicy("SAPInterfacePolicy", "Custom");
        PropertyListCollection plLotRequestCollection = plBatchTemplate.getCollection(policyNodeName);
        for (int row = 0; row < plLotRequestCollection.size(); row++) {
            String endPointURL = plLotRequestCollection.getPropertyList(row).getProperty("endpointurl", "");
            String username = plLotRequestCollection.getPropertyList(row).getProperty("username", "");
            String password = plLotRequestCollection.getPropertyList(row).getProperty("password", "");
            if (endPointURL.equals("") || username.equals("") || password.equals("")) {
                String error = "Endpoint URL has not set in SAPInterfacePolicy.";
                throw new SapphireException(error);
            }

            int rowId = dsConnData.addRow();
            dsConnData.setValue(rowId, "url", endPointURL);
            dsConnData.setValue(rowId, "username", username);
            dsConnData.setValue(rowId, "password", password);
            outBoundURL = endPointURL;
        }

        return dsConnData;
    }

}
