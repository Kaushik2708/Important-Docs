package labvantage.custom.alcon.sap.action;

import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

/**
 * $Author $
 * $Date: 2021-04-19 05:17:29 -0500 (Mon, 19 Apr 2021) $
 * $Revision: 262 $
 */

/***********************************************
 * $Revision: 262 $
 * Description:
 * This class is used to log the error into IntfError Table.
 *
 * @author Soumen Mitra
 * @version 1
 ************************************************/
public class SAPErrorHandler extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 262 $";

    public static final String ID = "SAPErrorHandler";
    public static final String VERSIONID = "1";

    public static final String PROPERTY_ERROR_MSG = "errormsg";
    public static final String PROPERTY_PROGRAM= "program";
    public static final String PROPERTY_TRANSACTION_ID= "intftransid";
    public static final String PROPERTY_TRANSACTION_ITEM_ID= "intftransitemid";

    /**
     * Description: processAction is an OOB LabVantage method. This is the main method where execution starts.
     *
     * @param properties
     * @throws SapphireException
     */

    public void processAction(PropertyList properties) throws SapphireException {

        String transItemId = properties.getProperty(PROPERTY_TRANSACTION_ITEM_ID,"");

        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "IntfError");
        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");

        //
        pl.setProperty(PROPERTY_TRANSACTION_ID, properties.getProperty(PROPERTY_TRANSACTION_ID,""));
        pl.setProperty(PROPERTY_TRANSACTION_ITEM_ID, transItemId);
        pl.setProperty(PROPERTY_ERROR_MSG, properties.getProperty(PROPERTY_ERROR_MSG,""));
        pl.setProperty(PROPERTY_PROGRAM,  properties.getProperty(PROPERTY_PROGRAM,""));
        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

        } catch (SapphireException e) {
            String err ="Can't update InftError table. Reason: "+e.getMessage();
            logger.error(err);
        }

    }


}
