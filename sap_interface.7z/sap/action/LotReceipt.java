package labvantage.custom.alcon.sap.action;


//import com.google.gwt.junit.client.WithProperties;
import labvantage.custom.alcon.sap.util.ErrorMessageUtil;
import labvantage.custom.alcon.sap.util.SAPUtil;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.util.DBAccess;
import sapphire.util.DataSet;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.ErrorManager;

public class LotReceipt extends BaseAction {
    public static String DEVOPS_ID ="";

    public static final String ID ="LotReceipt";
    public static final String VERSIONID ="1";

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("=============== Start Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
        StringBuilder _errMsg = new StringBuilder().append(" Error:::");
        String _transID = "";
        String transItemId = "";
        String strDataPayload = properties.getProperty("itemdata");
        if (strDataPayload == null || "".equalsIgnoreCase(strDataPayload)) {
            throw new SapphireException(_errMsg.append(ErrorMessageUtil.INVALID_SAP_DATA_PAYLOAD).toString());
        }
        // 1. Getting SAP payload
        DataSet dsItemPayLoad = SAPUtil.getDataSetFromXMLString(strDataPayload);
        logger.info(" Lot Receipt SAP payload " + dsItemPayLoad.toJSONString());

        DataSet dsBatchDetails = new DataSet();
        // 2. Setting SAP Required columns
        dsBatchDetails = getSAPDataForBatch(dsItemPayLoad, dsBatchDetails);
        //int size = dsBatchDetails.getRowCount();
        String inspectionLotStatus = dsBatchDetails.getValue(0, "SAPINSPECTIONLOTSTATUS", "");
        String sapBatch = dsBatchDetails.getValue(0, "SAPBATCHNUMBER", "");
        String inspectionLot = dsBatchDetails.getValue(0, "SAPINSPECTIONLOT", "");
        String sapPlant = dsBatchDetails.getValue(0, "SAPPLANT", "");
        String sapMaterial = dsBatchDetails.getValue(0, "SAPMATERIALNUMBER", "");
        String sapInspectionLotOrigin = dsBatchDetails.getValue(0, "INSPECTIONORIGIN", "");
        String sapOriginalBatch = dsBatchDetails.getValue(0,"SAPORIGINALBATCH","");
        String sapOriginalMat=dsBatchDetails.getValue(0,"SAPORIGINALMATERIAL","");
        String limsBatchId ="";
        // Checking Mandatory Fields for Inspection Lot, SAP Batch, SAP plant, Mat Number, Inspection Lot Origin
        checkMandatiryFields(dsBatchDetails, "SAPINSPECTIONLOTSTATUS", "SAPBATCHNUMBER", "SAPINSPECTIONLOT", "SAPPLANT", "SAPMATERIALNUMBER", "INSPECTIONORIGIN","SAPORIGINALBATCH","SAPORIGINALMATERIAL");
        // 3. Checking Cancelled Batch or Not (Inspection Lot Status = 'C' or 'D')
        boolean isCancelledBatch = checkCancelledBatch(inspectionLotStatus);
        // If Cancelled Batch
        if (isCancelledBatch) {
            // Todo: Now Just thoriwing Sapphire Exception
            processCancelBatch(inspectionLot,sapBatch,sapPlant,sapMaterial);

        }else if("Y".equalsIgnoreCase(sapLotBatchExists(inspectionLot,sapBatch,sapPlant,sapMaterial)[0])){
            // 4. Checking If Already a Open Batch or Not
            _errMsg = _errMsg.append(ErrorMessageUtil.BATCH_EXIST).append(" For SAP Batch Id:").append(sapBatch).append(", SAP Plant:").append(sapPlant).append(" and SAP Material# :").append(sapMaterial).append("\n");
            throw new SapphireException(_errMsg.toString());
        }else{
            // 5. Determining Batch Type and Setting it in Batch Details DataSet
            String batchType = getBatchType(dsBatchDetails,sapInspectionLotOrigin);
            // 6. Determing Batch Template and Setting it in Batch Details DataSet
            String batchTemplateId = getBatchTemplate(dsBatchDetails,batchType);
            // 7. Checking Batch Master Presence
            DataSet dsPendingBatchMaster = isBatchMasterPresent(sapBatch,sapPlant,sapMaterial);
            if(!"".equalsIgnoreCase(dsPendingBatchMaster.getClob(0,"itemdata",""))) {
                // 7.1. Creating DataSet for Batch Master Data Payload.
                DataSet dsBatchMaster = SAPUtil.getDataSetFromXMLString(dsPendingBatchMaster.getValue(0,"itemdata",""));
                // 7.2. Setting up Batch Details for Expiry Date, Mfg Date and Batch Date
                setBatchMasterData(dsBatchDetails,dsBatchMaster);
                // 7.3 Updating the Transaction Item status from "Pending" to "Complete"
                updateTransItemStatus(dsPendingBatchMaster);
            }
            //8. Processing Batch based upon Batch Type (Raw Material, Finished, Stock transfer, Expiry Product)

            if (("Raw Material").equalsIgnoreCase(batchType)) {
                // Todo: Next Phase
            } else if (("Finished").equalsIgnoreCase(batchType)) {
                limsBatchId= processNewFinishedGood(dsBatchDetails,inspectionLot,sapBatch,sapMaterial,sapPlant);
            } else if (("Stock Transfer").equalsIgnoreCase(batchType)) {
                //Todo: Next Phase
            } else if (("Expiry Product").equalsIgnoreCase(batchType)) {
                //Todo: Next Phase
            } else {
                _errMsg = _errMsg.append(ErrorMessageUtil.INVALID_BATCH_TYPE);
                throw new SapphireException(_errMsg.toString());
            }
            // 9. Receiving Batch.
            //receiveBatch(limsBatchId);
            // 10. Add Batch Genealogy.
            //ToDo: Need to add Batch Genealogy Code

            // 11. Setting SAP Result IDs for Result Upload.
            //setSAPResultData(limsBatchId,dsItemPayLoad);
        }


        logger.info("=============== Processed Action: "+ID+", Version:"+VERSIONID+"===============");

    }

    private void setSAPResultData(String limsBatchId, DataSet dsSAPPayload) throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside setSAPResultData (method)");
        // Getting QAIVC Data
        DataSet dsQAIMV = getQAIMVData(dsSAPPayload);
        // Getting Test Names
        String strSAPTestNames =dsQAIMV.getColumnValues("KURZTEXT",";");
        // Setting Characteristics at SDIDataItem for Result Upload
        DataSet dsSDIDataItems = getResultUploadParams(limsBatchId,strSAPTestNames);
        if(dsSDIDataItems.getRowCount()>0){
            //Todo: Need to update SDIDataItem
            String[] testNames = StringUtil.split(strSAPTestNames,";");
            // Creating DataSet for SDIDataItem Entry
            DataSet dsSAPTestExceptLC = new DataSet();
            dsSAPTestExceptLC.addColumn("SAPLABCONFNO",DataSet.STRING);
            dsSAPTestExceptLC.addColumn("SAPSELECTEDSET",DataSet.STRING);
            dsSAPTestExceptLC.addColumn("SAMPLEID",DataSet.STRING);
            dsSAPTestExceptLC.addColumn("PARAMLISTID",DataSet.STRING);
            dsSAPTestExceptLC.addColumn("PARAMLISTVERSIONID",DataSet.STRING);
            dsSAPTestExceptLC.addColumn("PARAMLISTVARINATID",DataSet.STRING);
            dsSAPTestExceptLC.addColumn("PARAMID",DataSet.STRING);

            int rowNo=0;
            for(int testNo=0;testNo<testNames.length;testNo++){
                String sapLabConfNum = dsQAIMV.getValue(testNo,"RUECKMELNR","");
                String sapSelectedSet = dsQAIMV.getValue(testNo,"AUSWMENGE1","");
                String testName = testNames[testNo];
                if("Laboratory System Confirmation".equalsIgnoreCase(testName)){
                    //Todo: Update Batch
                    updateBatch(limsBatchId,sapLabConfNum,sapSelectedSet);
                }
                else{

                    //Todo: Update SDIDataItem
                    if(rowNo<dsSDIDataItems.getRowCount()) {
                        // Creating DataSet for Test Names except Laboratory System Confirmation
                        dsSAPTestExceptLC.addRow();
                        dsSAPTestExceptLC.setValue(rowNo,"SAPLABCONFNO",sapLabConfNum);
                        dsSAPTestExceptLC.setValue(rowNo,"SAPSELECTEDSET",sapSelectedSet);
                        dsSAPTestExceptLC.setValue(rowNo,"SAMPLEID",dsSDIDataItems.getValue(rowNo,"sampleid",""));
                        dsSAPTestExceptLC.setValue(rowNo,"PARAMLISTID",dsSDIDataItems.getValue(rowNo,"paramlistid",""));
                        dsSAPTestExceptLC.setValue(rowNo,"PARAMLISTVERSIONID",dsSDIDataItems.getValue(rowNo,"paramlistversionid",""));
                        dsSAPTestExceptLC.setValue(rowNo,"PARAMLISTVARINATID",dsSDIDataItems.getValue(rowNo,"paramlistvariantid",""));
                        dsSAPTestExceptLC.setValue(rowNo,"PARAMID",dsSDIDataItems.getValue(rowNo,"paramid",""));

                        rowNo++;
                    }

                }
            }
            if(dsSAPTestExceptLC!=null && dsSAPTestExceptLC.getRowCount()>0){
                updateSDIDataItem(dsSAPTestExceptLC);
            }
        }

    }

    private void updateBatch(String limsBatchId,String sapLabConfNum,String sapSelectedSet) throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside updateTransItemStatus (method)");
        PropertyList plSAPResultData = new PropertyList();
        plSAPResultData.setProperty(EditSDI.PROPERTY_SDCID,"Batch");
        plSAPResultData.setProperty(EditSDI.PROPERTY_KEYID1,limsBatchId);
        plSAPResultData.setProperty("u_saplabconfnum",sapLabConfNum);
        plSAPResultData.setProperty("u_saplcselectedset",sapSelectedSet);
        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,plSAPResultData);
    }
    private void updateSDIDataItem(DataSet dsSAPTestDetailsExceptLC)throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside updateSDIDataItem (method)");
        // Reading SDIDataItem Column from Test Details except Laboratory System Confirmation
        try {
            String sqlStmt = "UPDATE SdiDataItem SET u_sapconfnum = ?,u_sapselectedset = ?,u_issapresult = 'Y' WHERE sdcid = 'Sample' AND keyid1 = ? AND paramlistid = ? AND paramlistversionid = ? AND variantid = ? AND paramid = ? AND dataset = 1 AND replicateid = 1";
            PreparedStatement psSDIDataItemMap = database.prepareStatement(sqlStmt);
            for (int testNo=0;testNo<dsSAPTestDetailsExceptLC.getRowCount();testNo++) {
                try {
                    String sapLabConfNum=dsSAPTestDetailsExceptLC.getValue(testNo, "SAPLABCONFNO", "");
                    String sapSelectedSet=dsSAPTestDetailsExceptLC.getValue(testNo, "SAPSELECTEDSET", "");
                    String sampleId = dsSAPTestDetailsExceptLC.getValue(testNo, "SAMPLEID", "");
                    String paramlistId = dsSAPTestDetailsExceptLC.getValue(testNo, "PARAMLISTID", "");
                    String paramlistVersionId = dsSAPTestDetailsExceptLC.getValue(testNo, "PARAMLISTVERSIONID", "");
                    String Varinatid = dsSAPTestDetailsExceptLC.getValue(testNo, "PARAMLISTVARINATID", "");
                    String paramId = dsSAPTestDetailsExceptLC.getValue(testNo, "PARAMID", "");

                    psSDIDataItemMap.setString(1, sapLabConfNum);
                    psSDIDataItemMap.setString(2, sapSelectedSet);
                    psSDIDataItemMap.setString(3, sampleId);
                    psSDIDataItemMap.setString(4, paramlistId);
                    psSDIDataItemMap.setString(5, paramlistVersionId);
                    psSDIDataItemMap.setString(6, Varinatid);
                    psSDIDataItemMap.setString(7, paramId);

                    psSDIDataItemMap.addBatch();
                }
                catch (SQLException e) {
                    throw new SapphireException("Unable to set Prepared Statement:Reason:" + e.getMessage());
                }

            }

            try {
                psSDIDataItemMap.executeBatch();
                psSDIDataItemMap.clearParameters();
                psSDIDataItemMap.clearBatch();
                psSDIDataItemMap.close();
            }
            catch (SQLException e) {
                throw new SapphireException("Failed to execute SDIDataItem update:Reason:" + e.getMessage());
            }
            finally {
                psSDIDataItemMap.close();
            }
        }
        catch (SQLException se) {
            throw new SapphireException("Error encountered during entries into SDIDataItem table. " + se.getMessage());
        }
    }
    private DataSet getResultUploadParams(String limsBatchId, String sapTestNames) throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside setResultUploadParams (method)");
        StringBuilder _errMsg = new StringBuilder().append(" Error:::");
        String sqlText ="select sdi.keyid1 sampleid,wii.keyid1 paramlistid,pl.paramlistversionid paramlistversionid, wii.keyid3 paramlistvariantid, sdi.paramid paramid\n" +
                "from workitem wi,workitemitem wii,paramlist pl,paramlistitem pli,sdidataitem sdi,s_sample s\n" +
                "where wi.u_saptestname in ('"+StringUtil.replaceAll(sapTestNames,";","','")+"')\n" +
                "and wi.versionstatus = 'C'\n" +
                "and wii.workitemid = wi.workitemid\n" +
                "and wii.workitemversionid = wi.workitemversionid\n" +
                "and wii.sdcid = 'ParamList'\n" +
                "and pl.paramlistid = wii.keyid1 \n" +
                "and pl.versionstatus = 'C'\n" +
                "and sdi.sdcid='Sample'\n" +
                "and sdi.paramlistid = wii.keyid1\n" +
                "and sdi.paramlistversionid = pl.paramlistversionid\n" +
                "and sdi.variantid = wii.keyid3\n" +
                "and sdi.dataset =1\n" +
                "and sdi.replicateid =1\n" +
                "and sdi.paramid = pli.paramid\n" +
                "and pli.paramlistid=wii.keyid1\n" +
                "and pli.paramlistversionid = pl.paramlistversionid\n" +
                "and pli.variantid = wii.keyid3\n" +
                "and pli.u_issapresult = 'Y'\n" +
                "and s.s_sampleid = sdi.keyid1\n" +
                "and s.batchid = '"+limsBatchId+"'";
        DataSet dsSDIData = getQueryProcessor().getSqlDataSet(sqlText);

        if(null==dsSDIData){
            _errMsg.append(ErrorMessageUtil.NULL_DATASET_FOUND).append(" While executing query for getting Characteristic details");
            throw new SapphireException(_errMsg.toString());
        }
        return dsSDIData;

    }
    private DataSet getQAIMVData(DataSet dsSAPPayload)throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside getQAIVCData (method)");
        StringBuilder _errMsg = new StringBuilder().append(" Error:::");
        DataSet dsQAIMV=new DataSet();
        dsQAIMV.addColumn("KURZTEXT",DataSet.STRING);
        dsQAIMV.addColumn("RUECKMELNR",DataSet.STRING);
        dsQAIMV.addColumn("AUSWMENGE1",DataSet.STRING);
        int sapTestCount = StringUtil.split(SAPUtil.getColumnValue(dsSAPPayload,"QAIMV","KURZTEXT"),";").length;
        if(sapTestCount<=0){
            _errMsg.append(" No SAP Test Name found for Result Upload.");
            throw new SapphireException(_errMsg.toString());
        }else{
            for(int rowNum=0;rowNum<sapTestCount;rowNum++){
                // Adding Rows to QAIMV DataSet
                dsQAIMV.addRow();
                dsQAIMV.setValue(rowNum,"KURZTEXT",StringUtil.split(SAPUtil.getColumnValue(dsSAPPayload,"QAIMV","KURZTEXT"),";")[rowNum]);
                dsQAIMV.setValue(rowNum,"RUECKMELNR",StringUtil.split(SAPUtil.getColumnValue(dsSAPPayload,"QAIMV","RUECKMELNR"),";")[rowNum]);
                dsQAIMV.setValue(rowNum,"AUSWMENGE1",StringUtil.split(SAPUtil.getColumnValue(dsSAPPayload,"QAIMV","AUSWMENGE1"),";")[rowNum]);
            }
        }
        return dsQAIMV;
    }


    private void updateTransItemStatus(DataSet dsPendingBatchMaster) throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside updateTransItemStatus (method)");
        PropertyList plPendingBM = new PropertyList();
        plPendingBM.setProperty(EditSDI.PROPERTY_SDCID,"IntfTransItem");
        plPendingBM.setProperty(EditSDI.PROPERTY_KEYID1,dsPendingBatchMaster.getColumnValues("u_intftransitemid",";"));
        plPendingBM.setProperty("status","COMPLETE");
        plPendingBM.setProperty("pendignglotflag","N");
        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,plPendingBM);
    }
    private void setBatchMasterData(DataSet dsBatchDetails, DataSet dsBatchMasterDetails) throws  SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside setBatchMasterData (method)");

        dsBatchDetails.setValue(0,"BATCHDATE","");
        dsBatchDetails.setValue(0,"BATCHMFGDATE",SAPUtil.getColumnValue(dsBatchMasterDetails,"E1BPBATCHATT","PRODDATE"));
        dsBatchDetails.setValue(0,"BATCHEXPIRYDATE",SAPUtil.getColumnValue(dsBatchMasterDetails,"E1BPBATCHATT","EXPIRYDATE"));

    }

    private DataSet isBatchMasterPresent(String sapBatch, String sapPlant, String sapMatNum) throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside isBatchMasterPresent (method)");
        StringBuilder errMsg = new StringBuilder().append("Error:::");
        StringBuilder sqlText = new StringBuilder().append("select u_intftransitemid,itemdata from u_intfTransItem").append(" where key1name = 'Batch' and key1value = '").append(sapBatch).append("' and key2name = 'Material Number' and key2value='").append(sapMatNum).append("' and plant ='").append(sapPlant).append("' and transname = 'BATCH_MASTER'").append(" and pendinglotflag = 'Y' order by createdt desc");
        DataSet dsItemData =getQueryProcessor().getSqlDataSet(sqlText.toString(),true);
        if(dsItemData==null){
            throw new SapphireException(errMsg.append(ErrorMessageUtil.NULL_SQL_VALUE).append(" While checking Batch master presence.").toString());
        }
        else
        {
            return dsItemData;
        }
    }

    private String processNewFinishedGood(DataSet dsBatchDetails,String inspectionLot,String sapBatch, String sapMaterial, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside processNewFinishedGood (method)");
        //String transId = dsBatchDetails.getValue(0,"TRANSID");
        //String transItemId = dsBatchDetails.getValue(0,"TRANSITEMID");
        StringBuilder errMsg = new StringBuilder().append(" Error:::");
        // Getting Finished Product Batch Product Variant
        getFinGoodProdVariantData(dsBatchDetails, sapBatch, sapMaterial, sapPlant);
        String strLIMSBatchId = "";
        strLIMSBatchId = createLIMSBatch(dsBatchDetails);
        if("".equalsIgnoreCase(strLIMSBatchId)){
            errMsg.append(ErrorMessageUtil.FAILED_EXECUTING_BATCH).append(" LIMS Batch Id not found. ");
            throw new SapphireException(errMsg.toString());
        }else{
            dsBatchDetails.addColumn("LIMSBATCHID",DataSet.STRING);
            dsBatchDetails.setValue(0,"LIMSBATCHID",strLIMSBatchId);
            logger.info(" New Batch Id is: " + strLIMSBatchId);
        }
        return strLIMSBatchId;
    }

    private void getFinGoodProdVariantData(DataSet dsBatchDetails, String sapBatch, String sapMatNum, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getFinGoodProdVariantData (method)");
        StringBuilder errMsg = new StringBuilder().append(" Error:::");
        // Getting PV and Product Details using SAP Inspection Lot Material# and Plant
        DataSet dsProdVarDetails = getActiveProductVariant(sapMatNum,sapPlant);
        // In case the SAP Inspection Lot Mat# and Plant is returning multiple PVs
        if (dsProdVarDetails.getRowCount() > 1) {
            //Todo for Multiple Product Variant -- getFinProdVariantByParent(sapMatNum, sapPlant);
            String sapOriginalBatch = dsBatchDetails.getValue(0,"SAPORIGINALBATCH");
            String sapOriginalMat = dsBatchDetails.getValue(0,"SAPORIGINALMATERIAL");
            // Parent / BAT Batch can't have multiple PVs.
            if(sapBatch.equalsIgnoreCase(sapOriginalBatch) && sapMatNum.equalsIgnoreCase(sapOriginalMat)){
                errMsg.append(ErrorMessageUtil.PARENT_BATCH_MULTIPLE_PV).append(" For SAP Batch: ").append(sapBatch).append(" and SAP Material: ").append(sapMatNum);
                throw new SapphireException(errMsg.toString());
            }else {
                // Getting parent Product Id
                String parentProductId = getParentProduct(sapOriginalBatch, sapOriginalMat, sapPlant);
                // Getting PV by passing Parent Product Id and Parent Material#
                DataSet dsProdVariantByParentProdId = getFinProdVariantByParent(parentProductId, sapMatNum);
                //DataSet dsProdVariantByParentProdId = getFinProdVariantByParent(parentProductId, sapOriginalMat);
                // If returned PV DataSet is having more than one row then throw Error
                if (dsProdVariantByParentProdId.getRowCount() > 1) {
                    errMsg.append(ErrorMessageUtil.FAILED_EXECUTING_PROD_VAR).append(" For SAP Batch: ").append(sapBatch).append(" and SAP Material: ").append(sapMatNum);
                    throw new SapphireException(errMsg.toString());
                } else if (dsProdVariantByParentProdId.getRowCount() == 0) {
                    errMsg.append(ErrorMessageUtil.NO_PROD_VAR_FOUND).append(" For SAP Batch: ").append(sapBatch).append(" and SAP Material: ").append(sapMatNum);
                    throw new SapphireException(errMsg.toString());
                } else {
                    for (int col = 0; col < dsProdVariantByParentProdId.getColumnCount(); col++) {
                        dsBatchDetails.addColumn(dsProdVariantByParentProdId.getColumnId(col), dsProdVariantByParentProdId.getColumnType(dsProdVariantByParentProdId.getColumnId(col)));
                        dsBatchDetails.setValue(0, dsProdVariantByParentProdId.getColumnId(col), dsProdVariantByParentProdId.getValue(0, dsProdVariantByParentProdId.getColumnId(col), ""));
                    }
                }
            }
        }else {
            for (int col = 0; col < dsProdVarDetails.getColumnCount(); col++) {
                dsBatchDetails.addColumn(dsProdVarDetails.getColumnId(col), dsProdVarDetails.getColumnType(dsProdVarDetails.getColumnId(col)));
                dsBatchDetails.setValue(0, dsProdVarDetails.getColumnId(col), dsProdVarDetails.getValue(0, dsProdVarDetails.getColumnId(col), ""));
            }
        }
    }

    private DataSet getActiveProductVariant(String sapMatNumber, String sapPlant) throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside getActiveProductVariant (method)");
        StringBuilder errMsg = new StringBuilder().append("");
        String sqlText = "";
        sqlText = "SELECT p.productdesc, p.sampletypeid, p.materialid, p.u_prodsubtypeid, pv.* " +
                "FROM s_product p, s_prodvariant pv " +
                "WHERE p.s_productid = pv.productid " +
                "AND pv.u_sapmatnumber ='" + sapMatNumber + "' " +
                "AND pv.u_sapplant = '" + sapPlant + "'" +
                "AND pv.productversionid = p.s_productversionid " +
                "AND p.versionstatus = 'C'"+
                "AND nvl(pv.activeflag,'Y')='Y'";
        DataSet dsPVDetails = getQueryProcessor().getSqlDataSet(sqlText);
        if (null == dsPVDetails) {
            errMsg = errMsg.append(" Error:::").append(ErrorMessageUtil.FAILED_EXECUTING_PROD_VAR).append(" for SAP material: ").append(sapMatNumber).append(" & SAP Plant: ").append(sapPlant).append("\n");
            throw new SapphireException(errMsg.toString());
        }else if (dsPVDetails.getRowCount() == 0) {
            errMsg = errMsg.append(" Error:::").append(ErrorMessageUtil.NO_PROD_VAR_FOUND).append(" for SAP material: ").append(sapMatNumber).append(" & SAP Plant: ").append(sapPlant).append("\n");
            throw new SapphireException(errMsg.toString());
        }else{
            return dsPVDetails;
        }
    }

    private String getParentProduct(String origSAPBatch, String origSAPMatNum, String sapPlant)throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside getParentProduct (method)");
        StringBuilder errMsg=new StringBuilder().append(" Error:::");
        String sqlText="select productid from s_batch where u_sapplant = '"+sapPlant+"' and u_sapmatnumber = '"+origSAPMatNum+"' and u_sapbatchnumber = '"+origSAPBatch+"' and batchstatus not in('Cancelled','Rejected','Released') order by createdt desc";
        DataSet dsProdDetails = getQueryProcessor().getSqlDataSet(sqlText);
        if(null==dsProdDetails){
            errMsg = errMsg.append(" Error:::").append(ErrorMessageUtil.FAILED_EXECUTING_PROD_VAR).append(" for SAP material: ").append(origSAPMatNum).append(" & SAP Plant: ").append(sapPlant).append("\n");
            throw new SapphireException(errMsg.toString());
        }else if (dsProdDetails.getRowCount() == 0) {
            errMsg = errMsg.append(" Error:::").append(ErrorMessageUtil.NO_PROD_VAR_FOUND).append(" for SAP material: ").append(origSAPMatNum).append(" & SAP Plant: ").append(sapPlant).append("\n");
            throw new SapphireException(errMsg.toString());
        }else {
            return dsProdDetails.getValue(0,"productid","");
        }
    }

    private DataSet getFinProdVariantByParent(String parentProdId, String originalMatNumber)throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside getFinProdVariantByParent (method)");
        StringBuilder errMsg = new StringBuilder().append("");
        String sqlText = "";
        sqlText = "SELECT p.productdesc, p.sampletypeid, p.materialid, p.u_prodsubtypeid, pv.* " +
                "FROM s_product p, s_prodvariant pv " +
                "WHERE p.s_productid = pv.productid " +
                "AND pv.u_sapmatnumber ='" + originalMatNumber + "' " +
                "AND pv.productid = '" + parentProdId + "'" +
                "AND pv.productversionid = p.s_productversionid " +
                "AND p.versionstatus = 'C'" +
                "AND nvl(pv.activeflag,'Y')='Y'";
        DataSet dsPVDetails = getQueryProcessor().getSqlDataSet(sqlText);
        if (null == dsPVDetails) {
            errMsg = errMsg.append(" Error:::").append(ErrorMessageUtil.FAILED_EXECUTING_PROD_VAR).append(" for SAP material: ").append(originalMatNumber).append(" & Parent Product Id: ").append(parentProdId).append("\n");
            throw new SapphireException(errMsg.toString());
        }else if (dsPVDetails.getRowCount() == 0) {
            errMsg = errMsg.append(" Error:::").append(ErrorMessageUtil.NO_PROD_VAR_FOUND).append(" for SAP material: ").append(originalMatNumber).append(" & Parent Product Id: ").append(parentProdId).append("\n");
            throw new SapphireException(errMsg.toString());
        }else{
            return dsPVDetails;
        }
    }

    private String createLIMSBatch(DataSet dsBatchDetails) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside createLIMSBatch (method)");
        // method variables
        String strBatchId = "";
        PropertyList plBatchDetails = new PropertyList();
        plBatchDetails.setProperty(AddSDI.PROPERTY_SDCID, "Batch");
        plBatchDetails.setProperty("productid", dsBatchDetails.getValue(0,"productid", ""));
        plBatchDetails.setProperty("productversionid", dsBatchDetails.getValue(0,"productversionid", ""));
        plBatchDetails.setProperty("prodvariantid", dsBatchDetails.getValue(0,"s_prodvariantid", ""));
        /*
        plBatchDetails.setProperty("u_sapinspectionlot", dsBatchDetails.getValue(0,"SAPINSPECTIONLOT", ""));
        plBatchDetails.setProperty("u_sapbatchnumber", dsBatchDetails.getValue(0,"SAPBATCHNUMBER", ""));
        plBatchDetails.setProperty("u_sapmatnumber", dsBatchDetails.getValue(0,"SAPMATERIALNUMBER", ""));
        plBatchDetails.setProperty("u_inspectionorigin", dsBatchDetails.getValue(0,"INSPECTIONORIGIN", ""));
        plBatchDetails.setProperty("u_inspectiontype", dsBatchDetails.getValue(0,"INSPECTIONTYPE", ""));
        plBatchDetails.setProperty("u_sapvendornum", dsBatchDetails.getValue(0,"SAPVENDORNUMBER", ""));
        plBatchDetails.setProperty("u_sapvendorname", dsBatchDetails.getValue(0,"SAPVENDORNAME", ""));
        plBatchDetails.setProperty("u_sapmaterialdesc", dsBatchDetails.getValue(0,"SAPMATERIALDESC", ""));
        plBatchDetails.setProperty("supplieraddresstype", dsBatchDetails.getValue(0,"supplieraddresstype", ""));
        plBatchDetails.setProperty("supplieraddressid", dsBatchDetails.getValue(0,"supplieraddressid", ""));
        plBatchDetails.setProperty("manufactureraddresstype", dsBatchDetails.getValue(0,"manufactureraddresstype", ""));
        plBatchDetails.setProperty("manufactureraddressid", dsBatchDetails.getValue(0,"manufactureraddressid", ""));
        plBatchDetails.setProperty("securityuser", dsBatchDetails.getValue(0,"securityuser", ""));
        plBatchDetails.setProperty("securitydepartment", dsBatchDetails.getValue(0,"securitydepartment", ""));
        plBatchDetails.setProperty("u_origsapbatch", dsBatchDetails.getValue(0,"SAPORIGINALBATCH", ""));// Need to discuss with Client what will be the actual value.
        plBatchDetails.setProperty("u_originalbatchid", dsBatchDetails.getValue(0,"SAPORIGINALBATCH", ""));// Need to discuss with Client what will be the actual value.
        plBatchDetails.setProperty("u_origsapmat", dsBatchDetails.getValue(0,"SAPORIGINALMATERIAL", "SWPHYNR"));// Need to discuss with Client what will be the actual value.
        plBatchDetails.setProperty("u_marscode", dsBatchDetails.getValue(0,"MARSCODE", ""));
        plBatchDetails.setProperty("u_mesordersapbatch1", "");
        plBatchDetails.setProperty("u_mesordersapbatch2", "");
        plBatchDetails.setProperty("u_toolid", dsBatchDetails.getValue(0,"TOOLID"));
        plBatchDetails.setProperty("u_locmatcode", dsBatchDetails.getValue(0,"LOCALMATERIALCODE", ""));
        plBatchDetails.setProperty("u_sapvendorstatus", dsBatchDetails.getValue(0,"SAPVENDORSTATUS", ""));
        plBatchDetails.setProperty("batchdesc", dsBatchDetails.getValue(0,"productdesc", ""));
        plBatchDetails.setProperty("u_productsubtypeid", dsBatchDetails.getValue(0,"u_prodsubtypeid", ""));
        plBatchDetails.setProperty("u_sapsubsystem", dsBatchDetails.getValue(0,"SAPSUBSYTEM", ""));
        plBatchDetails.setProperty("templateflag", "N");

        plBatchDetails.setProperty("activeflag", "Y");
        plBatchDetails.setProperty("u_resultsuploaded", "N");
        */
        plBatchDetails.setProperty("templateid", dsBatchDetails.getValue(0,"BATCHTEMPLATE"));
        /*plBatchDetails.setProperty("u_catcodegrouppass",dsBatchDetails.getValue(0,"CATCODEGROUPPASS",""));
        plBatchDetails.setProperty("u_catcodepass",dsBatchDetails.getValue(0,"CODEPASS",""));
        plBatchDetails.setProperty("u_catcodegroupfail",dsBatchDetails.getValue(0,"CATCODEGROUPFAIL",""));
        plBatchDetails.setProperty("u_catcodefail",dsBatchDetails.getValue(0,"CODEFAIL",""));
        plBatchDetails.setProperty("u_issapflag","Y");
        plBatchDetails.setProperty("u_sapplant",dsBatchDetails.getValue(0,"SAPPLANT",""));
        plBatchDetails.setProperty("batchdt",dsBatchDetails.getValue(0,"BATCHDATE",""));
        plBatchDetails.setProperty("manufacturedt",dsBatchDetails.getValue(0,"BATCHMFGDATE",""));
        plBatchDetails.setProperty("expirydt",dsBatchDetails.getValue(0,"BATCHEXPIRYDATE",""));
        */
        getActionProcessor().processAction(AddSDI.ID,AddSDI.VERSIONID, plBatchDetails);

        strBatchId = plBatchDetails.getProperty("newkeyid1");
        logger.info("---- New Batch Id is: " + strBatchId + " ----");

        return strBatchId;

    }

    private void receiveBatch(String limsBatchId) throws  SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside receiveBatch (method)");
        StringBuilder errMsg = new StringBuilder().append("");
        PropertyList plReceiveBatch = new PropertyList();
        plReceiveBatch.setProperty("keyid1",limsBatchId);
        plReceiveBatch.setProperty("batchstatus",getBatchStatus(limsBatchId));
        logger.info("============= Calling CreateReducedBatchSamples for Receiving Batch ===============");
        //getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,plReceiveBatch);
        getActionProcessor().processAction("CreateReducedBatchSamples","1",plReceiveBatch);

    }

    private String getBatchStatus(String batchId) throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside getBatchStatus (method)");
        StringBuilder errMsg = new StringBuilder().append(" Error:::");
        StringBuilder sqlText = new StringBuilder();
        String strBatchStatus = "";
        sqlText.append("select batchstatus from s_batch ").append("where s_batchid ='").append(batchId).append("'");
        DataSet dsBatchStatus = getQueryProcessor().getSqlDataSet(sqlText.toString());
        if(dsBatchStatus==null){
            errMsg.append(ErrorMessageUtil.NULL_SQL_VALUE).append(" For LIMS batch Id: ").append(batchId);
            throw new SapphireException(errMsg.toString());
        }
        if(dsBatchStatus.getRowCount()==0){
            errMsg.append(ErrorMessageUtil.NO_ROW_FOUND).append(" For LIMS batch Id: ").append(batchId);
            throw new SapphireException(errMsg.toString());
        }
        strBatchStatus = dsBatchStatus.getValue(0,"batchstatus");
        return strBatchStatus;
    }

    private String getBatchTemplate(DataSet dsBatchDetails, String batchType) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getBatchTemplate (method)");
        // private variable
        StringBuilder errMsg = new StringBuilder().append("");
        String templateId = "";

        PropertyList plBatchTemplate = getConfigurationProcessor().getPolicy("SAPInterfacePolicy", "Custom");
        PropertyListCollection plBatchTemplateCol = plBatchTemplate.getCollection("BatchTemplate");
        for (int row = 0; row < plBatchTemplateCol.size(); row++) {
            String policyBatchType = plBatchTemplateCol.getPropertyList(row).getProperty("BatchType");
            if ((policyBatchType).equalsIgnoreCase(batchType)) {
                templateId = plBatchTemplateCol.getPropertyList(row).getProperty("BatchTemplate");
                dsBatchDetails.addColumn("BATCHTEMPLATE",DataSet.STRING);
                dsBatchDetails.setValue(0,"BATCHTEMPLATE",templateId);
                return templateId;
            }
        }
        if (("").equalsIgnoreCase(templateId)) {
            errMsg = errMsg.append(" Error::: ").append(ErrorMessageUtil.INVALID_BATCH_TYPE);
            logger.error(errMsg.toString());
            throw new SapphireException(errMsg.toString());
        }
        return templateId;
    }
    private String getBatchType(DataSet dsBatchDetails, String lotOrigin) throws SapphireException {
        // determine type
        logger.info("Processing " + ID + ". (Action) : Inside getBatchType (method)");
        StringBuilder errMsg = new StringBuilder().append(" Error:::");
        switch (lotOrigin) {
            case "01":
                // Todo for Raw Material
            case "04":
                dsBatchDetails.addColumn("BATCHTYPE",DataSet.STRING);
                dsBatchDetails.setValue(0,"BATCHTYPE","Finished");
                return "Finished";
            case "08":
                //Todo for Stock Transfer
            case "09":
                // Todo for Expiry Product
            default:
                errMsg.append(ErrorMessageUtil.INVALID_BATCH_TYPE);
                throw new SapphireException();
        }
    }

    private String[] sapLotBatchExists(String strInspectionLot,String strSAPBatchId,String strSAPPlant,String strMatNum) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside sapLotBatchExists (method)");
        // method variables
        String[] limsBatchFound=new String[3];
        limsBatchFound[0]="N";
        limsBatchFound[1]="";
        limsBatchFound[2]="";
        StringBuilder errMsg = new StringBuilder().append("");
        String sqlText = "SELECT s_batchid,batchstatus FROM s_batch WHERE u_sapbatchnumber = '" + strSAPBatchId + "' and u_sapmatnumber ='" +strMatNum+"' and u_sapplant = '"+strSAPPlant+"'AND batchstatus not in('Released','Cancelled','Rejected')";
        DataSet dslimsBatch = getQueryProcessor().getSqlDataSet(sqlText);
        if (null == dslimsBatch) {
            errMsg = errMsg.append("Error:::").append(ErrorMessageUtil.NULL_SQL_VALUE).append("  While retriving LIMS Batch Id for SAP Batch Id: ").append(strSAPBatchId).append(" and SAP Inspection Lot: ").append(strInspectionLot).append("\n");
            throw new SapphireException(errMsg.toString());
        }
        if (dslimsBatch.getRowCount()>0) {
            limsBatchFound[0]="Y";
            limsBatchFound[1]=dslimsBatch.getValue(0,"s_batchid","");
            limsBatchFound[2]=dslimsBatch.getValue(0,"batchstatus","");
        }
        return limsBatchFound;
    }

    private void checkMandatiryFields(DataSet dsBatchDetails, String... colNames)throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside checkMandatiryFields (method)");
        StringBuilder errMsg = new StringBuilder().append(" Error:::");
        String colName ="";
        String dsColName = "";
        String colValue ="";
        for(int colNum=0;colNum<colNames.length;colNum++){
            colName = colNames[colNum];
            for(int dsColNo=0;dsColNo<dsBatchDetails.getColumnCount();dsColNo++){
                dsColName = dsBatchDetails.getColumnId(dsColNo);
                if(colName.equalsIgnoreCase(dsColName)){
                    colValue = dsBatchDetails.getValue(0,colName,"");
                    if("".equalsIgnoreCase(colValue)){
                        errMsg.append(ErrorMessageUtil.BlANK_VALUE).append(" For field:").append(colName);
                        logger.error(errMsg.toString());
                        throw new SapphireException(errMsg.toString());
                    }
                }
            }
        }
    }

    private void processCancelBatch(String inspectionLot,String sapBatch,String sapPlant, String sapMaterial) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside processCancelBatch (method)");
        StringBuilder errMsg = new StringBuilder().append(" Error::: ");
        String[] existinglimsBatch=sapLotBatchExists(inspectionLot,sapBatch,sapPlant,sapMaterial);
        if("N".equalsIgnoreCase(existinglimsBatch[0])){
            errMsg.append(ErrorMessageUtil.CANCELLED_BATCH).append(" For Inspection Lot: ").append(inspectionLot).append(" , SAP Batch: ").append(sapBatch).append(" , SAP Plant: ").append(sapPlant).append(" and SAP Material: ").append(sapMaterial);
            throw new SapphireException(errMsg.toString());
        }else{
            String limsBatchId= existinglimsBatch[1];
            String batchStatus = existinglimsBatch[2];
            if("Initial".equalsIgnoreCase(batchStatus)||"Received".equalsIgnoreCase(batchStatus)){
                //Todo: Set the Batch Status to cancelled
                PropertyList plBatchUpdate=new PropertyList();
                plBatchUpdate.setProperty(EditSDI.PROPERTY_SDCID,"Batch");
                plBatchUpdate.setProperty(EditSDI.PROPERTY_KEYID1,limsBatchId);
                plBatchUpdate.setProperty("batchstatus","Cancelled");
                try{
                    getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,plBatchUpdate);
                }catch(SapphireException ex){
                    errMsg.append(ErrorMessageUtil.FAILED_TO_CANCEL).append(" LIMS Batch: ").append(limsBatchId).append(" Error is: ").append("\r\n").append(ex.getMessage());
                    throw new SapphireException(errMsg.toString());
                }
            }else{
                //Todo: Marked For Cancellation
                PropertyList plBatchUpdate=new PropertyList();
                plBatchUpdate.setProperty(EditSDI.PROPERTY_SDCID,"Batch");
                plBatchUpdate.setProperty(EditSDI.PROPERTY_KEYID1,limsBatchId);
                plBatchUpdate.setProperty("u_markedforcancel","Y");
                try{
                    getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,plBatchUpdate);
                }catch(SapphireException ex){
                    errMsg.append(ErrorMessageUtil.FAILED_TO_MARK_AS_CANCEL).append(" For LIMS Batch Id: ").append(limsBatchId).append(" Error is: ").append("\r\n").append(ex.getMessage());
                    throw new SapphireException(errMsg.toString());
                }
                //Todo: Need to create a Event Plan /SDC Rule
            }
        }
    }

    private boolean checkCancelledBatch(String inspectionLotStatus) throws SapphireException{
        logger.info("Processing " + ID + ". (Action) : Inside checkCancelledBatch (method)");
        boolean status = false;
        StringBuilder errMsg = new StringBuilder().append(" Error");
        if("".equalsIgnoreCase(inspectionLotStatus)){
            errMsg.append(ErrorMessageUtil.BlANK_VALUE).append(" For SAP Inspection Lot Status.").append("\n");
            throw new SapphireException(errMsg.toString());
        }
        if ("D".equalsIgnoreCase(inspectionLotStatus) || "C".equalsIgnoreCase(inspectionLotStatus)) {
            status = true;
        }
        return status;
    }

    private DataSet getSAPDataForBatch(DataSet dsItemPayLoad,DataSet dsBatchDetails) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getSAPDataForBatch (method)");
        dsBatchDetails.addColumn("CATCODEGROUPPASS",DataSet.STRING);
        dsBatchDetails.addColumn("CODEPASS",DataSet.STRING);
        dsBatchDetails.addColumn("CATCODEGROUPFAIL",DataSet.STRING);
        dsBatchDetails.addColumn("CODEFAIL",DataSet.STRING);
        dsBatchDetails.addColumn("SAPINSPECTIONLOT",DataSet.STRING);
        dsBatchDetails.addColumn("SAPINSPECTIONLOTSTATUS",DataSet.STRING);
        dsBatchDetails.addColumn("SAPBATCHNUMBER",DataSet.STRING);
        dsBatchDetails.addColumn("SAPMATERIALNUMBER",DataSet.STRING);
        dsBatchDetails.addColumn("INSPECTIONORIGIN",DataSet.STRING);
        dsBatchDetails.addColumn("INSPECTIONTYPE",DataSet.STRING);
        dsBatchDetails.addColumn("SAPVENDORNUMBER",DataSet.STRING);
        dsBatchDetails.addColumn("SAPVENDORNAME",DataSet.STRING);
        dsBatchDetails.addColumn("SAPMATERIALDESC",DataSet.STRING);
        dsBatchDetails.addColumn("MARSCODE",DataSet.STRING);
        dsBatchDetails.addColumn("MESORDERSAPBATCH1",DataSet.STRING);
        dsBatchDetails.addColumn("MESORDERSAPBATCH2",DataSet.STRING);
        dsBatchDetails.addColumn("TOOLID",DataSet.STRING);
        dsBatchDetails.addColumn("LOCALMATERIALCODE",DataSet.STRING);
        dsBatchDetails.addColumn("SAPVENDORSTATUS",DataSet.STRING);
        dsBatchDetails.addColumn("SAPSUBSYTEM",DataSet.STRING);
        dsBatchDetails.addColumn("SAPPLANT",DataSet.STRING);
        dsBatchDetails.addColumn("SAPORIGINALBATCH",DataSet.STRING);
        dsBatchDetails.addColumn("SAPORIGINALMATERIAL",DataSet.STRING);
        //dsBatchDetails.addColumn("MFGPARTNUMBER",DataSet.STRING);
        //dsBatchDetails.addColumn("MANUFACTURER",DataSet.STRING);
        dsBatchDetails.addColumn("BATCHDATE",DataSet.DATE);
        dsBatchDetails.addColumn("BATCHMFGDATE",DataSet.DATE);
        dsBatchDetails.addColumn("BATCHEXPIRYDATE",DataSet.DATE);

        int rowId =dsBatchDetails.addRow();

        dsBatchDetails.setValue(rowId,"CATCODEGROUPPASS",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAICA", "CODEGRUPPE"),";")[0]);
        dsBatchDetails.setValue(rowId,"CODEPASS",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAICA", "CODE"),";")[0]);
        dsBatchDetails.setValue(rowId,"CATCODEGROUPFAIL",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAICA", "CODEGRUPPE"),";")[1]);
        dsBatchDetails.setValue(rowId,"CODEFAIL",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAICA", "CODE"),";")[1]);
        dsBatchDetails.setValue(rowId,"SAPINSPECTIONLOT",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "PRUEFLOS"), ";")[0]);
        dsBatchDetails.setValue(rowId,"SAPINSPECTIONLOTSTATUS",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "PRUEFSTAT"), ";")[0]);
        dsBatchDetails.setValue(rowId,"SAPBATCHNUMBER",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "CHARG"), ";")[0]);
        dsBatchDetails.setValue(rowId,"SAPMATERIALNUMBER",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "MATNR"), ";")[0]);
        dsBatchDetails.setValue(rowId,"INSPECTIONORIGIN",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "HERKUNFT"), ";")[0]);
        dsBatchDetails.setValue(rowId,"INSPECTIONTYPE",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "ART"), ";")[0]);
        dsBatchDetails.setValue(rowId,"SAPVENDORNUMBER","");
        dsBatchDetails.setValue(rowId,"SAPVENDORNAME","");
        dsBatchDetails.setValue(rowId,"SAPMATERIALDESC",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "KTEXTMAT"), ";")[0]);
        dsBatchDetails.setValue(rowId,"MARSCODE","");
        dsBatchDetails.setValue(rowId,"MESORDERSAPBATCH1",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "CHARG"), ";")[0]);
        dsBatchDetails.setValue(rowId,"MESORDERSAPBATCH2",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "CHARG"), ";")[0]);
        dsBatchDetails.setValue(rowId,"TOOLID","(null)");// Force fully setting this to (Null)
        dsBatchDetails.setValue(rowId,"LOCALMATERIALCODE",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWUSERD1"), ";")[0]);
        dsBatchDetails.setValue(rowId,"SAPVENDORSTATUS","");
        dsBatchDetails.setValue(rowId,"SAPSUBSYTEM",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SUBSYS"), ";")[0]);
        dsBatchDetails.setValue(rowId,"SAPPLANT",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "WERK"), ";")[0]);
        dsBatchDetails.setValue(rowId,"SAPORIGINALBATCH",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWUSERT1"), ";")[0]);
        dsBatchDetails.setValue(rowId,"SAPORIGINALMATERIAL",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWPHYNR"), ";")[0]);
        //dsBatchDetails.setValue(rowId,"MFGPARTNUMBER",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWPHYNR"), ";")[0]);
        //dsBatchDetails.setValue(rowId,"MANUFACTURER",StringUtil.split(SAPUtil.getColumnValue(dsItemPayLoad, "QAIVC", "SWPHYNR"), ";")[0]);
        dsBatchDetails.setValue(rowId,"BATCHDATE","(null)");
        dsBatchDetails.setValue(rowId,"BATCHMFGDATE","(null)");
        dsBatchDetails.setValue(rowId,"BATCHEXPIRYDATE","(null)");
        return  dsBatchDetails;
    }
}
