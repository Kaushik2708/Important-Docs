package labvantage.custom.alcon.sap.action;

import labvantage.custom.alcon.sap.util.SAPUtil;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.xml.PropertyList;

import static labvantage.custom.alcon.sap.util.SAPPlants.*;

/**
 * $Author: GHOSHKA1 $
 * $Date: 2021-10-05 10:08:46 -0500 (Tue, 05 Oct 2021) $
 * $Revision: 611 $
 */

/*******************************************************************
 * $Revision: 611 $
 * Description: This class works as a controller of different inbound services.
 * The service are channelized to different specific functionality (Batch Master, Lot Receipt).
 *
 *******************************************************************/
public class SAPProcessController extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 611 $";

    public static final String SERVICE_BATCH_MASTER = "BATCH_MASTER";
    public static final String SERVICE_LOT_RECEIPT = "LOT_RECEIPT";
    public static final String SERVICE_BATCH_CONSUMPTION = "BATCH_CONSUMPTION";
    public static final String SERVICE_MATERIAL_MASTER = "MATERIAL_MASTER";
    public static final String SERVICE_UNKNOWN = "UNKNOWN_SERVICE";

    public static final String POLICY_NAME = "SAPInboundPolicy";
    public static final String POLICY_NODE = "InboundValues";

    public static final String PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "processassysuserid";
    public String VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = "";

    /**
     * Description: Overloaded function to call the process action.
     *
     * @param properties
     * @throws SapphireException
     */
    public void processAction(PropertyList properties) throws SapphireException {

        VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID = properties.getProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, "");

        String intfTransId = properties.getProperty("transid", "");
        String intfTransItemId = properties.getProperty("transitemid", "");
        String itemData = properties.getProperty("itemdata", "");
        String serviceName = properties.getProperty("servicename", ""); //Example Batch Master, Lot Receipt
        String plantID = properties.getProperty("plantid", ""); //Example plantID wise ON/OFF to access the Batch master
        String inspectionLotOrigin = SAPUtil.getColumnValue(SAPUtil.getDataSetFromXMLString(itemData), "QAIVC", "HERKUNFT");
        String reprocessingFlag = properties.getProperty("reprocessingflag", "");


        if (itemData == null || itemData.equals("")) {
            String error = "Can't process SAP Process Controller. Item Data is null ";
            logger.error(error);
            throw new SapphireException(error);
        }
        if (serviceName == null || serviceName.equals("")) {
            String error = "Can't process SAP Process Controller. Service Name is null ";
            logger.error(error);
            throw new SapphireException(error);

        }

        if (!SAPUtil.validateProcessAsSysuserId(getQueryProcessor(), VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID)) {
            String err = "The userid - " + VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID + ", which scans SAP messages in staging table, does not exist.";
            throw new SapphireException(err);
        }

        if (serviceName.equalsIgnoreCase(SERVICE_BATCH_MASTER)) {
            if (SAPUtil.validateSystemService(getQueryProcessor(), plantID, SERVICE_BATCH_MASTER)) {
                processBatchMasterData(properties);
            } else {
                String err = "System is not active for the Plant ID : " + plantID;
                throw new SapphireException(err);
            }

        } else if (serviceName.equalsIgnoreCase(SERVICE_LOT_RECEIPT)) {
            if (SAPUtil.validateSystemService(getQueryProcessor(), plantID, SERVICE_LOT_RECEIPT)) {
                // ****** changed for JCM VisionCare RM
                // ****** Release 2
                processLotReceipt(properties, plantID, inspectionLotOrigin);
            } else {
                String err = "System is not active for the Plant ID : " + plantID;
                throw new SapphireException(err);
            }

        } else if (serviceName.equalsIgnoreCase(SERVICE_BATCH_CONSUMPTION)) {
            if (SAPUtil.validateSystemService(getQueryProcessor(), plantID, SERVICE_BATCH_CONSUMPTION)) {
                processBatchConsumption(properties);
            } else {
                String err = "System is not active for the Plant ID : " + plantID;
                throw new SapphireException(err);
            }

        } else if (serviceName.equalsIgnoreCase(SERVICE_MATERIAL_MASTER)) {
            processMaterialMaster(properties);

/**** Site check for Active/Offline bypassed, because SAP is sending material plan combination for any plants those are not yet gone live.
 if (SAPUtil.validateSystemService(getQueryProcessor(), plantID, SERVICE_MATERIAL_MASTER)) {
 } else {
 String err = "System is not active for the Plant ID : " + plantID;
 throw new SapphireException(err);
 }
 */

        } else {
            String error = "Service not defined.";
            logger.error(error);
            throw new SapphireException(error);
        }


    }

    /**
     * Description: Calls Batch Master function.
     *
     * @param properties
     * @throws SapphireException
     */
    private void processBatchMasterData(PropertyList properties) throws SapphireException {

        getActionProcessor().processAction(BatchMaster.ACTION_ID, BatchMaster.ACTION_VERSION_ID, properties);
        //properties.setProperty(IntfTransItem.PROP_PENDING_BATCH_CREATION,"Y");
    }

    /**
     * Description: Calls Lot Receipt function.
     *
     * @param properties
     * @param plantId
     * @param inspectionLotOrigin
     * @throws SapphireException
     */

    private void processLotReceipt(PropertyList properties, String plantId, String inspectionLotOrigin) throws SapphireException {

        properties.setProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);
        // ***** Added for VisionCare JCM RM
        // ***** Release 2
        if (PROPS_VISION_CARE_PLANT_U612.equalsIgnoreCase(plantId) || PROPS_VISION_CARE_PLANT_SG03.equalsIgnoreCase(plantId) || PROPS_VISION_CARE_PLANT_ID01.equalsIgnoreCase(plantId) || PROPS_VISION_CARE_PLANT_MY10.equalsIgnoreCase(plantId)) {
            getActionProcessor().processAction(VisionCare_Lot_Receipt.ID, VisionCare_Lot_Receipt.VERSIONID, properties);
        } else if (PROPS_ASEPTIC_PLANT_SG20.equalsIgnoreCase(plantId) || PROPS_ASEPTIC_PLANT_U630.equalsIgnoreCase(plantId) || PROPS_ASEPTIC_PLANT_U636.equalsIgnoreCase(plantId)) {
            if ("04".equalsIgnoreCase(inspectionLotOrigin)) {
                // For RM Inspection lot Origin is 01
                getActionProcessor().processAction(Lot_Receipt.ID, Lot_Receipt.VERSIONID, properties);
            } else {
                getActionProcessor().processAction(Aseptic_RM_Lot_Receipt.ID, Lot_Receipt.VERSIONID, properties);
            }
        }
    }

    /**
     * @param properties
     * @throws SapphireException
     */

    private void processMaterialMaster(PropertyList properties) throws SapphireException {

        properties.setProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

        getActionProcessor().processAction(MaterialMaster.ID, MaterialMaster.VERSIONID, properties);
    }

    /**
     * @param properties
     * @throws SapphireException
     */

    private void processBatchConsumption(PropertyList properties) throws SapphireException {

        properties.setProperty(PROPS_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID, VALUE_POLLER_SAP_MESSAGE_PROCESSASSYSUSERID);

        getActionProcessor().processAction(Batch_Consumption.ID, Batch_Consumption.VERSIONID, properties);
    }

}
