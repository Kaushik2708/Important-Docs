package labvantage.custom.alcon.sap.action;

import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.xml.PropertyList;

/**
 * $Author: MITRASO1 $
 * $Date: 2021-04-19 05:17:29 -0500 (Mon, 19 Apr 2021) $
 * $Revision: 262 $
 */

/***********************************************************
 * $Revision: 262 $
 * Description:
 * This class is used to set MarkForCancel status to "N".
 *
 * @author Aniruddha Bagchi
 * @version 1
 ***********************************************************/

public class UnmarkBatchMarkedForCancel extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 262 $";
    public static final String ID = "UnmarkBatchMarkedForCancel";
    public static final String VERSIONID = "1";

    /**
     * Description: processAction is an OOB LabVantage method. This is the main method where execution starts.
     *
     * @param properties
     * @throws SapphireException
     */

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("=============== Start Processing Action: " + ID + ", Version:" + VERSIONID + "===============");
        String batchId= properties.getProperty("s_batchid");
        try{
            setBatchStatus(batchId);
        }catch(SapphireException ex){
            logger.error(" Aborting Transaction!!!. Error detais is "+ex.getMessage());
        }
    }

    /**
     * Description: This Method is used to set the batch status.
     *
     * @param strBatchId
     * @throws SapphireException
     */

    private void setBatchStatus(String strBatchId) throws SapphireException{
        PropertyList plBatchDetails = new PropertyList();
        plBatchDetails.setProperty(EditSDI.PROPERTY_SDCID,"Batch");
        plBatchDetails.setProperty(EditSDI.PROPERTY_KEYID1,strBatchId);
        plBatchDetails.setProperty("u_markedforcancel","N");

        getActionProcessor().processAction(EditSDI.ID,EditSDI.VERSIONID,plBatchDetails);

    }
}
