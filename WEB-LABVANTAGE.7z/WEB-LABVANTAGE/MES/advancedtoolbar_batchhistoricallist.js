/**
 * Copyright (c) 2016 LABVANTAGE.  All rights reserved.
 * This software and documentation is the confidential and proprietary
 * information of LABVANTAGE. ("Confidential Information").
 * You shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement you
 * entered into with LABVANTAGE.
 *
 * If you are not authorized by LABVANTAGE to utilize this
 * software and/or documentation, you must immediately discontinue any
 * further use or viewing of this software and documentation.
 * Violators will be prosecuted to the fullest extent of the law by
 * LABVANTAGE.
 *
 * Developed by LABVANTAGE.
 * 265 Davidson Avenue, Suite 220
 * Somerset, NJ, 08873

 * Description: Added in AdvancedToolbar of Batch History List page.
 * <p>
 * <p>
 *
 * @author  Anal Mandal
 * @version $Author: analm $
 *          $Source: /extra/CVS/profserv/Alcon_06651/webapp/WEB-LABVANTAGE/scripts/advancedtoolbar_batchhistoricallist.js,v $
 *          $Revision: 1.3 $
 *          $Date: 2020/12/24 18:08:52 $
 *          $State: Exp $
 *          $Id: advancedtoolbar_batchhistoricallist.js,v 1.3 2020/12/24 18:08:52 analm Exp $
 */

function AT_BatchHistoricalList() {

    this.validateBatchBeforeUnrelease = function () {
        var batchIds = sapphire.page.list.getSelectedKeyId1().replaceAll("%3B",";");
        if(batchIds==""){
            sapphire.alert("Please select at least one batch.");
        } else {
            sapphire.ajax.callClass( "labvantage.custom.alcon.ajax.MES.CheckBatchUnderMESProcess", "objAT_BatchHistoricalList.callback_BatchIDValidation", {batchId: batchIds}, true, true );
        }
        return true;
    };
    this.callback_BatchIDValidation= function( result ){

        if ( result == 'PASS'){
            var formId = document.getElementById( 'submitdata' );
            var batchIds = sapphire.page.list.getSelectedKeyId1().replaceAll("%3B",";");
            addField( formId, 'hidden', 'action_keyid1', batchIds, 'action_keyid1' );
            addField( formId, 'hidden', 'action_sdcid', 'Batch', 'action_sdcid' );
            deferCallBack();
        }
        else{
            sapphire.alert("Sorry, can't Unrelease. Under the process of MES transaction.");
        }
    };
}

if ( typeof( objAT_BatchHistoricalList ) == 'undefined' ) {
    var objAT_BatchHistoricalList = new AT_BatchHistoricalList();
}