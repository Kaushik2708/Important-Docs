package labvantage.custom.alcon.mes.action;

import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import sapphire.SapphireException;
import sapphire.accessor.DAMProcessor;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SafeSQL;
import sapphire.xml.PropertyList;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
 * $Author: DIANAR1 $
 * $Date: 2023-01-02 16:34:26 +0530 (Mon, 02 Jan 2023) $
 * $Revision: 422 $
 */

/*************************************************************************************************
 * $Revision: 422 $
 * Description: This class is used for getting results when Sample Status is changed to Reviewed and send the results to MES
 **************************************************************************************************/

public class LIMSActionableResult extends BaseAction {

    public static final String DEVOPS_ID = "$Revision: 422 $";
    public static final String ID = "LIMSActionableResult";
    public static final String VERSIONID = "1";
    // Column variables for Site, SAP Batch Number, SAP Material Number, MES Sample ID, Stage Name related to the given sample
    private static final String SAP_PLANT = "u_sapplant";
    private static final String SAP_BATCH_NUMBER = "u_mesordersapbatch1";
    private static final String SAP_MATERIAL_NUMBER = "u_sapmatnumber";
    private static final String STAGE_NAME = "label";
    // KEY for Result items
    private static final String __PROPS_TEST_METHOD_NAME = "TEST_METHOD_NAME";
    private static final String __PROPS_PARAMETER_RESULT_NAME = "PARAMETER_RESULT_NAME";
    private static final String __PROPS_PARAMETER_RESULT_VALUE = "PARAMETER_RESULT_VALUE";
    private static final String __PROPS_TEST_METHOD_VERSION = "TEST_METHOD_VERSION";
    private static final String __PROPS_PARAMLIST_ID = "PARAMLIST_ID";
    private static final String __PROPS_PARAMLIST_VERSION = "PARAMLIST_VERSION";
    private static final String __PROPS_PARAMLIST_VARIANT = "PARAMLIST_VARIANT";
    private static final String __PROPS_PARAMLIST_DATASET = "PARAMLIST_DATASET";
    private static final String __PROPS_PARAMETER_TYPE = "PARAMETER_TYPE";
    private static final String __PROPS_REPLICATE_ID = "REPLICATE_ID";
    // TABLE COLUMN for Result items
    private static final String TEST_METHOD_NAME = "workitemid";
    private static final String PARAMETER_RESULT_NAME = "paramid";
    private static final String PARAMETER_RESULT_VALUE = "enteredtext";
    private static final String TEST_METHOD_VERSION = "workitemversionid";
    private static final String PARAMLIST_ID = "paramlistid";
    private static final String PARAMLIST_VERSION = "paramlistversionid";
    private static final String PARAMLIST_VARIANT = "variantid";
    private static final String PARAMLIST_DATASET = "dataset";
    private static final String PARAMETER_TYPE = "paramtype";
    private static final String REPLICATE_ID = "replicateid";
    private static final String DATATYPES = "datatypes";
    private static final String TRANSFORMDATE = "transformdt";
    private static final String ENTEREDVALUE = "enteredvalue";

    public static final String __EVENT_PROPS_SAMPLE_ID = "s_sampleid";
    private static final String __PROPS_POMS_DATE_FORMAT = "yyyyMMdd_HHmmss";
    private static final String __BLANK_STRING = "";
    private static final String __EVENT_PROPS_BATCHID = "batchid";
    private static final String __EVENT_PROPS_MESSAMPLEID = "messampleid";
    private static final String __EVENT_PROPS_BATCHSTAGEID = "batchstageid";
    private static final String __SDC_SAMPLE = "Sample";
    private boolean __PROP_LOG_DIAG_SWITCH = false;

    /**************************************************************
     * Description: This is the main method where execution starts.
     * @param properties Property List of properties.
     * @throws SapphireException OOB Sapphire exceptions.
     **************************************************************/
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        __PROP_LOG_DIAG_SWITCH = "ON".equalsIgnoreCase(MESUtil.getLogDiagSwitchValue(getConfigurationProcessor()));
        Long processingStartTime = System.currentTimeMillis();
        // *************  Local variables *************** //
        String limsBatchId = "";
        String batchStageId = "";
        String mesSampleId = "";
        String sampleId = "";
        String site = "";
        String transactiondatetime = "";
        String sapbatchnumber = "";
        String sapmaterialnumber = "";
        String stagename = "";
        String allMESSampleIds = properties.getProperty(__EVENT_PROPS_MESSAMPLEID, "");
        String allBatchStageIds = properties.getProperty(__EVENT_PROPS_BATCHSTAGEID, "");
        String allSampleIds = properties.getProperty(__EVENT_PROPS_SAMPLE_ID, "");
        String allLIMSBatchIds = properties.getProperty(__EVENT_PROPS_BATCHID, "");
        // ****** Splitting Multiple Batch Stage Ids, Sample Ids, MES Sample Ids  ******
        String[] arrBatchStageIds = allBatchStageIds.split(";");
        String[] arrMESSampleIds = allMESSampleIds.split(";");
        String[] arrSampleIds = allSampleIds.split(";");
        String[] arrLIMSBatchIds = allLIMSBatchIds.split(";");
        // ****** Getting All Results *********
        DataSet dsResults = getResultsBySampleId(allSampleIds);
        if (dsResults == null) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00002, " Result")));
        }
        // dsResults DataSet will be blank if no dataset inside sample is marked as MES Actionable
        if (dsResults.getRowCount() == 0) {
            return;
        }

        // ****** Getting LIMS Batch Ids *******
        for (int countSample = 0; countSample < arrSampleIds.length; countSample++) {
            sampleId = arrSampleIds[countSample];
            batchStageId = arrBatchStageIds[countSample];
            mesSampleId = arrMESSampleIds[countSample];
            limsBatchId = arrLIMSBatchIds[countSample];
            // ******** Checking if LIMS Batch is MES Batch else return *********
            if ("".equalsIgnoreCase(limsBatchId) || !isMESBatch(limsBatchId)) {
                continue;
            }
            // Getting: mesActionableflag from stage when batchstage is not cancelled.
            DataSet dsMESActionableFlag = getMESActionableFlag(sampleId);
            // If quuery is Wrong.
            if (dsMESActionableFlag == null) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.GENERAL_ERR_00002));
            }
            // dsMESActionableFlag DataSet will be blank if batchstage is cancelled.
            if (dsMESActionableFlag.getRowCount() == 0) {
                return;
            }
            // Checking: Is sample stage marked as MES Actionable If No then Exit
            if (!"Y".equalsIgnoreCase(dsMESActionableFlag.getValue(0, "u_ismesresult_aseptic", ""))) {
                return;
            }
            // Getting: JSON Payload data except Result Data
            DataSet dsJSONPayloadExceptResults = getBatchDetails(limsBatchId, batchStageId);

            // Getting site in a variable
            transactiondatetime = setTransactiondatetime();
            site = dsJSONPayloadExceptResults.getValue(0, SAP_PLANT, "");
            sapbatchnumber = dsJSONPayloadExceptResults.getValue(0, SAP_BATCH_NUMBER, "");
            sapmaterialnumber = dsJSONPayloadExceptResults.getValue(0, SAP_MATERIAL_NUMBER, "");
            stagename = dsJSONPayloadExceptResults.getValue(0, STAGE_NAME, "");

            // Creating: JSON String
            String JSONString = getResultJSONString(sampleId, dsResults);
            // ********* If JSONString is BLANK, then Continue *********
            if ("".equalsIgnoreCase(JSONString)) {
                continue;
            }

            // ******** Passing properties to OpcenterMESLVOutbound *********
            PropertyList prop = new PropertyList();
            prop.setProperty(OpcenterMESLVOutbound._PROPS_SERVICE_NAME, OpcenterMESLVOutbound._PROPS_LIMS_ACTIONABLE_RESULTS);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_SITE, site);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_TRANSACTIONDATETIME, transactiondatetime);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_SAP_BATCH_NUMBER, sapbatchnumber);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_LIMS_BATCH_NUMBER, limsBatchId);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_SAP_MATERIAL_NUMBER, sapmaterialnumber);
            prop.setProperty(OpcenterMESLVOutbound.__PROPS_MES_SAMPLE_ID, mesSampleId);
            prop.setProperty(OpcenterMESLVOutbound.__PROPS_STAGE_NAME, stagename);
            prop.setProperty(OpcenterMESLVOutbound.__PROPS_ITEMS, JSONString);
            prop.setProperty(OpcenterMESLVOutbound.MES_SAMPLE_NUMBER, mesSampleId);

            try {
                getActionProcessor().processAction(OpcenterMESLVOutbound.ID, OpcenterMESLVOutbound.VERSIONID, prop);
            } catch (SapphireException ex) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00011, OpcenterMESLVOutbound.ID)));
            }

        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "processAction");
        }
    }

    /*******************************************************************
     * This method is used to check MES Batch or Not.
     * @param limsBatchId LIMS Batch Id
     * @return True or False
     * @throws SapphireException OOB Sapphire Exception.
     *******************************************************************/
    private boolean isMESBatch(String limsBatchId) throws SapphireException {
        Long processingStartTime = System.currentTimeMillis();
        boolean isMESBatch = false;
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT NVL(u_ismesbatch,'N') ismesbatch FROM s_batch WHERE s_batchid = ").append(safeSQL.addVar(limsBatchId));

        DataSet dsISMESBatch = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());

        if (null == dsISMESBatch) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, " Aborting transaction. Failed to execute query for checking MES LIMS Batch or Not. ");
        }

        if ("Y".equalsIgnoreCase(dsISMESBatch.getValue(0, "ismesbatch", ""))) {
            isMESBatch = true;
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "isMESBatch");
        }
        return isMESBatch;

    }

    /**********************************************************************************
     * This Method is to get LIMS ACTIONABLE RESULT JSON String according By Sample Id.
     * @param sampleId getting as input property.
     * @param dsResults All result data
     * @return JSONString Payload as JSON String.
     * @throws SapphireException OOB Sapphire Exception.
     **********************************************************************************/
    private String getResultJSONString(String sampleId, DataSet dsResults) throws SapphireException {
        Long processingStartTime = System.currentTimeMillis();
        String retJSONString = "";
        PropertyList plFilter = new PropertyList();
        plFilter.setProperty("keyid1", sampleId);
        DataSet dsFilteredResults = dsResults.getFilteredDataSet(plFilter);
        if (dsFilteredResults.size() != 0) {
            retJSONString = dataSetToJSONString(dsFilteredResults);
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "getResultJSONString");
        }
        return retJSONString;
    }

    /*******************************************************
     * Tis method is used to convert DataSet to JSON String
     * @param ds DataSet given as input.
     * @return JSONString as JSON String.
     * @throws SapphireException OOB Sapphire Exception.
     *******************************************************/
    private String dataSetToJSONString(DataSet ds) throws SapphireException {
        Long processingStartTime = System.currentTimeMillis();
        ArrayList<String> result = new ArrayList<>();
        LinkedHashMap<String, String> resultProps = new LinkedHashMap<>();
        String parameterResultValue = "";
        String dataTypes = "";
        int length = ds.getRowCount();
        for (int rowNum = 0; rowNum < length; rowNum++) {
            parameterResultValue = "";
            dataTypes = ds.getValue(rowNum, DATATYPES, "");
            if ("O".equalsIgnoreCase(dataTypes) || "D".equalsIgnoreCase(dataTypes) || "DC".equalsIgnoreCase(dataTypes) || "OC".equalsIgnoreCase(dataTypes)) {
                parameterResultValue = getTransactiondatetime(ds.getValue(rowNum, TRANSFORMDATE, ""));
            } else if ("N".equalsIgnoreCase(dataTypes) || "A".equalsIgnoreCase(dataTypes) || "NC".equalsIgnoreCase(dataTypes)) {
                parameterResultValue = ds.getValue(rowNum, ENTEREDVALUE, "");
            }
            if ("".equalsIgnoreCase(parameterResultValue)) {
                parameterResultValue = ds.getValue(rowNum, PARAMETER_RESULT_VALUE, "");
            }

            resultProps.put(__PROPS_TEST_METHOD_NAME, ds.getValue(rowNum, TEST_METHOD_NAME, ""));
            resultProps.put(__PROPS_PARAMETER_RESULT_NAME, ds.getValue(rowNum, PARAMETER_RESULT_NAME, ""));
            resultProps.put(__PROPS_PARAMETER_RESULT_VALUE, parameterResultValue);
            resultProps.put(__PROPS_TEST_METHOD_VERSION, ds.getValue(rowNum, TEST_METHOD_VERSION, ""));
            resultProps.put(__PROPS_PARAMLIST_ID, ds.getValue(rowNum, PARAMLIST_ID, ""));
            resultProps.put(__PROPS_PARAMLIST_VERSION, ds.getValue(rowNum, PARAMLIST_VERSION, ""));
            resultProps.put(__PROPS_PARAMLIST_VARIANT, ds.getValue(rowNum, PARAMLIST_VARIANT, ""));
            resultProps.put(__PROPS_PARAMLIST_DATASET, ds.getValue(rowNum, PARAMLIST_DATASET, ""));
            resultProps.put(__PROPS_PARAMETER_TYPE, ds.getValue(rowNum, PARAMETER_TYPE, ""));
            resultProps.put(__PROPS_REPLICATE_ID, ds.getValue(rowNum, REPLICATE_ID, ""));

            result.add(MESUtil.lhmToJSONString(resultProps));
        }
        String JSONString = result.toString().replace(" {", "{").replace(":", ": ");
        if (length <= 1) {
            return JSONString.substring(1, JSONString.length() - 1);
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "dataSetToJSONString");
        }
        return JSONString;
    }

    /*******************************************************************
     * Getting: MES Actionable Flag from batchstage and processstage if batchstage status is not cancelled.
     * @return DataSet containing MES Actionable Flag.
     *******************************************************************/
    private DataSet getMESActionableFlag(String sampleid) throws SapphireException {
        Long processingStartTime = System.currentTimeMillis();
        // Query for checking: Inside Sampling Plan, is Stage marked as MES Actionable? (u_ismesresult_aseptic = 'Y') and Stage_Status != 'Cancelled'

        SafeSQL mesActionableFlagSafeSQL = new SafeSQL();
        StringBuilder mesActionableFlag = new StringBuilder().append("");
        mesActionableFlag.append(" SELECT pstg.u_ismesresult_aseptic FROM s_batchstage bstg INNER JOIN s_processstage pstg ");
        mesActionableFlag.append(" ON bstg.processstageid = pstg.s_processstageid AND bstg.samplingplanid = pstg.s_samplingplanid ");
        mesActionableFlag.append(" AND bstg.samplingplanversionid = pstg.s_samplingplanversionid AND bstg.label = pstg.label ");
        mesActionableFlag.append(" INNER JOIN s_sample s ON bstg.batchid = s.batchid AND s.batchstageid = bstg.s_batchstageid ");
        mesActionableFlag.append(" WHERE bstg.batchstagestatus <> 'Cancelled' ");
        mesActionableFlag.append(" AND s.s_sampleid in ( ").append(mesActionableFlagSafeSQL.addIn(sampleid, ";")).append(")");

        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "getMESActionableFlag");
        }
        return getQueryProcessor().getPreparedSqlDataSet(mesActionableFlag.toString(), mesActionableFlagSafeSQL.getValues());
    }

    /*************************************************************
     * Getting: Site, SAP Batch Number, SAP Material Number, MES Sample ID, Stage Name, Batch Id related to the given sample.
     * @return DataSet containing Site, SAP Batch Number, SAP Material Number, MES Sample ID, Stage Name, Batch Id from the given sample.
     *************************************************************/
    private DataSet getBatchDetails(String limsBatchId, String batchStageId) throws SapphireException {
        Long processingStartTime = System.currentTimeMillis();
        // Query for Fetching: Site, SAP Batch Number, SAP Material Number, MES Sample ID, Stage Name related to the given sample
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT s_batch.u_mesordersapbatch1, s_batch.u_sapplant,s_batch.u_sapmatnumber, s_batchstage.label  ").append(" FROM s_batch INNER JOIN s_batchstage ");
        strSQL.append(" ON s_batch.s_batchid = s_batchstage.batchid  ");
        strSQL.append(" WHERE s_batchid = ").append(safeSQL.addVar(limsBatchId));
        strSQL.append("AND s_batchstage.s_batchstageid = ").append(safeSQL.addVar(batchStageId));

        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "getBatchDetails");
        }
        return getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
    }

    /*********************************************
     * Getting: Test Method Name, Parameter Result Name, Parameter Result Value, Test Method Version, Paramlist Id,
     * Paramlist Version, Paramlist Variant, Paramlist DataSet, Paramlist Type, Replicate Id related to the given sample.
     * @return DataSet containing Test Method Name, Parameter Result Name, Parameter Result Value, Test Method Version, Paramlist Id,
     * Paramlist Version, Paramlist Variant, Paramlist DataSet, Paramlist Type, Replicate Id from the given sample.
     *********************************************/

    private DataSet getResultsBySampleId(String allSampleIds) throws SapphireException {
        Long processingStartTime = System.currentTimeMillis();
        // Query for Fetching: Test Method Name, Parameter Result Name, Parameter Result Value, Test Method Version, Paramlist Id,
        // Paramlist Version, Paramlist Variant, Paramlist DataSet, Paramlist Type, Replicate Id related to the given sample
        String rsetId = "";
        SafeSQL resultsSafeSQL = new SafeSQL();
        StringBuilder sqlText = new StringBuilder().append("");
        DataSet dsAllResults = new DataSet();
        try {
            rsetId = getDAMProcessor().createRSet(__SDC_SAMPLE, allSampleIds, "(null)", "(null)");
            sqlText.append(" SELECT swi.workitemid, swi.workitemversionid, sdi.keyid1, sdi.keyid2, sdi.keyid3, sdi.paramlistid, sdi.paramlistversionid, sdi.variantid, ");
            sqlText.append(" sdi.dataset, sdi.paramid, sdi.paramtype, sdi.datatypes, sdi.replicateid, sdi.enteredtext, sdi.transformdt, sdi.enteredvalue ");
            sqlText.append(" FROM sdiworkitem swi INNER JOIN sdidata ds ").append(" ON swi.sdcid = ds.sdcid AND swi.keyid1 = ds.keyid1  AND swi.keyid2 = ds.keyid2  AND swi.keyid3 = ds.keyid3 AND swi.workitemid = ds.sourceworkitemid AND swi.workiteminstance =  ds.sourceworkiteminstance ");
            sqlText.append(" INNER JOIN sdidataitem sdi ").append(" ON ds.sdcid = sdi.sdcid AND ds.keyid1 = sdi.keyid1 AND ds.keyid2 = sdi.keyid2 AND ds.keyid3 = sdi.keyid3 AND ds.paramlistid = sdi.paramlistid AND ds.paramlistversionid = sdi.paramlistversionid AND ds.variantid = sdi.variantid AND ds.dataset = sdi.dataset ");
            sqlText.append(" INNER JOIN rsetitems rsi ON rsi.sdcid = sdi.sdcid AND rsi.keyid1 = sdi.keyid1 AND rsi.keyid2 = sdi.keyid2 AND rsi.keyid3 = sdi.keyid3 ");
            sqlText.append(" WHERE rsi.rsetid = ").append(resultsSafeSQL.addVar(rsetId)).append(" AND sdi.u_ismesresult_aseptic = 'Y' AND swi.workitemstatus <> 'Cancelled' AND ds.s_datasetstatus <> 'Cancelled' ");

            dsAllResults = getQueryProcessor().getPreparedSqlDataSet(sqlText.toString(), resultsSafeSQL.getValues());
        } catch (SapphireException e) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR,ErrorDetail.TYPE_FAILURE,getTranslationProcessor().translate(MESErrorMessageUtil.MES_ACTIONABLE_RESULTS_ERR_00001));
        } finally {
            if (!"".equalsIgnoreCase(rsetId)) {
                getDAMProcessor().clearRSet(rsetId);
            }
        }
        // Getting results sorted by DataSet # & Replicate #
        DataSet dsResultsBySampleId = getHighestDataSetDetails(dsAllResults);
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "getResultsBySampleId");
        }
        return dsResultsBySampleId;
    }

    /*****************************************************************************
     * This method is used to get dataset sorted by highest dataSet & replicate #.
     * @param dsAllResults All results
     * @return DataSet  sorted by highest dataSet & replicate #.
     * @throws SapphireException OOB Sapphire Exception
     ******************************************************************************/
    private DataSet getHighestDataSetDetails(DataSet dsAllResults) throws SapphireException {
        Long processingStartTime = System.currentTimeMillis();
        DataSet dsHighestDSDetails = new DataSet();
        PropertyList plFilter = new PropertyList();
        String sortingCols = "keyid1, keyid2, keyid3, workitemid, workitemversionid, paramlistid, paramlistversionid, variantid, paramid, paramtype";
        String groupingCols = "keyid1, keyid2, keyid3, workitemid, workitemversionid, paramlistid, paramlistversionid, variantid, paramid, paramtype";
        // Sorting All Result details based on DataSet # in decending order
        dsAllResults.sort(sortingCols);
        // Grouping Results based on Sample Id, Test, Test Ver., ParamList, ParamList Ver., Varient
        ArrayList<DataSet> arrGroupDS = dsAllResults.getGroupedDataSets(groupingCols);
        // Looping through Each groupt
        for (DataSet dsItem : arrGroupDS) {
            dsItem.sort("dataset D, replicateid D");
            dsHighestDSDetails.copyRow(dsItem, 0, 1);
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "getHighestDataSetDetails");
        }
        return dsHighestDSDetails;
    }

    /****************************************
     * Setting:Server date and time.
     * @return Server date and time in proper format.
     ****************************************/
    private String setTransactiondatetime() {
        // Setting: Transaction Date-Time
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(__PROPS_POMS_DATE_FORMAT);
        LocalDateTime now = LocalDateTime.now();
        return formatter.format(now);
    }

    /**********************************************
     * Converting: Given date in proper format if date is not present populate current date in proper format.
     * @param dateTime getting from sdidataitem when parameter entered value is in date format.
     * @return date and time in proper format.
     * @throws SapphireException OOB Sapphire Exception.
     **********************************************/
    private String getTransactiondatetime(String dateTime) throws SapphireException {
        // ******** Converting Date into dateformat "yyyyMMdd_HHmmss" *********
        String transactionDateTime = MESUtil.getDateStringWithProperFormat(dateTime, __PROPS_POMS_DATE_FORMAT);
        // ******** If Date is not valid date, Converting CurrentDate into dateformat "yyyyMMdd_HHmmss" *********
        if (transactionDateTime == null || __BLANK_STRING.equalsIgnoreCase(transactionDateTime)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(__PROPS_POMS_DATE_FORMAT);
            LocalDateTime now = LocalDateTime.now();
            transactionDateTime = formatter.format(now);
        }

        return transactionDateTime;
    }
}
