package labvantage.custom.alcon.mes.action;
/**
 * $Author: BAGCHAN1 $
 * $Date: 2022-12-20 22:48:15 +0530 (Tue, 20 Dec 2022) $
 * $Revision: 418 $
 */

import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import labvantage.custom.alcon.util.AlconUtil;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SafeSQL;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.HashMap;

/********************************************************************************************************
 * $Revision: 418 $
 * Description: All necessary activities needed for Send MES Samples to LIMS Service
 *
 ********************************************************************************************************/
public class SendMESSamplesToLIMS extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 418 $";
    public static final String ID = "SendMESSamplesToLIMS";
    public static final String VERSIONID = "1";

    private static final String __PROP_LIMS_BATCH_ID = "s_batchid";
    private static final String __PROP_LIMS_BATCH_STATUS = "batchstatus";
    private static final String __PROP_BATCH_STATUS_CANCELLED = "Cancelled";
    private static final String __PROP_BATCH_STATUS_REJECTED = "Rejected";
    private static final String __PROP_SAMPLINGPLAN_ID = "s_samplingplanid";
    private static final String __PROPS_SAMPLINGPLAN_VERSION_ID = "s_samplingplanversionid";
    private static final String __PROP_SAMPLINGPLAN_VERSIONSTATUS = "versionstatus";
    private static final String __PROP_PROCESSSTAGEID = "s_processstageid";
    private static final String __PROP_PROCESSSTAGE_LABEL = "label";
    private static final String __PROP_BATCHSTAGEID = "s_batchstageid";
    private static final String __PROP_BATCHSTAGE_STATUS = "batchstagestatus";
    private static final String __PROP_BATCHSTAGE_STATUS_CANCELLED = "Cancelled";
    private static final String __PROP_BATCH_STATUS_INITIAL = "Initial";
    private static final String __PROP_LIMS_SAMPLE_ID = "s_sampleid";
    private static final String __PROP_SAMPLE_STATUS = "samplestatus";
    private static final String __PROP_MES_SAMPLE_ID = "messampleid";
    private static final String __PROP_BLANK_MES_SAMPLEID = "BLANK";
    private static final String __PROP_MES_BATCH_FLAG_YES = "Y";
    private static final String __PROP_SAMPLE_STATUS_INITIAL = "Initial";
    private static final String __PROP_SAMPLE_CREATE_DATE = "createdt";
    private static final String __PROPS_KEYID1 = "keyid1";
    private static final String __PROPS_STAGE_TEMPLATE_KEYID_ID = "template" + __PROPS_KEYID1;
    private static final String __PROPS_BATCH_SECURITY_DEPT = "securitydepartment";

    private static final String _PROP_SITE = "plant";
    private static final String _PROP_MES_SAMPLE_ID = "MES_SAMPLE_ID";
    private static final String _PROP_SAP_BATCH_NUMBER = "SAP_BATCH_NUMBER";
    private static final String _PROP_SAP_MATERIAL_NUMBER = "SAP_MATERIAL_NUMBER";
    private static final String _PROP_SAMPLE_DELIVERY_TYPE = "SAMPLE_DELIVERY_TYPE";
    private static final String _PROP_STAGE_NAME = "STAGE_NAME";
    private static final String _PROP_CONTAINER_QTY = "CONTAINER_QTY";
    private static final String _PROP_DELIVERY_DATETIME = "DELIVERY_DATETIME";
    private static final String _PROP_EQUIPMENT_ID = "EQUIPMENT_ID";
    private static final String _PROP_SAMPLER_EMPLOYEE_NUMBER_1_2 = "SAMPLER_EMPLOYEE_NUMBER_1_2";
    private static final String _PROP_SAMPLER_EMPLOYEE_NUMBER_3_4 = "SAMPLER_EMPLOYEE_NUMBER_3_4";
    private static final String _PROP_SETTLING_PLATE1_EXPOSURE_TIME = "SETTLING_PLATE1_EXPOSURE_TIME";
    private static final String _PROP_SETTLING_PLATE2_EXPOSURE_TIME = "SETTLING_PLATE2_EXPOSURE_TIME";
    private static final String __PROP_USER_MES_INTERFACE = "MES_INTERFACE";
    private static final String __PROP_SDC_BATCH = "Batch";
    private static final String __PROP_SDC_SAMPLE = "Sample";
    private static final String __PROP_COL_MESBATCH_ID = "u_messampleid";
    private static final String __PROPS_PROCESS_STAGE_ID = "s_processstageid";
    private static final String __PROPS_PROCESS_STAGE_LEVEL_ID = "levelid";
    private static final String __PROPS_PROCESS_STAGE_LABEL = "label";
    private static final String __PROPS_PROCESS_STAGE_SOURCE_LABEL = "sourcelabel";
    private static final String __PROPS_BATCH_STAGE_ID = "s_batchstageid";

    private static final String __PROPS_BATCH_SDCID = "Batch";
    private static final String __PROPS_SAMPLE_SDCID = "Sample";
    private static final String __PROPS_NEW_KEYID1 = "new" + __PROPS_KEYID1;
    private static final String __PROPS_LIMS_BATCH_STATUS = "batchstatus";
    private static final String __PROPS_VARIANTID = "variantid";
    private static final String __PROPS_LIMS_BATCH_PRODVARIANTID = "prod" + __PROPS_VARIANTID;
    private static final String __PROPS_LIMS_BATCH_PRODID = "productid";
    private static final String __PROPS_LIMS_BATCH_PRODVERSIONID = "productversionid";
    private static final String __PROPS_LIMS_BATCH_DESC = "batchdesc";

    // Added for different  batch status
    private static final String __PROPS_STATUS_REJECTED = "Rejected";
    private static final String __PROPS_STATUS_RELEASED = "Released";
    private static final String __PROPS_STATUS_PENDING_RELEASED = "Pending Release";

    private static final String __PROP_IS_MES_BATCH_FLAG = "ismesbatch";
    private static final String __PROPS_LIMS_SAMPLE_ID = "limssampleid";
    private static final String __PROPS_PARAMLIST_ID = "ParamlistID";
    private static final String __PROPS_PARAM_LIST_VERSION = "ParamListVersion";
    private static final String __PROPS_VARIANT_ID = "Variant_ID";
    private static final String __PROPS_DATASET = "Dataset";
    private static final String __PROPS_PARAM_ID = "ParamID";
    private static final String __PROPS_PARAM_TYPE = "ParamType";
    private static final String __PROPS_REPLICATE = "Replicate";
    private static final String __PROPS_RESULT = "Result";
    private static final String __PROPS_PARAMLISTID = "paramlistid";
    private static final String __PROPS_PARAMLISTVERSIONID = "paramlistversionid";
    private static final String __PROPS_DS = "dataset";
    private static final String __PROPS_PARAMID = "paramid";
    private static final String __PROPS_PARAMTYPE = "paramtype";
    private static final String __PROPS_KEYID2 = "keyid2";
    private static final String __PROPS_SDCID = "sdcid";
    private static final String __PROPS_KEYID3 = "keyid3";
    private static final String __PROPS_REPLICATEID = "replicateid";
    private static final String __PROPS_LIMS_BATCH_ID = "limsbatchid";
    private static final String __PROPS_TRANSITEM_STATUS = "status";
    private static final String __PROP_REPROCESSFLAG = "reprocessingflag";
    private static final String MES_STATUS_SUCCESS = "SUCCESS";
    private static final String SERVICE_SEND_SAMPLES_TO_LIMS = "alcSendSamplesToLIMS";
    private boolean __PROP_LOG_DIAG_SWITCH = false;


    /**************************************************************
     * Description: This is the main method where execution starts.
     * @param properties Property List of properties.
     * @throws SapphireException OOB Sapphire exceptions.
     **************************************************************/
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        __PROP_LOG_DIAG_SWITCH = "ON".equalsIgnoreCase(MESUtil.getLogDiagSwitchValue(getConfigurationProcessor()));
        Long processingStartTime = System.currentTimeMillis();
        String sapBatchNumber = properties.getProperty(_PROP_SAP_BATCH_NUMBER);
        String sapMaterialNumber = properties.getProperty(_PROP_SAP_MATERIAL_NUMBER);
        String sapPlant = properties.getProperty(_PROP_SITE);
        String mesStageName = properties.getProperty(_PROP_STAGE_NAME);
        String mesSampleId = properties.getProperty(_PROP_MES_SAMPLE_ID);
        String sampleDeliveryType = properties.getProperty(_PROP_SAMPLE_DELIVERY_TYPE);
        String containerQty = properties.getProperty(_PROP_CONTAINER_QTY);
        String deliveryDateTime = properties.getProperty(_PROP_DELIVERY_DATETIME);
        String equipmentID = properties.getProperty(_PROP_EQUIPMENT_ID);
        String samplerEmployeeNum1_2 = properties.getProperty(_PROP_SAMPLER_EMPLOYEE_NUMBER_1_2);
        String samplerEmployeeNum3_4 = properties.getProperty(_PROP_SAMPLER_EMPLOYEE_NUMBER_3_4);
        String settilingPlate1ExposureTime = properties.getProperty(_PROP_SETTLING_PLATE1_EXPOSURE_TIME);
        String settilingPlate2ExposureTime = properties.getProperty(_PROP_SETTLING_PLATE2_EXPOSURE_TIME);
        String reprocessedFlag = properties.getProperty(__PROP_REPROCESSFLAG);

        // ************** Below are list of local variables ************
        String limsBatchId = "", limsBatchStatus = "", prodVariantId = "", productId = "", productVersionId = "", limsBatchDesc = "";
        String limsSampleId = "";
        String samplingplanId = "";
        String samplingplanVersionId = "";
        String processStageId = "";
        String batchStageId = "";
        PropertyList plFilter = new PropertyList();
        // ************** End of local variable list **************** //
        try {


            // ********** Getting LIMS Batch Details **********
            String[] limsBatchDetails = getExistingLIMSBatch(sapBatchNumber, sapMaterialNumber, sapPlant);
            limsBatchId = limsBatchDetails[0];
            limsBatchStatus = limsBatchDetails[1];
            prodVariantId = limsBatchDetails[2];
            productId = limsBatchDetails[3];
            productVersionId = limsBatchDetails[4];
            limsBatchDesc = limsBatchDetails[5];
            // ********** Checking if LIMS Batch Id is BLANK ***********
            if ("".equalsIgnoreCase(limsBatchId)) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00004));
            }

            //********* Check LIMS Batch is received ********//
            if (__PROP_BATCH_STATUS_INITIAL.equalsIgnoreCase(limsBatchStatus)) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00040, limsBatchId)));
            }

            // ********** Check if the MES batch Id is BLANK or NOT If BLANK Update with MES Batch Id **********
            updateBatchByMESId(limsBatchId);

            // ********** Getting Samplingplan(Current ver.) details from LIMS Batch **********
            String[] currentSPDetails = getCurrentSP(limsBatchId);
            samplingplanId = currentSPDetails[0];
            samplingplanVersionId = currentSPDetails[1];
            // ********** Finding matching Stage name in current SP & getting process stage id ************
            processStageId = getProcessStageDetails(samplingplanId, samplingplanVersionId, mesStageName);
            // ********** Finding Batch Stage id ************
            batchStageId = getBatchStageId(limsBatchId, mesStageName);
            // ********** Find Samples by Batch Stage Id ***********
            DataSet dsSampleDetailsByMESStage = getSamplesByBatchStage(limsBatchId, batchStageId, mesStageName);
            // ********** Checking if matching MES Sample found or not *************
            plFilter.setProperty(__PROP_MES_SAMPLE_ID, mesSampleId);
            DataSet dsSampleByMESSampleId = dsSampleDetailsByMESStage.getFilteredDataSet(plFilter);
            // ************ If Matching MES Sample NOT found *****************
            if (dsSampleByMESSampleId.size() == 0) {
                // ************** Checking if BLANK MES Sample Id found or not **************
                plFilter.clear();
                plFilter.setProperty(__PROP_MES_SAMPLE_ID, __PROP_BLANK_MES_SAMPLEID);
                DataSet dsBLANKMESSampleDetails = dsSampleDetailsByMESStage.getFilteredDataSet(plFilter);
                // ************** Checking if BLANK MES Sample Id NOT found **************
                if (dsBLANKMESSampleDetails.size() == 0) {
                    // ************* Adding Sample to Stage *************
                    limsSampleId = addSamplesToStage(limsBatchId, limsBatchDesc, limsBatchStatus, prodVariantId, productId, productVersionId, samplingplanId, samplingplanVersionId, mesSampleId, batchStageId, processStageId, sapPlant);
                    // ***************** Update the Record information ****************
                    recordContainerInformation(limsSampleId, containerQty, __PROP_USER_MES_INTERFACE, deliveryDateTime);
                    if (!"".equalsIgnoreCase(equipmentID)) {

                        // ***************** Enter the Results & Save and Release **************
                        // **************** Get Master Data from MES for Result Entry ***************
                        DataSet dsMasterDataForResultEntry = getMasterDataForResultEntry(limsSampleId, equipmentID, samplerEmployeeNum1_2, samplerEmployeeNum3_4, settilingPlate1ExposureTime, settilingPlate2ExposureTime);
                        if (dsMasterDataForResultEntry.size() == 0) {
                            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00031));
                        }
                        // **************** Get Master Data from Sample for Result Entry ***************
                        DataSet dsMasterDataDetailsFromSample = getMasterDataDetailsFromSample(limsSampleId);
                        if (dsMasterDataDetailsFromSample.size() == 0) {
                            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00032, limsSampleId)));
                        }
                        // **************** Creating final dataset for Result Entry *****************
                        DataSet dsFinalResultSet = createFinalResultSet(dsMasterDataForResultEntry, dsMasterDataDetailsFromSample);
                        // ***************** Enter the Results **************
                        enterResults(dsFinalResultSet);
                    }
                } else {
                    // ********** If Matching BLANK MES Sample found **************
                    // ********* Checking if more than one or One BLANK MES Sample found in Stage *************
                    if (dsBLANKMESSampleDetails.size() >= 1) {
                        // ****************** Check if all BLANK Samples having status = 'Initial' ****************
                        plFilter.clear();
                        plFilter.setProperty(__PROP_SAMPLE_STATUS, __PROP_SAMPLE_STATUS_INITIAL);
                        // *************** Getting count of BLANK row Samples ***************
                        int countBLANKSample = dsBLANKMESSampleDetails.getFilteredDataSet(plFilter).getRowCount();
                        // **************** If All BLANK matching MES Samples are not having status = 'Initial' *****************
                        if (dsBLANKMESSampleDetails.getRowCount() != countBLANKSample) {
                            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00015, __PROP_SAMPLE_STATUS_INITIAL)));
                        } else {
                            // **************** Find the latest LIMS Sample Id ***************
                            dsBLANKMESSampleDetails.sort(__PROP_SAMPLE_CREATE_DATE + ", " + __PROP_LIMS_SAMPLE_ID);
                            limsSampleId = dsBLANKMESSampleDetails.getValue(0, __PROP_LIMS_SAMPLE_ID, "");
                            // ***************** Update the LIMS Sample by MES Sample Id if not already ************
                            updateSampleByMESId(limsSampleId, mesSampleId, sapPlant);
                            // ***************** Update the Record information ****************
                            recordContainerInformation(limsSampleId, containerQty, __PROP_USER_MES_INTERFACE, deliveryDateTime);
                            if (!"".equalsIgnoreCase(equipmentID)) {

                                // ***************** Enter the Results & Save and Release **************
                                // **************** Get Master Data from MES for Result Entry ***************
                                DataSet dsMasterDataForResultEntry = getMasterDataForResultEntry(limsSampleId, equipmentID, samplerEmployeeNum1_2, samplerEmployeeNum3_4, settilingPlate1ExposureTime, settilingPlate2ExposureTime);
                                if (dsMasterDataForResultEntry.size() == 0) {
                                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00031));
                                }
                                // **************** Get Master Data from Sample for Result Entry ***************
                                DataSet dsMasterDataDetailsFromSample = getMasterDataDetailsFromSample(limsSampleId);
                                if (dsMasterDataDetailsFromSample.size() == 0) {
                                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00032, limsSampleId)));
                                }
                                // **************** Creating final dataset for Result Entry *****************
                                DataSet dsFinalResultSet = createFinalResultSet(dsMasterDataForResultEntry, dsMasterDataDetailsFromSample);
                                // ***************** Enter the Results **************
                                enterResults(dsFinalResultSet);
                            }
                        }
                    }
                }

            } else {
                // ********* If Matching MES Sample found **************
                // ********* Checking if More than one Sample having matching MES Sample Id *********
                if (dsSampleByMESSampleId.size() > 1) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00013, mesSampleId)));
                } else {
                    limsSampleId = dsSampleByMESSampleId.getColumnValues(__PROP_LIMS_SAMPLE_ID, "");
                    // ************* Checking if LIMS Sample is having staus = Initail *************
                    if (dsSampleByMESSampleId.findRow(__PROP_SAMPLE_STATUS, __PROP_SAMPLE_STATUS_INITIAL) == -1) {
                        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00014, mesSampleId, dsSampleByMESSampleId.getColumnValues(__PROP_LIMS_SAMPLE_ID, ""))));
                    } else {
                        // Todo below
                        limsSampleId = dsSampleByMESSampleId.getColumnValues(__PROP_LIMS_SAMPLE_ID, "");
                        // ***************** Update the Record information ****************
                        recordContainerInformation(limsSampleId, containerQty, __PROP_USER_MES_INTERFACE, deliveryDateTime);
                        // ***************** Update the sapPlant for Sample ************
                        updateSampleByMESId(limsSampleId, mesSampleId, sapPlant);
                        if (!"".equalsIgnoreCase(equipmentID)) {

                            // ***************** Enter the Results & Save and Release **************
                            // **************** Get Master Data from MES for Result Entry ***************
                            DataSet dsMasterDataForResultEntry = getMasterDataForResultEntry(limsSampleId, equipmentID, samplerEmployeeNum1_2, samplerEmployeeNum3_4, settilingPlate1ExposureTime, settilingPlate2ExposureTime);
                            if (dsMasterDataForResultEntry.size() == 0) {
                                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00031));
                            }
                            // **************** Get Master Data from Sample for Result Entry ***************
                            DataSet dsMasterDataDetailsFromSample = getMasterDataDetailsFromSample(limsSampleId);
                            if (dsMasterDataDetailsFromSample.size() == 0) {
                                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00032, limsSampleId)));
                            }
                            // **************** Creating final dataset for Result Entry *****************
                            DataSet dsFinalResultSet = createFinalResultSet(dsMasterDataForResultEntry, dsMasterDataDetailsFromSample);
                            // ***************** Enter the Results **************
                            enterResults(dsFinalResultSet);

                        }
                    }
                }

            }

        } catch (SapphireException ex) {
            // ******** For ERROR ******* //
            // Concatinating the LIMS Batch Id and LIMS Sample Id with Error Msg.
            throw new SapphireException(ex.getMessage() + "|" + limsBatchId + "|" + limsSampleId);
        }
        // ******** For SUCCESS ******* //
        if ("Y".equalsIgnoreCase(reprocessedFlag)) {
            properties.setProperty(__PROPS_TRANSITEM_STATUS, MES_STATUS_SUCCESS);
        }
        properties.setProperty(__PROPS_LIMS_BATCH_ID, limsBatchId);
        properties.setProperty(__PROPS_LIMS_SAMPLE_ID, limsSampleId);
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-processAction");
        }
    }


    /*******************************************************************
     * This method is used to get maximum sample user sequence in batch
     * @param limsBatchId LIMS Batch Id
     * @return Returns user sequence
     * @throws SapphireException OOB Sapphire Exception.
     ********************************************************************/
    private String getUserSequence(String limsBatchId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getUserSequence (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT to_char(max(usersequence)) maxusersequence FROM s_sample ");
        strSQL.append(" WHERE batchid = ").append(safeSQL.addVar(limsBatchId));

        DataSet dsMaxUserSequence = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getUserSequence");
        }
        if (null == dsMaxUserSequence) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.NULL_SQL_VALUE));
        } else {
            return dsMaxUserSequence.getValue(0, "maxusersequence", "0");
        }
    }

    /*******************************************************************************
     * This method is used to get level sample details from logged in version of SP
     * @param limsBatchId LIMS Batch Id
     * @return returns DataSet of Sampling PLan Details
     * @throws SapphireException OOB Sapphire Exception
     ********************************************************************************/
    private DataSet getLevelSamplesFromLoggedVerSP(String limsBatchId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getLevelSamplesFromLoggedVerSP (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        String rsetId = "";
        try {
            rsetId = getDAMProcessor().createRSet(__PROP_SDC_BATCH, limsBatchId, "", "");
            strSQL.append(" SELECT s_batchstage.s_batchstageid,sstage.s_processstageid,sstage.label,sdetail.levelid,sdetail.sourcelabel,sdetail.template" + __PROPS_KEYID1 + ",sdetail.defaultdepartmentid ");
            strSQL.append(" FROM s_samplingplan   splan INNER JOIN s_processstage   sstage ON splan.s_samplingplanid = sstage.s_samplingplanid ");
            strSQL.append(" AND splan.s_samplingplanversionid = sstage.s_samplingplanversionid ");
            strSQL.append(" INNER JOIN s_spdetail sdetail ON sdetail.s_samplingplanid = sstage.s_samplingplanid ");
            strSQL.append(" AND sdetail.s_samplingplanversionid = sstage.s_samplingplanversionid AND sstage.s_processstageid = sdetail.processstageid ");
            strSQL.append(" INNER JOIN s_batch sb ON sb.samplingplanid = splan.s_samplingplanid AND sb.samplingplanversionid = splan.s_samplingplanversionid ");
            strSQL.append(" INNER JOIN s_batchstage ON s_batchstage.batchid = sb.s_batchid AND s_batchstage.samplingplanid = splan.s_samplingplanid ");
            strSQL.append(" AND s_batchstage.samplingplanversionid = splan.s_samplingplanversionid AND s_batchstage.processstageid = sstage.s_processstageid ");
            strSQL.append(" INNER JOIN rsetitems rsi ON rsi.sdcid = '" + __PROP_SDC_BATCH + "' AND rsi.keyid1 = sb.s_batchid  AND rsi.keyid2='(null)'  AND  rsi.keyid3='(null)'");
            strSQL.append(" WHERE rsi.rsetid = ").append(safeSQL.addVar(rsetId));
            strSQL.append(" AND sb.s_batchid= ").append(safeSQL.addVar(limsBatchId));

            DataSet dsLevelSampleDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
            if (__PROP_LOG_DIAG_SWITCH) {
                MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getLevelSamplesFromLoggedVerSP");
            }
            if (null == dsLevelSampleDetails) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.NULL_SQL_VALUE));
            } else if (dsLevelSampleDetails.getRowCount() == 0) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00020));
            } else {
                return dsLevelSampleDetails;
            }
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00039));

        } finally {
            if (!"".equalsIgnoreCase(rsetId)) {
                getDAMProcessor().clearRSet(rsetId);
            }
        }
    }


    /********************************************************************************
     * This  method is used to get workitem and spec details of current sampling plan
     * @param curSPId Current Sampling Plan details
     * @param curSPVerId Current Sampling Plan version
     * @return Returns Level details
     * @throws SapphireException OOB Sapphire Exception
     *********************************************************************************/
    private DataSet getSamplingPlanItemDetails(String curSPId, String curSPVerId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getSamplingPlanItemDetails (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT sp.processstageid,sp.s_samplingplanid,sp.s_samplingplanversionid,sp.levelid,sp.sourcelabel,spitems.item" + __PROPS_SDCID + ", ");
        strSQL.append(" spitems.item" + __PROPS_KEYID1 + ",spitems.item" + __PROPS_KEYID2 + ",spitems.item" + __PROPS_KEYID3 + ",sp.template" + __PROPS_SDCID + ",sp.templatekeyid1,sp.templatekeyid2,sp.template" + __PROPS_KEYID3 + ", ");
        strSQL.append(" sp.defaultdepartmentid,sp.usersequence,spitems.usersequence spitemusersequence ");
        strSQL.append(" FROM s_spdetail sp,s_spitem spitems,s_spdetailitem spdetailitems,s_samplingplan splan ");
        strSQL.append(" WHERE sp.s_samplingplanid = splan.s_samplingplanid AND sp.s_samplingplanversionid = splan.s_samplingplanversionid ");
        strSQL.append(" AND spitems.s_samplingplanid = sp.s_samplingplanid AND spitems.s_samplingplanversionid = sp.s_samplingplanversionid ");
        strSQL.append(" AND spdetailitems.s_samplingplanid = sp.s_samplingplanid AND spdetailitems.s_samplingplanversionid = sp.s_samplingplanversionid ");
        strSQL.append(" AND spdetailitems.s_samplingplandetailno = sp.s_samplingplandetailno AND spdetailitems.s_samplingplanitemno = spitems.s_samplingplanitemno ");
        strSQL.append(" AND splan.s_samplingplanid = ").append(safeSQL.addVar(curSPId));
        strSQL.append(" AND splan.s_samplingplanversionid = ").append(safeSQL.addVar(curSPVerId));

        DataSet dsSPItems = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getSamplingPlanItemDetails");
        }
        if (null == dsSPItems) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.NULL_SQL_VALUE));
        } else {
            dsSPItems.sort("usersequence");
            return dsSPItems;
        }

    }

    /****************************************************
     * This method is used to unrelease a batch
     * @param limsBatchId LIMS Batch Id
     * @throws SapphireException OOB Sapphire Exception
     ****************************************************/
    private void unreleaseLIMSBatch(String limsBatchId, String limsBatchStatus) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside unreleaseLIMSBatch (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plUnrelease = new PropertyList();
        plUnrelease.setProperty(UndoSDIColumnValue.PROPERTY_SDCID, __PROPS_BATCH_SDCID);
        plUnrelease.setProperty(UndoSDIColumnValue.PROPERTY_KEYID1, limsBatchId);
        plUnrelease.setProperty("statuscolumn", __PROPS_LIMS_BATCH_STATUS);
        plUnrelease.setProperty("defaultvalue", __PROPS_STATUS_PENDING_RELEASED);
        plUnrelease.setProperty("validatestatuscolumnvalue", __PROPS_STATUS_RELEASED.equalsIgnoreCase(limsBatchStatus) ? __PROPS_STATUS_RELEASED : __PROPS_STATUS_REJECTED);
        plUnrelease.setProperty("auditactivity", __PROPS_STATUS_RELEASED.equalsIgnoreCase(limsBatchStatus) ? "Un" + __PROPS_STATUS_RELEASED : "Un" + __PROPS_STATUS_REJECTED);
        plUnrelease.setProperty("auditreason", __PROPS_STATUS_RELEASED.equalsIgnoreCase(limsBatchStatus) ? __PROPS_STATUS_RELEASED + " by MES-INTERFACE" : __PROPS_STATUS_REJECTED + " by MES-INTERFACE");
        getActionProcessor().processAction(UndoSDIColumnValue.ID, UndoSDIColumnValue.VERSIONID, plUnrelease);
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-unreleaseLIMSBatch");
        }
    }

    /***********************************************************
     * This method is used to add samples to stages.
     * @param limsBatchId LIMS Batch Id
     * @param limsBatchStatus LIMS Batch Status
     * @param prodVariantId Product variant Id
     * @param productId Product Id
     * @param productVersionId Product Version
     * @param batchStageId Batch Stage Id
     * @param messampleId MES Sample Id
     * @param samplingPlanId Sampling Plan Id
     * @param samplingPlanVersionId Sampling Plan version
     * @param processStageId Process Stage
     * @param sapPlant sapPlant
     * @throws SapphireException OOB Sapphire Exception
     ****************************************************/

    private String addSamplesToStage(String limsBatchId, String limsBatchDesc, String limsBatchStatus, String prodVariantId, String productId, String productVersionId, String samplingPlanId, String samplingPlanVersionId, String messampleId, String batchStageId, String processStageId, String sapPlant) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside addSamplesToStage (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plFilter = new PropertyList();
        PropertyList plAddSDI = new PropertyList();
        String label = "";
        String sourcelabel = "";
        String levelid = "";
        String templateId = "";
        String spSecurityDept = "";
        String securityDept = "";
        int userSequence;
        String newSampleId = "";
        String uniqueLevelId[];
        plFilter.setProperty(__PROPS_PROCESS_STAGE_ID, processStageId);
        // Getting Level Sample Details from logged in version SP
        DataSet dsLevelDetailsForCurSP = getLevelSamples(samplingPlanId, samplingPlanVersionId);
        // Getting filtered dataset by process stage id
        DataSet dsFilteredLevelSampleDetailsByProcessStage = dsLevelDetailsForCurSP.getFilteredDataSet(plFilter);
        // Check if level details found against process stage id
        if (dsFilteredLevelSampleDetailsByProcessStage.getRowCount() == 0) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00021)));
        } else {
            // Getting unique list of level ids
            uniqueLevelId = StringUtil.split(AlconUtil.getUniqueList(dsFilteredLevelSampleDetailsByProcessStage.getColumnValues(__PROPS_PROCESS_STAGE_LEVEL_ID, ";"), ";", false), ";");
            // Check if level id is unique. If not the throw an error
            if (uniqueLevelId.length > 1) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00022, limsBatchId, prodVariantId, samplingPlanId, samplingPlanVersionId)));
            }
            // Getting max sample user sequence value
            userSequence = Integer.parseInt(getUserSequence(limsBatchId));
            // Getting Current Sampling Plan Item(WorkItem + Spec) details
            DataSet dsSPItems = getSamplingPlanItemDetails(samplingPlanId, samplingPlanVersionId);
            if (userSequence == 0) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00023, limsBatchId)));
            }
            // ********* unrelease/UnReject the batch
            //unreleaseLIMSBatch(limsBatchId, limsBatchStatus);
            int count = 0;
            DataSet dsLevelDetailsForLoggedSP = getLevelSamplesFromLoggedVerSP(limsBatchId);
            int dsRowCount = dsFilteredLevelSampleDetailsByProcessStage.getRowCount();
            // start looping level sample details for each level id
            for (int rowCount = 0; rowCount < dsRowCount; rowCount++) {
                // Getting lebel,sourcelebel and levelid from current SP againts processstageid
                label = dsFilteredLevelSampleDetailsByProcessStage.getValue(rowCount, __PROPS_PROCESS_STAGE_LABEL);
                sourcelabel = dsFilteredLevelSampleDetailsByProcessStage.getValue(rowCount, __PROPS_PROCESS_STAGE_SOURCE_LABEL);
                levelid = dsFilteredLevelSampleDetailsByProcessStage.getValue(rowCount, __PROPS_PROCESS_STAGE_LEVEL_ID);
                // Filtering level sample of logged in version of SP to get the batch stage id
                plFilter.clear();
                plFilter.setProperty(__PROPS_PROCESS_STAGE_LABEL, label);
                if (!"null".equalsIgnoreCase(sourcelabel) && !"".equalsIgnoreCase(sourcelabel)) {
                    plFilter.setProperty(__PROPS_PROCESS_STAGE_SOURCE_LABEL, sourcelabel);
                }
                if (!"null".equalsIgnoreCase(levelid) && !"".equalsIgnoreCase(levelid)) {
                    plFilter.setProperty(__PROPS_PROCESS_STAGE_LEVEL_ID, levelid);
                }
                // Getting Batch Stage Id from logged in version of SP
                batchStageId = dsLevelDetailsForLoggedSP.getFilteredDataSet(plFilter).getValue(0, __PROPS_BATCH_STAGE_ID, "");
                if ("".equalsIgnoreCase(batchStageId)) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00023, samplingPlanId, samplingPlanVersionId, label, sourcelabel, levelid)));
                } else {
                    templateId = dsLevelDetailsForLoggedSP.getFilteredDataSet(plFilter).getValue(0, __PROPS_STAGE_TEMPLATE_KEYID_ID, "");
                    securityDept = dsLevelDetailsForLoggedSP.getFilteredDataSet(plFilter).getValue(0, __PROPS_BATCH_SECURITY_DEPT, "");
                    spSecurityDept = dsLevelDetailsForLoggedSP.getFilteredDataSet(plFilter).getValue(0, "defaultdepartmentid", "");
                    // *************** Check if any existing RSet is locking in
                    // *************** Clear any LOCKED RSET for Batch Stage
                    unlockBatchStage(batchStageId);
                    // *************** Adding samples to stage based upon the Rule
                    plAddSDI.setProperty(AddSDI.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
                    plAddSDI.setProperty("batchid", limsBatchId);
                    plAddSDI.setProperty("batchstageid", batchStageId);
                    plAddSDI.setProperty("productversionid", productVersionId);
                    plAddSDI.setProperty("sourcespid", samplingPlanId);
                    plAddSDI.setProperty("sourcespversionid", samplingPlanVersionId);
                    plAddSDI.setProperty("sampledesc", limsBatchDesc);
                    plAddSDI.setProperty("productid", productId);
                    plAddSDI.setProperty("sourcespsourcelabel", sourcelabel);
                    plAddSDI.setProperty("sourcesplevelid", levelid);
                    plAddSDI.setProperty("templateid", templateId);
                    plAddSDI.setProperty("u_messampleid", messampleId);
                    plAddSDI.setProperty("u_sapplant", sapPlant);
                    plAddSDI.setProperty("securitydepartment", ("".equalsIgnoreCase(securityDept)) ? spSecurityDept : securityDept);
                    plAddSDI.setProperty("usersequence", String.valueOf(userSequence));
                    try {
                        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plAddSDI);
                        newSampleId = plAddSDI.getProperty(__PROPS_NEW_KEYID1, "");
                    } catch (SapphireException ex) {
                        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
                    }

                    plFilter.clear();
                    plFilter.setProperty("processstageid", processStageId);
                    if (!"null".equalsIgnoreCase(sourcelabel) && !"".equalsIgnoreCase(sourcelabel)) {
                        plFilter.setProperty(__PROPS_PROCESS_STAGE_SOURCE_LABEL, sourcelabel);
                    }
                    if (!"null".equalsIgnoreCase(levelid) && !"".equalsIgnoreCase(levelid)) {
                        plFilter.setProperty(__PROPS_PROCESS_STAGE_LEVEL_ID, levelid);
                    }
                    plFilter.setProperty("item" + __PROPS_SDCID, "WorkItem");

                    // Getting workitems to be applied
                    DataSet dsSPItemWorkItem = dsSPItems.getFilteredDataSet(plFilter);
                    if (dsSPItemWorkItem.getRowCount() > 0) {
                        // AddSDIWorkItem
                        PropertyList plAddWorkItem = new PropertyList();
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_KEYID1, StringUtil.repeat(newSampleId, dsSPItemWorkItem.size(), ";"));
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMID, dsSPItemWorkItem.getColumnValues("item" + __PROPS_KEYID1, ";"));
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_WORKITEMVERSIONID, dsSPItemWorkItem.getColumnValues("item" + __PROPS_KEYID2, ";"));
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_APPLYWORKITEM, "Y");
                        plAddWorkItem.setProperty(AddSDIWorkItem.PROPERTY_PROPSMATCH, "Y");

                        try {
                            getActionProcessor().processAction(AddSDIWorkItem.ID, AddSDIWorkItem.VERSIONID, plAddWorkItem);
                        } catch (SapphireException ex) {
                            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Failed to call  AddSDIWorkItem. Error is \n" + ex.getMessage()));
                        }
                    }

                    plFilter.clear();
                    plFilter.setProperty("processstageid", processStageId);
                    if (!"null".equalsIgnoreCase(sourcelabel) && !"".equalsIgnoreCase(sourcelabel)) {
                        plFilter.setProperty(__PROPS_PROCESS_STAGE_SOURCE_LABEL, sourcelabel);
                    }
                    if (!"null".equalsIgnoreCase(levelid) && !"".equalsIgnoreCase(levelid)) {
                        plFilter.setProperty(__PROPS_PROCESS_STAGE_LEVEL_ID, levelid);
                    }
                    plFilter.setProperty("item" + __PROPS_SDCID, "SpecSDC");

                    // Getting spec to be applied
                    DataSet dsSPItemSpec = dsSPItems.getFilteredDataSet(plFilter);
                    if (dsSPItemSpec.getRowCount() > 0) {
                        // AddSDISpec
                        PropertyList plAddSDISpec = new PropertyList();
                        plAddSDISpec.setProperty(AddSDISpec.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
                        plAddSDISpec.setProperty(AddSDISpec.PROPERTY_KEYID1, StringUtil.repeat(newSampleId, dsSPItemSpec.size(), ";"));
                        plAddSDISpec.setProperty(AddSDISpec.PROPERTY_SPECID, dsSPItemSpec.getColumnValues("item" + __PROPS_KEYID1, ";"));
                        plAddSDISpec.setProperty(AddSDISpec.PROPERTY_SPECVERSIONID, dsSPItemSpec.getColumnValues("item" + __PROPS_KEYID2, ";"));
                        plAddSDISpec.setProperty(AddSDISpec.PROPERTY_APPLYSPEC, "Y");
                        try {
                            getActionProcessor().processAction(AddSDISpec.ID, AddSDISpec.VERSIONID, plAddSDISpec);
                        } catch (SapphireException ex) {
                            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Failed to call  AddSDISpec. Error is : \n " + ex.getMessage()));
                        }
                    }

                }
                // Incrementing user sequence variable to avoid querying DB multiple times
                userSequence++;
            }

        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-addSamplesToStage");
        }
        return newSampleId;
    }

    /***********************************************************
     * This method is used to get level sample details from current SP
     * @param samplingPlanId
     * @param samplingPlanVersionId
     * @return
     * @throws SapphireException
     ************************************************************/
    private DataSet getLevelSamples(String samplingPlanId, String samplingPlanVersionId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getLevelSamples (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT s_processstage.s_processstageid,s_processstage.label,s_spdetail.levelid,s_spdetail.sourcelabel,s_spdetail.countrule,s_spdetail.template" + __PROPS_KEYID1 + ",s_spdetail.defaultdepartmentid ");
        strSQL.append(" FROM s_samplingplan INNER JOIN s_processstage ON s_samplingplan.s_samplingplanid = s_processstage.s_samplingplanid ");
        strSQL.append(" AND s_samplingplan.s_samplingplanversionid = s_processstage.s_samplingplanversionid ");
        strSQL.append(" INNER JOIN s_spdetail ON s_spdetail.s_samplingplanid = s_samplingplan.s_samplingplanid ");
        strSQL.append(" AND s_spdetail.s_samplingplanversionid = s_samplingplan.s_samplingplanversionid ");
        strSQL.append(" AND s_spdetail.processstageid = s_processstage.s_processstageid ");
        strSQL.append(" where s_samplingplan.s_samplingplanid = ").append(safeSQL.addVar(samplingPlanId));
        strSQL.append(" AND s_samplingplan.s_samplingplanversionid = ").append(safeSQL.addVar(samplingPlanVersionId));

        DataSet dsCurrentSPLevel = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getLevelSamples");
        }
        if (null == dsCurrentSPLevel) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.NULL_SQL_VALUE));
        } else if (dsCurrentSPLevel.getRowCount() == 0) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00025, samplingPlanId)));
        } else {
            return dsCurrentSPLevel;
        }

    }


    /***********************************************************
     * This method is used to remove the locking on BatchStage.
     * @param limsBatchId
     * @throws SapphireException
     ***********************************************************/

    private void unlockBatchStage(String limsBatchId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside unlockBatchStage (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT rsetid FROM rsetitems WHERE " + __PROPS_SDCID + " = 'LV_BatchStage' ");
        strSQL.append(" AND " + __PROPS_KEYID1 + " = ").append(safeSQL.addVar(limsBatchId));
        strSQL.append(" AND " + __PROPS_KEYID2 + " = '(null)' ");
        strSQL.append(" AND " + __PROPS_KEYID3 + " = '(null)' ");

        DataSet dsBatchStageRset = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsBatchStageRset) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.NULL_SQL_VALUE));
        }
        // If there are any open RsetIds . Clease those before proceeding
        if (dsBatchStageRset.getRowCount() > 0) {
            getDAMProcessor().clearRSet(dsBatchStageRset.getColumnValues("rsetid", ";"));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-unlockBatchStage");
        }
    }


    /***********************************************************
     * This method is used to get exiting LIMS Batch details
     * @param sapBatchNumber SAP Batch Number
     * @param sapMaterialNumber SAP Material Number
     * @param sapPlant SAP plant
     * @return Returns LIMS Batch Id & Status
     * @throws SapphireException OOB Sapphire Exception.
     ************************************************************/
    private String[] getExistingLIMSBatch(String sapBatchNumber, String sapMaterialNumber, String sapPlant) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getExistingLIMSBatch (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String limsBatchDetails[] = new String[6];
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT s_batch." + __PROP_LIMS_BATCH_ID + ", s_batch." + __PROP_LIMS_BATCH_STATUS + ", s_batch." + __PROPS_LIMS_BATCH_PRODVARIANTID + " ,s_prodvariant.productid,s_prodvariant.productversionid,s_batch.batchdesc  ");
        strSQL.append(" FROM s_batch INNER JOIN s_prodvariant ").append(" ON s_batch.prod" + __PROPS_VARIANTID + " = s_prodvariant.s_prodvariantid ");
        strSQL.append(" WHERE s_batch.u_mesordersapbatch1 = ").append(safeSQL.addVar(sapBatchNumber));
        strSQL.append(" AND s_batch.u_sapmatnumber = ").append(safeSQL.addVar(sapMaterialNumber));
        strSQL.append(" AND ( s_batch.u_sapplant = ").append(safeSQL.addVar(sapPlant));
        strSQL.append(" OR s_prodvariant.securitydepartment IN( SELECT department.departmentid FROM department INNER JOIN u_sites ");
        strSQL.append(" ON department.u_siteid = u_sites.u_sitesid WHERE u_sites.sapplant = ").append(safeSQL.addVar(sapPlant)).append("))");
        strSQL.append(" AND s_batch.batchstatus <> '" + __PROP_BATCH_STATUS_CANCELLED + "' ");
        strSQL.append(" AND s_batch.batchstatus <> '" + __PROP_BATCH_STATUS_REJECTED + "' ");
        DataSet dsLIMSBatchDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        // ****** If Query returns NULL
        if (null == dsLIMSBatchDetails) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00016)));
        } else if (dsLIMSBatchDetails.size() == 0) {
            // ******* If No LIMS Batch found against SAP Batch + SAP Material + SAP plant combination.
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00001, sapBatchNumber, sapMaterialNumber, sapPlant)));
        } else if (dsLIMSBatchDetails.size() > 1) {
            // ******* If More than One LIMS Batch found against SAP Batch + SAP Material + SAP plant combination.
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00002, sapBatchNumber, sapMaterialNumber, sapPlant)));
        } else if (dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_STATUS, "").equalsIgnoreCase(__PROP_BATCH_STATUS_CANCELLED)) {
            // ******* If Batch Status is Cancelled
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00003, dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_ID, ""), __PROP_BATCH_STATUS_CANCELLED)));
        } else if (dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_STATUS, "").equalsIgnoreCase(__PROP_BATCH_STATUS_REJECTED)) {
            // ******* If Batch Status is Rejected
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00003, dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_ID, ""), __PROP_BATCH_STATUS_REJECTED)));
        } else {
            // ******* Setting LIMS Batch Id
            limsBatchDetails[0] = dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_ID, "");
            limsBatchDetails[1] = dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_STATUS, "");
            limsBatchDetails[2] = dsLIMSBatchDetails.getValue(0, __PROPS_LIMS_BATCH_PRODVARIANTID, "");
            limsBatchDetails[3] = dsLIMSBatchDetails.getValue(0, __PROPS_LIMS_BATCH_PRODID, "");
            limsBatchDetails[4] = dsLIMSBatchDetails.getValue(0, __PROPS_LIMS_BATCH_PRODVERSIONID, "");
            limsBatchDetails[5] = dsLIMSBatchDetails.getValue(0, __PROPS_LIMS_BATCH_DESC, "");
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getExistingLIMSBatch");
        }
        return limsBatchDetails;
    }

    /**********************************************************************************
     * This method is used to get current Sampling Plan details.
     * @param limsBatchId LIMS Batch Id
     * @return Array of 2 elements - 0 : Sampling Plan Id, 1 : Sampling Plan Version Id
     * @throws SapphireException OOB Sapphire Exception.
     **********************************************************************************/
    private String[] getCurrentSP(String limsBatchId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getCurrentSP (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String curSPDetails[] = new String[3];
        StringBuilder strSQL = new StringBuilder().append("");
        SafeSQL safeSQL = new SafeSQL();
        String rsetId = "";
        try {
            rsetId = getDAMProcessor().createRSet(__PROP_SDC_BATCH, limsBatchId, "", "");
            strSQL.append(" SELECT sp." + __PROP_SAMPLINGPLAN_ID + " , sp." + __PROPS_SAMPLINGPLAN_VERSION_ID + " ");
            strSQL.append(" FROM s_batch b INNER JOIN s_samplingplan sp ").append(" ON b.samplingplanid = sp." + __PROP_SAMPLINGPLAN_ID);
            strSQL.append(" INNER JOIN rsetitems rsi ON rsi.sdcid = '" + __PROP_SDC_BATCH + "' AND rsi.keyid1 = b.s_batchid  AND rsi.keyid2='(null)'  AND  rsi.keyid3='(null)'");
            strSQL.append(" WHERE rsi.rsetid = ").append(safeSQL.addVar(rsetId));
            strSQL.append(" AND b." + __PROP_LIMS_BATCH_ID + " = ").append(safeSQL.addVar(limsBatchId)).append(" AND sp." + __PROP_SAMPLINGPLAN_VERSIONSTATUS + " = 'C' ");

            DataSet dsCurrentSPDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
            if (null == dsCurrentSPDetails) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting Current Samplingplan  details for LIMS Batch # - " + limsBatchId)));
            } else if (dsCurrentSPDetails.size() == 0) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00005, limsBatchId)));
            } else if (dsCurrentSPDetails.size() > 1) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00006, limsBatchId)));
            } else {
                // ********* Assigning Current Sampling Plan Id & Sampling Plan version ***********
                curSPDetails[0] = dsCurrentSPDetails.getValue(0, __PROP_SAMPLINGPLAN_ID, "");
                curSPDetails[1] = dsCurrentSPDetails.getValue(0, __PROPS_SAMPLINGPLAN_VERSION_ID, "");
            }
        } finally {
            if (!"".equalsIgnoreCase(rsetId)) {
                getDAMProcessor().clearRSet(rsetId);
            }
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getCurrentSP");
        }
        return curSPDetails;

    }

    /*****************************************************************************************
     * This method is used to check whether MES stage exists in Samplingplan --> Process Stage
     * @param samplingplanId Current Samplingplan Id
     * @param samplingplanversionId Current Samplingplan version Id
     * @return Processstage id
     * @throws SapphireException OOB Sapphire exception.
     *****************************************************************************************/
    private String getProcessStageDetails(String samplingplanId, String samplingplanversionId, String stageName) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside isMESStageNameFound (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String processStageId = "";
        StringBuilder strSQL = new StringBuilder().append("");
        SafeSQL safeSQL = new SafeSQL();
        strSQL.append(" SELECT s_processstage." + __PROP_PROCESSSTAGEID + ", s_processstage." + __PROP_PROCESSSTAGE_LABEL + " FROM s_processstage ");
        strSQL.append(" WHERE s_processstage." + __PROP_SAMPLINGPLAN_ID + " = ").append(safeSQL.addVar(samplingplanId));
        strSQL.append(" AND s_processstage." + __PROPS_SAMPLINGPLAN_VERSION_ID + " =  ").append(safeSQL.addVar(samplingplanversionId));
        strSQL.append(" AND s_processstage." + __PROP_PROCESSSTAGE_LABEL + " =  ").append(safeSQL.addVar(stageName));

        DataSet dsProcessStageDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsProcessStageDetails) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting Stage details from Current Samplingplan  for Samplingplan # - " + samplingplanId + " and Samplinplan version # -" + samplingplanversionId)));
        } else if (dsProcessStageDetails.size() == 0) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00007, stageName, samplingplanId, samplingplanversionId)));
        } else if (dsProcessStageDetails.size() > 1) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00008, samplingplanId, samplingplanversionId)));
        } else {
            processStageId = dsProcessStageDetails.getValue(0, __PROP_PROCESSSTAGEID, "");
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getProcessStageDetails");
        }
        return processStageId;
    }

    /************************************************************************
     * This method is used to get batch stage details.
     * @param limsBatchId LIMS Batch Id
     * @param mesStageName MES Satge name
     * @return Returns batchstage id
     * @throws SapphireException OOB Sapphire Exception
     *************************************************************************/
    private String getBatchStageId(String limsBatchId, String mesStageName) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getBatchStageId (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String batchstageId = "";
        SafeSQL safeSQL = new SafeSQL();

/*
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT s_batchstage." + __PROP_BATCHSTAGEID + ", s_batchstage." + __PROP_BATCHSTAGE_STATUS + " FROM s_batchstage ");
        strSQL.append(" WHERE s_batchstage.batchid = ").append(safeSQL.addVar(limsBatchId)).append(" AND  s_batchstage." + __PROP_PROCESSSTAGE_LABEL + " = ").append(safeSQL.addVar(mesStageName));
        DataSet dsBatchStageDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
*/

        String sql = "SELECT s_batchstage." + __PROP_BATCHSTAGEID + ", s_batchstage." + __PROP_BATCHSTAGE_STATUS + " FROM s_batchstage " +
                " WHERE s_batchstage.batchid = " + safeSQL.addVar(limsBatchId) + "AND  s_batchstage." + __PROP_PROCESSSTAGE_LABEL + " =  " + safeSQL.addVar(mesStageName);

        DataSet dsBatchStageDetails = getQueryProcessor().getPreparedSqlDataSet(sql, safeSQL.getValues());

        if (null == dsBatchStageDetails) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting Batch Stage details for LIMS Batch # - " + limsBatchId + " and MES Stage # -" + mesStageName)));

        } else if (dsBatchStageDetails.size() == 0) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00009, mesStageName, limsBatchId)));

        } else if (dsBatchStageDetails.size() > 1) {

            //Check if all stages are Cancelled
            HashMap hm = new HashMap();
            hm.put(__PROP_BATCHSTAGE_STATUS, __PROP_BATCHSTAGE_STATUS_CANCELLED);

            DataSet dsFilter = dsBatchStageDetails.getFilteredDataSet(hm);
            if (dsFilter.size() == dsBatchStageDetails.size()) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00011, limsBatchId, mesStageName)));
            }

            //Ignore cancelled stages
            dsFilter = dsBatchStageDetails.getFilteredDataSet(hm, true);

            //If non-cancelled stages are multiple, throw error
            if (dsFilter.size() > 1) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00010, mesStageName, limsBatchId)));
            }

            // batchstageId = dsBatchStageDetails.getValue(0, __PROP_BATCHSTAGEID, "");
            batchstageId = dsFilter.getValue(0, __PROP_BATCHSTAGEID, "");


        } else {
            //Check if the stage is Cancelled
            HashMap hm = new HashMap();
            hm.put(__PROP_BATCHSTAGE_STATUS, __PROP_BATCHSTAGE_STATUS_CANCELLED);

            DataSet dsFilter = dsBatchStageDetails.getFilteredDataSet(hm);
            if (dsFilter.size() == dsBatchStageDetails.size()) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00011, limsBatchId, mesStageName)));
            }

            batchstageId = dsBatchStageDetails.getValue(0, __PROP_BATCHSTAGEID, "");

        }

        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getBatchStageId");
        }

        return batchstageId;

    }

    /**************************************************************
     * This method is used to get Sample details from Stage details.
     * @param limsBatchId LIMS Batch Id
     * @param batchStageId Batch Stage Id
     * @param mesStageName MES Stage Name
     * @return DataSet contaning LIMS Sample details
     * @throws SapphireException OOB Sapphire Exception
     ***************************************************************/
    private DataSet getSamplesByBatchStage(String limsBatchId, String batchStageId, String mesStageName) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getSamplesByBatchStage (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT s_sample." + __PROP_LIMS_SAMPLE_ID + ", s_sample." + __PROP_SAMPLE_STATUS + ", NVL(s_sample.u_messampleid,'" + __PROP_BLANK_MES_SAMPLEID + "') " + __PROP_MES_SAMPLE_ID + " , s_sample." + __PROP_SAMPLE_CREATE_DATE + " FROM s_sample ");
        strSQL.append(" WHERE s_sample.batchstageid = ").append(safeSQL.addVar(batchStageId));
        strSQL.append(" AND s_sample.batchid = ").append(safeSQL.addVar(limsBatchId));
        strSQL.append(" AND s_sample.samplestatus <> 'Cancelled'");

        DataSet dsSampleDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsSampleDetails) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting Sample details for LIMS Batch # - " + limsBatchId + " and MES Stage # -" + mesStageName)));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getSamplesByBatchStage");
        }
        return dsSampleDetails;
    }

    /***********************************************************************
     * This method is used to UPDATE Batch as MES Batch iff it's BLANK
     * @param limsBatchId LIMS Batch Id
     * @throws SapphireException OOB Sapphire Exception
     ***********************************************************************/
    private void updateBatchByMESId(String limsBatchId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside updateBatchByMESId (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        PropertyList plUpdateBatch = new PropertyList();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT NVL(u_ismesbatch,'N') " + __PROP_IS_MES_BATCH_FLAG + " FROM s_batch WHERE s_batchid = ").append(safeSQL.addVar(limsBatchId));
        DataSet dsIsMESIdPresent = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsIsMESIdPresent) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting MES Batch details for LIMS Batch # - " + limsBatchId)));
        }
        // ********* Check if not MES Batch ************
        if (!__PROP_MES_BATCH_FLAG_YES.equalsIgnoreCase(dsIsMESIdPresent.getValue(0, __PROP_IS_MES_BATCH_FLAG, ""))) {
            plUpdateBatch.setProperty(EditSDI.PROPERTY_SDCID, __PROP_SDC_BATCH);
            plUpdateBatch.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
            plUpdateBatch.setProperty("auditreason", " Marked as MES Batch. ");
            plUpdateBatch.setProperty("u_ismesbatch", __PROP_MES_BATCH_FLAG_YES);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plUpdateBatch);
            } catch (SapphireException ex) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00018, limsBatchId));
            }
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-updateBatchByMESId");
        }

    }

    /*************************************************************************
     * This method is used to UPDATE Sample by MES Sample Id iff it's BLANK
     * @param limsSampleId LIMS Sample Id
     * @param mesSampleId MES Sample Id
     * @param sapPlant sapPlant
     * @throws SapphireException OOB Sapphire Exception
     *************************************************************************/
    private void updateSampleByMESId(String limsSampleId, String mesSampleId, String sapPlant) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside updateSampleByMESId (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        PropertyList plUpdateBatch = new PropertyList();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT NVL(u_messampleid,'BLANK') " + __PROP_MES_SAMPLE_ID + "  FROM s_sample WHERE s_sampleid = ").append(safeSQL.addVar(limsSampleId));
        DataSet dsIsMESIdPresent = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsIsMESIdPresent) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting MES Sample # details for LIMS Sample # - " + limsSampleId + " and MES Sample # -" + mesSampleId)));
        }
        // ********* Check if MES Sample Id is BLANK or not ************
        if (__PROP_BLANK_MES_SAMPLEID.equalsIgnoreCase(dsIsMESIdPresent.getValue(0, __PROP_MES_SAMPLE_ID, ""))) {
            plUpdateBatch.setProperty(EditSDI.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
            plUpdateBatch.setProperty(EditSDI.PROPERTY_KEYID1, limsSampleId);
            plUpdateBatch.setProperty("auditreason", " MES Sample Id Updated. ");
            plUpdateBatch.setProperty(__PROP_COL_MESBATCH_ID, mesSampleId);
            plUpdateBatch.setProperty("u_sapplant", sapPlant);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plUpdateBatch);
            } catch (SapphireException ex) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00019, limsSampleId));
            }
        } else {
            plUpdateBatch.setProperty(EditSDI.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
            plUpdateBatch.setProperty(EditSDI.PROPERTY_KEYID1, limsSampleId);
            plUpdateBatch.setProperty("u_sapplant", sapPlant);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plUpdateBatch);
            } catch (SapphireException ex) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00019, limsSampleId));
            }
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-updateSampleByMESId");
        }
    }

    /*********************************************************************
     * This method is used to record information for a Sample.
     * @param limsSampleId LIMS Sample Id
     * @param containersDelivered Number of Containers delivered
     * @param user User who logged the containers
     * @throws SapphireException OOB Sapphire Exception
     **********************************************************************/
    private void recordContainerInformation(String limsSampleId, String containersDelivered, String user, String deliveryDateTime) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside recordContainerInformation (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String deliveryDateFormat = MESUtil.getDateTimeStringWithProperFormat(deliveryDateTime);
        PropertyList plRecordInformation = new PropertyList();
        plRecordInformation.setProperty(EditSDI.PROPERTY_SDCID, __PROPS_SAMPLE_SDCID);
        plRecordInformation.setProperty(EditSDI.PROPERTY_KEYID1, limsSampleId);
        plRecordInformation.setProperty("u_no_containers_delivered", containersDelivered);
        plRecordInformation.setProperty("u_deliveredby", user);
        plRecordInformation.setProperty("u_deliveredon", deliveryDateFormat);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plRecordInformation);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00026, limsSampleId));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-recordContainerInformation");
        }
    }

    /***************************************************************************
     * This method is used to create a DataSet of Master Data.
     * @param sampleId LIMS Sample Id
     * @param equipmentID Parameter Equiptment Id
     * @param samplerEmployeeNum1_2 Parameter Employee Number 1
     * @param samplerEmployeeNum3_4 Parameter Employee Number 2
     * @param settilingPlate1ExposureTime Parameter Settling Plate 1 Exposure Time
     * @param settilingPlate2ExposureTime Parameter Settling Plate 2 Exposure Time
     * @return DataSet of Static Data
     * @throws SapphireException OOB Sapphire Exception
     ******************************************************************************/
    private DataSet getMasterDataForResultEntry(String sampleId, String equipmentID, String samplerEmployeeNum1_2, String samplerEmployeeNum3_4, String settilingPlate1ExposureTime, String settilingPlate2ExposureTime) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getMasterDataForResultEntry (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        DataSet dsMasterData = new DataSet(connectionInfo);
        // ************ Creating DataSet columns ************
        if (!dsMasterData.isValidColumn(__PROPS_LIMS_SAMPLE_ID)) {
            dsMasterData.addColumn(__PROPS_LIMS_SAMPLE_ID, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_PARAMLIST_ID)) {
            dsMasterData.addColumn(__PROPS_PARAMLIST_ID, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_PARAM_LIST_VERSION)) {
            dsMasterData.addColumn(__PROPS_PARAM_LIST_VERSION, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_VARIANT_ID)) {
            dsMasterData.addColumn(__PROPS_VARIANT_ID, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_DATASET)) {
            dsMasterData.addColumn(__PROPS_DATASET, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_PARAM_ID)) {
            dsMasterData.addColumn(__PROPS_PARAM_ID, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_PARAM_TYPE)) {
            dsMasterData.addColumn(__PROPS_PARAM_TYPE, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_REPLICATE)) {
            dsMasterData.addColumn(__PROPS_REPLICATE, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_RESULT)) {
            dsMasterData.addColumn(__PROPS_RESULT, DataSet.STRING);
        }

        // ************** Entering Master Data *****************

        int row;
        if (!"".equalsIgnoreCase(equipmentID)) {
            // ***** Row 1 *****
            row = dsMasterData.addRow();
            dsMasterData.setValue(row, __PROPS_LIMS_SAMPLE_ID, sampleId);
            dsMasterData.setValue(row, __PROPS_PARAMLIST_ID, "ASPEX ENV.CMPD.ISO.PAS");
            dsMasterData.setValue(row, __PROPS_VARIANT_ID, "FWMDOC-02133");
            dsMasterData.setValue(row, __PROPS_PARAM_ID, "Equipment Id");
            dsMasterData.setValue(row, __PROPS_PARAM_TYPE, "Reference");
            dsMasterData.setValue(row, __PROPS_RESULT, equipmentID);

        }
        if (!"".equalsIgnoreCase(samplerEmployeeNum1_2)) {
            // **** Row 2 *****
            row = dsMasterData.addRow();
            dsMasterData.setValue(row, __PROPS_LIMS_SAMPLE_ID, sampleId);
            dsMasterData.setValue(row, __PROPS_PARAMLIST_ID, "ASPEX,ENV,CMPD ISO,PERS MON GLOVE");
            dsMasterData.setValue(row, __PROPS_VARIANT_ID, "FWMDOC-02133");
            dsMasterData.setValue(row, __PROPS_PARAM_ID, "SAMPLER_EMPLOYEE_NUMBER_1_2");
            dsMasterData.setValue(row, __PROPS_PARAM_TYPE, "Reference");
            dsMasterData.setValue(row, __PROPS_RESULT, samplerEmployeeNum1_2);

        }
        if (!"".equalsIgnoreCase(samplerEmployeeNum3_4)) {
            // ***** Row 3 *****
            row = dsMasterData.addRow();
            dsMasterData.setValue(row, __PROPS_LIMS_SAMPLE_ID, sampleId);
            dsMasterData.setValue(row, __PROPS_PARAMLIST_ID, "ASPEX,ENV,CMPD ISO,PERS MON GLOVE");
            dsMasterData.setValue(row, __PROPS_VARIANT_ID, "FWMDOC-02133");
            dsMasterData.setValue(row, __PROPS_PARAM_ID, "SAMPLER_EMPLOYEE_NUMBER_3_4");
            dsMasterData.setValue(row, __PROPS_PARAM_TYPE, "Reference");
            dsMasterData.setValue(row, __PROPS_RESULT, samplerEmployeeNum3_4);

        }

        if (!"".equalsIgnoreCase(settilingPlate1ExposureTime)) {
            // **** Row 4 ****
            row = dsMasterData.addRow();
            dsMasterData.setValue(row, __PROPS_LIMS_SAMPLE_ID, sampleId);
            dsMasterData.setValue(row, __PROPS_PARAMLIST_ID, "ASPEX.ENV.CMPD.ISO.SP");
            dsMasterData.setValue(row, __PROPS_PARAM_LIST_VERSION, "");
            dsMasterData.setValue(row, __PROPS_VARIANT_ID, "FWMDOC-02133");
            dsMasterData.setValue(row, __PROPS_PARAM_ID, "ISO-SP-1,EXPOSURE TIME");
            dsMasterData.setValue(row, __PROPS_PARAM_TYPE, "Time");
            dsMasterData.setValue(row, __PROPS_RESULT, settilingPlate1ExposureTime);
        }

        if (!"".equalsIgnoreCase(settilingPlate2ExposureTime)) {
            // **** Row 5 ****
            row = dsMasterData.addRow();
            dsMasterData.setValue(row, __PROPS_LIMS_SAMPLE_ID, sampleId);
            dsMasterData.setValue(row, __PROPS_PARAMLIST_ID, "ASPEX.ENV.CMPD.ISO.SP");
            dsMasterData.setValue(row, __PROPS_PARAM_LIST_VERSION, "");
            dsMasterData.setValue(row, __PROPS_VARIANT_ID, "FWMDOC-02133");
            dsMasterData.setValue(row, __PROPS_PARAM_ID, "ISO-SP-2,EXPOSURE TIME");
            dsMasterData.setValue(row, __PROPS_PARAM_TYPE, "Time");
            dsMasterData.setValue(row, __PROPS_RESULT, settilingPlate2ExposureTime);

        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getMasterDataForResultEntry");
        }
        return dsMasterData;
    }

    /**************************************************************
     * This method is used get Master Data details from Sample Id
     * @param limsSampleId LIMS Sample Id
     * @return DataSet of Master Data
     * @throws SapphireException OOB Sapphire Exception
     **************************************************************/
    private DataSet getMasterDataDetailsFromSample(String limsSampleId) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside getMasterDataDetailsFromSample (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String rsetId = "";
        StringBuilder strSQL = new StringBuilder().append("");
        DataSet dsSampleResults = new DataSet();
        SafeSQL safeSQL = new SafeSQL();
        try {
            rsetId = getDAMProcessor().createRSet(__PROP_SDC_SAMPLE, limsSampleId, "", "");
            strSQL.append(" SELECT sdi." + __PROPS_KEYID1 + ", sdi." + __PROPS_PARAMLISTID + ", sdi." + __PROPS_PARAMLISTVERSIONID + ", sdi." + __PROPS_VARIANTID + ", sdi." + __PROPS_DS + ", TO_CHAR(sdi.dataset) strdataset, sdi." + __PROPS_PARAMID + ", sdi." + __PROPS_PARAMTYPE + ", sdi." + __PROPS_REPLICATEID + ", TO_CHAR(sdi.replicateid) strreplicateid ");
            strSQL.append(" FROM sdidata sd INNER JOIN sdidataitem sdi ");
            strSQL.append(" ON sd." + __PROPS_SDCID + " =  sdi.sdcid  AND sd." + __PROPS_KEYID1 + " =  sdi." + __PROPS_KEYID1 + "  AND sd." + __PROPS_KEYID2 + " =  sdi." + __PROPS_KEYID2 + " AND sd." + __PROPS_KEYID3 + " =  sdi.keyid3 AND sd." + __PROPS_PARAMLISTID + " = sdi.paramlistid AND sd." + __PROPS_PARAMLISTVERSIONID + " = sdi." + __PROPS_PARAMLISTVERSIONID + " AND sd." + __PROPS_VARIANTID + " =  sdi." + __PROPS_VARIANTID + " AND sd." + __PROPS_DS + " =  sdi." + __PROPS_DS + "  ");
            strSQL.append(" INNER JOIN rsetitems rsi ON rsi." + __PROPS_SDCID + " = sdi." + __PROPS_SDCID + " AND rsi." + __PROPS_KEYID1 + " = sdi." + __PROPS_KEYID1 + " AND rsi." + __PROPS_KEYID2 + " =  sdi." + __PROPS_KEYID2 + " AND rsi." + __PROPS_KEYID3 + " = sdi." + __PROPS_KEYID3);
            strSQL.append(" WHERE rsi.rsetid = ").append(safeSQL.addVar(rsetId));
            strSQL.append(" AND sdi.sdcid='Sample' and sd.s_datasetstatus <> 'Cancelled' and sdi.keyid1= ").append(safeSQL.addVar(limsSampleId));
            dsSampleResults = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
            if (null == dsSampleResults) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting result details for LIMS Sample # - " + limsSampleId)));
            }
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00026, limsSampleId)));
        } finally {
            if (!"".equalsIgnoreCase(rsetId)) {
                getDAMProcessor().clearRSet(rsetId);
            }
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-getMasterDataDetailsFromSample");
        }
        return dsSampleResults;

    }

    /*******************************************************************************
     * This method is used to create final Result set for inserting results.
     * @param dsMasterDataForResultEntry DataSet of Master Data coming from MES
     * @param dsMasterDataDetailsFromSample DataSEt of Master Data fetched from LIMS
     * @return Returns final Result set for data entry
     * @throws SapphireException OOB Saaphire Exception
     ********************************************************************************/
    private DataSet createFinalResultSet(DataSet dsMasterDataForResultEntry, DataSet dsMasterDataDetailsFromSample) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside createFinalResultSet (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plFilter = new PropertyList();
        DataSet dsTemp = new DataSet(connectionInfo);
        // ************** Looping though the static data ***************
        int dsSize = dsMasterDataForResultEntry.size();
        for (int row = 0; row < dsSize; row++) {
            plFilter.clear();
            dsTemp.clear();
            plFilter.setProperty(__PROPS_KEYID1, dsMasterDataForResultEntry.getValue(row, __PROPS_LIMS_SAMPLE_ID, ""));
            plFilter.setProperty(__PROPS_PARAMLISTID, dsMasterDataForResultEntry.getValue(row, __PROPS_PARAMLIST_ID, ""));
            plFilter.setProperty(__PROPS_VARIANTID, dsMasterDataForResultEntry.getValue(row, __PROPS_VARIANT_ID, ""));
            // ********** Special Handling is made for Employee # Parameter **********
            plFilter.setProperty(__PROPS_PARAMID, ("SAMPLER_EMPLOYEE_NUMBER_1_2".equalsIgnoreCase(dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_ID, "")) || "SAMPLER_EMPLOYEE_NUMBER_3_4".equalsIgnoreCase(dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_ID, ""))) ? "EMPLOYEE #" : dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_ID, ""));
            plFilter.setProperty(__PROPS_PARAMTYPE, dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_TYPE, ""));
            if ("SAMPLER_EMPLOYEE_NUMBER_1_2".equalsIgnoreCase(dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_ID, ""))) {
                plFilter.setProperty("strdataset", "1");
            }
            if ("SAMPLER_EMPLOYEE_NUMBER_3_4".equalsIgnoreCase(dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_ID, ""))) {
                plFilter.setProperty("strdataset", "2");
            }
            // **********  Filtering  SDIDataItem based on Static data came from MES **********
            dsTemp = dsMasterDataDetailsFromSample.getFilteredDataSet(plFilter);
            // ********* If no matching resultset found then ERROR **********
            if (dsTemp.size() == 0) {
                String errMsg = "";
                String paramId = dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_ID, "");
                if ("SAMPLER_EMPLOYEE_NUMBER_1_2".equalsIgnoreCase(paramId)) {
                    paramId = "EMPLOYEE #";
                    errMsg = String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00028, dsMasterDataForResultEntry.getValue(row, __PROPS_LIMS_SAMPLE_ID, ""), dsMasterDataForResultEntry.getValue(row, __PROPS_PARAMLIST_ID, ""), dsMasterDataForResultEntry.getValue(row, __PROPS_VARIANT_ID, ""), paramId, dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_TYPE, "")) + " and Dataset# - 1";
                } else if ("SAMPLER_EMPLOYEE_NUMBER_3_4".equalsIgnoreCase(paramId)) {
                    paramId = "EMPLOYEE #";
                    errMsg = String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00028, dsMasterDataForResultEntry.getValue(row, __PROPS_LIMS_SAMPLE_ID, ""), dsMasterDataForResultEntry.getValue(row, __PROPS_PARAMLIST_ID, ""), dsMasterDataForResultEntry.getValue(row, __PROPS_VARIANT_ID, ""), paramId, dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_TYPE, "")) + " and Dataset# - 2";
                } else {
                    errMsg = String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00028, dsMasterDataForResultEntry.getValue(row, __PROPS_LIMS_SAMPLE_ID, ""), dsMasterDataForResultEntry.getValue(row, __PROPS_PARAMLIST_ID, ""), dsMasterDataForResultEntry.getValue(row, __PROPS_VARIANT_ID, ""), paramId, dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_TYPE, ""));
                }
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(errMsg));
            }
            // ********* Sorting SDIDataItem based on Latest DataSet followed by Replicate Id in Descending order **********
            dsTemp.sort(__PROPS_DS + " D, " + __PROPS_REPLICATEID + " D");

            // ********* Setting DataSet and Replicate Information ***********
            // ********* 0 th index is taken because it will contain the latest DataSet & Replicate information *********
            // ********* Special Handling :::: if SAMPLER_EMPLOYEE_NUMBER_1_2 OR SAMPLER_EMPLOYEE_NUMBER_3_4 Then DataSet must be 1 & 2 respectively
            if ("SAMPLER_EMPLOYEE_NUMBER_1_2".equalsIgnoreCase(dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_ID, "")) && !"1".equalsIgnoreCase(dsTemp.getValue(0, __PROPS_DS, ""))) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00029));
            } else if ("SAMPLER_EMPLOYEE_NUMBER_3_4".equalsIgnoreCase(dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_ID, "")) && !"2".equalsIgnoreCase(dsTemp.getValue(0, __PROPS_DS, ""))) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00030));
            } else {
                dsMasterDataForResultEntry.setValue(row, __PROPS_DATASET, dsTemp.getValue(0, __PROPS_DS, ""));
                dsMasterDataForResultEntry.setValue(row, __PROPS_REPLICATE, dsTemp.getValue(0, __PROPS_REPLICATEID, ""));
                dsMasterDataForResultEntry.setValue(row, __PROPS_PARAM_LIST_VERSION, dsTemp.getValue(0, __PROPS_PARAMLISTVERSIONID, ""));
            }

        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-createFinalResultSet");
        }
        return dsMasterDataForResultEntry;

    }

    /**********************************************************
     * This method is used to enter results.
     * @param dsFinalResultSet Final result set
     * @throws SapphireException OOB Sapphire exception
     **********************************************************/
    private void enterResults(DataSet dsFinalResultSet) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside enterResults (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plEnterDetails = new PropertyList();
        String paramID = "";
        int dsSize = dsFinalResultSet.size();
        for (int i = 0; i < dsSize; i++) {
            paramID += ("SAMPLER_EMPLOYEE_NUMBER_1_2".equalsIgnoreCase(dsFinalResultSet.getValue(i, __PROPS_PARAM_ID, "")) || "SAMPLER_EMPLOYEE_NUMBER_3_4".equalsIgnoreCase(dsFinalResultSet.getValue(i, __PROPS_PARAM_ID, ""))) ? "EMPLOYEE #;" : dsFinalResultSet.getValue(i, __PROPS_PARAM_ID, "") + ";";
        }
        if (paramID.endsWith(";")) {
            paramID = paramID.substring(0, paramID.length() - 1);
        }

        //--- Unrelease dataitems ---//
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_KEYID1, dsFinalResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMLISTID, dsFinalResultSet.getColumnValues(__PROPS_PARAMLIST_ID, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMLISTVERSIONID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_LIST_VERSION, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_VARIANTID, dsFinalResultSet.getColumnValues(__PROPS_VARIANT_ID, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_DATASET, dsFinalResultSet.getColumnValues(__PROPS_DATASET, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMID, paramID);
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMTYPE, dsFinalResultSet.getColumnValues(__PROPS_PARAM_TYPE, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_REPLICATEID, dsFinalResultSet.getColumnValues(__PROPS_REPLICATE, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_AUDITREASON, "MES Interface Update");

        try {
            getActionProcessor().processAction(UnReleaseDataItem.ID, UnReleaseDataItem.VERSIONID, plEnterDetails);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00033, ex.getMessage())));
        }

        // ********* Update Dataset status *************
        updateDatasetStatus(dsFinalResultSet);

        // ******** SyncSDIWIStatus ***************
        syncSDIWIStatus(dsFinalResultSet);

        // *************** SyncSDIDataSetStatus **************
        syncSDIDataSetStatus(dsFinalResultSet);

        //--- Result entry ---//
        plEnterDetails.clear();
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_KEYID1, dsFinalResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsFinalResultSet.getColumnValues(__PROPS_PARAMLIST_ID, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_LIST_VERSION, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsFinalResultSet.getColumnValues(__PROPS_VARIANT_ID, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_DATASET, dsFinalResultSet.getColumnValues(__PROPS_DATASET, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMID, paramID);
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsFinalResultSet.getColumnValues(__PROPS_PARAM_TYPE, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsFinalResultSet.getColumnValues(__PROPS_REPLICATE, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, dsFinalResultSet.getColumnValues(__PROPS_RESULT, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_AUDITREASON, "MES Interface results update");
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_PROPSMATCH, "Y");

        try {
            getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, plEnterDetails);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00033, ex.getMessage())));
        }

        //--- Release Dataitems----//
        plEnterDetails.clear();
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_KEYID1, dsFinalResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMLISTID, dsFinalResultSet.getColumnValues(__PROPS_PARAMLIST_ID, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMLISTVERSIONID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_LIST_VERSION, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_VARIANTID, dsFinalResultSet.getColumnValues(__PROPS_VARIANT_ID, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_DATASET, dsFinalResultSet.getColumnValues(__PROPS_DATASET, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMID, paramID);
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMTYPE, dsFinalResultSet.getColumnValues(__PROPS_PARAM_TYPE, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_REPLICATEID, dsFinalResultSet.getColumnValues(__PROPS_REPLICATE, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_AUDITREASON, "MES Interface Update");

        try {
            getActionProcessor().processAction(ReleaseDataItem.ID, ReleaseDataItem.VERSIONID, plEnterDetails);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00033, ex.getMessage())));
        }

        // ********* Update Dataset status *************
        updateDatasetStatus(dsFinalResultSet);

        // ******** SyncSDIWIStatus ***************
        syncSDIWIStatus(dsFinalResultSet);

        // *************** SyncSDIDataSetStatus **************
        syncSDIDataSetStatus(dsFinalResultSet);
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-enterResults");
        }
    }

    /**********************************************************************
     * This method is used to update DataSet status after result is released
     * @param dsFinalResultSet DataSet for Result Entry
     * @throws SapphireException OOB Sapphire Exception
     ***********************************************************************/
    private void updateDatasetStatus(DataSet dsFinalResultSet) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside updateDatasetStatus (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plUpdateDataSetStatus = new PropertyList();
        plUpdateDataSetStatus.setProperty(UpdateDatasetStatus.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plUpdateDataSetStatus.setProperty(UpdateDatasetStatus.PROPERTY_KEYID1, dsFinalResultSet.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
        plUpdateDataSetStatus.setProperty(UpdateDatasetStatus.PROPERTY_AUDITREASON, "MES Interface Result Update");
        try {
            getActionProcessor().processAction(UpdateDatasetStatus.ID, UpdateDatasetStatus.VERSIONID, plUpdateDataSetStatus);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00034, ex.getMessage())));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-updateDatasetStatus");
        }
    }

    /****************************************************************
     * This method is used to sync SDI WI Status
     * @param dsFinalResultSet Final Result Set
     * @throws SapphireException OOB Sapphire Exception
     ****************************************************************/
    private void syncSDIWIStatus(DataSet dsFinalResultSet) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside syncSDIWIStatus (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plUpdateDataSetStatus = new PropertyList();
        plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_KEYID1, dsFinalResultSet.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
        plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_AUDITSIGNEDFLAG, "Y");
        plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_AUDITACTIVITY, "MES Interface Result Update");
        try {
            getActionProcessor().processAction(SyncSDIWIStatus.ID, SyncSDIWIStatus.VERSIONID, plUpdateDataSetStatus);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00035, ex.getMessage())));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-syncSDIWIStatus");
        }
    }

    /******************************************************************
     * This method is used to SDI DataSet status
     * @param dsFinalResultSet FInal Result Set
     * @throws SapphireException OOB Sapphire Exception
     *****************************************************************/
    private void syncSDIDataSetStatus(DataSet dsFinalResultSet) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Inside syncSDIDataSetStatus (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plUpdateDataSetStatus = new PropertyList();
        plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_KEYID1, dsFinalResultSet.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
        plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_STATUSCOLID, "samplestatus");
        plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_AUDITREASON, "MES Interface Result Update");
        try {
            getActionProcessor().processAction(SyncSDIDataSetStatus.ID, SyncSDIDataSetStatus.VERSIONID, plUpdateDataSetStatus);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_SAMPLE_TO_LIMS_ERR_00036, ex.getMessage())));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "SendMESSamplesToLIMS-syncSDIDataSetStatus");
        }
    }
}
