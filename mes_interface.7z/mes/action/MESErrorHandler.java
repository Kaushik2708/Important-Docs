package labvantage.custom.alcon.mes.action;

/**
 * $Author $ SAHAPI1
 * $Date: 2022-10-05 00:21:57 +0530 (Wed, 05 Oct 2022) $
 * $Revision: 174 $
 */

import sapphire.xml.PropertyList;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.AddSDI;

/***********************************************
 * $Revision: 174 $
 * Description:
 * This class is used to log the error into IntfError Table.
 *
 * */

public class MESErrorHandler  extends BaseAction {
 public static final String DEVOPS_ID = "$Revision: 174 $";

 public static final String ID = "MESErrorHandler";
 public static final String VERSIONID = "1";

 public static final String PROP_ERROR_MSG = "errormsg";
 public static final String PROP_SERVICE = "program";
public static final String PROP_STATUS = "status";
 public static final String PROP_MES_TRANS_ID = "mesintftransid";
 public static final String PROP_MES_TRANS_ITEM_ID = "mesintftransitemid";
 public static final String PROP_CREATE_BY = "createby";

 /**
 * Description: processAction is an OOB LabVantage method. This is the main method where execution starts.
 *
 * @param properties
 * @throws sapphire.SapphireException
 */

public void processAction(PropertyList properties) throws SapphireException {

        PropertyList pl = new PropertyList();
        pl.setProperty(AddSDI.PROPERTY_SDCID, "MESIntfError");
        pl.setProperty(AddSDI.PROPERTY_COPIES, "1");


        pl.setProperty(PROP_MES_TRANS_ID, properties.getProperty(PROP_MES_TRANS_ID, ""));
        pl.setProperty(PROP_MES_TRANS_ITEM_ID, properties.getProperty(PROP_MES_TRANS_ITEM_ID,""));
        pl.setProperty(PROP_ERROR_MSG, properties.getProperty(PROP_ERROR_MSG, ""));
        pl.setProperty(PROP_SERVICE, properties.getProperty(PROP_SERVICE, ""));
        pl.setProperty(PROP_STATUS, properties.getProperty(PROP_STATUS, ""));
        pl.setProperty(PROP_CREATE_BY, properties.getProperty(PROP_CREATE_BY, ""));
        try {
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, pl);

        } catch (SapphireException e) {
        String err = "Can't update MESInftError table. Reason: " + e.getMessage();
        logger.error(err);
        }
        }


        }
