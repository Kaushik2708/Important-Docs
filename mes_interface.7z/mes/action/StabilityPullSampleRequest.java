package labvantage.custom.alcon.mes.action;
/**
 * $Author: DIANAR1 $
 * $Date: 2022-12-05 13:09:16 +0530 (Mon, 05 Dec 2022) $
 * $Revision: 373 $
 */

/*************************************************************************************************
 * $Revision: 373 $
 * Description: This service is used to request stability pull sample from MES.
 **************************************************************************************************/

import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SafeSQL;
import sapphire.xml.PropertyList;


public class StabilityPullSampleRequest extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 373 $";
    public static final String ID = "StabilityPullSampleRequest";
    public static final String VERSIONID = "1";
    public static final String __STAGE_LABEL = "PRODUCT STABILITY";

    private static final String SAP_PLANT = "u_sapplant";
    private static final String SAP_BATCH_NUMBER = "u_mesordersapbatch1";
    private static final String SAP_MATERIAL_NUMBER = "u_sapmatnumber";
    private static final String __PROPS_KEYID_1 = "keyid1";
    private static final String __PROPS_PARAMLISTID = "paramlistid";
    private static final String __PROPS_PARAMLISTVERSIONID = "paramlistversionid";
    private static final String __PROPS_VARIANTID = "variantid";
    private static final String __PROPS_DATASET = "dataset";
    private static final String __PROPS_PARAMID = "paramid";
    private static final String __PROPS_PARAMTYPE = "paramtype";
    private static final String __PROPS_REPLICATEID = "replicateid";
    private static final String __VARIANT_FWMDOC_00237 = "FWMDOC-00237";
    private static final String __PARAMLIST_STABILITY_ENROLLMENT = "STABILITY ENROLLMENT";
    private static final String __ENTERED_VALUE = "enteredvalue";
    private static final String __LIMSBATCH_ID = "batchid";
    public static final String __SDC_SAMPLE = "Sample";
    public static final String __STATUS_CANCELLED = "Cancelled";
    public static final String __PROPS_STRDATASET = "strdataset";
    public static final String __PROPS_STRREPLICATEID = "strreplicateid";
    private boolean __PROP_LOG_DIAG_SWITCH = false;

    /*********************************************************************************************
     * Description: Main method of Stability pull sample request service.
     * @param properties Properties passed from sample.java.
     * @throws SapphireException OOB Sapphire Exception.
     *********************************************************************************************/
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        __PROP_LOG_DIAG_SWITCH = "ON".equalsIgnoreCase(MESUtil.getLogDiagSwitchValue(getConfigurationProcessor()));
        Long processingStartTime = System.currentTimeMillis();
        // *************  Local variables *************** //
        String allSampleIds = properties.getProperty(__PROPS_KEYID_1, "");
        String allParamListIds = properties.getProperty(__PROPS_PARAMLISTID, "");
        String allParamlistVerIds = properties.getProperty(__PROPS_PARAMLISTVERSIONID, "");
        String allParamlistVariantIds = properties.getProperty(__PROPS_VARIANTID, "");
        String allDatasets = properties.getProperty(__PROPS_DATASET, "");
        String allParamIds = properties.getProperty(__PROPS_PARAMID, "");
        String allParamTypes = properties.getProperty(__PROPS_PARAMTYPE, "");
        String allReplicateIds = properties.getProperty(__PROPS_REPLICATEID, "");

        String sampleId = "";
        String paramListId = "";
        String paramListVerId = "";
        String paramListVariantId = "";
        String dataset = "";
        String paramId = "";
        String paramType = "";
        String replicateId = "";
        String transactiondatetime = "";
        String sapbatchnumber = "";
        String sapmaterialnumber = "";
        String site = "";
        String noRequiredUnits = "";
        String limsbatchid = "";

        String[] arrSampleIds = allSampleIds.split(";");
        String[] arrParamListIds = allParamListIds.split(";");
        String[] arrParamListVerIds = allParamlistVerIds.split(";");
        String[] arrParamListVariantIds = allParamlistVariantIds.split(";");
        String[] arrDatasets = allDatasets.split(";");
        String[] arrParamIds = allParamIds.split(";");
        String[] arrParamTpes = allParamTypes.split(";");
        String[] arrReplicateIds = allReplicateIds.split(";");
        DataSet dsResults = getBatchDetailsBySampleId(allSampleIds, allParamListIds, allParamlistVerIds, allParamlistVariantIds, allDatasets);
        if (dsResults == null) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00002, " Result")));
        }
        if (dsResults.getRowCount() == 0) {
            return;
        }
        // *********** Property List to filter Results by Sample Id ************* //
        PropertyList plSampleFilter = new PropertyList();
        DataSet dsResultsBySampleId = new DataSet(connectionInfo);
        for (int countSample = 0; countSample < arrSampleIds.length; countSample++) {
            sampleId = arrSampleIds[countSample];
            paramListId = arrParamListIds[countSample];
            paramListVerId = arrParamListVerIds[countSample];
            paramListVariantId = arrParamListVariantIds[countSample];
            dataset = arrDatasets[countSample];
            paramId = arrParamIds[countSample];
            paramType = arrParamTpes[countSample];
            replicateId = arrReplicateIds[countSample];
            // Setting Sample Id as KEYID 1,paramListId as PARAMLISTID,paramListVerId as PARAMLISTVERSIONEDID,paramType as PARAMTYPE,replicateId as STRREPLICATEID

            plSampleFilter.clear();
            plSampleFilter.setProperty(__PROPS_KEYID_1, sampleId);
            plSampleFilter.setProperty(__PROPS_PARAMLISTID, paramListId);
            plSampleFilter.setProperty(__PROPS_PARAMLISTVERSIONID, paramListVerId);
            plSampleFilter.setProperty(__PROPS_VARIANTID, paramListVariantId);
            plSampleFilter.setProperty(__PROPS_STRDATASET, dataset);
            plSampleFilter.setProperty(__PROPS_PARAMID, paramId);
            plSampleFilter.setProperty(__PROPS_PARAMTYPE, paramType);
            plSampleFilter.setProperty(__PROPS_STRREPLICATEID, replicateId);
            dsResultsBySampleId = dsResults.getFilteredDataSet(plSampleFilter);
            // Getting site in a variable
            transactiondatetime = MESUtil.setTransactiondatetime();
            site = dsResultsBySampleId.getValue(0, SAP_PLANT, "");
            sapbatchnumber = dsResultsBySampleId.getValue(0, SAP_BATCH_NUMBER, "");
            sapmaterialnumber = dsResultsBySampleId.getValue(0, SAP_MATERIAL_NUMBER, "");
            noRequiredUnits = dsResultsBySampleId.getValue(0, __ENTERED_VALUE, "");
            limsbatchid = dsResultsBySampleId.getValue(0, __LIMSBATCH_ID, "");

            // ******** Passing properties to OpcenterMESLVOutbound *********
            PropertyList prop = new PropertyList();
            prop.setProperty(OpcenterMESLVOutbound._PROPS_SERVICE_NAME, OpcenterMESLVOutbound._PROPS_STABILITY_PULL_SAMPLE_REQUEST);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_SITE, site);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_TRANSACTIONDATETIME, transactiondatetime);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_SAP_BATCH_NUMBER, sapbatchnumber);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_SAP_MATERIAL_NUMBER, sapmaterialnumber);
            prop.setProperty(OpcenterMESLVOutbound.__PROPS_STAGE_NAME, __STAGE_LABEL);
            prop.setProperty(OpcenterMESLVOutbound.__PROP_PARAMLIST_ID, __PARAMLIST_STABILITY_ENROLLMENT);
            prop.setProperty(OpcenterMESLVOutbound.__PROP_PARAMLIST_VERSION, paramListVerId);
            prop.setProperty(OpcenterMESLVOutbound.__PROP_PARAMLIST_VARIANT, __VARIANT_FWMDOC_00237);
            prop.setProperty(OpcenterMESLVOutbound.__PROP_PARAMLIST_DATASET, dataset);
            prop.setProperty(OpcenterMESLVOutbound.__PROP_NUMBER_REQUIRED_UNITS, noRequiredUnits);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_LIMS_BATCH_NUMBER, limsbatchid);
            // ************* Calling Outbound ********** //
            try {
                getActionProcessor().processAction(OpcenterMESLVOutbound.ID, OpcenterMESLVOutbound.VERSIONID, prop);
            } catch (SapphireException ex) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00011, OpcenterMESLVOutbound.ID)));
            }

        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "processAction");
        }
    }
    /**************************************************************
     * This method is used to retrive Batch details by Sample Id information.
     * @param allSampleIds List of Sample Ids selected for save and release after parameter result has been entred.
     * @return Returs result set.
     * @throws SapphireException OOB Sapphire Exception.
     **************************************************************/
    private DataSet getBatchDetailsBySampleId(String allSampleIds, String allParamListIds, String allParamlistVerId, String allParamlistVariantId, String allDataSet) throws SapphireException {
        Long processingStartTime = System.currentTimeMillis();
        SafeSQL resultsSafeSQL = new SafeSQL();
        StringBuilder sqlText =new StringBuilder("");
        String rsetid = "";
        DataSet dsAllResults = new DataSet();
        try {
            rsetid = getDAMProcessor().createRSetDS(__SDC_SAMPLE, allSampleIds, null, null, allParamListIds, allParamlistVerId, allParamlistVariantId, allDataSet, true);
           sqlText.append(" SELECT sdi."+__PROPS_KEYID_1+" ,s.batchid,b.u_mesordersapbatch1,b.u_sapplant, b.u_sapmatnumber , sdi.enteredvalue,TO_CHAR(sdi.dataset) strdataset,TO_CHAR( sdi.replicateid) strreplicateid ,sdi.paramlistid,sdi.paramlistversionid,sdi.variantid,sdi.paramid,sdi.paramtype FROM rsetitemsds rsids INNER JOIN sdidata sd ");
           sqlText.append(" ON rsids.sdcid = sd.sdcid AND rsids.keyid1 = sd.keyid1 AND rsids.keyid2 = sd.keyid2 ");
           sqlText.append(" AND rsids.keyid3 =  sd.keyid3  AND rsids.paramlistid = sd.paramlistid AND rsids.paramlistversionid = sd.paramlistversionid ");
           sqlText.append(" AND rsids.variantid = sd.variantid AND rsids.dataset = sd.dataset INNER JOIN sdidataitem sdi ");
           sqlText.append(" ON sd.sdcid = sdi.sdcid AND sd.keyid1 = sdi.keyid1 AND sd.keyid2 = sdi.keyid2 AND sd.keyid3 =  sdi.keyid3 ");
           sqlText.append(" AND sd.paramlistid = sdi.paramlistid AND sd.paramlistversionid = sdi.paramlistversionid ");
           sqlText.append("AND sd.variantid = sdi.variantid AND sd.dataset = sdi.dataset  INNER JOIN s_sample s ON sdi.keyid1 = s.s_sampleid INNER JOIN s_batch b ON s.batchid = b.s_batchid ");
           sqlText.append(" INNER JOIN s_batchstage bstg ON b.s_batchid = bstg.batchid AND s.batchstageid = bstg.s_batchstageid ").append(" WHERE rsids.sdcid = '").append(__SDC_SAMPLE).append("' AND rsids.rsetid = ? ").append(" AND bstg.label = '").append(__STAGE_LABEL).append("' AND bstg.batchstagestatus <> '").append(__STATUS_CANCELLED).append("'");
           sqlText.append(" AND sdi.enteredvalue IS NOT NULL ");
            dsAllResults = getQueryProcessor().getPreparedSqlDataSet(sqlText.toString(),new Object[]{rsetid});
            if (null == dsAllResults) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.NULL_SQL_VALUE));
            }
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, ex.getMessage());
        } finally {
            if (!"".equalsIgnoreCase(rsetid) || null != rsetid) {
                getDAMProcessor().clearRSet(rsetid);
            }
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "getBatchDetailsBySampleId");
        }
        return dsAllResults;
    }

}