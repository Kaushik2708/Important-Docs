package labvantage.custom.alcon.mes.action;
/**
 * $Author: SAHAPI1 $
 * $Date: 2022-12-23 03:39:53 +0530 (Fri, 23 Dec 2022) $
 * $Revision: 420 $
 */

import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/********************************************************************************************************
 * $Revision: 420 $
 * Description: This class works as a controller of different inbound services.
 ********************************************************************************************************/
public class MESProcessController extends BaseAction {
public static final String DEVOPS_ID = "$Revision: 420 $";
public static final String ID = "MESProcessController";
public static final String VERSIONID = "1";
private static final String __BLANK_STRING = "";
private static final String __PROP_SERVICE_NAME = "servicename";
private static final String __PROP_SITE = "plant";
private static final String __PROP_TRANS_ITEM_COL_ITEM_DATA = "itemdata";
private static final String __PROP_SAP_BATCH_NUMBER = "SAP_BATCH_NUMBER";
private static final String __PROP_SAP_MATERIAL_NUMBER = "SAP_MATERIAL_NUMBER";
private static final String __PROP_TRANSACTIONID = "TRANSACTIONID";
private static final String __PROP_TRANSACTIONDATETIME = "TRANSACTIONDATETIME";
private static final String __PROP_SAMPLE_DELIVERY_TYPE = "SAMPLE_DELIVERY_TYPE";
private static final String __PROP_MES_SAMPLE_ID = "MES_SAMPLE_ID";
private static final String __PROP_STAGE_NAME = "STAGE_NAME";
private static final String __PROP_CONTAINER_QTY = "CONTAINER_QTY";
private static final String __PROP_DELIVERY_DATETIME = "DELIVERY_DATETIME";
private static final String __PROPS_DATE_TIME_FORMAT = "yyyyMMdd_HHmmss";
private static final String _PROPS_PARAMLIST_ID = "PARAMLIST_ID";
private static final String _PROPS_PARAMLIST_VERSION = "PARAMLIST_VERSION";
private static final String _PROPS_PARAMLIST_VARIANT = "PARAMLIST_VARIANT";
private static final String _PROPS_PARAMLIST_DATASET = "PARAMLIST_DATASET";
private static final String _PROPS_PULL_DATE_TIME = "PULL_DATE_TIME";
private static final String _PROPS_ACTUAL_UNITS_PULLED = "ACTUAL_UNITS_PULLED";
private static final String _PROPS_AR_SAMPLE_DESCRIPTION = "AR_SAMPLE_DESCRIPTION";
private static final String _PROPS_AR_SAMPLE_TEMPLATE = "AR_SAMPLE_TEMPLATE";
private static final String _PROPS_RETAIN_STAGE_NAME = "RETAIN_STAGE_NAME";
private static final String _PROPS_RETAIN_MES_SAMPLE_ID = "RETAIN_MES_SAMPLE_ID";
private static final String _PROPS_ORIENTATION = "ORIENTATION";
private static final String _PROPS_RETAIN_INSPECTION_RESULT = "RETAIN_INSPECTION_RESULT";
private static final String _PROPS_RETAIN_CONTAINERS_INSPECTED = "RETAIN_CONTAINERS_INSPECTED";
private static final String _PROPS_RETENTION_STORAGE_LOCATION = "RETENTION_STORAGE_LOCATION";
private static final String _PROPS_RETAIN_STORAGE_LOCATION_ID = "RETAIN_STORAGE_LOCATION_ID";
private static final String _PROPS_RETAIN_CONTAINER_QTY = "RETAIN_CONTAINER_QTY";
private static final String _PROPS_INSPECTION_STAGE_NAME = "INSPECTION_STAGE_NAME";
private static final String _PROPS_INSPECTION_MES_SAMPLE_ID = "INSPECTION_MES_SAMPLE_ID";
private static final String _PROPS_INSPECTION_RESULT = "INSPECTION_RESULT";

private static final String SERVICE_SEND_SAMPLES_TO_LIMS = "alcSendSamplesToLIMS";
private static final String SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS = "alcSendStabilitySamplesToLIMS";
private static final String SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS = "alcSendEquipMonitorSamplesToLIMS";
private static final String SERVICE_SEND_RETENTION_SAMPLE_TO_LIMS = "alcSendRetentionSamplesToLIMS";
private static final String SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS = "alcSendInspectionSamplesToLIMS";


/**************************************************************
 * Description: This is the main method where execution starts.
 * @param properties Property List of properties.
 * @throws SapphireException OOB Sapphire exceptions.
 **************************************************************/

@Override
public void processAction(PropertyList properties) throws SapphireException {
    logger.info("--------- Processing Action:" + ID + ", Version:" + VERSIONID + "---------");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String serviceName = properties.getProperty(__PROP_SERVICE_NAME, "");
    String itemData = properties.getProperty(__PROP_TRANS_ITEM_COL_ITEM_DATA, "");
    String site = properties.getProperty(__PROP_SITE, "");
    if (itemData == null || itemData.equals("")) {
        String error = "Can't process MES Process Controller. Item Data is null ";
        logger.error(error);
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.MES_PROCESS_CONTROLLER_ERR_00001)));
    }
    checkMandatoryFieldsofPayload(properties);
    // ******** getting activesite *********
    DataSet dsActiveSites = MESUtil.getActiveSiteForService(getQueryProcessor(), serviceName, site);
    if (dsActiveSites == null || dsActiveSites.getRowCount() == 0) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00014, site)));
    }

    if (SERVICE_SEND_SAMPLES_TO_LIMS.equalsIgnoreCase(serviceName)) {
        sendSamplesToLIMS(properties);
    }
    if (SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS.equalsIgnoreCase(serviceName)) {
        sendStabilitySamplesToLIMS(properties);
    }
    if (SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        sendEquipMonitorSamplesToLIMS(properties);
    }
    if (SERVICE_SEND_RETENTION_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        sendRetentionSamplesToLIMS(properties);
    }
    if (SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        sendInspectionSamplesToLIMS(properties);
    }
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, serviceName, "MESProcessController-processAction");
}

/*************************************************************
 * This method is used to check mandatory fields of payload
 * @param properties Date String
 * @throws SapphireException OOB Sapphire Exception.
 **************************************************************/
private void checkMandatoryFieldsofPayload(PropertyList properties) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String serviceName = properties.getProperty(__PROP_SERVICE_NAME, "");
    String site = properties.getProperty(__PROP_SITE, "");
    String transactionId = properties.getProperty(__PROP_TRANSACTIONID, "");
    String transactionDateTime = properties.getProperty(__PROP_TRANSACTIONDATETIME, "");
    String sapBatchNumber = properties.getProperty(__PROP_SAP_BATCH_NUMBER, "");
    String sapMaterialNumber = properties.getProperty(__PROP_SAP_MATERIAL_NUMBER, "");
    String sampleDeliveryType = properties.getProperty(__PROP_SAMPLE_DELIVERY_TYPE, "");
    String mesSampleId = properties.getProperty(__PROP_MES_SAMPLE_ID, "");
    String stageName = properties.getProperty(__PROP_STAGE_NAME, "");
    String containerQty = properties.getProperty(__PROP_CONTAINER_QTY, "");
    String deliveryDateTime = properties.getProperty(__PROP_DELIVERY_DATETIME, "");
    String paramListId = properties.getProperty(_PROPS_PARAMLIST_ID, "");
    String paramListVersion = properties.getProperty(_PROPS_PARAMLIST_VERSION, "");
    String paramListVariant = properties.getProperty(_PROPS_PARAMLIST_VARIANT, "");
    String paramListDataSet = properties.getProperty(_PROPS_PARAMLIST_DATASET, "");
    String pullDateTime = properties.getProperty(_PROPS_PULL_DATE_TIME, "");
    String actualUnitsPulled = properties.getProperty(_PROPS_ACTUAL_UNITS_PULLED, "");
    String aRSampleDescription = properties.getProperty(_PROPS_AR_SAMPLE_DESCRIPTION, "");
    String aRSampleTemplate = properties.getProperty(_PROPS_AR_SAMPLE_TEMPLATE, "");
    String retainStageName = properties.getProperty(_PROPS_RETAIN_STAGE_NAME, "");
    String retainMesSampleId = properties.getProperty(_PROPS_RETAIN_MES_SAMPLE_ID, "");
    String orientation = properties.getProperty(_PROPS_ORIENTATION, "");
    String retainInspectionResult = properties.getProperty(_PROPS_RETAIN_INSPECTION_RESULT, "");
    String retainContainersInspected = properties.getProperty(_PROPS_RETAIN_CONTAINERS_INSPECTED, "");
    String retentionStorageLocation = properties.getProperty(_PROPS_RETENTION_STORAGE_LOCATION, "");
    String retainStorageLocationId = properties.getProperty(_PROPS_RETAIN_STORAGE_LOCATION_ID, "");
    String retainContainerQty = properties.getProperty(_PROPS_RETAIN_CONTAINER_QTY, "");
    String inspectionStageName = properties.getProperty(_PROPS_INSPECTION_STAGE_NAME);
    String inspectionSampleId = properties.getProperty(_PROPS_INSPECTION_MES_SAMPLE_ID);
    String inspectionResult = properties.getProperty(_PROPS_INSPECTION_RESULT);

    if (null == serviceName || __BLANK_STRING.equalsIgnoreCase(serviceName)) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00016)));
    }
    if (null == site || __BLANK_STRING.equalsIgnoreCase(site)) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00017)));
    }
    if (null == transactionId || __BLANK_STRING.equalsIgnoreCase(transactionId)) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00021)));
    }
    if (null == transactionDateTime || __BLANK_STRING.equalsIgnoreCase(transactionDateTime)) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00022)));
    }

    if (SERVICE_SEND_SAMPLES_TO_LIMS.equalsIgnoreCase(serviceName)) {
        if (null == mesSampleId || __BLANK_STRING.equalsIgnoreCase(mesSampleId)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00024)));
        }
        if (null == sapBatchNumber || __BLANK_STRING.equalsIgnoreCase(sapBatchNumber)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00019)));
        }
        if (null == sapMaterialNumber || __BLANK_STRING.equalsIgnoreCase(sapMaterialNumber)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00020)));
        }
        if (null == sampleDeliveryType || __BLANK_STRING.equalsIgnoreCase(sampleDeliveryType)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00023)));
        }

        if (null == stageName || __BLANK_STRING.equalsIgnoreCase(stageName)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00025)));
        }
        if (null == containerQty || __BLANK_STRING.equalsIgnoreCase(containerQty)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00026)));
        }
        try {
            int intValue = Integer.parseInt(containerQty);

        } catch (NumberFormatException e) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00028, containerQty)));
        }

        if (null == deliveryDateTime || __BLANK_STRING.equalsIgnoreCase(deliveryDateTime)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00027)));
        }
        getValidDate(deliveryDateTime,SERVICE_SEND_SAMPLES_TO_LIMS);
    }
    if (SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS.equalsIgnoreCase(serviceName)) {
        if (null == mesSampleId || __BLANK_STRING.equalsIgnoreCase(mesSampleId)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00024)));
        }
        if (null == sapBatchNumber || __BLANK_STRING.equalsIgnoreCase(sapBatchNumber)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00019)));
        }
        if (null == sapMaterialNumber || __BLANK_STRING.equalsIgnoreCase(sapMaterialNumber)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00020)));
        }
        if (null == stageName || __BLANK_STRING.equalsIgnoreCase(stageName)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00025)));
        }
        if (null == paramListId || __BLANK_STRING.equalsIgnoreCase(paramListId)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00030)));
        }
        if (null == paramListVersion || __BLANK_STRING.equalsIgnoreCase(paramListVersion)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00031)));
        }
        if (null == paramListVariant || __BLANK_STRING.equalsIgnoreCase(paramListVariant)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00032)));
        }
        if (null == paramListDataSet || __BLANK_STRING.equalsIgnoreCase(paramListDataSet)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00033)));
        }
        if (null == pullDateTime || __BLANK_STRING.equalsIgnoreCase(pullDateTime)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00034)));
        }
        if (null == actualUnitsPulled || __BLANK_STRING.equalsIgnoreCase(actualUnitsPulled)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00035)));
        }
    }
    if (SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        if (null == mesSampleId || __BLANK_STRING.equalsIgnoreCase(mesSampleId)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00024)));
        }
        if (null == aRSampleDescription || __BLANK_STRING.equalsIgnoreCase(aRSampleDescription)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00036)));
        }
        if (null == aRSampleTemplate || __BLANK_STRING.equalsIgnoreCase(aRSampleTemplate)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00037)));
        }
        if (null == containerQty || __BLANK_STRING.equalsIgnoreCase(containerQty)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00026)));
        }
        try {
            int intValue = Integer.parseInt(containerQty);

        } catch (NumberFormatException e) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00028, containerQty)));
        }
        getValidDate(transactionDateTime,SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS);
    }
    if (SERVICE_SEND_RETENTION_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        if (null == sapBatchNumber || __BLANK_STRING.equalsIgnoreCase(sapBatchNumber)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00019)));
        }
        if (null == sapMaterialNumber || __BLANK_STRING.equalsIgnoreCase(sapMaterialNumber)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00020)));
        }
        if (null == retainStageName || __BLANK_STRING.equalsIgnoreCase(retainStageName)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00038)));
        }
        if (null == retainMesSampleId || __BLANK_STRING.equalsIgnoreCase(retainMesSampleId)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00039)));
        }
        if (null == orientation || __BLANK_STRING.equalsIgnoreCase(orientation)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00040)));
        }
        if (null == retainInspectionResult || __BLANK_STRING.equalsIgnoreCase(retainInspectionResult)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00041)));
        }
        if (null == retainContainersInspected || __BLANK_STRING.equalsIgnoreCase(retainContainersInspected)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00042)));
        }
        if (null == retentionStorageLocation || __BLANK_STRING.equalsIgnoreCase(retentionStorageLocation)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00043)));
        }
        if (null == retainStorageLocationId || __BLANK_STRING.equalsIgnoreCase(retainStorageLocationId)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00044)));
        }
        if (null == retainContainerQty || __BLANK_STRING.equalsIgnoreCase(retainContainerQty)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00045)));
        }
        try {
            int intValue = Integer.parseInt(retainContainerQty);

        } catch (NumberFormatException e) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00046, retainContainerQty)));
        }
        getValidDate(transactionDateTime,SERVICE_SEND_RETENTION_SAMPLE_TO_LIMS);
    }
    if (SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        if (null == sapBatchNumber || __BLANK_STRING.equalsIgnoreCase(sapBatchNumber)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00019)));
        }
        if (null == sapMaterialNumber || __BLANK_STRING.equalsIgnoreCase(sapMaterialNumber)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00020)));
        }
        if (null == inspectionStageName || __BLANK_STRING.equalsIgnoreCase(inspectionStageName)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00047)));
        }
        if (null == inspectionSampleId || __BLANK_STRING.equalsIgnoreCase(inspectionSampleId)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00048)));
        }
        if (null == inspectionResult || __BLANK_STRING.equalsIgnoreCase(inspectionResult)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00049)));
        }
        getValidDate(transactionDateTime,SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS);getValidDate(transactionDateTime,SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS);
    }
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, serviceName, "MESProcessController-checkMandatoryFieldsofPayload");
}


/*************************************************************
 * This method is used to get Date Time String in specified format.
 * @param inputDateString Date String
 * @throws SapphireException OOB Sapphire Exception.
 **************************************************************/
private void getValidDate(String inputDateString, String serviceName) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    SimpleDateFormat dateParser = new SimpleDateFormat(__PROPS_DATE_TIME_FORMAT);
    Date date = null;
    try {
        date = dateParser.parse(inputDateString);
        SimpleDateFormat dateFormatter = new SimpleDateFormat(__PROPS_DATE_TIME_FORMAT);
        if (!inputDateString.equals(dateFormatter.format(date))) {
            date = null;
        }

    } catch (ParseException e) {
        e.printStackTrace();
    }
    if (date == null && SERVICE_SEND_SAMPLES_TO_LIMS.equalsIgnoreCase(serviceName)) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00029, inputDateString)));
    }
    if (date == null && SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00050, inputDateString)));
    }
    if (date == null && SERVICE_SEND_RETENTION_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00050, inputDateString)));
    }
    if (date == null && SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00050, inputDateString)));
    }

    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "MESProcessController-getValidDate");
}

/*************************************************************
 * This method is used calling action method sendSamplesToLIMS.
 * @param properties Date String
 * @throws SapphireException OOB Sapphire Exception.
 **************************************************************/
private void sendSamplesToLIMS(PropertyList properties) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    getActionProcessor().processAction(SendMESSamplesToLIMS.ID, SendMESSamplesToLIMS.VERSIONID, properties);
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_SAMPLES_TO_LIMS, "MESProcessController-sendSamplesToLIMS");
}


/*************************************************************
 * This method is used calling action method sendStabilitySamplesToLIMS.
 * @param properties Date String
 * @throws SapphireException OOB Sapphire Exception.
 **************************************************************/
private void sendStabilitySamplesToLIMS(PropertyList properties) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    getActionProcessor().processAction(SendMESStabilitySamplesToLIMS.ID, SendMESStabilitySamplesToLIMS.VERSIONID, properties);
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS, "MESProcessController-sendStabilitySamplesToLIMS");
}


/*************************************************************
 * This method is used calling action method sendEquipMonitorSamplesToLIMS.
 * @param properties Date String
 * @throws SapphireException OOB Sapphire Exception.
 **************************************************************/
private void sendEquipMonitorSamplesToLIMS(PropertyList properties) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    getActionProcessor().processAction(SendMESEquipmentMonitorSamplesToLIMS.ID, SendMESEquipmentMonitorSamplesToLIMS.VERSIONID, properties);
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS, "MESProcessController-sendEquipMonitorSamplesToLIMS");
}


/*************************************************************
 * This method is used calling action method sendRetentionSamplesToLIMS.
 * @param properties Date String
 * @throws SapphireException OOB Sapphire Exception.
 **************************************************************/
private void sendRetentionSamplesToLIMS(PropertyList properties) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    getActionProcessor().processAction(SendRetentionSamplesToLIMS.ID, SendRetentionSamplesToLIMS.VERSIONID, properties);
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_RETENTION_SAMPLE_TO_LIMS, "MESProcessController-sendRetentionSamplesToLIMS");
}


/*************************************************************
 * This method is used calling action method sendInspectionSamplesToLIMS.
 * @param properties Date String
 * @throws SapphireException OOB Sapphire Exception.
 **************************************************************/
private void sendInspectionSamplesToLIMS(PropertyList properties) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    getActionProcessor().processAction(SendInspectionSamplesToLIMS.ID, SendInspectionSamplesToLIMS.VERSIONID, properties);
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "MESProcessController-sendInspectionSamplesToLIMS");
}

}
