package labvantage.custom.alcon.mes.action;

import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import org.json.JSONException;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;

import java.util.LinkedHashMap;
import java.util.Map;


/**
 * $Author: DIANAR1 $
 * $Date: 2022-11-18 18:15:27 +0530 (Fri, 18 Nov 2022) $
 * $Revision: 328 $
 */

/*************************************************************************************************
 * $Revision: 328 $
 * Description: This class is used for getting all properties when there is an entry in POMS Page
 **************************************************************************************************/

public class OpcenterMESLVOutbound extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 328 $";
    public static final String ID = "OpcenterMESLVOutbound";
    public static final String VERSIONID = "1";

    public static final String _PROPS_SERVICE_NAME = "SERVICE_NAME";
    public static final String _PROPS_SITE = "SITE";
    public static final String _PROPS_POMS_INTERFACE_ID = "POMS_INTERFACE_ID";
    public static final String _PROPS_TRANSACTIONID = "TRANSACTIONID";
    public static final String _PROPS_TRANSACTIONDATETIME = "TRANSACTIONDATETIME";
    public static final String _PROPS_SAP_BATCH_NUMBER = "SAP_BATCH_NUMBER";
    public static final String _PROPS_LIMS_BATCH_NUMBER = "LIMS_BATCH_NUMBER";
    public static final String _PROPS_SAP_MATERIAL_NUMBER = "SAP_MATERIAL_NUMBER";
    public static final String _PROPS_VENDOR_BATCH_NUMBER = "VENDOR_BATCH_NUMBER";
    public static final String _PROPS_BATCH_POTENCY = "BATCH_POTENCY";
    public static final String _PROPS_LIMS_ACTIONABLE_RESULTS = "LIMS_ACTIONABLE_RESULTS";
    public static final String _PROPS_STABILITY_PULL_SAMPLE_REQUEST = "STABILITY_PULL_SAMPLE_REQUEST";
    public static final String __PROPS_LIMS_EQUIPMENT_RESULTS = "LIMS_EQUIPMENT_RESULTS";
    public static final String _PROPS_LIMS_RELEASE_DATE = "LIMS_RELEASE_DATE";

    public static final String SDC_ID = "MESIntfTrans";
    public static final String TRANSACTION_ID = "u_mesintftransid";
    public static final String SERVICE_NAME = "servicename";
    public static final String TRANSACTION_TYPE = "transtype";
    public static final String TRANSACTION_DIRECTION = "transdirection";
    public static final String TRANSACTION_DATA = "msgpayload";
    public static final String STATUS = "status";
    public static final String SAP_BATCH_ID = "sapbatchnumber";
    public static final String SAP_MATERIAL_ID = "sapmaterialnumber";
    public static final String LIMS_BATCH_ID = "limsbatchid";
    public static final String POMS_INTERFACE_ID = "pomsinterfaceid";
    public static final String SITE = "plant";
    public static final String DATE_MARKED_DONE = "processdonedt";
    public static final String STAGE_NAME = "stagename";


    private static final String __PROP_ERROR_MSG = "errormsg";
    private static final String __PROP_OUTBOUND_TRANSACTION_DIRECTION = "OUTBOUND";
    private static final String __PROP_OUTBOUND_TRANSACTION_TYPE = "WEB_SERVICE";
    private static final String __PROP_STATUS_PENDING = "PENDING";
    private static final String __PROP_STATUS_ERROR = "ERROR";
    private static final String __PROP_PAYLOAD = "PAYLOAD";
    private static final String __PROP_TESTMODE_STANDARD = "STANDARD";
    private static final String __PROP_TESTMODE_INTERNAL = "INTERNAL";
    public static final String __PROP_REPROCESSINGFLAG = "reprocessingflag";
    private static final String __PROP_HTTP_RESPONSE_MSGTYPE = "MSGTYPE";
    private static final String __PROP_HTTP_RES_MESSAGE = "MESSAGE";
    private static final String __PROP_HTTP_RESPONSECODE = "responsecode";
    private static final String __PROP_HTTP_RESPONSE_STATUS = "responsestatus";
    private static final String __PROP_HTTP_RESPONSE_MESSAGE = "responsemessage";
    private static final String __PROP_CREATEBY = "createby";
    private static final String __PROP_MES_OPCENTER = "MES_OPCENTER";
    private static final String __PROP_HTTP_RES_STATUS_FAILURE = "FAILURE";
    private static final String __BLANK_STRING = "";
    public static final String __PROPS_MES_SAMPLE_ID = "MES_SAMPLE_ID";
    public static final String __PROPS_STAGE_NAME = "STAGE_NAME";
    private static final String __PROPS_RESULTS = "RESULTS";
    public static final String __PROPS_ITEMS = "ITEMS";
    private static final String __PROPS_SUCCESS = "SUCCESS";
    public static final String MES_SAMPLE_NUMBER = "messamplenumber";
    // ************ Property variables for STABILITY_PULL_SAMPLE_REQUEST ************* //
    public static final String __PROP_PARAMLIST_ID = "PARAMLIST_ID";
    public static final String __PROP_PARAMLIST_VERSION = "PARAMLIST_VERSION";
    public static final String __PROP_PARAMLIST_VARIANT = "PARAMLIST_VARIANT";
    public static final String __PROP_PARAMLIST_DATASET = "PARAMLIST_DATASET";
    public static final String __PROP_NUMBER_REQUIRED_UNITS = "NUMBER_REQUIRED_UNITS";
    //************ Property variables for EQUIPMENT_MONITOR_SAMPLE_RESULTS ************* //
    public static final String __PROP_TEST_RESULTS = "TEST_RESULTS";

    /**************************************************************
     * Description: This is the main method where execution starts.
     * @param properties Property List of properties.
     * @throws SapphireException OOB Sapphire exceptions.
     **************************************************************/
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("--------- Processing Action:" + ID + ", Version:" + VERSIONID + "---------");
        // ************* Declaration of method variables *****************
        String arrSites = properties.getProperty(_PROPS_SITE);
        String transactionids = "";
        String responseCode = "";
        String responseStatus = "";
        String responseMsg = "";
        // **************** Getting Service & Site details *****************
        String serviceName = properties.getProperty(_PROPS_SERVICE_NAME, "");
        String site = properties.getProperty(_PROPS_SITE, "");
        // ************** Checking if Site is active *****************
        DataSet dsActiveSites = MESUtil.getActiveSiteForService(getQueryProcessor(), serviceName, site);
        if (dsActiveSites == null || dsActiveSites.getRowCount() == 0) {
            return; // If Site is INACTIVE do nothing
        }
        // *************** By default Reprocessing flag is set to N ******************
        String reProcessingFlag = properties.getProperty(__PROP_REPROCESSINGFLAG, "N");
        // ***************
        if ("N".equalsIgnoreCase(reProcessingFlag)) {
            // Calling a method to add values in MESIntfTrans SDC and
            transactionids = populateMESTransTable(properties);
        } else {
            transactionids = properties.getProperty(TRANSACTION_ID, "");
        }
        PropertyList editprops = new PropertyList();
        String transactionId = "";
        String statusMessage = "";

        transactionId = transactionids;
        // ************* Getting JSON details from  Policy ***************
        String[] endpointDetails = new String[2];
        // ************* Creating JSON string ***************
        String JSONString = "";
        if ("Y".equalsIgnoreCase(reProcessingFlag)) {
            JSONString = properties.getProperty(__PROPS_ITEMS, "");
        } else if (properties.getProperty(_PROPS_SERVICE_NAME).equalsIgnoreCase(_PROPS_BATCH_POTENCY)) {
            // *************** If Batch Potency Service ***************** //
            JSONString = getBatchPotencyJSONString(properties, transactionId, arrSites);
        } else if (properties.getProperty(_PROPS_SERVICE_NAME).equalsIgnoreCase(_PROPS_LIMS_ACTIONABLE_RESULTS)) {
            // **************** If LIMS Actionable Results *************** //
            JSONString = createLIMSActionableJSONString(properties, transactionId, arrSites);
        } else if (properties.getProperty(_PROPS_SERVICE_NAME).equalsIgnoreCase(_PROPS_STABILITY_PULL_SAMPLE_REQUEST)) {
            // **************** If LIMS Actionable Results *************** //
            JSONString = getStabilityPullSampleReqJSONString(properties, transactionId, arrSites);
        }else if (properties.getProperty(_PROPS_SERVICE_NAME).equalsIgnoreCase(__PROPS_LIMS_EQUIPMENT_RESULTS)) {
            // **************** If LIMS Actionable Results *************** //
            JSONString = getEquipmentMonitorSampleResultsJSONString(properties, transactionId, arrSites);
        }
        // *********** Checking if JSON String is BLANK then Return ************ //
        if ("".equalsIgnoreCase(JSONString)) {
            return;
        }
        endpointDetails = MESUtil.getEndPointDetails(serviceName, getConfigurationProcessor(), getTranslationProcessor());
        if (endpointDetails.length == 0) {
            return;
        }

        // *********** Formatting the JSON if Reprocessing flag is not Yes ******************
        String formattedJSON = ("N".equalsIgnoreCase(reProcessingFlag)) ? MESUtil.getFormattedJSON(JSONString) : JSONString;
        // ************* Sending JSON payload via REST ****************
        String[] response = MESUtil.sendRESTMessage(JSONString, getTranslationProcessor(), endpointDetails);

        if (__PROPS_SUCCESS.equalsIgnoreCase(response[0])) {
            JSONObject objJSONResponse = null;
            try {
                objJSONResponse = new JSONObject(response[1]);
            } catch (JSONException ex) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.BATCH_POTENCY_ERR_00002 + "\n" + ex.getMessage()));
            }
            // *************** Test Mode to decide the property reading todo remove when Internal QA done ***************
            String testingMode = "".equalsIgnoreCase(endpointDetails[3]) ? __PROP_TESTMODE_STANDARD : endpointDetails[3];
            if (__PROP_TESTMODE_STANDARD.equalsIgnoreCase(testingMode)) {
                PropertyList plJSONResponse = new PropertyList(objJSONResponse);
                if (plJSONResponse.size() == 0) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.BATCH_POTENCY_ERR_00004));
                }
                responseStatus = plJSONResponse.getProperty(__PROP_HTTP_RESPONSE_MSGTYPE);
                if (responseStatus.startsWith("\"") && responseStatus.endsWith("\"")) {
                    responseStatus = responseStatus.substring(1, responseStatus.length() - 1);
                }
                responseStatus = responseStatus.equalsIgnoreCase(__PROP_HTTP_RES_STATUS_FAILURE) ? __PROP_STATUS_ERROR : responseStatus;
                responseMsg = plJSONResponse.getProperty(__PROP_HTTP_RES_MESSAGE);
            } else {
                //******************* todo ELSE part to remove when Internal QA done ***************
                PropertyList plJSONResponse = new PropertyList(objJSONResponse);
                PropertyList plOutput = new PropertyList(plJSONResponse.getPropertyList("output"));
                if (plOutput.size() == 0) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.BATCH_POTENCY_ERR_00004));
                }
                responseCode = plOutput.getProperty(__PROP_HTTP_RESPONSECODE);
                responseStatus = plOutput.getProperty(__PROP_HTTP_RESPONSE_STATUS);
                responseMsg = plOutput.getProperty(__PROP_HTTP_RESPONSE_MESSAGE);
            }

            // ****************** Todo uncomment when internal QA done *********************
            //String statusMessage = responseMsg;
            // ****************** Todo Remove the below line when internal QA done *********************
            statusMessage = (testingMode.equalsIgnoreCase(__PROP_TESTMODE_INTERNAL)) ? "[" + responseCode + "] - " + responseMsg : responseMsg;
        } else {
            responseStatus = response[0];
            statusMessage = response[1];
        }
        // *************** Checking if Payload sent successfully ? *******************
        //      - YES update the transaction status to Complete  --> EditSDI MESIntfTrans [ status = DONE ]
        //      - NO - Populate Error SDC * set the status of Trans Id to Error  --> AddSDI to MESIntfError & EditSDI MESIntfTrans table [ status = ERROR]
        // ************ Updating the Transaction status with proper status *************
        editprops.clear();
        editprops.setProperty(EditSDI.PROPERTY_SDCID, SDC_ID);
        editprops.setProperty(EditSDI.PROPERTY_KEYID1, transactionId);
        editprops.setProperty(STATUS, responseStatus);
        editprops.setProperty(__PROP_ERROR_MSG, statusMessage);
        // ********** Reprocessing causing formatting problem, hence checked ******** //
        if ("N".equalsIgnoreCase(reProcessingFlag)) {
            editprops.setProperty(TRANSACTION_DATA, formattedJSON);
        }
        editprops.setProperty(__PROP_CREATEBY, __PROP_MES_OPCENTER);
        editprops.setProperty(SERVICE_NAME, properties.getProperty(_PROPS_SERVICE_NAME, ""));
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, editprops);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.BATCH_POTENCY_ERR_00005 + transactionids));
        }

    }


    /******************************************************************************************
     * This method is used to add data into the MESIntfTrans SDC. This tracks the outbound data.
     * @return New transaction id
     * @throws SapphireException OOB Sapphire exception
     ******************************************************************************************/
    private String populateMESTransTable(PropertyList properties) throws SapphireException {
        String transactionIds = "";
        String stagename = properties.getProperty(__PROPS_STAGE_NAME, "");
        String serviceName = properties.getProperty(_PROPS_SERVICE_NAME, "");
        String sites = properties.getProperty(_PROPS_SITE, "");
        String POMSInterfaceId = properties.getProperty(_PROPS_POMS_INTERFACE_ID, "");
        String transactiondatetime = properties.getProperty(_PROPS_TRANSACTIONDATETIME, "");
        String SAPBatchNumber = properties.getProperty(_PROPS_SAP_BATCH_NUMBER, "");
        String LIMSBatchNumber = properties.getProperty(_PROPS_LIMS_BATCH_NUMBER, "");
        String SAPMaterialNumber = properties.getProperty(_PROPS_SAP_MATERIAL_NUMBER, "");
        String mesSampleId = properties.getProperty(MES_SAMPLE_NUMBER, "");

        PropertyList plMESIntfTransData = new PropertyList();

        plMESIntfTransData.setProperty(AddSDI.PROPERTY_SDCID, SDC_ID);
        plMESIntfTransData.setProperty(SERVICE_NAME, serviceName);
        plMESIntfTransData.setProperty(SITE, sites);
        plMESIntfTransData.setProperty(POMS_INTERFACE_ID, POMSInterfaceId);
        plMESIntfTransData.setProperty(DATE_MARKED_DONE, transactiondatetime);
        plMESIntfTransData.setProperty(SAP_BATCH_ID, SAPBatchNumber);
        plMESIntfTransData.setProperty(LIMS_BATCH_ID, LIMSBatchNumber);
        plMESIntfTransData.setProperty(SAP_MATERIAL_ID, SAPMaterialNumber);
        plMESIntfTransData.setProperty(TRANSACTION_DIRECTION, __PROP_OUTBOUND_TRANSACTION_DIRECTION);
        plMESIntfTransData.setProperty(TRANSACTION_TYPE, __PROP_OUTBOUND_TRANSACTION_TYPE);
        plMESIntfTransData.setProperty(STATUS, __PROP_STATUS_PENDING);
        plMESIntfTransData.setProperty(STAGE_NAME, stagename);
        plMESIntfTransData.setProperty(MES_SAMPLE_NUMBER, mesSampleId);


        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plMESIntfTransData);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, MESErrorMessageUtil.GENERAL_ERR_00010 + "\n" + ex.getMessage());
        }
        transactionIds = plMESIntfTransData.getProperty(AddSDI.RETURN_NEWKEYID1, "");
        return transactionIds;
    }

    /***************************************************************************************
     * This Method is to get Batch Potency JSON String according to the given JSON structure.
     * @param properties List of properties to be passed from LIMS to MES as JSON Payload.
     * @param transactionid LIMS Outbound transaction Id.
     * @return JSONString Payload as JSON String
     * @throws SapphireException OOB Sapphire Exception.
     ***************************************************************************************/
    private String getBatchPotencyJSONString(PropertyList properties, String transactionid, String site) throws SapphireException {
        String serviceName = properties.getProperty(_PROPS_SERVICE_NAME, "");
        String transactiondatetime = properties.getProperty(_PROPS_TRANSACTIONDATETIME, "");
        String SAPBatchNumber = properties.getProperty(_PROPS_SAP_BATCH_NUMBER, "");
        String SAPMaterialNumber = properties.getProperty(_PROPS_SAP_MATERIAL_NUMBER, "");
        String vendorBatchNumber = properties.getProperty(_PROPS_VENDOR_BATCH_NUMBER, "");
        String batchPotency = properties.getProperty(_PROPS_BATCH_POTENCY, "");
        String LIMSReleaseDate = properties.getProperty(_PROPS_LIMS_RELEASE_DATE, "");

        LinkedHashMap<String, String> lhmJSONString = new LinkedHashMap<>();
        lhmJSONString.put(_PROPS_SERVICE_NAME, serviceName);
        lhmJSONString.put(_PROPS_SITE, site);
        LinkedHashMap<String, String> lhmPayload = new LinkedHashMap<>();
        lhmPayload.put(_PROPS_TRANSACTIONID, transactionid);
        lhmPayload.put(_PROPS_TRANSACTIONDATETIME, transactiondatetime);
        lhmPayload.put(_PROPS_SAP_BATCH_NUMBER, SAPBatchNumber);
        lhmPayload.put(_PROPS_SAP_MATERIAL_NUMBER, SAPMaterialNumber);
        lhmPayload.put(_PROPS_VENDOR_BATCH_NUMBER, vendorBatchNumber);
        lhmPayload.put(_PROPS_BATCH_POTENCY, batchPotency);
        lhmPayload.put(_PROPS_LIMS_RELEASE_DATE, LIMSReleaseDate);
        lhmJSONString.put(__PROP_PAYLOAD, toJSONString(lhmPayload));
        return toJSONString(lhmJSONString);
    }

    /*************************************************************************************************
     * This Method is to get LIMS ACTIONABLE RESULT JSON String according to the given JSON structure.
     * @return JSONString Payload as JSON String.
     * @throws SapphireException OOB Sapphire Exception.
     *************************************************************************************************/
    private String createLIMSActionableJSONString(PropertyList properties, String transactionId, String site) throws SapphireException {

        String transactiondatetime = properties.getProperty(_PROPS_TRANSACTIONDATETIME, "");
        String SAPBatchNumber = properties.getProperty(_PROPS_SAP_BATCH_NUMBER, "");
        String SAPMaterialNumber = properties.getProperty(_PROPS_SAP_MATERIAL_NUMBER, "");
        String MESSampleId = properties.getProperty(__PROPS_MES_SAMPLE_ID, "");
        String stageName = properties.getProperty(__PROPS_STAGE_NAME, "");
        String serviceName = properties.getProperty(_PROPS_SERVICE_NAME, "");
        String resultsJSON = properties.getProperty(__PROPS_ITEMS, "");

        LinkedHashMap<String, String> lhmLIMSActionableResults = new LinkedHashMap();
        LinkedHashMap<String, String> lhmPayload = new LinkedHashMap();
        LinkedHashMap<String, String> lhmItems = new LinkedHashMap();

        lhmItems.put(__PROPS_ITEMS, resultsJSON);

        lhmPayload.put(_PROPS_TRANSACTIONID, transactionId);
        lhmPayload.put(_PROPS_TRANSACTIONDATETIME, transactiondatetime);
        lhmPayload.put(_PROPS_SAP_BATCH_NUMBER, SAPBatchNumber);
        lhmPayload.put(_PROPS_SAP_MATERIAL_NUMBER, SAPMaterialNumber);
        lhmPayload.put(__PROPS_MES_SAMPLE_ID, MESSampleId);
        lhmPayload.put(__PROPS_STAGE_NAME, stageName);
        lhmPayload.put(__PROPS_RESULTS, MESUtil.lhmToJSONString(lhmItems));

        lhmLIMSActionableResults.put(_PROPS_SERVICE_NAME, serviceName);
        lhmLIMSActionableResults.put(_PROPS_SITE, site);
        lhmLIMSActionableResults.put(__PROP_PAYLOAD, MESUtil.lhmToJSONString(lhmPayload));

        return MESUtil.lhmToJSONString(lhmLIMSActionableResults);
    }

    /***************************************************************************************
     * This Method is to get Stability Pull Sample Request JSON String according to the given JSON structure.
     * @param properties List of properties to be passed from LIMS to MES as JSON Payload.
     * @param transactionid LIMS Outbound transaction Id.
     * @return JSONString Payload as JSON String
     * @throws SapphireException OOB Sapphire Exception.
     ***************************************************************************************/
    private String getStabilityPullSampleReqJSONString(PropertyList properties, String transactionid, String site) throws SapphireException {
        String serviceName = properties.getProperty(_PROPS_SERVICE_NAME, "");
        String transactiondatetime = properties.getProperty(_PROPS_TRANSACTIONDATETIME, "");
        String SAPBatchNumber = properties.getProperty(_PROPS_SAP_BATCH_NUMBER, "");
        String SAPMaterialNumber = properties.getProperty(_PROPS_SAP_MATERIAL_NUMBER, "");
        String stageName = properties.getProperty(__PROPS_STAGE_NAME, "");
        String paramlistId = properties.getProperty(__PROP_PARAMLIST_ID, "");
        String paramlistVer = properties.getProperty(__PROP_PARAMLIST_VERSION, "");
        String variantId = properties.getProperty(__PROP_PARAMLIST_VARIANT, "");
        String dataset = properties.getProperty(__PROP_PARAMLIST_DATASET, "");
        String noRequiredUnits = properties.getProperty(__PROP_NUMBER_REQUIRED_UNITS, "");

        LinkedHashMap<String, String> lhmJSONString = new LinkedHashMap<>();
        lhmJSONString.put(_PROPS_SERVICE_NAME, serviceName);
        lhmJSONString.put(_PROPS_SITE, site);
        LinkedHashMap<String, String> lhmPayload = new LinkedHashMap<>();
        lhmPayload.put(_PROPS_TRANSACTIONID, transactionid);
        lhmPayload.put(_PROPS_TRANSACTIONDATETIME, transactiondatetime);
        lhmPayload.put(_PROPS_SAP_BATCH_NUMBER, SAPBatchNumber);
        lhmPayload.put(_PROPS_SAP_MATERIAL_NUMBER, SAPMaterialNumber);
        lhmPayload.put(__PROPS_STAGE_NAME, stageName);
        lhmPayload.put(__PROP_PARAMLIST_ID, paramlistId);
        lhmPayload.put(__PROP_PARAMLIST_VERSION, paramlistVer);
        lhmPayload.put(__PROP_PARAMLIST_VARIANT, variantId);
        lhmPayload.put(__PROP_PARAMLIST_DATASET, dataset);
        lhmPayload.put(__PROP_NUMBER_REQUIRED_UNITS, noRequiredUnits);
        lhmJSONString.put(__PROP_PAYLOAD, toJSONString(lhmPayload));
        return toJSONString(lhmJSONString);
    }
/***************************************************************************************
     * This Method is to get LIMS Equipment Results JSON String according to the given JSON structure.
     * @param properties List of properties to be passed from LIMS to MES as JSON Payload.
     * @param transactionid LIMS Outbound transaction Id.
     * @return JSONString Payload as JSON String
     * @throws SapphireException OOB Sapphire Exception.
     ***************************************************************************************/
    private String getEquipmentMonitorSampleResultsJSONString(PropertyList properties, String transactionid, String site) throws SapphireException {
        String serviceName = properties.getProperty(_PROPS_SERVICE_NAME, "");
        String transactiondatetime = properties.getProperty(_PROPS_TRANSACTIONDATETIME, "");
        String messampleId = properties.getProperty(__PROPS_MES_SAMPLE_ID, "");
        String testresults = properties.getProperty(__PROP_TEST_RESULTS, "");

        LinkedHashMap<String, String> lhmJSONString = new LinkedHashMap<>();
        lhmJSONString.put(_PROPS_SERVICE_NAME, serviceName);
        lhmJSONString.put(_PROPS_SITE, site);
        LinkedHashMap<String, String> lhmPayload = new LinkedHashMap<>();
        lhmPayload.put(_PROPS_TRANSACTIONID, transactionid);
        lhmPayload.put(_PROPS_TRANSACTIONDATETIME, transactiondatetime);
        lhmPayload.put(__PROPS_MES_SAMPLE_ID,messampleId);
        lhmPayload.put(__PROP_TEST_RESULTS, testresults);
        lhmJSONString.put(__PROP_PAYLOAD, toJSONString(lhmPayload));
        return toJSONString(lhmJSONString);
    }

    /*************************************************************
     * This method is to create a JSON String from a LinkedHashMap
     * @param map Properties as Key: Value pair.
     * @return JSON String
     * @throws SapphireException OOB Sapphire Exception.
     *************************************************************/
    private String toJSONString(LinkedHashMap<String, String> map) throws SapphireException {
        LinkedHashMap lhmap = new LinkedHashMap<>();
        try {
            for (Map.Entry<String, String> item : map.entrySet()) {
                if ((item.getValue() != null && !__BLANK_STRING.equalsIgnoreCase(item.getValue())) && item.getValue().charAt(0) == '{')
                    lhmap.put("\"" + item.getKey() + "\"", item.getValue());
                else {
                    if (!__BLANK_STRING.equalsIgnoreCase(item.getValue())) {
                        lhmap.put("\"" + item.getKey() + "\"", "\"" + item.getValue() + "\"");
                    } else {
                        lhmap.put("\"" + item.getKey() + "\"", "\"" + "" + "\"");
                    }
                }
            }
        } catch (Exception ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, MESErrorMessageUtil.BATCH_POTENCY_ERR_00006 + "\n" + ex.getMessage());
        }
        return lhmap.toString().replaceAll("=", ": ");
    }

}
