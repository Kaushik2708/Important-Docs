package labvantage.custom.alcon.mes.action;

/**
 * $Author: BAGCHAN1 $
 * $Date: 2022-12-06 10:57:06 +0530 (Tue, 06 Dec 2022) $
 * $Revision: 374 $
 */


import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SafeSQL;
import sapphire.util.StringUtil;
import sapphire.xml.PropertyList;

import java.util.ArrayList;


public class EquipmentMonitorSampleResults extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 374 $";
    public static final String ID = "EquipmentMonitorSampleResults";
    public static final String VERSIONID = "1";
    private static final String __KEYID_1 = "keyid1";
    private static final String __PROPS_LIMS_SAMPLE_ID = "limssampleid";
    private static final String __PROPS_LIMS_MES_SAMPLE_ID = "messampleid";
    private static final String __PROPS_SAP_PLANT = "sapplant";
    private static final String __MES_SAMPLE_ID = "u_messampleid";
    private static final String __SDC_SAMPLE = "Sample";
    private static final String __PARAMLIST_ID = "AR RINSE WATER,AX";
    private static final String __VARIANT_ID = "FW.2USP";
    private static final String __PARAM_ID = "FINAL RESULT-PASS/FAIL";
    private static final String __PARAM_TYPE = "Any";
    private static final String __ENTERED_TEXT = "enteredtext";
    private static final String __LIMSBATCH_ID = "batchid";
    private boolean __PROP_LOG_DIAG_SWITCH = false;

    /*********************************************************************************************
     * Description: This service uploads the equiptment monitor sample results to MES from LIMS.
     * @param properties Properties passed from event plan.
     * @throws SapphireException OOB Sapphire Exception
     *********************************************************************************************/
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        __PROP_LOG_DIAG_SWITCH = "ON".equalsIgnoreCase(MESUtil.getLogDiagSwitchValue(getConfigurationProcessor()));
        Long processingStartTime = System.currentTimeMillis();
        // *************  Local variables *************** //
        String sampleId = "";
        String batchId = "";
        String messampleId = "";
        String transactiondatetime = "";
        String site = "";
        String testresults = "";
        // ******** Getting properties from Event Plan ********
        String allSampleIds = properties.getProperty(__PROPS_LIMS_SAMPLE_ID, "");
        String allMessampleIds = properties.getProperty(__PROPS_LIMS_MES_SAMPLE_ID, "");
        String allsites = properties.getProperty(__PROPS_SAP_PLANT, "");
        // ******** Splitting More than one Sample Ids, MES Sample Ids, Batch Ids & Sites onto Array *********
        String[] arrSampleIds = StringUtil.split(allSampleIds, ";");
        String[] arrMessampleIds = StringUtil.split(allMessampleIds, ";");
        String[] arrsites = StringUtil.split(allsites, ";");
        // ******** Getting result information of all Sample Ids ********
        DataSet dsResults = getResultsBySampleId(allSampleIds);
        if (dsResults == null) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00002, " Result")));
        }
        // *********** If no result found then NO ACTION *********
        if (dsResults.getRowCount() == 0) {
            return;
        }

        // *********** Property List to filter Results by Sample Id ************* //
        PropertyList plSampleFilter = new PropertyList();
        int arrSampleSize = arrSampleIds.length;
        for (int countSample = 0; countSample < arrSampleSize; countSample++) {
            sampleId = arrSampleIds[countSample];
            messampleId = arrMessampleIds[countSample];
            site = arrsites[countSample];

            // ************ Setting Sample Id as KEYID 1 , MESSampleId as MESSAMPLE ID , BatchId as LIMSBATCH ID  ************ //
            plSampleFilter.clear();
            plSampleFilter.setProperty(__KEYID_1, sampleId);
            plSampleFilter.setProperty(__MES_SAMPLE_ID, messampleId);
            plSampleFilter.setProperty(__LIMSBATCH_ID, batchId);
            transactiondatetime = MESUtil.setTransactiondatetime();
            testresults = dsResults.getValue(0, __ENTERED_TEXT, "");
            // ******** Passing properties to OpcenterMESLVOutbound *********
            PropertyList prop = new PropertyList();
            prop.setProperty(OpcenterMESLVOutbound._PROPS_SERVICE_NAME, OpcenterMESLVOutbound.__PROPS_LIMS_EQUIPMENT_RESULTS);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_SITE, site);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_TRANSACTIONDATETIME, transactiondatetime);
            prop.setProperty(OpcenterMESLVOutbound.__PROPS_MES_SAMPLE_ID, messampleId);
            prop.setProperty(OpcenterMESLVOutbound.__PROP_TEST_RESULTS, testresults);
            prop.setProperty(OpcenterMESLVOutbound._PROPS_LIMS_BATCH_NUMBER, batchId);

            // ************* Calling Outbound ********** //
            try {
                getActionProcessor().processAction(OpcenterMESLVOutbound.ID, OpcenterMESLVOutbound.VERSIONID, prop);
            } catch (SapphireException ex) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00011, OpcenterMESLVOutbound.ID)));
            }

        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "processAction");
        }
    }

    /**************************************************************
     * This method is used to retrive result information.
     * @param allSampleIds List of Sample Ids selected for review
     * @return Returs result set.
     * @throws SapphireException OOB Sapphire Exception.
     **************************************************************/
    private DataSet getResultsBySampleId(String allSampleIds) throws SapphireException {
        Long processingStartTime = System.currentTimeMillis();
        String rsetId = "";
        SafeSQL resultsSafeSQL = new SafeSQL();
        StringBuilder sqlText = new StringBuilder().append("");
        DataSet dsAllResults;
        try {
            rsetId = getDAMProcessor().createRSet(__SDC_SAMPLE, allSampleIds, "(null)", "(null)");
            sqlText.append(" SELECT sdi.keyid1,sdi.keyid2,sdi.keyid3,sdi.paramlistid, sdi.paramlistversionid, sdi.variantid,sdi.dataset, sdi.paramid, sdi.paramtype, ");
            sqlText.append(" sdi.datatypes, sdi.replicateid, sdi.enteredtext FROM sdidata ds INNER JOIN sdidataitem sdi ");
            sqlText.append(" ON ds.sdcid = sdi.sdcid AND ds.keyid1 = sdi.keyid1 AND ds.keyid2 = sdi.keyid2 AND ds.keyid3 = sdi.keyid3 ");
            sqlText.append(" AND ds.paramlistid = sdi.paramlistid AND ds.paramlistversionid = sdi.paramlistversionid AND ds.variantid = sdi.variantid ");
            sqlText.append(" AND ds.dataset = sdi.dataset INNER JOIN rsetitems rsi ON rsi.sdcid = sdi.sdcid AND rsi.keyid1 = sdi.keyid1 AND rsi.keyid2 = sdi.keyid2 AND rsi.keyid3 = sdi.keyid3 ");
            sqlText.append(" WHERE rsi.rsetid = ").append(resultsSafeSQL.addVar(rsetId));
            sqlText.append(" AND ds.paramlistid = ").append(resultsSafeSQL.addVar(__PARAMLIST_ID)).append(" AND sdi.variantid = ").append(resultsSafeSQL.addVar(__VARIANT_ID)).append(" AND ds.s_datasetstatus <> 'Cancelled' ");
            sqlText.append(" AND sdi.enteredtext IS NOT NULL AND sdi.paramid = ").append(resultsSafeSQL.addVar(__PARAM_ID)).append(" AND sdi.paramtype = ").append(resultsSafeSQL.addVar(__PARAM_TYPE));
            dsAllResults = getQueryProcessor().getPreparedSqlDataSet(sqlText.toString(), resultsSafeSQL.getValues());
        } catch (SapphireException e) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.MES_ACTIONABLE_RESULTS_ERR_00001));
        } finally {
            if (!"".equalsIgnoreCase(rsetId)) {
                getDAMProcessor().clearRSet(rsetId);
            }
        }
        // ***** Sorting result dataset to get latest DataSet, Replicate Id information *****
        DataSet dsResultsBySampleId = getHighestDataSetDetails(dsAllResults);
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "getResultsBySampleId");
        }
        return dsResultsBySampleId;
    }

    /*****************************************************************************
     * This method is used to get dataset sorted by highest dataSet & replicate #.
     * @param dsAllResults All results
     * @return DataSet  sorted by highest dataSet & replicate #.
     * @throws SapphireException OOB Sapphire Exception
     ******************************************************************************/
    private DataSet getHighestDataSetDetails(DataSet dsAllResults) throws SapphireException {
        Long processingStartTime = System.currentTimeMillis();
        DataSet dsHighestDSDetails = new DataSet();
        String sortingCols = "keyid1, keyid2, keyid3, workitemid, workitemversionid, paramlistid, paramlistversionid, variantid, paramid, paramtype";
        String groupingCols = "keyid1, keyid2, keyid3, workitemid, workitemversionid, paramlistid, paramlistversionid, variantid, paramid, paramtype";
        // Sorting All Result details based on DataSet # in decending order
        dsAllResults.sort(sortingCols);
        // Grouping Results based on Sample Id, Test, Test Ver., ParamList, ParamList Ver., Varient
        ArrayList<DataSet> arrGroupDS = dsAllResults.getGroupedDataSets(groupingCols);
        // Looping through Each groupt
        for (DataSet dsItem : arrGroupDS) {
            dsItem.sort("dataset D, replicateid D");
            dsHighestDSDetails.copyRow(dsItem, 0, 1);
            dsItem.clear();
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTime, ID, "getHighestDataSetDetails");
        }
        return dsHighestDSDetails;
    }


}

