package labvantage.custom.alcon.mes.action;


import java.util.ArrayList;
import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SafeSQL;
import sapphire.xml.PropertyList;
/**
 * $Author: SAHAPI1 $
 * $Date: 2022-09-29 20:05:31 +0530 (Thu, 29 Sep 2022) $
 * $Revision: 157 $
 */

/************************************************************************************************
 * $Revision: 157 $
 * Description: This class is used for getting all properties when there is an entry in POMS Page
 ************************************************************************************************/


public class DispensingInterfaceAction extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 157 $";
    public static final String ID = "DispensingInterfaceAction";
    public static final String VERSIONID = "1";

    private static final String PROP_POMS_INTERFACE = "POMS_Interface";
    private static final String PROP_MES_SAP_BATCH = "u_mesordersapbatch1";
    private static final String PROP_PROD_VARIANT_LOT_REFERENCE = "prodvariantlotreference";
    private static final String PROP_MATERIAL_NUM = "u_sapmatnumber";
    private static final String PROP_PARAM_LIST_ID = "paramlistid";
    private static final String PROP_ENTERED_VALUE= "enteredvalue";
    private static final String PROP_SAP_PLANT= "u_sapplant";
    private static final String PROP_BATCH_ID = "s_batchid";

    private static final String LIMS_LOT_NUM = "lims_lot_number";
    private static final String MANUFACTURER_LOT = "manufacturer_lot";
    private static final String PART_NUM = "part_number";
    private static final String ASSAY_NAME = "assay_name";
    private static final String ASSAY_VALUE = "assay_value";
    private static final String STATUS = "status";
    private static final String TIME_STAMP = "timestamp";
    private static final String LIMS_BATCH_ID = "lims_batchid";
    private static final String SITE = "site";


    /**************************************************************
     * Description: This is the main method where execution starts.
     * @param properties Property List of properties.
     * @throws SapphireException OOB Sapphire exceptions.
     **************************************************************/

    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.debug("Processing " + ID + ". (Action) : Properties  : " + properties.toJSONString());
        String batchid = properties.getProperty(PROP_BATCH_ID);
        String strRSet="";
        DataSet dsSQLForStatus, dsBatchInformation;
        try {
            strRSet = getDAMProcessor().createRSet("Batch", batchid, "", "");
            SafeSQL safeSQL = new SafeSQL();
            StringBuilder stSQL = new StringBuilder().append("");
            stSQL.append(" SELECT refdisplayvalue FROM refvalue ");
            stSQL.append("WHERE reftypeid = 'POMS_Reference' AND refvalueid = 'Pending Release'");
            // ************** Using SafeSQL--> getValues to replace bind variable with values  ***************
            dsSQLForStatus = getQueryProcessor().getPreparedSqlDataSet(stSQL.toString(), safeSQL.getValues());

            StringBuilder strSQL = new StringBuilder().append("");
            strSQL.append("SELECT DISTINCT  SB.u_mesordersapbatch1,  SB.prodvariantlotreference,  SB.u_sapmatnumber,  SB.productid,  nvl(substr(TRIM(SB.productid),1,instr(TRIM(SB.productid),' ')-1),TRIM(SB.productid)) as product,  SB.s_batchid, SB.u_sapplant, sdi.enteredvalue,  SB.batchstatus,  sdi.paramlistid  ");
            strSQL.append(" FROM s_batch SB  INNER JOIN s_product SP  ON SP.s_productid=SB.productid ");
            strSQL.append(" AND SP.s_productversionid=SB.productversionid  INNER JOIN s_sample SS ON SS.batchid=SB.s_batchid INNER JOIN sdidata sd ");
            strSQL.append(" ON sd.sdcid = 'Sample' AND sd.keyid1 = ss.s_sampleid AND sd.keyid2 = '(null)' AND sd.keyid3 = '(null)' INNER JOIN sdidataitem sdi ");
            strSQL.append(" ON sdi.sdcid = sd.sdcid  AND  sdi.keyid1 = sd.keyid1 AND sdi.keyid2 = sd.keyid2 AND sdi.keyid3 = sd.keyid3 AND sdi.paramlistid = sd.paramlistid AND sdi.paramlistversionid = sd.paramlistversionid AND sdi.dataset = sd.dataset ");
            strSQL.append(" INNER JOIN rsetitems ON rsetitems.sdcid='Batch'  AND rsetitems.keyid1=SB.s_batchid  AND rsetitems.keyid2='(null)'  AND rsetitems.keyid3='(null)' ");
            strSQL.append(" WHERE  NVL(SP.u_pomsproduct,'N') = 'Y'  AND NVL(sdi.u_pomsassay,'N') = 'Y' AND ss.samplestatus <> 'Cancelled' AND sd.s_datasetstatus <> 'Cancelled' AND rsetitems.rsetid = ").append(safeSQL.addVar(strRSet));
            ;
            // ************** Using SafeSQL--> getValues to replace bind variable with values  ***************
            dsBatchInformation = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        }
        catch(SapphireException ex){
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.DISPENSING_ERR_00003));
        }
        finally {
            if (!"".equals(strRSet)) {
                getDAMProcessor().clearRSet(strRSet);
            }
        }
        if (dsSQLForStatus == null) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.DISPENSING_ERR_00001));
        }
        String poms_status = dsSQLForStatus.getValue(0, "refdisplayvalue");

        if (dsBatchInformation == null) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.DISPENSING_ERR_00001));
        } else {
            dsBatchInformation.sort("s_batchid");
            ArrayList arGroupArrayList = dsBatchInformation.getGroupedDataSets("s_batchid");

            for (int i = 0; i < arGroupArrayList.size(); ++i) {
                DataSet dsGroup = (DataSet) arGroupArrayList.get(i);
                addRecordsInTransactionTable(dsGroup,poms_status);
            }

        }
    }

    /*************************************************************************
     * This method is used to add records in POMS_Interface SDC
     * @param dsInformation Primary DataSet
     * @param poms_status as String
     *************************************************************************/

    private void addRecordsInTransactionTable(DataSet dsInformation,String poms_status) {
        PropertyList plAddSDI = new PropertyList();
        plAddSDI.setProperty(AddSDI.PROPERTY_SDCID ,PROP_POMS_INTERFACE);
        plAddSDI.setProperty(LIMS_LOT_NUM, dsInformation.getValue(0, PROP_MES_SAP_BATCH,""));
        plAddSDI.setProperty(MANUFACTURER_LOT, dsInformation.getValue(0, PROP_PROD_VARIANT_LOT_REFERENCE,""));
        plAddSDI.setProperty(PART_NUM, dsInformation.getValue(0, PROP_MATERIAL_NUM,""));
        plAddSDI.setProperty(ASSAY_NAME, dsInformation.getValue(0, PROP_PARAM_LIST_ID,""));
        plAddSDI.setProperty(ASSAY_VALUE, dsInformation.getValue(0, PROP_ENTERED_VALUE,""));
        plAddSDI.setProperty(STATUS, poms_status);
        plAddSDI.setProperty(TIME_STAMP, "n");
        plAddSDI.setProperty(LIMS_BATCH_ID, dsInformation.getValue(0, PROP_BATCH_ID, ""));
        plAddSDI.setProperty(SITE, dsInformation.getValue(0, PROP_SAP_PLANT, ""));

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plAddSDI);
            } catch (SapphireException var4) {
            logger.error("Error while processing AddSDI within " + ID + "::addRecordsInTransactionTable " + var4);
        }

    }
}
