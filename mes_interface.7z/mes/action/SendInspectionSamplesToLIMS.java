package labvantage.custom.alcon.mes.action;

/**
 * $Author: DIANAR1 $
 * $Date: 2023-01-02 18:42:29 +0530 (Mon, 02 Jan 2023) $
 * $Revision: 425 $
 */

import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import sapphire.SapphireException;
import sapphire.action.*;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SafeSQL;
import sapphire.xml.PropertyList;

import java.util.HashMap;


/********************************************************************************************************
 * $Revision: 425 $
 * Description: All necessary activities needed for Send Inspection Samples to LIMS Service
 *
 ********************************************************************************************************/


public class SendInspectionSamplesToLIMS extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 425 $";
    public static final String ID = "SendInspectionSamplesToLIMS";
    public static final String VERSIONID = "1";
    private static final String __PROP_TRANSACTIONDATETIME = "TRANSACTIONDATETIME";
    private static final String _PROP_SAP_BATCH_NUMBER = "SAP_BATCH_NUMBER";
    private static final String _PROP_SAP_MATERIAL_NUMBER = "SAP_MATERIAL_NUMBER";
    private static final String _PROP_SITE = "plant";
    private static final String _PROPS_INSPECTION_STAGE_NAME = "INSPECTION_STAGE_NAME";
    private static final String _PROPS_INSPECTION_MES_SAMPLE_ID = "INSPECTION_MES_SAMPLE_ID";
    private static final String _PROPS_INSPECTION_RESULT = "INSPECTION_RESULT";

    private static final String __PROP_SDC_BATCH = "Batch";
    private static final String __PROP_SDC_SAMPLE = "Sample";
    private static final String __PROP_COL_MESBATCH_ID = "u_messampleid";
    private static final String __PROP_BATCH_STATUS_INITIAL = "Initial";

    private static final String __PROPS_TRANSITEM_STATUS = "status";
    private static final String MES_STATUS_SUCCESS = "SUCCESS";
    private static final String __PROP_REPROCESSFLAG = "reprocessingflag";
    private static final String __PROPS_LIMS_SAMPLE_ID = "limssampleid";
    private static final String __PROPS_LIMS_BATCH_ID = "limsbatchid";
    private static final String __PROP_LIMS_BATCH_ID = "s_batchid";
    private static final String __PROP_LIMS_BATCH_STATUS = "batchstatus";
    private static final String __PROPS_VARIANTID = "variantid";
    private static final String __PROPS_LIMS_BATCH_PRODVARIANTID = "prod" + __PROPS_VARIANTID;

    private static final String __PROPS_KEYID1 = "keyid1";
    private static final String __PROPS_PARAMLIST_ID = "ParamlistID";
    private static final String __PROPS_PARAM_LIST_VERSION = "ParamListVersion";
    private static final String __PROPS_VARIANT_ID = "Variant_ID";
    private static final String __PROPS_DATASET = "Dataset";
    private static final String __PROPS_PARAM_ID = "ParamID";
    private static final String __PROPS_PARAM_TYPE = "ParamType";
    private static final String __PROPS_REPLICATE = "Replicate";
    private static final String __PROPS_RESULT = "Result";
    private static final String __PROPS_PARAMLISTID = "paramlistid";
    private static final String __PROPS_PARAMLISTVERSIONID = "paramlistversionid";
    private static final String __PROPS_DS = "dataset";
    private static final String __PROPS_PARAMID = "paramid";
    private static final String __PROPS_PARAMTYPE = "paramtype";
    private static final String __PROPS_KEYID2 = "keyid2";
    private static final String __PROPS_SDCID = "sdcid";
    private static final String __PROPS_KEYID3 = "keyid3";
    private static final String __PROPS_REPLICATEID = "replicateid";

    private static final String __PROP_BATCH_STATUS_CANCELLED = "Cancelled";
    private static final String __PROP_BATCH_STATUS_REJECTED = "Rejected";

    private static final String __PROP_IS_MES_BATCH_FLAG = "ismesbatch";
    private static final String __PROPS_PARAMLIST = "AUDIT OF FILL/PKG OPS(AX)";
    private static final String __PROPS_VARIANT = "FWMDOC-02819";
    private static final String __PROPS_PARAM = "AUDIT OF FILL/PKG OPERATIONS";
    private static final String __PROPS_PARAM_TYPE_ANY = "Any";
    private static final String __PROP_MES_BATCH_FLAG_YES = "Y";


    // Added for different  sample status
    private static final String __PROP_SAMPLE_STATUS_RECEIVED = "Received";
    private static final String __PROP_SAMPLE_STATUS_COMPLETED = "Completed";
    private static final String __PROP_SAMPLE_STATUS_REVIEWED = "Reviewed";
    private static final String __PROP_SAMPLE_STATUS_INITIAL = "Initial";

    private static final String __PROP_PROCESSSTAGE_LABEL = "label";
    private static final String __PROP_BATCHSTAGEID = "s_batchstageid";
    private static final String __PROP_BATCHSTAGE_STATUS = "batchstagestatus";
    private static final String __PROP_BATCHSTAGE_STATUS_CANCELLED = "Cancelled";

    private static final String __PROP_LIMS_SAMPLE_ID = "s_sampleid";
    private static final String __PROP_SAMPLE_STATUS = "samplestatus";
    private static final String __PROP_MES_SAMPLE_ID = "messampleid";
    private static final String __PROP_BLANK_MES_SAMPLEID = "BLANK";
    private static final String __PROP_SAMPLE_CREATE_DATE = "createdt";
    private static final String __PROPS_PARAM_TEST_DATE = "TEST DATE";
    private static final String __PROPS_PARAM_TYPE_STANDARD = "Standard";

    private static final String SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS = "alcSendInspectionSamplesToLIMS";
    private boolean __PROP_LOG_DIAG_SWITCH = false;


    /**************************************************************
     * Description: This is the main method where execution starts.
     * @param properties Property List of properties.
     * @throws SapphireException OOB Sapphire exceptions.
     **************************************************************/
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        logger.info("--------- Processing Action:" + ID + ", Version:" + VERSIONID + "---------");
        __PROP_LOG_DIAG_SWITCH = "ON".equalsIgnoreCase(MESUtil.getLogDiagSwitchValue(getConfigurationProcessor()));
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String sapBatchNumber = properties.getProperty(_PROP_SAP_BATCH_NUMBER);
        String sapMaterialNumber = properties.getProperty(_PROP_SAP_MATERIAL_NUMBER);
        String transactionDateTime = properties.getProperty(__PROP_TRANSACTIONDATETIME);
        String testDate = MESUtil.getDateTimeStringWithProperFormat(transactionDateTime);
        String sapPlant = properties.getProperty(_PROP_SITE);
        String inspectionStageName = properties.getProperty(_PROPS_INSPECTION_STAGE_NAME);
        String inspectionSampleId = properties.getProperty(_PROPS_INSPECTION_MES_SAMPLE_ID);
        String reprocessedFlag = properties.getProperty(__PROP_REPROCESSFLAG);
        String inspectionResult = properties.getProperty(_PROPS_INSPECTION_RESULT, "");
        //  ***************Below are list of local variables ************
        String limsBatchId = "", limsBatchStatus="";
        String limsSampleId = "";
        String sampleId = "";

        String batchStageId = "";
        PropertyList plFilter = new PropertyList();

        // ************** End of local variable list **************** //
        try {
            // ********** Getting LIMS Batch Details **********
            String[] limsBatchDetails = getExistingLIMSBatch(sapBatchNumber, sapMaterialNumber, sapPlant);
            limsBatchId = limsBatchDetails[0];
            limsBatchStatus = limsBatchDetails[1];

            // ********** Checking if LIMS Batch Id is BLANK ***********
            if ("".equalsIgnoreCase(limsBatchId)) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00006));
            }

            //********* Check LIMS Batch is received ********//
            if (__PROP_BATCH_STATUS_INITIAL.equalsIgnoreCase(limsBatchStatus)) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00031, limsBatchId)));
            }

            // ********** Check if the MES batch Id is BLANK or NOT If BLANK Update with MES Batch Id **********
            updateBatchByMESId(limsBatchId);

            // ********** Finding Batch Stage id ************
            batchStageId = getBatchStageId(limsBatchId, inspectionStageName);
            // ********** Find Samples by Batch Stage Id ***********
            DataSet dsSampleDetailsByMESStage = getSamplesByBatchStage(limsBatchId, batchStageId, inspectionStageName);
            // ********** Checking if matching MES Sample found or not *************
            plFilter.setProperty(__PROP_MES_SAMPLE_ID, inspectionSampleId);
            DataSet dsSampleByMESSampleId = dsSampleDetailsByMESStage.getFilteredDataSet(plFilter);
            // ************ If Matching MES Sample NOT found *****************
            if (dsSampleByMESSampleId.size() == 0) {
                // ************** Checking if BLANK MES Sample Id found or not **************
                plFilter.clear();
                plFilter.setProperty(__PROP_MES_SAMPLE_ID, __PROP_BLANK_MES_SAMPLEID);
                DataSet dsBLANKMESSampleDetails = dsSampleDetailsByMESStage.getFilteredDataSet(plFilter);
                // ************** Checking if BLANK MES Sample Id NOT found **************
                if (dsBLANKMESSampleDetails.size() == 0) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00001, inspectionSampleId)));
                }
                // ********** If Matching BLANK MES Sample found **************
                // ********* Checking if more than one  BLANK MES Sample found in Stage *************
                if (dsBLANKMESSampleDetails.size() >= 1) {
                    // **************** Find the earliest LIMS Sample Id ***************
                    dsBLANKMESSampleDetails.sort(__PROP_SAMPLE_CREATE_DATE + ", " + __PROP_LIMS_SAMPLE_ID);
                    sampleId = dsBLANKMESSampleDetails.getValue(0, __PROP_LIMS_SAMPLE_ID);
                    // **************** Get Master Data from Sample  ***************
                    DataSet dsMasterDataDetailsFromSample = getMasterDataDetailsFromSample(sampleId);
                    if (dsMasterDataDetailsFromSample.size() == 0) {
                        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00020, limsSampleId)));
                    }

                    // **************** Getting Master Data from MES ***************
                    DataSet dsMasterDataForResultEntry = new DataSet();
                    dsMasterDataForResultEntry = getMasterDataForResultEntry(sampleId, inspectionResult,testDate);
                    if (dsMasterDataForResultEntry.size() == 0) {
                        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00020));
                    }

                    // **************** Creating dataset for Result Entry *****************
                    DataSet dsResultSet = createFinalResultSet(dsMasterDataForResultEntry, dsMasterDataDetailsFromSample);

                    // **************** Check if Datasetstatus is Initial or not ***************
                    PropertyList plFilter1 = new PropertyList();
                    plFilter1.setProperty(__PROPS_KEYID1, dsResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ""));
                    plFilter1.setProperty(__PROPS_PARAMLISTID, dsResultSet.getValue(0, __PROPS_PARAMLIST_ID, ""));
                    plFilter1.setProperty(__PROPS_PARAMLISTVERSIONID, dsResultSet.getValue(0, __PROPS_PARAM_LIST_VERSION, ""));
                    plFilter1.setProperty(__PROPS_VARIANTID, dsResultSet.getValue(0, __PROPS_VARIANT_ID, ""));
                    plFilter1.setProperty("strdataset", dsResultSet.getValue(0, __PROPS_DATASET, ""));
                    plFilter1.setProperty(__PROPS_PARAMID, dsResultSet.getValue(0, __PROPS_PARAM_ID, ""));
                    plFilter1.setProperty(__PROPS_PARAMTYPE, dsResultSet.getValue(0, __PROPS_PARAM_TYPE, ""));
                    plFilter1.setProperty("strreplicateid", dsResultSet.getValue(0, __PROPS_REPLICATE, ""));
                    DataSet dsStatus = dsMasterDataDetailsFromSample.getFilteredDataSet(plFilter1);
                    if(!dsStatus.getValue(0,"s_datasetstatus").equalsIgnoreCase("Initial")){
                        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00027, dsResultSet.getValue(0,__PROPS_LIMS_SAMPLE_ID),dsResultSet.getValue(0,__PROPS_PARAMLIST_ID),dsResultSet.getValue(0,__PROPS_PARAM_LIST_VERSION),dsResultSet.getValue(0,__PROPS_VARIANT_ID),dsResultSet.getValue(0,__PROPS_DATASET),dsResultSet.getValue(0,__PROPS_PARAM_ID),dsResultSet.getValue(0,__PROPS_PARAM_TYPE),dsResultSet.getValue(0,__PROPS_REPLICATE))));
                    }

                    // ***************** Update the LIMS Sample by MES Sample Id if not already ************
                    updateSampleByMESId(sampleId, inspectionSampleId);

                    // ***************** Enter Results ************
                    enterResults(dsResultSet);
                    // ***************** Auto Review sample ************
                    autoReviewSample(sampleId, sapPlant);

                }
            }
            else {
                // ********* Checking if More than one Sample having matching MES Sample Id *********
                if (dsSampleByMESSampleId.size() > 1) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00015, inspectionSampleId)));
                } else {
                    sampleId = dsSampleByMESSampleId.getColumnValues(__PROP_LIMS_SAMPLE_ID, "");
                    // **************** Get Master Data from Sample  ***************
                    DataSet dsMasterDataDetailsFromSample = getMasterDataDetailsFromSample(sampleId);
                    if (dsMasterDataDetailsFromSample.size() == 0) {
                        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00020, limsSampleId)));
                    }

                    // **************** Get Master Data from MES ***************
                    DataSet dsMasterDataForResultEntry = new DataSet();
                    dsMasterDataForResultEntry = getMasterDataForResultEntry(sampleId, inspectionResult,testDate);
                    if (dsMasterDataForResultEntry.size() == 0) {
                        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00019));
                    }
                    // **************** Creating dataset for Result Entry *****************
                    DataSet dsResultSet = createFinalResultSet(dsMasterDataForResultEntry, dsMasterDataDetailsFromSample);

                    // **************** Check if Datasetstatus is Initial or not ***************
                    PropertyList plFilter1 = new PropertyList();
                    plFilter1.setProperty(__PROPS_KEYID1, dsResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ""));
                    plFilter1.setProperty(__PROPS_PARAMLISTID, dsResultSet.getValue(0, __PROPS_PARAMLIST_ID, ""));
                    plFilter1.setProperty(__PROPS_PARAMLISTVERSIONID, dsResultSet.getValue(0, __PROPS_PARAM_LIST_VERSION, ""));
                    plFilter1.setProperty(__PROPS_VARIANTID, dsResultSet.getValue(0, __PROPS_VARIANT_ID, ""));
                    plFilter1.setProperty("strdataset", dsResultSet.getValue(0, __PROPS_DATASET, ""));
                    plFilter1.setProperty(__PROPS_PARAMID, dsResultSet.getValue(0, __PROPS_PARAM_ID, ""));
                    plFilter1.setProperty(__PROPS_PARAMTYPE, dsResultSet.getValue(0, __PROPS_PARAM_TYPE, ""));
                    plFilter1.setProperty("strreplicateid", dsResultSet.getValue(0, __PROPS_REPLICATE, ""));
                    DataSet dsStatus = dsMasterDataDetailsFromSample.getFilteredDataSet(plFilter1);
                    if(!dsStatus.getValue(0,"s_datasetstatus").equalsIgnoreCase("Initial")){
                        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00027, dsResultSet.getValue(0,__PROPS_LIMS_SAMPLE_ID),dsResultSet.getValue(0,__PROPS_PARAMLIST_ID),dsResultSet.getValue(0,__PROPS_PARAM_LIST_VERSION),dsResultSet.getValue(0,__PROPS_VARIANT_ID),dsResultSet.getValue(0,__PROPS_DATASET),dsResultSet.getValue(0,__PROPS_PARAM_ID),dsResultSet.getValue(0,__PROPS_PARAM_TYPE),dsResultSet.getValue(0,__PROPS_REPLICATE))));
                    }

                    // ***************** Enter Results ************
                    enterResults(dsResultSet);
                    // ***************** Auto Review sample ************
                    autoReviewSample(sampleId, sapPlant);

                }
            }

        } catch (SapphireException ex) {
            // ******** For ERROR ******* //
            // Concatinating the LIMS Batch Id and LIMS Sample Id with Error Msg.
            throw new SapphireException(ex.getMessage() + "|" + limsBatchId + "|" + sampleId);
        }
        // ******** For SUCCESS ******* //
        if ("Y".equalsIgnoreCase(reprocessedFlag)) {
            properties.setProperty(__PROPS_TRANSITEM_STATUS, MES_STATUS_SUCCESS);
        }
        properties.setProperty(__PROPS_LIMS_BATCH_ID, limsBatchId);
        properties.setProperty(__PROPS_LIMS_SAMPLE_ID, sampleId);

        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-processAction");
        }
    }

    /***********************************************************
     * This method is used to get exiting LIMS Batch details
     * @param sapBatchNumber SAP Batch Number
     * @param sapMaterialNumber SAP Material Number
     * @param sapPlant SAP plant
     * @return Returns LIMS Batch Id
     * @throws SapphireException OOB Sapphire Exception.
     ************************************************************/
    private String[] getExistingLIMSBatch(String sapBatchNumber, String sapMaterialNumber, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getExistingLIMSBatch (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String limsBatchDetails[] = new String[2];
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT s_batch." + __PROP_LIMS_BATCH_ID + ", s_batch." + __PROP_LIMS_BATCH_STATUS + ", s_batch." + __PROPS_LIMS_BATCH_PRODVARIANTID + " ,s_prodvariant.productid,s_prodvariant.productversionid,s_batch.batchdesc  ");
        strSQL.append(" FROM s_batch INNER JOIN s_prodvariant ").append(" ON s_batch.prod" + __PROPS_VARIANTID + " = s_prodvariant.s_prodvariantid ");
        strSQL.append(" WHERE s_batch.u_mesordersapbatch1 = ").append(safeSQL.addVar(sapBatchNumber));
        strSQL.append(" AND s_batch.u_sapmatnumber = ").append(safeSQL.addVar(sapMaterialNumber));
        strSQL.append(" AND ( s_batch.u_sapplant = ").append(safeSQL.addVar(sapPlant));
        strSQL.append(" OR s_prodvariant.securitydepartment IN( SELECT department.departmentid FROM department INNER JOIN u_sites ");
        strSQL.append(" ON department.u_siteid = u_sites.u_sitesid WHERE u_sites.sapplant = ").append(safeSQL.addVar(sapPlant)).append("))");
        strSQL.append(" AND s_batch.batchstatus <> '" + __PROP_BATCH_STATUS_CANCELLED + "' ");
        strSQL.append(" AND s_batch.batchstatus <> '" + __PROP_BATCH_STATUS_REJECTED + "' ");
        DataSet dsLIMSBatchDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        // ****** If Query returns NULL
        if (null == dsLIMSBatchDetails) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00007)));
        } else if (dsLIMSBatchDetails.size() == 0) {
            // ******* If No LIMS Batch found against SAP Batch + SAP Material + SAP plant combination.
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00008, sapBatchNumber, sapMaterialNumber, sapPlant)));
        } else if (dsLIMSBatchDetails.size() > 1) {
            // ******* If More than One LIMS Batch found against SAP Batch + SAP Material + SAP plant combination.
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00009, sapBatchNumber, sapMaterialNumber, sapPlant)));
        } else if (dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_STATUS, "").equalsIgnoreCase(__PROP_BATCH_STATUS_CANCELLED)) {
            // ******* If Batch Status is Cancelled
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00010, dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_ID, ""), __PROP_BATCH_STATUS_CANCELLED)));
        } else if (dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_STATUS, "").equalsIgnoreCase(__PROP_BATCH_STATUS_REJECTED)) {
            // ******* If Batch Status is Rejected
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00010, dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_ID, ""), __PROP_BATCH_STATUS_REJECTED)));
        } else {
            // ******* Setting LIMS Batch Id and Status
            limsBatchDetails[0] = dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_ID, "");
            limsBatchDetails[1] = dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_STATUS, "");
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-getExistingLIMSBatch");
        }
        return limsBatchDetails;
    }

    /***********************************************************************
     * This method is used to UPDATE Batch as MES Batch iff it's BLANK
     * @param limsBatchId LIMS Batch Id
     * @throws SapphireException OOB Sapphire Exception
     ***********************************************************************/
    private void updateBatchByMESId(String limsBatchId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside updateBatchByMESId (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        PropertyList plUpdateBatch = new PropertyList();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT NVL(u_ismesbatch,'N') " + __PROP_IS_MES_BATCH_FLAG + " FROM s_batch WHERE s_batchid = ").append(safeSQL.addVar(limsBatchId));
        DataSet dsIsMESIdPresent = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsIsMESIdPresent) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting MES Batch details for LIMS Batch # - " + limsBatchId)));
        }
        // ********* Check if not MES Batch ************
        if (!__PROP_MES_BATCH_FLAG_YES.equalsIgnoreCase(dsIsMESIdPresent.getValue(0, __PROP_IS_MES_BATCH_FLAG, ""))) {
            plUpdateBatch.setProperty(EditSDI.PROPERTY_SDCID, __PROP_SDC_BATCH);
            plUpdateBatch.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
            plUpdateBatch.setProperty("auditreason", " Marked as MES Batch. ");
            plUpdateBatch.setProperty("u_ismesbatch", __PROP_MES_BATCH_FLAG_YES);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plUpdateBatch);
            } catch (SapphireException ex) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00016, limsBatchId));
            }
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-updateBatchByMESId");
        }

    }

    /************************************************************************
     * This method is used to get batch stage details.
     * @param limsBatchId LIMS Batch Id
     * @param mesStageName MES Stage Name
     * @return Returns batch stage id
     * @throws SapphireException OOB Sapphire Exception
     *************************************************************************/
    private String getBatchStageId(String limsBatchId, String mesStageName) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getBatchStageId (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String batchstageId = "";
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT s_batchstage." + __PROP_BATCHSTAGEID + ", s_batchstage." + __PROP_BATCHSTAGE_STATUS + " FROM s_batchstage ");
        strSQL.append(" WHERE s_batchstage.batchid = ").append(safeSQL.addVar(limsBatchId)).append(" AND  s_batchstage." + __PROP_PROCESSSTAGE_LABEL + " = ").append(safeSQL.addVar(mesStageName));

        DataSet dsBatchStageDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsBatchStageDetails) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting Batch Stage details for LIMS Batch # - " + limsBatchId + " and MES Stage # -" + mesStageName)));

        } else if (dsBatchStageDetails.size() == 0) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00011, mesStageName, limsBatchId)));

        } else if (dsBatchStageDetails.size() > 1) {

            //Check if all stages are Cancelled
            HashMap hm = new HashMap();
            hm.put(__PROP_BATCHSTAGE_STATUS, __PROP_BATCHSTAGE_STATUS_CANCELLED);

            DataSet dsFilter = dsBatchStageDetails.getFilteredDataSet(hm);
            if (dsFilter.size() == dsBatchStageDetails.size()) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00013, limsBatchId, mesStageName)));
            }

            //Ignore cancelled stages
            dsFilter = dsBatchStageDetails.getFilteredDataSet(hm, true);

            //If non-cancelled stages are multiple, throw error
            if (dsFilter.size() > 1) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00012, mesStageName, limsBatchId)));
            }

            // batchstageId = dsBatchStageDetails.getValue(0, __PROP_BATCHSTAGEID, "");
            batchstageId = dsFilter.getValue(0, __PROP_BATCHSTAGEID, "");


        } else {
            //Check if the stage is Cancelled
            HashMap hm = new HashMap();
            hm.put(__PROP_BATCHSTAGE_STATUS, __PROP_BATCHSTAGE_STATUS_CANCELLED);

            DataSet dsFilter = dsBatchStageDetails.getFilteredDataSet(hm);
            if (dsFilter.size() == dsBatchStageDetails.size()) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00013, limsBatchId, mesStageName)));
            }

            batchstageId = dsBatchStageDetails.getValue(0, __PROP_BATCHSTAGEID, "");

        }

        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-getBatchStageId");
        }

        return batchstageId;
    }

    /**************************************************************
     * This method is used to get Sample details from Stage details.
     * @param limsBatchId LIMS Batch Id
     * @param batchStageId Batch Stage Id
     * @param mesStageName MES Stage Name
     * @return DataSet containing LIMS Sample details
     * @throws SapphireException OOB Sapphire Exception
     ***************************************************************/
    private DataSet getSamplesByBatchStage(String limsBatchId, String batchStageId, String mesStageName) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getSamplesByBatchStage (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT s_sample." + __PROP_LIMS_SAMPLE_ID + ", s_sample." + __PROP_SAMPLE_STATUS + ", NVL(s_sample.u_messampleid,'" + __PROP_BLANK_MES_SAMPLEID + "') " + __PROP_MES_SAMPLE_ID + " ,s_sample.usersequence, s_sample." + __PROP_SAMPLE_CREATE_DATE + " FROM s_sample ");
        strSQL.append(" WHERE s_sample.batchstageid = ").append(safeSQL.addVar(batchStageId));
        strSQL.append(" AND s_sample.batchid = ").append(safeSQL.addVar(limsBatchId));
        strSQL.append(" AND s_sample.samplestatus <> 'Cancelled'");

        DataSet dsSampleDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsSampleDetails) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting Sample details for LIMS Batch # - " + limsBatchId + " and MES Stage # -" + mesStageName)));
        } else if (dsSampleDetails.size() == 0) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00014, limsBatchId, mesStageName)));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-getSamplesByBatchStage");
        }
        return dsSampleDetails;
    }

    /**********************************************************************
     * This method is used to Receive Sample.
     * @param limsSampleId LIMS Sample id
     * @throws SapphireException OOB Sapphire Exception
     **********************************************************************/
    private void receiveSample(String limsSampleId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside receiveSample (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        PropertyList plReceiveSample = new PropertyList();
        plReceiveSample.setProperty(EditSDI.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plReceiveSample.setProperty(EditSDI.PROPERTY_KEYID1, limsSampleId);
        plReceiveSample.setProperty(__PROP_SAMPLE_STATUS, __PROP_SAMPLE_STATUS_RECEIVED);
        plReceiveSample.setProperty("receivedby", currentUser);
        plReceiveSample.setProperty("auditactivity", __PROP_SAMPLE_STATUS_RECEIVED);
        plReceiveSample.setProperty("receiveddt", "N");
        plReceiveSample.setProperty("auditreason", "Sample Received");
        plReceiveSample.setProperty("auditsignedflag", "Y");
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plReceiveSample);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00025, limsSampleId));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-receiveSample");
        }
    }

    /**************************************************************
     * This method is used get Master Data details from Sample Id
     * @param limsSampleId LIMS Sample Id
     * @return DataSet of Master Data
     * @throws SapphireException OOB Sapphire Exception
     **************************************************************/
    private DataSet getMasterDataDetailsFromSample(String limsSampleId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getMasterDataDetailsFromSample (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String rsetId = "";
        StringBuilder strSQL = new StringBuilder().append("");
        DataSet dsSampleResults = new DataSet();
        SafeSQL safeSQL = new SafeSQL();
        try {
            rsetId = getDAMProcessor().createRSet(__PROP_SDC_SAMPLE, limsSampleId, "(null)", "(null)");
            strSQL.append(" SELECT sdi." + __PROPS_KEYID1 + ", sdi." + __PROPS_PARAMLISTID + ", sdi." + __PROPS_PARAMLISTVERSIONID + ", sdi." + __PROPS_VARIANTID + ", sdi." + __PROPS_DS + ", TO_CHAR(sdi.dataset) strdataset, sdi." + __PROPS_PARAMID + ", sdi." + __PROPS_PARAMTYPE + ", sdi." + __PROPS_REPLICATEID + ", TO_CHAR(sdi.replicateid) strreplicateid, sdi.createdt, sd.s_datasetstatus ");
            strSQL.append(" FROM sdidata sd INNER JOIN sdidataitem sdi ");
            strSQL.append(" ON sd." + __PROPS_SDCID + " =  sdi.sdcid  AND sd." + __PROPS_KEYID1 + " =  sdi." + __PROPS_KEYID1 + "  AND sd." + __PROPS_KEYID2 + " =  sdi." + __PROPS_KEYID2 + " AND sd." + __PROPS_KEYID3 + " =  sdi.keyid3 AND sd." + __PROPS_PARAMLISTID + " = sdi.paramlistid AND sd." + __PROPS_PARAMLISTVERSIONID + " = sdi." + __PROPS_PARAMLISTVERSIONID + " AND sd." + __PROPS_VARIANTID + " =  sdi." + __PROPS_VARIANTID + " AND sd." + __PROPS_DS + " =  sdi." + __PROPS_DS + "  ");
            strSQL.append(" INNER JOIN rsetitems rsi ON rsi." + __PROPS_SDCID + " = sdi." + __PROPS_SDCID + " AND rsi." + __PROPS_KEYID1 + " = sdi." + __PROPS_KEYID1 + " AND rsi." + __PROPS_KEYID2 + " =  sdi." + __PROPS_KEYID2 + " AND rsi." + __PROPS_KEYID3 + " = sdi." + __PROPS_KEYID3);
            strSQL.append(" WHERE rsi.rsetid = ").append(safeSQL.addVar(rsetId));
            strSQL.append(" AND sdi.sdcid='Sample' and sd.s_datasetstatus <> 'Cancelled' ");
            strSQL.append(" and sdi.keyid1 in ( ").append(safeSQL.addIn(limsSampleId, ";")).append(")");
            dsSampleResults = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
            if (null == dsSampleResults) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting result details for LIMS Sample # - " + limsSampleId)));
            }

        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00018));

        } finally {
            if (!"".equalsIgnoreCase(rsetId)) {
                getDAMProcessor().clearRSet(rsetId);
            }
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-getMasterDataDetailsFromSample");
        }
        return dsSampleResults;

    }


    /***************************************************************************
     * This method is used to create a DataSet of Master Data.
     * @param sampleId LIMS Sample Id
     * @param inspectionResult inspectionResult
     * @param testDate testDate
     * @return DataSet of Static Data
     * @throws SapphireException OOB Sapphire Exception
     ******************************************************************************/
    private DataSet getMasterDataForResultEntry(String sampleId, String inspectionResult,String testDate) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside getMasterDataForResultEntry (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        DataSet dsMasterData = new DataSet(connectionInfo);
        // ************ Creating DataSet columns ************
        if (!dsMasterData.isValidColumn(__PROPS_LIMS_SAMPLE_ID)) {
            dsMasterData.addColumn(__PROPS_LIMS_SAMPLE_ID, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_PARAMLIST_ID)) {
            dsMasterData.addColumn(__PROPS_PARAMLIST_ID, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_PARAM_LIST_VERSION)) {
            dsMasterData.addColumn(__PROPS_PARAM_LIST_VERSION, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_VARIANT_ID)) {
            dsMasterData.addColumn(__PROPS_VARIANT_ID, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_DATASET)) {
            dsMasterData.addColumn(__PROPS_DATASET, DataSet.STRING);
        }
        if (!dsMasterData.isValidColumn(__PROPS_PARAM_ID)) {
            dsMasterData.addColumn(__PROPS_PARAM_ID, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_PARAM_TYPE)) {
            dsMasterData.addColumn(__PROPS_PARAM_TYPE, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_REPLICATE)) {
            dsMasterData.addColumn(__PROPS_REPLICATE, DataSet.STRING);
        }

        if (!dsMasterData.isValidColumn(__PROPS_RESULT)) {
            dsMasterData.addColumn(__PROPS_RESULT, DataSet.STRING);
        }


        // ************** Entering Master Data *****************

        int row1;

        // ***** Row 1 *****
        int row;
        if (!"".equalsIgnoreCase(inspectionResult)) {
            // ***** Row 1 *****
            row = dsMasterData.addRow();
            dsMasterData.setValue(row, __PROPS_LIMS_SAMPLE_ID, sampleId);
            dsMasterData.setValue(row, __PROPS_PARAMLIST_ID, __PROPS_PARAMLIST);
            dsMasterData.setValue(row, __PROPS_VARIANT_ID, __PROPS_VARIANT);
            dsMasterData.setValue(row, __PROPS_PARAM_ID, __PROPS_PARAM);
            dsMasterData.setValue(row, __PROPS_PARAM_TYPE, __PROPS_PARAM_TYPE_ANY);
            dsMasterData.setValue(row, __PROPS_RESULT, inspectionResult);

        }
        if (!"".equalsIgnoreCase(testDate)) {
            // **** Row 5 ****
            row = dsMasterData.addRow();
            dsMasterData.setValue(row, __PROPS_LIMS_SAMPLE_ID, sampleId);
            dsMasterData.setValue(row, __PROPS_PARAMLIST_ID, __PROPS_PARAMLIST);
            dsMasterData.setValue(row, __PROPS_VARIANT_ID, __PROPS_VARIANT);
            dsMasterData.setValue(row, __PROPS_PARAM_ID, __PROPS_PARAM_TEST_DATE);
            dsMasterData.setValue(row, __PROPS_PARAM_TYPE, __PROPS_PARAM_TYPE_STANDARD);
            dsMasterData.setValue(row, __PROPS_RESULT, testDate);
        }

        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-getMasterDataForResultEntry");
        }
        return dsMasterData;
    }

    /*******************************************************************************
     * This method is used to create final Result set for inserting results.
     * @param dsMasterDataForResultEntry DataSet of Master Data coming from MES
     * @param dsMasterDataDetailsFromSample DataSEt of Master Data fetched from LIMS
     * @return Returns final Result set for data entry
     * @throws SapphireException OOB Saaphire Exception
     ********************************************************************************/
    private DataSet createFinalResultSet(DataSet dsMasterDataForResultEntry, DataSet dsMasterDataDetailsFromSample) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside createFinalResultSet (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plFilter = new PropertyList();
        DataSet dsTemp = new DataSet(connectionInfo);
        // ************** Looping though the static data ***************
        int dsSize = dsMasterDataForResultEntry.size();
        for (int row = 0; row < dsSize; row++) {
            plFilter.clear();
            dsTemp.clear();
            plFilter.setProperty(__PROPS_KEYID1, dsMasterDataForResultEntry.getValue(row, __PROPS_LIMS_SAMPLE_ID, ""));
            plFilter.setProperty(__PROPS_PARAMLISTID, dsMasterDataForResultEntry.getValue(row, __PROPS_PARAMLIST_ID, ""));
            plFilter.setProperty(__PROPS_VARIANTID, dsMasterDataForResultEntry.getValue(row, __PROPS_VARIANT_ID, ""));
            plFilter.setProperty(__PROPS_PARAMID, dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_ID, ""));
            plFilter.setProperty(__PROPS_PARAMTYPE, dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_TYPE, ""));

            // **********  Filtering  SDIDataItem based on Static data came from MES **********
            dsTemp = dsMasterDataDetailsFromSample.getFilteredDataSet(plFilter);
            // ********* If no matching resultset found then ERROR **********
            if (dsTemp.size() == 0) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00026,dsMasterDataForResultEntry.getValue(row, __PROPS_LIMS_SAMPLE_ID, ""), dsMasterDataForResultEntry.getValue(row, __PROPS_PARAMLIST_ID, ""), dsMasterDataForResultEntry.getValue(row, __PROPS_VARIANT_ID, ""), dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_ID, ""), dsMasterDataForResultEntry.getValue(row, __PROPS_PARAM_TYPE, ""))));
            }
            // ********* Sorting SDIDataItem based on Latest DataSet followed by Replicate Id in Descending order **********
            dsTemp.sort(__PROPS_DS + " D, " + __PROPS_REPLICATEID + " D");

            // ********* Setting DataSet and Replicate Information ***********
            // ********* 0 th index is taken because it will contain the latest DataSet & Replicate information *********
            dsMasterDataForResultEntry.setValue(row, __PROPS_DATASET, dsTemp.getValue(0, __PROPS_DS, ""));
            dsMasterDataForResultEntry.setValue(row, __PROPS_REPLICATE, dsTemp.getValue(0, __PROPS_REPLICATEID, ""));
            dsMasterDataForResultEntry.setValue(row, __PROPS_PARAM_LIST_VERSION, dsTemp.getValue(0, __PROPS_PARAMLISTVERSIONID, ""));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-createFinalResultSet");
        }
        return dsMasterDataForResultEntry;

    }

    /*************************************************************************
     * This method is used to UPDATE Sample by MES Sample Id iff it's BLANK
     * @param limsSampleId LIMS Sample Id
     * @param mesSampleId MES Sample Id
     * @throws SapphireException OOB Sapphire Exception
     *************************************************************************/
    private void updateSampleByMESId(String limsSampleId, String mesSampleId) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside updateSampleByMESId (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        SafeSQL safeSQL = new SafeSQL();
        PropertyList plUpdateBatch = new PropertyList();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT NVL(u_messampleid,'BLANK') " + __PROP_MES_SAMPLE_ID + "  FROM s_sample WHERE s_sampleid = ").append(safeSQL.addVar(limsSampleId));
        DataSet dsIsMESIdPresent = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsIsMESIdPresent) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting MES Sample # details for LIMS Sample # - " + limsSampleId + " and MES Sample # -" + mesSampleId)));
        }
        // ********* Check if MES Sample Id is BLANK or not ************
        if (__PROP_BLANK_MES_SAMPLEID.equalsIgnoreCase(dsIsMESIdPresent.getValue(0, __PROP_MES_SAMPLE_ID, ""))) {
            plUpdateBatch.setProperty(EditSDI.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
            plUpdateBatch.setProperty(EditSDI.PROPERTY_KEYID1, limsSampleId);
            plUpdateBatch.setProperty("auditreason", " MES Sample Id Updated. ");
            plUpdateBatch.setProperty(__PROP_COL_MESBATCH_ID, mesSampleId);
            try {
                getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plUpdateBatch);
            } catch (SapphireException ex) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00017, limsSampleId));
            }
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-updateSampleByMESId");
        }
    }

    /**********************************************************
     * This method is used to enter results.
     * @param dsFinalResultSet Final result set
     * @throws SapphireException OOB Sapphire exception
     **********************************************************/
    private void enterResults(DataSet dsFinalResultSet) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside enterResults (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plEnterDetails = new PropertyList();

        //--- Unrelease dataitems ---//
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_KEYID1, dsFinalResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMLISTID, dsFinalResultSet.getColumnValues(__PROPS_PARAMLIST_ID, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMLISTVERSIONID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_LIST_VERSION, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_VARIANTID, dsFinalResultSet.getColumnValues(__PROPS_VARIANT_ID, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_DATASET, dsFinalResultSet.getColumnValues(__PROPS_DATASET, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_ID, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMTYPE, dsFinalResultSet.getColumnValues(__PROPS_PARAM_TYPE, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_REPLICATEID, dsFinalResultSet.getColumnValues(__PROPS_REPLICATE, ";"));
        plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_AUDITREASON, "MES Interface Update");

        try {
            getActionProcessor().processAction(UnReleaseDataItem.ID, UnReleaseDataItem.VERSIONID, plEnterDetails);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00021, ex.getMessage())));
        }

        // ********* Update Dataset status *************
        updateDatasetStatus(dsFinalResultSet);

        // ******** SyncSDIWIStatus ***************
        syncSDIWIStatus(dsFinalResultSet);

        // *************** SyncSDIDataSetStatus **************
        syncSDIDataSetStatus(dsFinalResultSet);

        //--- Result entry ---//
        plEnterDetails.clear();
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_KEYID1, dsFinalResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsFinalResultSet.getColumnValues(__PROPS_PARAMLIST_ID, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_LIST_VERSION, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsFinalResultSet.getColumnValues(__PROPS_VARIANT_ID, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_DATASET, dsFinalResultSet.getColumnValues(__PROPS_DATASET, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_ID, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsFinalResultSet.getColumnValues(__PROPS_PARAM_TYPE, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsFinalResultSet.getColumnValues(__PROPS_REPLICATE, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, dsFinalResultSet.getColumnValues(__PROPS_RESULT, ";"));
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_AUDITREASON, "MES Interface results update");
        plEnterDetails.setProperty(EnterDataItem.PROPERTY_PROPSMATCH, "Y");

        try {
            getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, plEnterDetails);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00021, ex.getMessage())));
        }

        //--- Release Dataitems----//
        plEnterDetails.clear();
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_KEYID1, dsFinalResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMLISTID, dsFinalResultSet.getColumnValues(__PROPS_PARAMLIST_ID, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMLISTVERSIONID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_LIST_VERSION, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_VARIANTID, dsFinalResultSet.getColumnValues(__PROPS_VARIANT_ID, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_DATASET, dsFinalResultSet.getColumnValues(__PROPS_DATASET, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_ID, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMTYPE, dsFinalResultSet.getColumnValues(__PROPS_PARAM_TYPE, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_REPLICATEID, dsFinalResultSet.getColumnValues(__PROPS_REPLICATE, ";"));
        plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_AUDITREASON, "MES Interface Update");

        try {
            getActionProcessor().processAction(ReleaseDataItem.ID, ReleaseDataItem.VERSIONID, plEnterDetails);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00021, ex.getMessage())));
        }

        // ********* Update Dataset status *************
        updateDatasetStatus(dsFinalResultSet);

        // ******** SyncSDIWIStatus ***************
        syncSDIWIStatus(dsFinalResultSet);

        // *************** SyncSDIDataSetStatus **************
        syncSDIDataSetStatus(dsFinalResultSet);

        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-enterResults");
        }
    }

    /**********************************************************************
     * This method is used to update DataSet status after result is released
     * @param dsFinalResultSet DataSet for Result Entry
     * @throws SapphireException OOB Sapphire Exception
     ***********************************************************************/
    private void updateDatasetStatus(DataSet dsFinalResultSet) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside updateDatasetStatus (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plUpdateDataSetStatus = new PropertyList();
        plUpdateDataSetStatus.setProperty(UpdateDatasetStatus.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plUpdateDataSetStatus.setProperty(UpdateDatasetStatus.PROPERTY_KEYID1, dsFinalResultSet.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
        plUpdateDataSetStatus.setProperty(UpdateDatasetStatus.PROPERTY_AUDITREASON, "MES Interface Result Update");
        try {
            getActionProcessor().processAction(UpdateDatasetStatus.ID, UpdateDatasetStatus.VERSIONID, plUpdateDataSetStatus);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00022, ex.getMessage())));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-updateDatasetStatus");
        }
    }

    /****************************************************************
     * This method is used to sync SDI WI Status
     * @param dsFinalResultSet Final Result Set
     * @throws SapphireException OOB Sapphire Exception
     ****************************************************************/
    private void syncSDIWIStatus(DataSet dsFinalResultSet) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside syncSDIWIStatus (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plUpdateDataSetStatus = new PropertyList();
        plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_KEYID1, dsFinalResultSet.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
        plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_AUDITSIGNEDFLAG, "Y");
        plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_AUDITACTIVITY, "MES Interface Result Update");
        try {
            getActionProcessor().processAction(SyncSDIWIStatus.ID, SyncSDIWIStatus.VERSIONID, plUpdateDataSetStatus);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00023, ex.getMessage())));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-syncSDIWIStatus");
        }
    }

    /******************************************************************
     * This method is used to sync SDI DataSet status
     * @param dsFinalResultSet Final Result Set
     * @throws SapphireException OOB Sapphire Exception
     *****************************************************************/
    private void syncSDIDataSetStatus(DataSet dsFinalResultSet) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside syncSDIDataSetStatus (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        PropertyList plUpdateDataSetStatus = new PropertyList();
        plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_KEYID1, dsFinalResultSet.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
        plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_STATUSCOLID, "samplestatus");
        plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_AUDITREASON, "MES Interface Result Update");
        try {
            getActionProcessor().processAction(SyncSDIDataSetStatus.ID, SyncSDIDataSetStatus.VERSIONID, plUpdateDataSetStatus);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00024, ex.getMessage())));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-syncSDIDataSetStatus");
        }
    }

    /*******************************************************************************
     * This method is used to update QTYCurrent for Trackitem Id
     * @param sampleId sampleId
     * @param sapPlant sapPlant
     * @throws SapphireException OOB Sapphire Exception
     ********************************************************************************/
    private void autoReviewSample(String sampleId, String sapPlant) throws SapphireException {
        logger.info("Processing " + ID + ". (Action) : Inside autoReviewSample (method)");
        Long processingStartTimeInNanoSec = System.currentTimeMillis();
        String sampleStatus ="", reviewRequiredFlag ="";
        String currentUser = getConnectionProcessor().getConnectionInfo(getConnectionid()).getSysuserId();
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT samplestatus , reviewrequiredflag FROM s_sample ");
        strSQL.append(" WHERE s_sampleid =  ").append(safeSQL.addVar(sampleId));

        DataSet dsSampleDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsSampleDetails) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " Sample Details - " + sampleId)));
        } else if (dsSampleDetails.size() == 0) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_INSPECTION_SAMPLES_ERR_00030, sampleId)));
        }else{
            sampleStatus = dsSampleDetails.getValue(0,"samplestatus");
            reviewRequiredFlag = dsSampleDetails.getValue(0,"reviewrequiredflag");
            if(__PROP_SAMPLE_STATUS_COMPLETED.equalsIgnoreCase(sampleStatus) && "Y".equalsIgnoreCase(reviewRequiredFlag)){
                PropertyList plUpdateSample = new PropertyList();
                plUpdateSample.setProperty("sdcid", __PROP_SDC_SAMPLE);
                plUpdateSample.setProperty("keyid1", sampleId);
                plUpdateSample.setProperty("samplestatus", __PROP_SAMPLE_STATUS_REVIEWED);
                plUpdateSample.setProperty("auditactivity", "MES Interface Result Update");
                plUpdateSample.setProperty("reviewdisposition", "Approved");
                plUpdateSample.setProperty("disposalstatus", "Marked for Disposal");
                plUpdateSample.setProperty("revieweddt", "N");
                plUpdateSample.setProperty("reviewedby", currentUser);
                plUpdateSample.setProperty("u_sapplant", sapPlant);
                plUpdateSample.setProperty("auditactivity", __PROP_SAMPLE_STATUS_REVIEWED);
                plUpdateSample.setProperty("auditreason", "Sample Approved");
                plUpdateSample.setProperty("auditsignedflag", "Y");
                try {
                    getActionProcessor().processAction("EditSDI", "1", plUpdateSample);
                } catch (SapphireException ex) {
                    throw new SapphireException(" General Error ", ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate("Aborting transaction. Inside autoReviewSample - unable to update Sample."));
                }

            }
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS, "SendInspectionSamplesToLIMS-autoReviewSample");
        }
    }
}
