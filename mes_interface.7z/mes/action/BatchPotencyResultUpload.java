package labvantage.custom.alcon.mes.action;


import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.xml.PropertyList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


/**
 * $Author: DIANAR1 $
 * $Date: 2022-11-24 14:51:08 +0530 (Thu, 24 Nov 2022) $
 * $Revision: 354 $
 */

/******************************************************************************
 * $Revision: 354 $
 * Description:
 * This class is used for getting all properties when there is an entry in POMS Page
 ******************************************************************************/

public class BatchPotencyResultUpload extends BaseAction {
    public static final String DEVOPS_ID = "$Revision: 354 $";
    public static final String ID = "BatchPotencyResultUpload";
    public static final String VERSIONID = "1";

    private static final String __PROPS_POMS_INTERFACE_ID = "u_poms_interfaceid";
    private static final String __PROPS_POMS_CREATE_DATE = "createdt";
    private static final String __PROPS_POMS_SAP_BATCH_ID = "sapbatchid";
    private static final String __PROPS_POMS_LIMS_BATCH_ID = "limsbatchid";
    private static final String __PROPS_POMS_SITE = "site";
    private static final String __PROPS_POMS_MATERIAL_NUMBER = "part_number";
    private static final String __PROPS_POMS_BATCH_POTENCY = "assay_value";
    private static final String __PROPS_POMS_PROD_VARIANT_LOT_REFERENCE = "manufacturer_lot";
    private static final String __PROPS_POMS_DATE_FORMAT = "yyyyMMdd_HHmmss";
    private static final String __BLANK_STRING = "";
    private boolean __PROP_LOG_DIAG_SWITCH = false;


    /************************************************************************
     * Description: processAction is the main method where execution starts.
     * @param properties List of Input properties
     ************************************************************************/
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        __PROP_LOG_DIAG_SWITCH = "ON".equalsIgnoreCase(MESUtil.getLogDiagSwitchValue(getConfigurationProcessor()));
        Long processingStartTime = System.currentTimeMillis();

        String pomsInterfaceid = properties.getProperty(__PROPS_POMS_INTERFACE_ID, "");
        String transactionDateTime = properties.getProperty(__PROPS_POMS_CREATE_DATE, "");
        String sapBatchId = properties.getProperty(__PROPS_POMS_SAP_BATCH_ID, "");
        String limsBatchId = properties.getProperty(__PROPS_POMS_LIMS_BATCH_ID, "");
        String site = properties.getProperty(__PROPS_POMS_SITE, "");
        String materialNum = properties.getProperty(__PROPS_POMS_MATERIAL_NUMBER, "");
        String batchPotency = properties.getProperty(__PROPS_POMS_BATCH_POTENCY, "");
        String prodVariantLotReference = properties.getProperty(__PROPS_POMS_PROD_VARIANT_LOT_REFERENCE, "");
        // ******** Checking for Mandatory values *********
        //MESUtil.checkMadatoryFields(properties, __PROPS_POMS_INTERFACE_ID, __PROPS_POMS_CREATE_DATE, __PROPS_POMS_SAP_BATCH_ID, __PROPS_POMS_MATERIAL_NUMBER, __PROPS_POMS_BATCH_POTENCY, __PROPS_POMS_PROD_VARIANT_LOT_REFERENCE);
        // ******** Converting Date into dateformat "yyyyMMdd_HHmmss" *********
        transactionDateTime = MESUtil.getDateStringWithProperFormat(transactionDateTime, __PROPS_POMS_DATE_FORMAT);
        // ******** If Date is not valid date, Converting CurrentDate into dateformat "yyyyMMdd_HHmmss" *********
        if(transactionDateTime == null || __BLANK_STRING.equalsIgnoreCase(transactionDateTime)){
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(__PROPS_POMS_DATE_FORMAT);
            LocalDateTime now = LocalDateTime.now();
            transactionDateTime= formatter.format(now);
           }
        // ******** Passing properties to OpcenterMESLVOutbound *********
        PropertyList prop = new PropertyList();
        prop.setProperty(OpcenterMESLVOutbound._PROPS_SERVICE_NAME, OpcenterMESLVOutbound._PROPS_BATCH_POTENCY);
        prop.setProperty(OpcenterMESLVOutbound._PROPS_SITE, site);
        prop.setProperty(OpcenterMESLVOutbound._PROPS_POMS_INTERFACE_ID, pomsInterfaceid);
        prop.setProperty(OpcenterMESLVOutbound._PROPS_TRANSACTIONDATETIME, transactionDateTime);
        prop.setProperty(OpcenterMESLVOutbound._PROPS_SAP_BATCH_NUMBER, sapBatchId);
        prop.setProperty(OpcenterMESLVOutbound._PROPS_LIMS_BATCH_NUMBER, limsBatchId);
        prop.setProperty(OpcenterMESLVOutbound._PROPS_VENDOR_BATCH_NUMBER, prodVariantLotReference);
        prop.setProperty(OpcenterMESLVOutbound._PROPS_SAP_MATERIAL_NUMBER, materialNum);
        prop.setProperty(OpcenterMESLVOutbound._PROPS_BATCH_POTENCY, batchPotency);
        prop.setProperty(OpcenterMESLVOutbound._PROPS_LIMS_RELEASE_DATE, transactionDateTime);

        try {
            getActionProcessor().processAction(OpcenterMESLVOutbound.ID, OpcenterMESLVOutbound.VERSIONID, prop);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00011, OpcenterMESLVOutbound.ID)));
        }
        if (__PROP_LOG_DIAG_SWITCH) {
            MESUtil.calculateElapsedTime(logger,processingStartTime, ID, "processAction");
    }

    }

}
