package labvantage.custom.alcon.mes.action;

import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SafeSQL;
import sapphire.xml.PropertyList;

import static labvantage.custom.alcon.mes.util.MESUtil.getFormattedJSON;

public class MESResponse extends BaseAction {

    public static final String DEVOPS_ID = "$Revision: 209 $";
    public static final String ID = "MESResponse";
    public static final String VERSIONID = "1";
    public static final String _PROPS_SERVICE_NAME = "servicename";
    public static final String _PROPS_RESULT_DATA = "data";
    public static final String _PROPS_MSG_DATE = "pushdt";
    public static final String _PROPS_STATUS = "status";
    public static final String _PROPS_SERVICE_STATUS = "servicestatus";
    public static final String _PROPS_RES_CODE = "responsecode";
    public static final String _PROPS_RES_MSG = "responsemessage";
    public static final String _PROPS_RES_STATUS = "responsestatus";

    public static final String SDC_ID = "TestMESIntfTrans";

    /**
     * Description: processAction is an OOB LabVantage method. This is the main method where execution starts.
     *
     * @param properties
     * @throws SapphireException
     */
    @Override
    public void processAction(PropertyList properties) throws SapphireException {
        String serviceName = properties.getProperty(_PROPS_SERVICE_NAME, "");
        String resultData = properties.getProperty(_PROPS_RESULT_DATA, "");
        String pushDate = properties.getProperty(_PROPS_MSG_DATE, "");
        // Todo Mandatory check
        SafeSQL safeSQL = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append("SELECT servicename,servicestatus,responsecode, responsestatus, responsemessage FROM u_mestest ");
        // ************** Using SafeSQL--> addVar to use as bind variable ***************
        strSQL.append("WHERE servicename = ").append(safeSQL.addVar(serviceName));
        // ************** Using SafeSQL--> getValues to replace bind variable with values  ***************
        DataSet dsResponseSetting = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (dsResponseSetting == null) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.GENERAL_ERR_00002));

        }


        if (dsResponseSetting.getValue(0, _PROPS_SERVICE_STATUS, "").equalsIgnoreCase("OFFLINE")) {
            properties.setProperty(_PROPS_RES_CODE, dsResponseSetting.getValue(0, _PROPS_RES_CODE, ""));
            properties.setProperty(_PROPS_RES_STATUS, "ERROR");
            properties.setProperty(_PROPS_RES_MSG, dsResponseSetting.getValue(0, _PROPS_RES_MSG, ""));

        } else {
            if (!dsResponseSetting.getValue(0, _PROPS_RES_STATUS, "").equalsIgnoreCase("FAILURE")) {
                populateTestMESIntfTrans(serviceName, resultData, pushDate);
            }
            //throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.MESRESPONSE_ERR_00002));
            properties.setProperty(_PROPS_RES_CODE, dsResponseSetting.getValue(0, _PROPS_RES_CODE, ""));
            properties.setProperty(_PROPS_RES_STATUS, "FAILURE".equalsIgnoreCase(dsResponseSetting.getValue(0, _PROPS_RES_STATUS, "")) ? "ERROR" : dsResponseSetting.getValue(0, _PROPS_RES_STATUS, ""));
            properties.setProperty(_PROPS_RES_MSG, dsResponseSetting.getValue(0, _PROPS_RES_MSG, ""));
        }

    }

    public void populateTestMESIntfTrans(String serviceName, String resultData, String pushDate) throws SapphireException {

        //serviceName = "BATCH_POTENCY";
        //resultData = MESUtil.getFormattedJSON("{\"SERVICE_NAME\":\"BATCH_POTENCY\",\"SITE\":\"U630\",\"PAYLOAD\":{\"LIMS_RELEASE_DATE\":\"20220919_083829\",\"TRANSACTIONDATETIME\":\"20220919_083829\",\"SAP_MATERIAL_NUMBER\":\"PTest\",\"SAP_BATCH_NUMBER\":\"C0001\",\"BATCH_POTENCY\":\"10.2\",\"VENDOR_BATCH_NUMBER\":\"VendorBatch1\",\"TRANSACTIONID\":\"MIT00000169\"}}");
        // status = "SUCCESS";
        PropertyList plTestMESIntfTrans = new PropertyList();
        plTestMESIntfTrans.setProperty(AddSDI.PROPERTY_SDCID, SDC_ID);
        plTestMESIntfTrans.setProperty(_PROPS_SERVICE_NAME, serviceName);
        plTestMESIntfTrans.setProperty(_PROPS_RESULT_DATA, getFormattedJSON(resultData));
        plTestMESIntfTrans.setProperty(_PROPS_MSG_DATE, pushDate);
        plTestMESIntfTrans.setProperty(_PROPS_STATUS, "SUCCESS");

        try {
            getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plTestMESIntfTrans);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, "Aborting transaction. Failed to execute AddSDI. Error is - " + ex.getMessage());
        }
    }
}
