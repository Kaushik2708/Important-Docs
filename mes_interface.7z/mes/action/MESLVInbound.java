package labvantage.custom.alcon.mes.action;
/**
 * $Author: SAHAPI1 $
 * $Date: 2022-12-15 20:24:47 +0530 (Thu, 15 Dec 2022) $
 * $Revision: 404 $
 */

import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import org.json.JSONException;
import org.json.JSONObject;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.xml.PropertyList;

import java.util.LinkedHashMap;
import java.util.Map;

/********************************************************************************************************
 * $Revision: 404 $
 * Description: This is an entry class, which will be triggered first from Postman.
 * This class is used to process different type of services sent by MES.
 * ********************************************************************************************************/
public class MESLVInbound extends BaseAction {
public static final String DEVOPS_ID = "$Revision: 404 $";
public static final String ID = "MESLVInbound";
public static final String VERSIONID = "1";

private static final String PROP_PAY_LOAD = "PAYLOAD";
private static final String PROP_SERVICE_NAME = "SERVICE_NAME";
private static final String PROP_SITE = "SITE";
private static final String PROP_MES_SAMPLE_ID = "MES_SAMPLE_ID";
private static final String PROP_SAP_BATCH_NUM = "SAP_BATCH_NUMBER";
private static final String PROP_SAP_MATERIAL_NUM = "SAP_MATERIAL_NUMBER";

private static final String PROP_MESSAGE = "MESSAGE";
private static final String PROP_MSGTYPE = "MSGTYPE";
private static final String MSG_SUCCESS = "SUCCESS";

private static final String SERVICE_NAME = "servicename";
private static final String SITE = "plant";

//JSON properties
private static final String _PROPS_SERVICE_NAME = "SERVICE_NAME";
private static final String _PROPS_SITE = "SITE";
private static final String _PROPS_TRANSIONID = "TRANSACTIONID";
private static final String _PROPS_TRANSIONDATETIME = "TRANSACTIONDATETIME";
private static final String _PROPS_SAP_BATCH_NUMBER = "SAP_BATCH_NUMBER";
private static final String _PROPS_SAP_MATERIAL_NUMBER = "SAP_MATERIAL_NUMBER";
private static final String _PROPS_SAMPLE_DELIVERY_TYPE = "SAMPLE_DELIVERY_TYPE";
private static final String _PROPS_MES_SAMPLE_ID = "MES_SAMPLE_ID";
private static final String _PROPS_STAGE_NAME = "STAGE_NAME";
private static final String _PROPS_CONTAINER_QTY = "CONTAINER_QTY";
private static final String _PROPS_DELIVERY_DATETIME = "DELIVERY_DATETIME";
private static final String _PROPS_EQUIPMENT_ID = "EQUIPMENT_ID";
private static final String _PROPS_SAMPLER_EMPLOYEE_NUMBER_1_2 = "SAMPLER_EMPLOYEE_NUMBER_1_2";
private static final String _PROPS_SAMPLER_EMPLOYEE_NUMBER_3_4 = "SAMPLER_EMPLOYEE_NUMBER_3_4";
private static final String _PROPS_SETTLING_PLATE1_EXPOSURE_TIME = "SETTLING_PLATE1_EXPOSURE_TIME";
private static final String _PROPS_SETTLING_PLATE2_EXPOSURE_TIME = "SETTLING_PLATE2_EXPOSURE_TIME";
private static final String __PROP_PAYLOAD = "PAYLOAD";
private static final String _PROPS_PARAMLIST_ID = "PARAMLIST_ID";
private static final String _PROPS_PARAMLIST_VERSION = "PARAMLIST_VERSION";
private static final String _PROPS_PARAMLIST_VARIANT = "PARAMLIST_VARIANT";
private static final String _PROPS_PARAMLIST_DATASET = "PARAMLIST_DATASET";
private static final String _PROPS_PULL_DATE_TIME = "PULL_DATE_TIME";
private static final String _PROPS_ACTUAL_UNITS_PULLED = "ACTUAL_UNITS_PULLED";
private static final String _PROPS_AR_SAMPLE_DESCRIPTION = "AR_SAMPLE_DESCRIPTION";
private static final String _PROPS_AR_SAMPLE_TEMPLATE = "AR_SAMPLE_TEMPLATE";
private static final String _PROPS_RETAIN_STAGE_NAME = "RETAIN_STAGE_NAME";
private static final String _PROPS_RETAIN_MES_SAMPLE_ID = "RETAIN_MES_SAMPLE_ID";
private static final String _PROPS_ORIENTATION = "ORIENTATION";
private static final String _PROPS_RETAIN_INSPECTION_RESULT = "RETAIN_INSPECTION_RESULT";
private static final String _PROPS_RETAIN_CONTAINERS_INSPECTED = "RETAIN_CONTAINERS_INSPECTED";
private static final String _PROPS_RETENTION_STORAGE_LOCATION = "RETENTION_STORAGE_LOCATION";
private static final String _PROPS_RETAIN_STORAGE_LOCATION_ID = "RETAIN_STORAGE_LOCATION_ID";
private static final String _PROPS_RETAIN_CONTAINER_QTY = "RETAIN_CONTAINER_QTY";
private static final String _PROPS_INSPECTION_STAGE_NAME = "INSPECTION_STAGE_NAME";
private static final String _PROPS_INSPECTION_MES_SAMPLE_ID = "INSPECTION_MES_SAMPLE_ID";
private static final String _PROPS_INSPECTION_RESULT = "INSPECTION_RESULT";

private static final String TRANSTYPE = "transtype";
private static final String TRANSDIRECTION = "transdirection";
private static final String MSGPAYLOAD = "msgpayload";
private static final String STATUS = "status";
private static final String STATUS_SUCCESS = "SUCCESS";
private static final String LIMSBATCHID = "limsbatchid";
private static final String MESSAMPLENUMBER = "messamplenumber";
private static final String SAPBATCHNUMBER = "sapbatchnumber";
private static final String SAPMATERIALNUMBER = "sapmaterialnumber";
private static final String LIMSAMPLEID = "limssampleid";

private static final String ITEMDATA = "itemdata";
private static final String MESINTFTRANSID = "mesintftransid";

private static final String SDC_ID_TRANS = "mesintftrans";
private static final String SDC_ID_TRANSITEM = "mesintftransitem";
private static final String __PROP_INBOUND_TRANSACTION_DIRECTION = "INBOUND";
private static final String __PROP_INBOUND_TRANSACTION_TYPE = "WEB_SERVICE";
private static final String __BLANK_STRING = "";
private static final String __PROPS_PROCESS_DONE_SERVER = "processdoneserver";
private static final String __PROPS_SERVICE_SEND_SAMPLE_TO_LIMS = "alcSendSamplesToLIMS";
private static final String __PROPS_SERVICE_SEND_STABILITY_SAMPLE_TO_LIMS = "alcSendStabilitySamplesToLIMS";
private static final String __PROPS_SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS = "alcSendEquipMonitorSamplesToLIMS";
private static final String __PROPS_SERVICE_SEND_RETENTION_SAMPLE_TO_LIMS = "alcSendRetentionSamplesToLIMS";
private static final String __PROPS_SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS = "alcSendInspectionSamplesToLIMS";

/**************************************************************
 * Description: This is the main method where execution starts.
 * @param properties Property List of properties.
 * @throws SapphireException OOB Sapphire exceptions.
 **************************************************************/
@Override
public void processAction(PropertyList properties) throws SapphireException {
    logger.info("--------- Processing Action:" + ID + ", Version:" + VERSIONID + "---------");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String mesSampleId = populateMESTransTable(properties);
    properties.setProperty(PROP_MSGTYPE, MSG_SUCCESS);
    properties.setProperty(PROP_MESSAGE, "Payload information for Sample [" + mesSampleId + "] is registered in LIMS.");
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, properties.getProperty(PROP_SERVICE_NAME, ""), "MESLVInbound-processAction");
}


/***************************************************************************************
 * This Method is to get SendSampleToLIMS JSON String according to the given JSON structure.
 * @param properties List of properties to be passed from LIMS to MES as JSON Payload.
 * @return JSONString Payload as JSON String
 * @throws SapphireException OOB Sapphire Exception.
 ***************************************************************************************/
private String getJSONStringForSendSamplesToLIMS(PropertyList properties, String serviceName, String site) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String transactionId = properties.getProperty(_PROPS_TRANSIONID, "");
    String transactionDateTime = properties.getProperty(_PROPS_TRANSIONDATETIME, "");
    String SAPBatchNumber = properties.getProperty(_PROPS_SAP_BATCH_NUMBER, "");
    String SAPMaterialNumber = properties.getProperty(_PROPS_SAP_MATERIAL_NUMBER, "");
    String sampleDeliveryType = properties.getProperty(_PROPS_SAMPLE_DELIVERY_TYPE, "");
    String mesSampleId = properties.getProperty(_PROPS_MES_SAMPLE_ID, "");
    String stageName = properties.getProperty(_PROPS_STAGE_NAME, "");
    String containerQty = properties.getProperty(_PROPS_CONTAINER_QTY, "");
    String deliveryDateTime = properties.getProperty(_PROPS_DELIVERY_DATETIME, "");
    String equipmentId = properties.getProperty(_PROPS_EQUIPMENT_ID, "");
    String sampler12 = properties.getProperty(_PROPS_SAMPLER_EMPLOYEE_NUMBER_1_2, "");
    String sampler34 = properties.getProperty(_PROPS_SAMPLER_EMPLOYEE_NUMBER_3_4, "");
    String plate1 = properties.getProperty(_PROPS_SETTLING_PLATE1_EXPOSURE_TIME, "");
    String plate2 = properties.getProperty(_PROPS_SETTLING_PLATE2_EXPOSURE_TIME, "");

    LinkedHashMap<String, String> lhmJSONString = new LinkedHashMap<>();
    lhmJSONString.put(_PROPS_SERVICE_NAME, serviceName);
    lhmJSONString.put(_PROPS_SITE, site);
    LinkedHashMap<String, String> lhmPayload = new LinkedHashMap<>();
    lhmPayload.put(_PROPS_TRANSIONID, transactionId);
    lhmPayload.put(_PROPS_TRANSIONDATETIME, transactionDateTime);
    lhmPayload.put(_PROPS_SAP_BATCH_NUMBER, SAPBatchNumber);
    lhmPayload.put(_PROPS_SAP_MATERIAL_NUMBER, SAPMaterialNumber);
    lhmPayload.put(_PROPS_SAMPLE_DELIVERY_TYPE, sampleDeliveryType);
    lhmPayload.put(_PROPS_MES_SAMPLE_ID, mesSampleId);
    lhmPayload.put(_PROPS_STAGE_NAME, stageName);
    lhmPayload.put(_PROPS_CONTAINER_QTY, containerQty);
    lhmPayload.put(_PROPS_DELIVERY_DATETIME, deliveryDateTime);
    lhmPayload.put(_PROPS_EQUIPMENT_ID, equipmentId);
    lhmPayload.put(_PROPS_SAMPLER_EMPLOYEE_NUMBER_1_2, sampler12);
    lhmPayload.put(_PROPS_SAMPLER_EMPLOYEE_NUMBER_3_4, sampler34);
    lhmPayload.put(_PROPS_SETTLING_PLATE1_EXPOSURE_TIME, plate1);
    lhmPayload.put(_PROPS_SETTLING_PLATE2_EXPOSURE_TIME, plate2);
    lhmJSONString.put(__PROP_PAYLOAD, toJSONString(lhmPayload));
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, __PROPS_SERVICE_SEND_SAMPLE_TO_LIMS, "MESLVInbound-getJSONStringForSendSamplesToLIMS");
    return toJSONString(lhmJSONString);
}

/***************************************************************************************
 * This Method is to get SendStabilitySampleToLIMS JSON String according to the given JSON structure.
 * @param properties List of properties to be passed from LIMS to MES as JSON Payload.
 * @return JSONString Payload as JSON String
 * @throws SapphireException OOB Sapphire Exception.
 ***************************************************************************************/
private String getJSONStringForSendStabilitySamplesToLIMS(PropertyList properties, String serviceName, String site) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String transactionId = properties.getProperty(_PROPS_TRANSIONID, "");
    String transactionDateTime = properties.getProperty(_PROPS_TRANSIONDATETIME, "");
    String SAPBatchNumber = properties.getProperty(_PROPS_SAP_BATCH_NUMBER, "");
    String SAPMaterialNumber = properties.getProperty(_PROPS_SAP_MATERIAL_NUMBER, "");
    String mesSampleId = properties.getProperty(_PROPS_MES_SAMPLE_ID, "");
    String stageName = properties.getProperty(_PROPS_STAGE_NAME, "");
    String paramListId = properties.getProperty(_PROPS_PARAMLIST_ID, "");
    String paramListVersion = properties.getProperty(_PROPS_PARAMLIST_VERSION, "");
    String paramListVariant = properties.getProperty(_PROPS_PARAMLIST_VARIANT, "");
    String paramListDataSet = properties.getProperty(_PROPS_PARAMLIST_DATASET, "");
    String pullDateTime = properties.getProperty(_PROPS_PULL_DATE_TIME, "");
    String actualUnitsPulled = properties.getProperty(_PROPS_ACTUAL_UNITS_PULLED, "");

    LinkedHashMap<String, String> lhmJSONString = new LinkedHashMap<>();
    lhmJSONString.put(_PROPS_SERVICE_NAME, serviceName);
    lhmJSONString.put(_PROPS_SITE, site);
    LinkedHashMap<String, String> lhmPayload = new LinkedHashMap<>();
    lhmPayload.put(_PROPS_TRANSIONID, transactionId);
    lhmPayload.put(_PROPS_TRANSIONDATETIME, transactionDateTime);
    lhmPayload.put(_PROPS_SAP_BATCH_NUMBER, SAPBatchNumber);
    lhmPayload.put(_PROPS_SAP_MATERIAL_NUMBER, SAPMaterialNumber);
    lhmPayload.put(_PROPS_STAGE_NAME, stageName);
    lhmPayload.put(_PROPS_MES_SAMPLE_ID, mesSampleId);
    lhmPayload.put(_PROPS_PARAMLIST_ID, paramListId);
    lhmPayload.put(_PROPS_PARAMLIST_VERSION, paramListVersion);
    lhmPayload.put(_PROPS_PARAMLIST_VARIANT, paramListVariant);
    lhmPayload.put(_PROPS_PARAMLIST_DATASET, paramListDataSet);
    lhmPayload.put(_PROPS_PULL_DATE_TIME, pullDateTime);
    lhmPayload.put(_PROPS_ACTUAL_UNITS_PULLED, actualUnitsPulled);
    lhmJSONString.put(__PROP_PAYLOAD, toJSONString(lhmPayload));
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, __PROPS_SERVICE_SEND_STABILITY_SAMPLE_TO_LIMS, "MESLVInbound-getJSONStringForSendStabilitySamplesToLIMS");
    return toJSONString(lhmJSONString);
}

/***************************************************************************************
 * This Method is to get SendEquipmentSampleToLIMS JSON String according to the given JSON structure.
 * @param properties List of properties to be passed from LIMS to MES as JSON Payload.
 * @return JSONString Payload as JSON String
 * @throws SapphireException OOB Sapphire Exception.
 ***************************************************************************************/
private String getJSONStringForSendEquipMonitorSamplesToLIMS(PropertyList properties, String serviceName, String site) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String transactionId = properties.getProperty(_PROPS_TRANSIONID, "");
    String transactionDateTime = properties.getProperty(_PROPS_TRANSIONDATETIME, "");
    String mesSampleId = properties.getProperty(_PROPS_MES_SAMPLE_ID, "");
    String aRSampleDescription = properties.getProperty(_PROPS_AR_SAMPLE_DESCRIPTION, "");
    String aRSampleTemplate = properties.getProperty(_PROPS_AR_SAMPLE_TEMPLATE, "");
    String containerQty = properties.getProperty(_PROPS_CONTAINER_QTY, "");

    LinkedHashMap<String, String> lhmJSONString = new LinkedHashMap<>();
    lhmJSONString.put(_PROPS_SERVICE_NAME, serviceName);
    lhmJSONString.put(_PROPS_SITE, site);
    LinkedHashMap<String, String> lhmPayload = new LinkedHashMap<>();
    lhmPayload.put(_PROPS_TRANSIONID, transactionId);
    lhmPayload.put(_PROPS_TRANSIONDATETIME, transactionDateTime);
    lhmPayload.put(_PROPS_AR_SAMPLE_DESCRIPTION, aRSampleDescription);
    lhmPayload.put(_PROPS_AR_SAMPLE_TEMPLATE, aRSampleTemplate);
    lhmPayload.put(_PROPS_MES_SAMPLE_ID, mesSampleId);
    lhmPayload.put(_PROPS_CONTAINER_QTY, containerQty);
    lhmJSONString.put(__PROP_PAYLOAD, toJSONString(lhmPayload));
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, __PROPS_SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS, "MESLVInbound-getJSONStringForSendEquipMonitorSamplesToLIMS");
    return toJSONString(lhmJSONString);
}

/***************************************************************************************
 * This Method is to get SendRetentionSampleToLIMS JSON String according to the given JSON structure.
 * @param properties List of properties to be passed from LIMS to MES as JSON Payload.
 * @return JSONString Payload as JSON String
 * @throws SapphireException OOB Sapphire Exception.
 ***************************************************************************************/
private String getJSONStringForSendRetentionSamplesToLIMS(PropertyList properties, String serviceName, String site) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String transactionId = properties.getProperty(_PROPS_TRANSIONID, "");
    String transactionDateTime = properties.getProperty(_PROPS_TRANSIONDATETIME, "");
    String sapBatchNumber = properties.getProperty(_PROPS_SAP_BATCH_NUMBER, "");
    String sapMaterialNumber = properties.getProperty(_PROPS_SAP_MATERIAL_NUMBER, "");
    String retainStageName = properties.getProperty(_PROPS_RETAIN_STAGE_NAME, "");
    String retainMesSampleId = properties.getProperty(_PROPS_RETAIN_MES_SAMPLE_ID, "");
    String orientation = properties.getProperty(_PROPS_ORIENTATION, "");
    String retainInspectionResult = properties.getProperty(_PROPS_RETAIN_INSPECTION_RESULT, "");
    String retainContainersInspected = properties.getProperty(_PROPS_RETAIN_CONTAINERS_INSPECTED, "");
    String retentionStorageLocation = properties.getProperty(_PROPS_RETENTION_STORAGE_LOCATION, "");
    String retainStorageLocationId = properties.getProperty(_PROPS_RETAIN_STORAGE_LOCATION_ID, "");
    String retainContainerQty = properties.getProperty(_PROPS_RETAIN_CONTAINER_QTY, "");

    LinkedHashMap<String, String> lhmJSONString = new LinkedHashMap<>();
    lhmJSONString.put(_PROPS_SERVICE_NAME, serviceName);
    lhmJSONString.put(_PROPS_SITE, site);
    LinkedHashMap<String, String> lhmPayload = new LinkedHashMap<>();
    lhmPayload.put(_PROPS_TRANSIONID, transactionId);
    lhmPayload.put(_PROPS_TRANSIONDATETIME, transactionDateTime);
    lhmPayload.put(_PROPS_SAP_BATCH_NUMBER, sapBatchNumber);
    lhmPayload.put(_PROPS_SAP_MATERIAL_NUMBER, sapMaterialNumber);
    lhmPayload.put(_PROPS_RETAIN_STAGE_NAME, retainStageName);
    lhmPayload.put(_PROPS_RETAIN_MES_SAMPLE_ID, retainMesSampleId);
    lhmPayload.put(_PROPS_ORIENTATION, orientation);
    lhmPayload.put(_PROPS_RETAIN_INSPECTION_RESULT, retainInspectionResult);
    lhmPayload.put(_PROPS_RETAIN_CONTAINERS_INSPECTED, retainContainersInspected);
    lhmPayload.put(_PROPS_RETENTION_STORAGE_LOCATION, retentionStorageLocation);
    lhmPayload.put(_PROPS_RETAIN_STORAGE_LOCATION_ID, retainStorageLocationId);
    lhmPayload.put(_PROPS_RETAIN_CONTAINER_QTY, retainContainerQty);
    lhmJSONString.put(__PROP_PAYLOAD, toJSONString(lhmPayload));
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, __PROPS_SERVICE_SEND_RETENTION_SAMPLE_TO_LIMS, "MESLVInbound-getJSONStringForSendRetentionSamplesToLIMS");
    return toJSONString(lhmJSONString);
}

/***************************************************************************************
 * This Method is to get SendInspectionSampleToLIMS JSON String according to the given JSON structure.
 * @param properties List of properties to be passed from LIMS to MES as JSON Payload.
 * @return JSONString Payload as JSON String
 * @throws SapphireException OOB Sapphire Exception.
 ***************************************************************************************/
private String getJSONStringForSendInspectionSamplesToLIMS(PropertyList properties, String serviceName, String site) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String transactionId = properties.getProperty(_PROPS_TRANSIONID, "");
    String transactionDateTime = properties.getProperty(_PROPS_TRANSIONDATETIME, "");
    String sapBatchNumber = properties.getProperty(_PROPS_SAP_BATCH_NUMBER, "");
    String sapMaterialNumber = properties.getProperty(_PROPS_SAP_MATERIAL_NUMBER, "");
    String inspectionStageName = properties.getProperty(_PROPS_INSPECTION_STAGE_NAME, "");
    String inspectionMesSampleId = properties.getProperty(_PROPS_INSPECTION_MES_SAMPLE_ID, "");
    String inspectionResult = properties.getProperty(_PROPS_INSPECTION_RESULT, "");

    LinkedHashMap<String, String> lhmJSONString = new LinkedHashMap<>();
    lhmJSONString.put(_PROPS_SERVICE_NAME, serviceName);
    lhmJSONString.put(_PROPS_SITE, site);
    LinkedHashMap<String, String> lhmPayload = new LinkedHashMap<>();
    lhmPayload.put(_PROPS_TRANSIONID, transactionId);
    lhmPayload.put(_PROPS_TRANSIONDATETIME, transactionDateTime);
    lhmPayload.put(_PROPS_SAP_BATCH_NUMBER, sapBatchNumber);
    lhmPayload.put(_PROPS_SAP_MATERIAL_NUMBER, sapMaterialNumber);
    lhmPayload.put(_PROPS_INSPECTION_STAGE_NAME, inspectionStageName);
    lhmPayload.put(_PROPS_INSPECTION_MES_SAMPLE_ID, inspectionMesSampleId);
    lhmPayload.put(_PROPS_INSPECTION_RESULT, inspectionResult);
    lhmJSONString.put(__PROP_PAYLOAD, toJSONString(lhmPayload));
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, __PROPS_SERVICE_SEND_RETENTION_SAMPLE_TO_LIMS, "MESLVInbound-getJSONStringForSendInspectionSamplesToLIMS");
    return toJSONString(lhmJSONString);
}


/***************************************************************************************
 * This Method is to get BLANK Services JSON String according to the given JSON structure.
 * @param properties List of properties to be passed from LIMS to MES as JSON Payload.
 * @return JSONString Payload as JSON String
 * @throws SapphireException OOB Sapphire Exception.
 ***************************************************************************************/
private String getJsonForOthers(PropertyList properties, String serviceName, String site) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();

    LinkedHashMap<String, String> lhmJSONString = new LinkedHashMap<>();
    lhmJSONString.put(_PROPS_SERVICE_NAME, serviceName);
    lhmJSONString.put(_PROPS_SITE, site);
    lhmJSONString.put(__PROP_PAYLOAD, properties.getProperty(__PROP_PAYLOAD));
    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, properties.getProperty(PROP_SERVICE_NAME, ""), "MESLVInbound-getJsonForOthers");
    return toJSONString(lhmJSONString);
}


/*************************************************************
 * This method is to create a JSON String from a LinkedHashMap
 * @param map Properties as Key: Value pair.
 * @return JSON String
 * @throws SapphireException OOB Sapphire Exception.
 *************************************************************/
private String toJSONString(LinkedHashMap<String, String> map) throws SapphireException {
    LinkedHashMap lhmap = new LinkedHashMap<>();
    try {
        for (Map.Entry<String, String> item : map.entrySet()) {
            if ((item.getValue() != null && !__BLANK_STRING.equalsIgnoreCase(item.getValue())) && item.getValue().charAt(0) == '{')
                lhmap.put("\"" + item.getKey() + "\"", item.getValue());
            else {
                if (!__BLANK_STRING.equalsIgnoreCase(item.getValue())) {
                    lhmap.put("\"" + item.getKey() + "\"", "\"" + item.getValue() + "\"");
                } else {
                    lhmap.put("\"" + item.getKey() + "\"", "\"" + "" + "\"");
                }
            }
        }
    } catch (Exception ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, MESErrorMessageUtil.GENERAL_ERR_00015 + "\n" + ex.getMessage());
    }
    return lhmap.toString().replaceAll("=", ": ");
}

/*************************************************************
 * This method is to create a Transaction in MESIntfTrans and MESIntftransItem table
 * @param properties
 * @throws SapphireException OOB Sapphire Exception.
 *************************************************************/
private String populateMESTransTable(PropertyList properties) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String transactionId = "", mesSampleId = "", sapBatchNum = "", sapMaterialNum = "";
    String transactionItemId = "";
    String formattedJSONpayload = "";
    String serviceName = properties.getProperty(PROP_SERVICE_NAME, "");
    String site = properties.getProperty(PROP_SITE, "");
    String payload = properties.getProperty(PROP_PAY_LOAD, "");
    PropertyList plJson;
    try {
        JSONObject jsPayload = new JSONObject(payload);
        plJson = new PropertyList(jsPayload);
    } catch (JSONException e) {
        throw new SapphireException(e);
    }
    mesSampleId = plJson.getProperty(PROP_MES_SAMPLE_ID, "");
    sapBatchNum = plJson.getProperty(PROP_SAP_BATCH_NUM, "");
    sapMaterialNum = plJson.getProperty(PROP_SAP_MATERIAL_NUM, "");
    // ************* Creating JSON string ***************
    if (__PROPS_SERVICE_SEND_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        String JSONString = getJSONStringForSendSamplesToLIMS(plJson, serviceName, site);
        formattedJSONpayload = MESUtil.getFormattedJSON(JSONString);
    } else if (__PROPS_SERVICE_SEND_STABILITY_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        String JSONString = getJSONStringForSendStabilitySamplesToLIMS(plJson, serviceName, site);
        formattedJSONpayload = MESUtil.getFormattedJSON(JSONString);
    } else if (__PROPS_SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        String JSONString = getJSONStringForSendEquipMonitorSamplesToLIMS(plJson, serviceName, site);
        formattedJSONpayload = MESUtil.getFormattedJSON(JSONString);
    } else if (__PROPS_SERVICE_SEND_RETENTION_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        String JSONString = getJSONStringForSendRetentionSamplesToLIMS(plJson, serviceName, site);
        formattedJSONpayload = MESUtil.getFormattedJSON(JSONString);
        mesSampleId = plJson.getProperty(_PROPS_RETAIN_MES_SAMPLE_ID, "");
    } else if (__PROPS_SERVICE_SEND_INSPECTION_SAMPLE_TO_LIMS.equalsIgnoreCase(serviceName)) {
        String JSONString = getJSONStringForSendInspectionSamplesToLIMS(plJson, serviceName, site);
        formattedJSONpayload = MESUtil.getFormattedJSON(JSONString);
        mesSampleId = plJson.getProperty(_PROPS_INSPECTION_MES_SAMPLE_ID, "");
    } else {
        String JSONString = getJsonForOthers(properties, serviceName, site);
        formattedJSONpayload = MESUtil.getFormattedJSON(JSONString);
    }

    PropertyList plMESIntfTransData = new PropertyList();
    try {
        /* Insert into MESINTFTRANS sdc */
        plMESIntfTransData.setProperty(AddSDI.PROPERTY_SDCID, SDC_ID_TRANS);
        plMESIntfTransData.setProperty(SERVICE_NAME, serviceName);
        plMESIntfTransData.setProperty(SITE, site);
        plMESIntfTransData.setProperty(MSGPAYLOAD, formattedJSONpayload);
        plMESIntfTransData.setProperty(SAPBATCHNUMBER, sapBatchNum);
        plMESIntfTransData.setProperty(SAPMATERIALNUMBER, sapMaterialNum);
        plMESIntfTransData.setProperty(MESSAMPLENUMBER, mesSampleId);
        plMESIntfTransData.setProperty(TRANSDIRECTION, __PROP_INBOUND_TRANSACTION_DIRECTION);
        plMESIntfTransData.setProperty(TRANSTYPE, __PROP_INBOUND_TRANSACTION_TYPE);
        plMESIntfTransData.setProperty(STATUS, STATUS_SUCCESS);
        plMESIntfTransData.setProperty(__PROPS_PROCESS_DONE_SERVER, MESUtil.getServerDetails());

        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plMESIntfTransData, true);
    } catch (SapphireException ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, MESErrorMessageUtil.GENERAL_ERR_00010 + "\n" + ex.getMessage());
    } catch (Exception e) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, MESErrorMessageUtil.GENERAL_ERR_00010 + "\n" + e.getMessage());
    }
    transactionId = plMESIntfTransData.getProperty(AddSDI.RETURN_NEWKEYID1, "");



    /* Insert into MESINTFTRANSITEM sdc */
    plMESIntfTransData.clear();
    plMESIntfTransData.setProperty(AddSDI.PROPERTY_SDCID, SDC_ID_TRANSITEM);
    plMESIntfTransData.setProperty(SERVICE_NAME, serviceName);
    plMESIntfTransData.setProperty(SITE, site);
    plMESIntfTransData.setProperty(ITEMDATA, formattedJSONpayload);
    plMESIntfTransData.setProperty(SAPBATCHNUMBER, sapBatchNum);
    plMESIntfTransData.setProperty(SAPMATERIALNUMBER, sapMaterialNum);
    plMESIntfTransData.setProperty(MESSAMPLENUMBER, mesSampleId);
    plMESIntfTransData.setProperty(MESINTFTRANSID, transactionId);
    plMESIntfTransData.setProperty(LIMSBATCHID, "");
    plMESIntfTransData.setProperty(LIMSAMPLEID, "");
    plMESIntfTransData.setProperty(STATUS, STATUS_SUCCESS);
    try {
        //Reason for new Transaction::  In a multiple Sample payload scenario, if one sample is errored out, other samples must not get rolled back.
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plMESIntfTransData, true);
    } catch (SapphireException ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, MESErrorMessageUtil.GENERAL_ERR_00010 + "\n" + ex.getMessage());
    }
    transactionItemId = plMESIntfTransData.getProperty(AddSDI.RETURN_NEWKEYID1, "");

    MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, serviceName, "MESLVInbound-populateMESTransTable");
    return mesSampleId;
}
}
