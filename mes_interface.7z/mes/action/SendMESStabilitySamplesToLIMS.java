package labvantage.custom.alcon.mes.action;
/**
 * $Author: SAHAPI1 $
 * $Date: 2022-12-17 01:22:18 +0530 (Sat, 17 Dec 2022) $
 * $Revision: 415 $
 */

import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import sapphire.SapphireException;
import sapphire.action.BaseAction;
import sapphire.action.UnReleaseDataItem;
import sapphire.action.ReleaseDataItem;
import sapphire.action.EnterDataItem;
import sapphire.action.SyncSDIDataSetStatus;
import sapphire.action.UpdateDatasetStatus;
import sapphire.action.SyncSDIWIStatus;
import sapphire.action.EditSDI;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SafeSQL;
import sapphire.xml.PropertyList;

import java.util.HashMap;


/********************************************************************************************************
 * $Revision: 415 $
 * Description: All necessary activities needed for Send Stability Samples to LIMS Service
 *
 ********************************************************************************************************/

public class SendMESStabilitySamplesToLIMS extends BaseAction {
public static final String DEVOPS_ID = "$Revision: 415 $";
public static final String ID = "SendMESStabilitySamplesToLIMS";
public static final String VERSIONID = "1";

private static final String __PROP_LIMS_BATCH_ID = "s_batchid";
private static final String __PROP_LIMS_BATCH_STATUS = "batchstatus";
private static final String __PROP_BATCH_STATUS_CANCELLED = "Cancelled";
private static final String __PROP_BATCH_STATUS_REJECTED = "Rejected";
private static final String __PROP_BATCH_STATUS_INITIAL = "Initial";

private static final String __PROP_PROCESSSTAGE_LABEL = "label";
private static final String __PROP_BATCHSTAGEID = "s_batchstageid";
private static final String __PROP_BATCHSTAGE_STATUS = "batchstagestatus";
private static final String __PROP_BATCHSTAGE_STATUS_CANCELLED = "Cancelled";
private static final String __PROP_LIMS_SAMPLE_ID = "s_sampleid";
private static final String __PROP_SAMPLE_STATUS = "samplestatus";
private static final String __PROP_MES_SAMPLE_ID = "messampleid";
private static final String __PROP_BLANK_MES_SAMPLEID = "BLANK";
private static final String __PROP_MES_BATCH_FLAG_YES = "Y";

private static final String __PROP_SAMPLE_CREATE_DATE = "createdt";
private static final String __PROPS_KEYID1 = "keyid1";
private static final String _PROP_SITE = "plant";

private static final String _PROP_MES_SAMPLE_ID = "MES_SAMPLE_ID";
private static final String _PROP_SAP_BATCH_NUMBER = "SAP_BATCH_NUMBER";
private static final String _PROP_SAP_MATERIAL_NUMBER = "SAP_MATERIAL_NUMBER";
private static final String _PROP_STAGE_NAME = "STAGE_NAME";
private static final String _PROP_PARAMLIST_ID = "PARAMLIST_ID";
private static final String _PROP_PARAMLIST_VERSION = "PARAMLIST_VERSION";
private static final String _PROP_PARAMLIST_VARIANT = "PARAMLIST_VARIANT";
private static final String _PROP_PARAMLIST_DATASET = "PARAMLIST_DATASET";
private static final String _PROP_PULL_DATE_TIME = "PULL_DATE_TIME";
private static final String _PROP_ACTUAL_UNITS_PULLED = "ACTUAL_UNITS_PULLED";

private static final String __PROP_SDC_BATCH = "Batch";
private static final String __PROP_SDC_SAMPLE = "Sample";
private static final String __PROP_COL_MESBATCH_ID = "u_messampleid";
;
private static final String __PROPS_VARIANTID = "variantid";
private static final String __PROPS_LIMS_BATCH_PRODVARIANTID = "prod" + __PROPS_VARIANTID;

// Added for different  sample status
private static final String __PROPS_SAMPLE_STATUS_CANCELLED = "Cancelled";
private static final String __PROPS_SAMPLE_STATUS_REVIEWED = "Reviewed";
private static final String __PROPS_SAMPLE_STATUS_DISPOSED = "Disposed";

private static final String __PROP_IS_MES_BATCH_FLAG = "ismesbatch";
private static final String __PROPS_LIMS_SAMPLE_ID = "limssampleid";
private static final String __PROPS_PARAMLIST_ID = "ParamlistID";
private static final String __PROPS_PARAM_LIST_VERSION = "ParamListVersion";
private static final String __PROPS_VARIANT_ID = "Variant_ID";
private static final String __PROPS_DATASET = "Dataset";
private static final String __PROPS_PARAM_ID = "ParamID";
private static final String __PROPS_PARAM_TYPE = "ParamType";
private static final String __PROPS_REPLICATE = "Replicate";
private static final String __PROPS_RESULT = "Result";
private static final String __PROPS_PARAMLISTID = "paramlistid";
private static final String __PROPS_PARAMLISTVERSIONID = "paramlistversionid";
private static final String __PROPS_DS = "dataset";
private static final String __PROPS_PARAMID = "paramid";
private static final String __PROPS_PARAMTYPE = "paramtype";
private static final String __PROPS_KEYID2 = "keyid2";
private static final String __PROPS_SDCID = "sdcid";
private static final String __PROPS_KEYID3 = "keyid3";
private static final String __PROPS_REPLICATEID = "replicateid";
private static final String __PROPS_LIMS_BATCH_ID = "limsbatchid";
private static final String __PROPS_TRANSITEM_STATUS = "status";
private static final String __PROP_REPROCESSFLAG = "reprocessingflag";
private static final String MES_STATUS_SUCCESS = "SUCCESS";

private static final String _PROP_PARAM_PULL_DATE = "PULL DATE";
private static final String _PROP_PARAM_NUMBER_OF_ACTUAL_UNITS_PULLED = "NUMBER OF ACTUAL UNITS PULLED";

private static final String SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS = "alcSendStabilitySamplesToLIMS";
private boolean __PROP_LOG_DIAG_SWITCH = false;


/**************************************************************
 * Description: This is the main method where execution starts.
 * @param properties Property List of properties.
 * @throws SapphireException OOB Sapphire exceptions.
 **************************************************************/
@Override
public void processAction(PropertyList properties) throws SapphireException {
    logger.info("--------- Processing Action:" + ID + ", Version:" + VERSIONID + "---------");
    __PROP_LOG_DIAG_SWITCH = "ON".equalsIgnoreCase(MESUtil.getLogDiagSwitchValue(getConfigurationProcessor()));
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String sapBatchNumber = properties.getProperty(_PROP_SAP_BATCH_NUMBER);
    String sapMaterialNumber = properties.getProperty(_PROP_SAP_MATERIAL_NUMBER);
    String sapPlant = properties.getProperty(_PROP_SITE);
    String mesStageName = properties.getProperty(_PROP_STAGE_NAME);
    String mesSampleId = properties.getProperty(_PROP_MES_SAMPLE_ID);
    String paramListID = properties.getProperty(_PROP_PARAMLIST_ID);
    String paramListVersion = properties.getProperty(_PROP_PARAMLIST_VERSION);
    String paramListVariant = properties.getProperty(_PROP_PARAMLIST_VARIANT);
    String paramListDataSet = properties.getProperty(_PROP_PARAMLIST_DATASET);
    String pullDateTime = properties.getProperty(_PROP_PULL_DATE_TIME);
    String actualUnitsPulled = properties.getProperty(_PROP_ACTUAL_UNITS_PULLED);
    String reprocessedFlag = properties.getProperty(__PROP_REPROCESSFLAG);

    // **************Below are list of local variables ************
    String limsBatchId = "", limsBatchStatus="";
    String limsSampleId = "", sampleId = "";
    String batchStageId = "";
    PropertyList plFilter = new PropertyList();

    // ************** End of local variable list **************** //
    try {
        // ********** Getting LIMS Batch Details **********
        String[] limsBatchDetails = getExistingLIMSBatch(sapBatchNumber, sapMaterialNumber, sapPlant);
        limsBatchId = limsBatchDetails[0];
        limsBatchStatus = limsBatchDetails[1];

        // ********** Checking if LIMS Batch Id is BLANK ***********
        if ("".equalsIgnoreCase(limsBatchId)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00006));
        }

        //********* Check LIMS Batch is received ********//
        if (__PROP_BATCH_STATUS_INITIAL.equalsIgnoreCase(limsBatchStatus)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00025, limsBatchId)));
        }

        // ********** Check if the MES batch Id is BLANK or NOT If BLANK Update with MES Batch Id **********
        updateBatchByMESId(limsBatchId);

        // ********** Finding Batch Stage id ************
        batchStageId = getBatchStageId(limsBatchId, mesStageName);
        // ********** Find Samples by Batch Stage Id ***********
        DataSet dsSampleDetailsByMESStage = getSamplesByBatchStage(limsBatchId, batchStageId, mesStageName);
        // ********** Checking if matching MES Sample found or not *************
        plFilter.setProperty(__PROP_MES_SAMPLE_ID, mesSampleId);
        DataSet dsSampleByMESSampleId = dsSampleDetailsByMESStage.getFilteredDataSet(plFilter);
        // ************ If Matching MES Sample NOT found *****************
        if (dsSampleByMESSampleId.size() == 0) {
            // ************** Checking if BLANK MES Sample Id found or not **************
            plFilter.clear();
            plFilter.setProperty(__PROP_MES_SAMPLE_ID, __PROP_BLANK_MES_SAMPLEID);
            DataSet dsBLANKMESSampleDetails = dsSampleDetailsByMESStage.getFilteredDataSet(plFilter);
            // ************** Checking if BLANK MES Sample Id NOT found **************
            if (dsBLANKMESSampleDetails.size() == 0) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00001, mesSampleId)));
            }
            // ********** If Matching BLANK MES Sample found **************
            // ********* Checking if more than one  BLANK MES Sample found in Stage *************
            if (dsBLANKMESSampleDetails.size() > 1) {
                // **************** Find the earliest LIMS Sample Id ***************
                dsBLANKMESSampleDetails.sort(__PROP_SAMPLE_CREATE_DATE + ", " + __PROP_LIMS_SAMPLE_ID);
                sampleId = dsBLANKMESSampleDetails.getValue(0, __PROP_LIMS_SAMPLE_ID);
                if (__PROPS_SAMPLE_STATUS_CANCELLED.equalsIgnoreCase(dsBLANKMESSampleDetails.getValue(0, __PROP_SAMPLE_STATUS)) || __PROPS_SAMPLE_STATUS_REVIEWED.equalsIgnoreCase(dsBLANKMESSampleDetails.getValue(0, __PROP_SAMPLE_STATUS)) || __PROPS_SAMPLE_STATUS_DISPOSED.equalsIgnoreCase(dsBLANKMESSampleDetails.getValue(0, __PROP_SAMPLE_STATUS))) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00002, sampleId, dsBLANKMESSampleDetails.getValue(0, __PROP_SAMPLE_STATUS))));
                }
                // **************** Get Master Data from Sample  ***************
                DataSet dsMasterDataDetailsFromSample = getMasterDataDetailsFromSample(sampleId);
                if (dsMasterDataDetailsFromSample.size() == 0) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00020, limsSampleId)));
                }
                // **************** Getting Master Data from MES ***************
                DataSet dsMasterDataForResultEntry = new DataSet();
                dsMasterDataForResultEntry = getMasterDataForResultEntry(sampleId, paramListID, paramListVersion, paramListVariant, paramListDataSet);
                if (dsMasterDataForResultEntry.size() == 0) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00019));
                }

                // **************** Creating dataset for Result Entry *****************
                DataSet dsResultSet = createFinalResultSet(dsMasterDataForResultEntry, dsMasterDataDetailsFromSample, pullDateTime, actualUnitsPulled, mesSampleId);

                // ***************** Update the LIMS Sample by MES Sample Id if not already ************
                updateSampleByMESId(sampleId, mesSampleId, sapPlant);

                // ***************** Enter Results ************
                enterResults(dsResultSet);

            }
            // ********* Checking if only One BLANK MES Sample found in Stage *************
            else {
                sampleId = dsBLANKMESSampleDetails.getColumnValues(__PROP_LIMS_SAMPLE_ID, "");
                // **************** Checking status of sample != Cancelled/ Reveiwed/ Disposed ***************
                if (__PROPS_SAMPLE_STATUS_CANCELLED.equalsIgnoreCase(dsBLANKMESSampleDetails.getValue(0, __PROP_SAMPLE_STATUS)) || __PROPS_SAMPLE_STATUS_REVIEWED.equalsIgnoreCase(dsBLANKMESSampleDetails.getValue(0, __PROP_SAMPLE_STATUS)) || __PROPS_SAMPLE_STATUS_DISPOSED.equalsIgnoreCase(dsBLANKMESSampleDetails.getValue(0, __PROP_SAMPLE_STATUS))) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00005, mesSampleId, dsBLANKMESSampleDetails.getValue(0, __PROP_SAMPLE_STATUS))));
                }
                // **************** Get Master Data from Sample  ***************
                DataSet dsMasterDataDetailsFromSample = getMasterDataDetailsFromSample(sampleId);
                if (dsMasterDataDetailsFromSample.size() == 0) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00020, limsSampleId)));
                }
                // **************** Getting Master Data from MES ***************
                DataSet dsMasterDataForResultEntry = new DataSet();
                dsMasterDataForResultEntry = getMasterDataForResultEntry(sampleId, paramListID, paramListVersion, paramListVariant, paramListDataSet);
                if (dsMasterDataForResultEntry.size() == 0) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00019));
                }

                // **************** Creating dataset for Result Entry *****************
                DataSet dsResultSet = createFinalResultSet(dsMasterDataForResultEntry, dsMasterDataDetailsFromSample, pullDateTime, actualUnitsPulled, mesSampleId);
                // ***************** Update the LIMS Sample by MES Sample Id if not already ************
                updateSampleByMESId(sampleId, mesSampleId, sapPlant);
                // ***************** Enter Results ************
                enterResults(dsResultSet);
            }
        }
        // ************ If Matching MES Sample found *****************
        else {
            // ********* Checking if More than one Sample having matching MES Sample Id *********
            if (dsSampleByMESSampleId.size() > 1) {
                throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00015, mesSampleId)));
            } else {
                sampleId = dsSampleByMESSampleId.getColumnValues(__PROP_LIMS_SAMPLE_ID, "");
                // **************** Checking status of sample != Cancelled/ Reveiwed/ Disposed ***************
                if (__PROPS_SAMPLE_STATUS_CANCELLED.equalsIgnoreCase(dsSampleByMESSampleId.getValue(0, __PROP_SAMPLE_STATUS)) || __PROPS_SAMPLE_STATUS_REVIEWED.equalsIgnoreCase(dsSampleByMESSampleId.getValue(0, __PROP_SAMPLE_STATUS)) || __PROPS_SAMPLE_STATUS_DISPOSED.equalsIgnoreCase(dsSampleByMESSampleId.getValue(0, __PROP_SAMPLE_STATUS))) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00005, mesSampleId, dsSampleByMESSampleId.getValue(0, __PROP_SAMPLE_STATUS))));
                }
                // **************** Get Master Data from Sample  ***************
                DataSet dsMasterDataDetailsFromSample = getMasterDataDetailsFromSample(sampleId);
                if (dsMasterDataDetailsFromSample.size() == 0) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00020, limsSampleId)));
                }
                // **************** Get Master Data from MES ***************
                DataSet dsMasterDataForResultEntry = new DataSet();
                dsMasterDataForResultEntry = getMasterDataForResultEntry(sampleId, paramListID, paramListVersion, paramListVariant, paramListDataSet);
                if (dsMasterDataForResultEntry.size() == 0) {
                    throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00019));
                }
                // **************** Creating dataset for Result Entry *****************
                DataSet dsResultSet = createFinalResultSet(dsMasterDataForResultEntry, dsMasterDataDetailsFromSample, pullDateTime, actualUnitsPulled, mesSampleId);

                // ***************** Update the SAP plant ************
                updateSampleByMESId(sampleId, mesSampleId, sapPlant);
                // ***************** Enter Results ************
                enterResults(dsResultSet);

            }
        }
    } catch (SapphireException ex) {
        // ******** For ERROR ******* //
        // Concatinating the LIMS Batch Id and LIMS Sample Id with Error Msg.
        throw new SapphireException(ex.getMessage() + "|" + limsBatchId + "|" + sampleId);
    }
    // ******** For SUCCESS ******* //
    if ("Y".equalsIgnoreCase(reprocessedFlag)) {
        properties.setProperty(__PROPS_TRANSITEM_STATUS, MES_STATUS_SUCCESS);
    }
    properties.setProperty(__PROPS_LIMS_BATCH_ID, limsBatchId);
    properties.setProperty(__PROPS_LIMS_SAMPLE_ID, sampleId);

    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-processAction");
    }
}

/**********************************************************
 * This method is used to enter results.
 * @param dsFinalResultSet Final result set
 * @throws SapphireException OOB Sapphire exception
 **********************************************************/
private void enterResults(DataSet dsFinalResultSet) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside enterResults (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    PropertyList plEnterDetails = new PropertyList();

    //--- Unrelease dataitems ---//
    plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
    plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_KEYID1, dsFinalResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ";"));
    plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMLISTID, dsFinalResultSet.getColumnValues(__PROPS_PARAMLIST_ID, ";"));
    plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMLISTVERSIONID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_LIST_VERSION, ";"));
    plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_VARIANTID, dsFinalResultSet.getColumnValues(__PROPS_VARIANT_ID, ";"));
    plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_DATASET, dsFinalResultSet.getColumnValues(__PROPS_DATASET, ";"));
    plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_ID, ";"));
    plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_PARAMTYPE, dsFinalResultSet.getColumnValues(__PROPS_PARAM_TYPE, ";"));
    plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_REPLICATEID, dsFinalResultSet.getColumnValues(__PROPS_REPLICATE, ";"));
    plEnterDetails.setProperty(UnReleaseDataItem.PROPERTY_AUDITREASON, "MES Interface Update");

    try {
        getActionProcessor().processAction(UnReleaseDataItem.ID, UnReleaseDataItem.VERSIONID, plEnterDetails);
    } catch (SapphireException ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00021, ex.getMessage())));
    }

    // ********* Update Dataset status *************
    updateDatasetStatus(dsFinalResultSet);

    // ******** SyncSDIWIStatus ***************
    syncSDIWIStatus(dsFinalResultSet);

    // *************** SyncSDIDataSetStatus **************
    syncSDIDataSetStatus(dsFinalResultSet);

    //--- Result entry ---//
    plEnterDetails.clear();
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_KEYID1, dsFinalResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ";"));
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMLISTID, dsFinalResultSet.getColumnValues(__PROPS_PARAMLIST_ID, ";"));
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMLISTVERSIONID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_LIST_VERSION, ";"));
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_VARIANTID, dsFinalResultSet.getColumnValues(__PROPS_VARIANT_ID, ";"));
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_DATASET, dsFinalResultSet.getColumnValues(__PROPS_DATASET, ";"));
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_ID, ";"));
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_PARAMTYPE, dsFinalResultSet.getColumnValues(__PROPS_PARAM_TYPE, ";"));
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_REPLICATEID, dsFinalResultSet.getColumnValues(__PROPS_REPLICATE, ";"));
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_ENTEREDTEXT, dsFinalResultSet.getColumnValues(__PROPS_RESULT, ";"));
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_AUDITREASON, "MES Interface results update");
    plEnterDetails.setProperty(EnterDataItem.PROPERTY_PROPSMATCH, "Y");

    try {
        getActionProcessor().processAction(EnterDataItem.ID, EnterDataItem.VERSIONID, plEnterDetails);
    } catch (SapphireException ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00021, ex.getMessage())));
    }

    //--- Release Dataitems----//
    plEnterDetails.clear();
    plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
    plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_KEYID1, dsFinalResultSet.getValue(0, __PROPS_LIMS_SAMPLE_ID, ";"));
    plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMLISTID, dsFinalResultSet.getColumnValues(__PROPS_PARAMLIST_ID, ";"));
    plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMLISTVERSIONID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_LIST_VERSION, ";"));
    plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_VARIANTID, dsFinalResultSet.getColumnValues(__PROPS_VARIANT_ID, ";"));
    plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_DATASET, dsFinalResultSet.getColumnValues(__PROPS_DATASET, ";"));
    plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMID, dsFinalResultSet.getColumnValues(__PROPS_PARAM_ID, ";"));
    plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_PARAMTYPE, dsFinalResultSet.getColumnValues(__PROPS_PARAM_TYPE, ";"));
    plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_REPLICATEID, dsFinalResultSet.getColumnValues(__PROPS_REPLICATE, ";"));
    plEnterDetails.setProperty(ReleaseDataItem.PROPERTY_AUDITREASON, "MES Interface Update");

    try {
        getActionProcessor().processAction(ReleaseDataItem.ID, ReleaseDataItem.VERSIONID, plEnterDetails);
    } catch (SapphireException ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00021, ex.getMessage())));
    }

    // ********* Update Dataset status *************
    updateDatasetStatus(dsFinalResultSet);

    // ******** SyncSDIWIStatus ***************
    syncSDIWIStatus(dsFinalResultSet);

    // *************** SyncSDIDataSetStatus **************
    syncSDIDataSetStatus(dsFinalResultSet);

    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-enterResults");
    }
}


/**********************************************************************
 * This method is used to update DataSet status after result is released
 * @param dsFinalResultSet DataSet for Result Entry
 * @throws SapphireException OOB Sapphire Exception
 ***********************************************************************/
private void updateDatasetStatus(DataSet dsFinalResultSet) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside updateDatasetStatus (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    PropertyList plUpdateDataSetStatus = new PropertyList();
    plUpdateDataSetStatus.setProperty(UpdateDatasetStatus.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
    plUpdateDataSetStatus.setProperty(UpdateDatasetStatus.PROPERTY_KEYID1, dsFinalResultSet.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
    plUpdateDataSetStatus.setProperty(UpdateDatasetStatus.PROPERTY_AUDITREASON, "MES Interface Result Update");
    try {
        getActionProcessor().processAction(UpdateDatasetStatus.ID, UpdateDatasetStatus.VERSIONID, plUpdateDataSetStatus);
    } catch (SapphireException ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00022, ex.getMessage())));
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-updateDatasetStatus");
    }
}

/****************************************************************
 * This method is used to sync SDI WI Status
 * @param dsFinalResultSet Final Result Set
 * @throws SapphireException OOB Sapphire Exception
 ****************************************************************/
private void syncSDIWIStatus(DataSet dsFinalResultSet) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside syncSDIWIStatus (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    PropertyList plUpdateDataSetStatus = new PropertyList();
    plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
    plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_KEYID1, dsFinalResultSet.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
    plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_AUDITSIGNEDFLAG, "Y");
    plUpdateDataSetStatus.setProperty(SyncSDIWIStatus.PROPERTY_AUDITACTIVITY, "MES Interface Result Update");
    try {
        getActionProcessor().processAction(SyncSDIWIStatus.ID, SyncSDIWIStatus.VERSIONID, plUpdateDataSetStatus);
    } catch (SapphireException ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00023, ex.getMessage())));
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-syncSDIWIStatus");
    }
}

/******************************************************************
 * This method is used to sync SDI DataSet status
 * @param dsFinalResultSet Final Result Set
 * @throws SapphireException OOB Sapphire Exception
 *****************************************************************/
private void syncSDIDataSetStatus(DataSet dsFinalResultSet) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside syncSDIDataSetStatus (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    PropertyList plUpdateDataSetStatus = new PropertyList();
    plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
    plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_KEYID1, dsFinalResultSet.getColumnValues(__PROPS_LIMS_SAMPLE_ID, ";"));
    plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_STATUSCOLID, "samplestatus");
    plUpdateDataSetStatus.setProperty(SyncSDIDataSetStatus.PROPERTY_AUDITREASON, "MES Interface Result Update");
    try {
        getActionProcessor().processAction(SyncSDIDataSetStatus.ID, SyncSDIDataSetStatus.VERSIONID, plUpdateDataSetStatus);
    } catch (SapphireException ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00024, ex.getMessage())));
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-syncSDIDataSetStatus");
    }
}


/*******************************************************************************
 * This method is used to check ParamIDs are present or not.
 * @param dsFinalResultSet Final Result Set
 * @param mesSampleId MES Sample Id
 * @throws SapphireException OOB Sapphire Exception
 ********************************************************************************/
private void checkParamIDPresentInSample(DataSet dsFinalResultSet, String mesSampleId) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside checkParamIdPresent (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    PropertyList plFilter = new PropertyList();
    plFilter.clear();
    plFilter.setProperty(__PROPS_PARAMID, _PROP_PARAM_NUMBER_OF_ACTUAL_UNITS_PULLED);
    DataSet dsParamNumberOfRequiredUnits = dsFinalResultSet.getFilteredDataSet(plFilter);
    if (0 == dsParamNumberOfRequiredUnits.getRowCount()) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00003, mesSampleId, _PROP_PARAM_NUMBER_OF_ACTUAL_UNITS_PULLED)));
    }
    plFilter.clear();
    plFilter.setProperty(__PROPS_PARAMID, _PROP_PARAM_PULL_DATE);
    DataSet dsParamPullDate = dsFinalResultSet.getFilteredDataSet(plFilter);
    if (0 == dsParamPullDate.getRowCount()) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00003, mesSampleId, _PROP_PARAM_PULL_DATE)));
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-checkParamIDPresentInSample");
    }
}


/*******************************************************************************
 * This method is used to create final Result set for inserting results.
 * @param dsMasterDataForResultEntry DataSet of Master Data coming from MES
 * @param dsMasterDataDetailsFromSample DataSEt of Master Data fetched from LIMS
 * @param pulldateTime Parameter PULL DATE
 * @param actualUnitsPulled Parameter NUMBER OF ACTUAL UNITS
 * @param mesSampleId MES Sample Id
 * @return Returns final Result set for data entry
 * @throws SapphireException OOB Sapphire Exception
 ********************************************************************************/
private DataSet createFinalResultSet(DataSet dsMasterDataForResultEntry, DataSet dsMasterDataDetailsFromSample, String pulldateTime, String actualUnitsPulled, String mesSampleId) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside createFinalResultSet (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    PropertyList plFilter = new PropertyList();
    DataSet dsTemp = new DataSet(connectionInfo);
    DataSet dsMasterData = new DataSet(connectionInfo);
    String pullDateFormat = MESUtil.getDateTimeStringWithProperFormat(pulldateTime);
    // ************ Creating DataSet columns ************
    if (!dsMasterData.isValidColumn(__PROPS_LIMS_SAMPLE_ID)) {
        dsMasterData.addColumn(__PROPS_LIMS_SAMPLE_ID, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_PARAMLIST_ID)) {
        dsMasterData.addColumn(__PROPS_PARAMLIST_ID, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_PARAM_LIST_VERSION)) {
        dsMasterData.addColumn(__PROPS_PARAM_LIST_VERSION, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_VARIANT_ID)) {
        dsMasterData.addColumn(__PROPS_VARIANT_ID, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_DATASET)) {
        dsMasterData.addColumn(__PROPS_DATASET, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_PARAM_ID)) {
        dsMasterData.addColumn(__PROPS_PARAM_ID, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_PARAM_TYPE)) {
        dsMasterData.addColumn(__PROPS_PARAM_TYPE, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_REPLICATE)) {
        dsMasterData.addColumn(__PROPS_REPLICATE, DataSet.STRING);
    }
    if (!dsMasterData.isValidColumn(__PROP_SAMPLE_CREATE_DATE)) {
        dsMasterData.addColumn(__PROP_SAMPLE_CREATE_DATE, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_RESULT)) {
        dsMasterData.addColumn(__PROPS_RESULT, DataSet.STRING);
    }

    plFilter.clear();
    plFilter.setProperty(__PROPS_PARAMLISTID, dsMasterDataForResultEntry.getValue(0, __PROPS_PARAMLIST_ID, ""));
    plFilter.setProperty(__PROPS_PARAMLISTVERSIONID, dsMasterDataForResultEntry.getValue(0, __PROPS_PARAM_LIST_VERSION, ""));
    plFilter.setProperty(__PROPS_VARIANTID, dsMasterDataForResultEntry.getValue(0, __PROPS_VARIANT_ID, ""));
    plFilter.setProperty("strdataset", dsMasterDataForResultEntry.getValue(0, __PROPS_DATASET, ""));

    // **********  Filtering  SDIDataItem based on Static data came from MES **********
    dsTemp = dsMasterDataDetailsFromSample.getFilteredDataSet(plFilter);
    if (dsTemp.getRowCount() == 0) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00004, dsMasterDataForResultEntry.getValue(0, __PROPS_PARAMLIST_ID, ""), dsMasterDataForResultEntry.getValue(0, __PROPS_PARAM_LIST_VERSION, ""), dsMasterDataForResultEntry.getValue(0, __PROPS_VARIANT_ID, ""), dsMasterDataForResultEntry.getValue(0, __PROPS_DATASET, ""), mesSampleId)));
    }
    // ***************** Check ParamId "PULL DATE" and "NUMBER OF REQUIRED UNITS" are present ************
    checkParamIDPresentInSample(dsTemp, mesSampleId);
    int row1;
    int dsSize = dsTemp.size();
    for (int i = 0; i < dsSize; i++) {

        if (_PROP_PARAM_NUMBER_OF_ACTUAL_UNITS_PULLED.equalsIgnoreCase(dsTemp.getValue(i, __PROPS_PARAM_ID))) {
            row1 = dsMasterData.addRow();
            dsMasterData.setValue(row1, __PROPS_LIMS_SAMPLE_ID, dsTemp.getValue(i, __PROPS_KEYID1));
            dsMasterData.setValue(row1, __PROPS_PARAMLIST_ID, dsTemp.getValue(i, __PROPS_PARAMLISTID));
            dsMasterData.setValue(row1, __PROPS_PARAM_LIST_VERSION, dsTemp.getValue(i, __PROPS_PARAMLISTVERSIONID));
            dsMasterData.setValue(row1, __PROPS_VARIANT_ID, dsTemp.getValue(i, __PROPS_VARIANTID));
            dsMasterData.setValue(row1, __PROPS_DATASET, dsTemp.getValue(i, __PROPS_DS));
            dsMasterData.setValue(row1, __PROPS_PARAM_ID, dsTemp.getValue(i, __PROPS_PARAMID));
            dsMasterData.setValue(row1, __PROP_SAMPLE_CREATE_DATE, dsTemp.getValue(i, __PROP_SAMPLE_CREATE_DATE));
            dsMasterData.setValue(row1, __PROPS_PARAM_TYPE, dsTemp.getValue(i, __PROPS_PARAMTYPE));
            dsMasterData.setValue(row1, __PROPS_RESULT, actualUnitsPulled);
            dsMasterData.setValue(row1, __PROPS_REPLICATE, dsTemp.getValue(i, __PROPS_REPLICATEID));
        } else if (_PROP_PARAM_PULL_DATE.equalsIgnoreCase(dsTemp.getValue(i, __PROPS_PARAM_ID))) {
            row1 = dsMasterData.addRow();
            dsMasterData.setValue(row1, __PROPS_LIMS_SAMPLE_ID, dsTemp.getValue(i, __PROPS_KEYID1));
            dsMasterData.setValue(row1, __PROPS_PARAMLIST_ID, dsTemp.getValue(i, __PROPS_PARAMLISTID));
            dsMasterData.setValue(row1, __PROPS_PARAM_LIST_VERSION, dsTemp.getValue(i, __PROPS_PARAMLISTVERSIONID));
            dsMasterData.setValue(row1, __PROPS_VARIANT_ID, dsTemp.getValue(i, __PROPS_VARIANTID));
            dsMasterData.setValue(row1, __PROPS_DATASET, dsTemp.getValue(i, __PROPS_DS));
            dsMasterData.setValue(row1, __PROPS_PARAM_ID, dsTemp.getValue(i, __PROPS_PARAMID));
            dsMasterData.setValue(row1, __PROP_SAMPLE_CREATE_DATE, dsTemp.getValue(i, __PROP_SAMPLE_CREATE_DATE));
            dsMasterData.setValue(row1, __PROPS_PARAM_TYPE, dsTemp.getValue(i, __PROPS_PARAMTYPE));
            dsMasterData.setValue(row1, __PROPS_RESULT, pullDateFormat);
            dsMasterData.setValue(row1, __PROPS_REPLICATE, dsTemp.getValue(i, __PROPS_REPLICATEID));
        }

    }

    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-createFinalResultSet");
    }
    return dsMasterData;

}


/***************************************************************************
 * This method is used to create a DataSet of Master Data.
 * @param sampleId LIMS Sample Id
 * @param paramlistId Paramlist Id
 * @param paramlistVersionId Paramlist Version Id
 * @param variantId Variant Id
 * @param dataset Dataset
 * @return DataSet of Static Data
 * @throws SapphireException OOB Sapphire Exception
 ******************************************************************************/
private DataSet getMasterDataForResultEntry(String sampleId, String paramlistId, String paramlistVersionId, String variantId, String dataset) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside getMasterDataForResultEntry (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    DataSet dsMasterData = new DataSet(connectionInfo);
    // ************ Creating DataSet columns ************

    if (!dsMasterData.isValidColumn(__PROPS_PARAMLIST_ID)) {
        dsMasterData.addColumn(__PROPS_PARAMLIST_ID, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_PARAM_LIST_VERSION)) {
        dsMasterData.addColumn(__PROPS_PARAM_LIST_VERSION, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_VARIANT_ID)) {
        dsMasterData.addColumn(__PROPS_VARIANT_ID, DataSet.STRING);
    }

    if (!dsMasterData.isValidColumn(__PROPS_DATASET)) {
        dsMasterData.addColumn(__PROPS_DATASET, DataSet.STRING);
    }


    // ************** Entering Master Data *****************

    int row1;

    // ***** Row 1 *****
    row1 = dsMasterData.addRow();
    dsMasterData.setValue(row1, __PROPS_PARAMLIST_ID, paramlistId);
    dsMasterData.setValue(row1, __PROPS_PARAM_LIST_VERSION, paramlistVersionId);
    dsMasterData.setValue(row1, __PROPS_VARIANT_ID, variantId);
    dsMasterData.setValue(row1, __PROPS_DATASET, dataset);

    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-getMasterDataForResultEntry");
    }
    return dsMasterData;
}


/***********************************************************
 * Thsi method is used to get exiting LIMS Batch details
 * @param sapBatchNumber SAP Batch Number
 * @param sapMaterialNumber SAP Material Number
 * @param sapPlant SAP plant
 * @return Returns LIMS Batch Id
 * @throws SapphireException OOB Sapphire Exception.
 ************************************************************/
private String[] getExistingLIMSBatch(String sapBatchNumber, String sapMaterialNumber, String sapPlant) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside getExistingLIMSBatch (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String limsBatchDetails[] = new String[2];
    SafeSQL safeSQL = new SafeSQL();
    StringBuilder strSQL = new StringBuilder().append("");
    strSQL.append(" SELECT s_batch." + __PROP_LIMS_BATCH_ID + ", s_batch." + __PROP_LIMS_BATCH_STATUS + ", s_batch." + __PROPS_LIMS_BATCH_PRODVARIANTID + " ,s_prodvariant.productid,s_prodvariant.productversionid,s_batch.batchdesc  ");
    strSQL.append(" FROM s_batch INNER JOIN s_prodvariant ").append(" ON s_batch.prod" + __PROPS_VARIANTID + " = s_prodvariant.s_prodvariantid ");
    strSQL.append(" WHERE s_batch.u_mesordersapbatch1 = ").append(safeSQL.addVar(sapBatchNumber));
    strSQL.append(" AND s_batch.u_sapmatnumber = ").append(safeSQL.addVar(sapMaterialNumber));
    strSQL.append(" AND ( s_batch.u_sapplant = ").append(safeSQL.addVar(sapPlant));
    strSQL.append(" OR s_prodvariant.securitydepartment IN( SELECT department.departmentid FROM department INNER JOIN u_sites ");
    strSQL.append(" ON department.u_siteid = u_sites.u_sitesid WHERE u_sites.sapplant = ").append(safeSQL.addVar(sapPlant)).append("))");
    strSQL.append(" AND s_batch.batchstatus <> '" + __PROP_BATCH_STATUS_CANCELLED + "' ");
    strSQL.append(" AND s_batch.batchstatus <> '" + __PROP_BATCH_STATUS_REJECTED + "' ");
    DataSet dsLIMSBatchDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
    // ****** If Query returns NULL
    if (null == dsLIMSBatchDetails) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00007)));
    } else if (dsLIMSBatchDetails.size() == 0) {
        // ******* If No LIMS Batch found against SAP Batch + SAP Material + SAP plant combination.
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00008, sapBatchNumber, sapMaterialNumber, sapPlant)));
    } else if (dsLIMSBatchDetails.size() > 1) {
        // ******* If More than One LIMS Batch found against SAP Batch + SAP Material + SAP plant combination.
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00009, sapBatchNumber, sapMaterialNumber, sapPlant)));
    } else if (dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_STATUS, "").equalsIgnoreCase(__PROP_BATCH_STATUS_CANCELLED)) {
        // ******* If Batch Status is Cancelled
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00010, dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_ID, ""), __PROP_BATCH_STATUS_CANCELLED)));
    } else if (dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_STATUS, "").equalsIgnoreCase(__PROP_BATCH_STATUS_REJECTED)) {
        // ******* If Batch Status is Rejected
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00010, dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_ID, ""), __PROP_BATCH_STATUS_REJECTED)));
    } else {
        // ******* Setting LIMS Batch Id and Status
        limsBatchDetails[0] = dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_ID, "");
        limsBatchDetails[1] = dsLIMSBatchDetails.getValue(0, __PROP_LIMS_BATCH_STATUS, "");
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-getExistingLIMSBatch");
    }
    return limsBatchDetails;
}


/**************************************************************
 * This method is used get Master Data details from Sample Id
 * @param limsSampleId LIMS Sample Id
 * @return DataSet of Master Data
 * @throws SapphireException OOB Sapphire Exception
 **************************************************************/
private DataSet getMasterDataDetailsFromSample(String limsSampleId) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside getMasterDataDetailsFromSample (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String rsetId = "";
    StringBuilder strSQL = new StringBuilder().append("");
    DataSet dsSampleResults = new DataSet();
    SafeSQL safeSQL = new SafeSQL();
    try {
        rsetId = getDAMProcessor().createRSet(__PROP_SDC_SAMPLE, limsSampleId, "(null)", "(null)");
        strSQL.append(" SELECT sdi." + __PROPS_KEYID1 + ", sdi." + __PROPS_PARAMLISTID + ", sdi." + __PROPS_PARAMLISTVERSIONID + ", sdi." + __PROPS_VARIANTID + ", sdi." + __PROPS_DS + ", TO_CHAR(sdi.dataset) strdataset, sdi." + __PROPS_PARAMID + ", sdi." + __PROPS_PARAMTYPE + ", sdi." + __PROPS_REPLICATEID + ", TO_CHAR(sdi.replicateid) strreplicateid, sdi.createdt ");
        strSQL.append(" FROM sdidata sd INNER JOIN sdidataitem sdi ");
        strSQL.append(" ON sd." + __PROPS_SDCID + " =  sdi.sdcid  AND sd." + __PROPS_KEYID1 + " =  sdi." + __PROPS_KEYID1 + "  AND sd." + __PROPS_KEYID2 + " =  sdi." + __PROPS_KEYID2 + " AND sd." + __PROPS_KEYID3 + " =  sdi.keyid3 AND sd." + __PROPS_PARAMLISTID + " = sdi.paramlistid AND sd." + __PROPS_PARAMLISTVERSIONID + " = sdi." + __PROPS_PARAMLISTVERSIONID + " AND sd." + __PROPS_VARIANTID + " =  sdi." + __PROPS_VARIANTID + " AND sd." + __PROPS_DS + " =  sdi." + __PROPS_DS + "  ");
        strSQL.append(" INNER JOIN rsetitems rsi ON rsi." + __PROPS_SDCID + " = sdi." + __PROPS_SDCID + " AND rsi." + __PROPS_KEYID1 + " = sdi." + __PROPS_KEYID1 + " AND rsi." + __PROPS_KEYID2 + " =  sdi." + __PROPS_KEYID2 + " AND rsi." + __PROPS_KEYID3 + " = sdi." + __PROPS_KEYID3);
        strSQL.append(" WHERE rsi.rsetid = ").append(safeSQL.addVar(rsetId));
        strSQL.append(" AND sdi.sdcid='Sample' and sd.s_datasetstatus <> 'Cancelled'");
        strSQL.append(" and sdi.keyid1 in ( ").append(safeSQL.addIn(limsSampleId, ";")).append(")");
        dsSampleResults = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
        if (null == dsSampleResults) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting result details for LIMS Sample # - " + limsSampleId)));
        }
    } catch (SapphireException ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00018));

    } finally {
        if (!"".equalsIgnoreCase(rsetId)) {
            getDAMProcessor().clearRSet(rsetId);
        }
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-getMasterDataDetailsFromSample");
    }
    return dsSampleResults;

}


/************************************************************************
 * This method is used to get batch stage details.
 * @param limsBatchId LIMS Batch Id
 * @param mesStageName MES Stage Name
 * @return Returns batch stage id
 * @throws SapphireException OOB Sapphire Exception
 *************************************************************************/
private String getBatchStageId(String limsBatchId, String mesStageName) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside getBatchStageId (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String batchstageId = "";
    SafeSQL safeSQL = new SafeSQL();
    StringBuilder strSQL = new StringBuilder().append("");
    strSQL.append(" SELECT s_batchstage." + __PROP_BATCHSTAGEID + ", s_batchstage." + __PROP_BATCHSTAGE_STATUS + " FROM s_batchstage ");
    strSQL.append(" WHERE s_batchstage.batchid = ").append(safeSQL.addVar(limsBatchId)).append(" AND  s_batchstage." + __PROP_PROCESSSTAGE_LABEL + " = ").append(safeSQL.addVar(mesStageName));

    DataSet dsBatchStageDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
    if (null == dsBatchStageDetails) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting Batch Stage details for LIMS Batch # - " + limsBatchId + " and MES Stage # -" + mesStageName)));
    } else if (dsBatchStageDetails.size() == 0) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00011, mesStageName, limsBatchId)));
    } else if (dsBatchStageDetails.size() > 1) {
        //Check if all stages are Cancelled
        HashMap hm = new HashMap();
        hm.put(__PROP_BATCHSTAGE_STATUS, __PROP_BATCHSTAGE_STATUS_CANCELLED);

        DataSet dsFilter = dsBatchStageDetails.getFilteredDataSet(hm);
        if (dsFilter.size() == dsBatchStageDetails.size()) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00013, limsBatchId, mesStageName)));
        }

        //Ignore cancelled stages
        dsFilter = dsBatchStageDetails.getFilteredDataSet(hm, true);

        //If non-cancelled stages are multiple, throw error
        if (dsFilter.size() > 1) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00012, mesStageName, limsBatchId)));
        }

        // batchstageId = dsBatchStageDetails.getValue(0, __PROP_BATCHSTAGEID, "");
        batchstageId = dsFilter.getValue(0, __PROP_BATCHSTAGEID, "");


    } else {
        //Check if the stage is Cancelled
        HashMap hm = new HashMap();
        hm.put(__PROP_BATCHSTAGE_STATUS, __PROP_BATCHSTAGE_STATUS_CANCELLED);

        DataSet dsFilter = dsBatchStageDetails.getFilteredDataSet(hm);
        if (dsFilter.size() == dsBatchStageDetails.size()) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00013, limsBatchId, mesStageName)));
        }

        batchstageId = dsBatchStageDetails.getValue(0, __PROP_BATCHSTAGEID, "");

    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-getBatchStageId");
    }
    return batchstageId;
}

/**************************************************************
 * This method is used to get Sample details from Stage details.
 * @param limsBatchId LIMS Batch Id
 * @param batchStageId Batch Stage Id
 * @param mesStageName MES Stage Name
 * @return DataSet containing LIMS Sample details
 * @throws SapphireException OOB Sapphire Exception
 ***************************************************************/
private DataSet getSamplesByBatchStage(String limsBatchId, String batchStageId, String mesStageName) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside getSamplesByBatchStage (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    SafeSQL safeSQL = new SafeSQL();
    StringBuilder strSQL = new StringBuilder().append("");
    strSQL.append(" SELECT s_sample." + __PROP_LIMS_SAMPLE_ID + ", s_sample." + __PROP_SAMPLE_STATUS + ", NVL(s_sample.u_messampleid,'" + __PROP_BLANK_MES_SAMPLEID + "') " + __PROP_MES_SAMPLE_ID + " ,s_sample.usersequence, s_sample." + __PROP_SAMPLE_CREATE_DATE + " FROM s_sample ");
    strSQL.append(" WHERE s_sample.batchstageid = ").append(safeSQL.addVar(batchStageId));
    strSQL.append(" AND s_sample.batchid = ").append(safeSQL.addVar(limsBatchId));

    DataSet dsSampleDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
    if (null == dsSampleDetails) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting Sample details for LIMS Batch # - " + limsBatchId + " and MES Stage # -" + mesStageName)));
    } else if (dsSampleDetails.size() == 0) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00014, limsBatchId, mesStageName)));
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-getSamplesByBatchStage");
    }
    return dsSampleDetails;
}


/***********************************************************************
 * This method is used to UPDATE Batch as MES Batch iff it's BLANK
 * @param limsBatchId LIMS Batch Id
 * @throws SapphireException OOB Sapphire Exception
 ***********************************************************************/
private void updateBatchByMESId(String limsBatchId) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside updateBatchByMESId (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    SafeSQL safeSQL = new SafeSQL();
    PropertyList plUpdateBatch = new PropertyList();
    StringBuilder strSQL = new StringBuilder().append("");
    strSQL.append(" SELECT NVL(u_ismesbatch,'N') " + __PROP_IS_MES_BATCH_FLAG + " FROM s_batch WHERE s_batchid = ").append(safeSQL.addVar(limsBatchId));
    DataSet dsIsMESIdPresent = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
    if (null == dsIsMESIdPresent) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting MES Batch details for LIMS Batch # - " + limsBatchId)));
    }
    // ********* Check if not MES Batch ************
    if (!__PROP_MES_BATCH_FLAG_YES.equalsIgnoreCase(dsIsMESIdPresent.getValue(0, __PROP_IS_MES_BATCH_FLAG, ""))) {
        plUpdateBatch.setProperty(EditSDI.PROPERTY_SDCID, __PROP_SDC_BATCH);
        plUpdateBatch.setProperty(EditSDI.PROPERTY_KEYID1, limsBatchId);
        plUpdateBatch.setProperty("auditreason", " Marked as MES Batch. ");
        plUpdateBatch.setProperty("u_ismesbatch", __PROP_MES_BATCH_FLAG_YES);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plUpdateBatch);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00016, limsBatchId));
        }
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-updateBatchByMESId");
    }

}

/*************************************************************************
 * This method is used to UPDATE Sample by MES Sample Id iff it's BLANK
 * @param limsSampleId LIMS Sample Id
 * @param mesSampleId MES Sample Id
 * @param sapPlant sapplant
 * @throws SapphireException OOB Sapphire Exception
 *************************************************************************/
private void updateSampleByMESId(String limsSampleId, String mesSampleId,String sapPlant) throws SapphireException {
    logger.info("Processing " + ID + ". (Action) : Inside updateSampleByMESId (method)");
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    SafeSQL safeSQL = new SafeSQL();
    PropertyList plUpdateBatch = new PropertyList();
    StringBuilder strSQL = new StringBuilder().append("");
    strSQL.append(" SELECT NVL(u_messampleid,'BLANK') " + __PROP_MES_SAMPLE_ID + "  FROM s_sample WHERE s_sampleid = ").append(safeSQL.addVar(limsSampleId));
    DataSet dsIsMESIdPresent = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
    if (null == dsIsMESIdPresent) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting MES Sample # details for LIMS Sample # - " + limsSampleId + " and MES Sample # -" + mesSampleId)));
    }
    // ********* Check if MES Sample Id is BLANK or not ************
    if (__PROP_BLANK_MES_SAMPLEID.equalsIgnoreCase(dsIsMESIdPresent.getValue(0, __PROP_MES_SAMPLE_ID, ""))) {
        plUpdateBatch.setProperty(EditSDI.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plUpdateBatch.setProperty(EditSDI.PROPERTY_KEYID1, limsSampleId);
        plUpdateBatch.setProperty("auditreason", " MES Sample Id Updated. ");
        plUpdateBatch.setProperty(__PROP_COL_MESBATCH_ID, mesSampleId);
        plUpdateBatch.setProperty("u_sapplant", sapPlant);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plUpdateBatch);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00017, limsSampleId));
        }
    }
    else{
        plUpdateBatch.clear();
        plUpdateBatch.setProperty(EditSDI.PROPERTY_SDCID, __PROP_SDC_SAMPLE);
        plUpdateBatch.setProperty(EditSDI.PROPERTY_KEYID1, limsSampleId);
        plUpdateBatch.setProperty("u_sapplant", sapPlant);
        try {
            getActionProcessor().processAction(EditSDI.ID, EditSDI.VERSIONID, plUpdateBatch);
        } catch (SapphireException ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.SEND_STABILITY_SAMPLES_ERR_00017, limsSampleId));
        }
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, SERVICE_SEND_STABILITY_SAMPLES_TO_LIMS , "SendMESStabilitySamplesToLIMS-updateSampleByMESId");
    }
}

}
