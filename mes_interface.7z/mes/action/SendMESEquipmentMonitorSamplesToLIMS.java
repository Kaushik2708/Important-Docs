package labvantage.custom.alcon.mes.action;


/**
 * $Author: SAHAPI1 $
 * $Date: 2022-12-23 03:39:29 +0530 (Fri, 23 Dec 2022) $
 * $Revision: 419 $
 */

import labvantage.custom.alcon.mes.util.MESErrorMessageUtil;
import labvantage.custom.alcon.mes.util.MESUtil;
import sapphire.SapphireException;
import sapphire.action.AddSDI;
import sapphire.action.BaseAction;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.SafeSQL;
import sapphire.xml.PropertyList;




/********************************************************************************************************
 * $Revision: 419 $
 * Description: All necessary activities needed for Equipment Monitor Samples to LIMS Service
 *
 ********************************************************************************************************/



public class SendMESEquipmentMonitorSamplesToLIMS extends BaseAction {
public static final String DEVOPS_ID = "$Revision: 419 $";
public static final String ID = "SendMESEquipmentMonitorSamplesToLIMS";
public static final String VERSIONID = "1";

private static final String _PROP_MES_SAMPLE_ID = "MES_SAMPLE_ID";
private static final String _PROPS_AR_SAMPLE_DESCRIPTION = "AR_SAMPLE_DESCRIPTION";
private static final String _PROPS_AR_SAMPLE_TEMPLATE = "AR_SAMPLE_TEMPLATE";
private static final String _PROPS_CONTAINER_QTY = "CONTAINER_QTY";
private static final String _PROP_SITE = "plant";
private static final String __PROP_TRANSACTIONDATETIME = "TRANSACTIONDATETIME";
private static final String __PROP_USER_MES_INTERFACE = "MES_INTERFACE";

private static final String _PROP_TEMPLATE_FLAG = "templateflag";
private static final String _PROP_ACTIVE_FLAG = "activeflag";
private static final String _PROP_SDC_SAMPLE = "s_sample";
private static final String _PROP_SAMPLE = "sample";
private static final String _PROP_SAMPLEID = "s_sampleid";
private static final String _PROP_MESSAMPLEID = "u_messampleid";
private static final String __PROPS_NEW_KEYID1 = "newkeyid1";

private static final String __PROPS_TRANSITEM_STATUS = "status";
private static final String MES_STATUS_SUCCESS = "SUCCESS";
private static final String __PROP_REPROCESSFLAG = "reprocessingflag";
private static final String __PROPS_LIMS_SAMPLE_ID = "limssampleid";
private static final String __PROPS_SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS = "alcSendEquipMonitorSamplesToLIMS";
private boolean __PROP_LOG_DIAG_SWITCH = false;



/**************************************************************
 * Description: This is the main method where execution starts.
 * @param properties Property List of properties.
 * @throws SapphireException OOB Sapphire exceptions.
 **************************************************************/
@Override
public void processAction(PropertyList properties) throws SapphireException {
    logger.info("--------- Processing Action:" + ID + ", Version:" + VERSIONID + "---------");
    __PROP_LOG_DIAG_SWITCH = "ON".equalsIgnoreCase(MESUtil.getLogDiagSwitchValue(getConfigurationProcessor()));
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    String transactionDateTime = properties.getProperty(__PROP_TRANSACTIONDATETIME);
    String sapPlant = properties.getProperty(_PROP_SITE);
    String aRSampleDescription = properties.getProperty(_PROPS_AR_SAMPLE_DESCRIPTION);
    String aRSampleTemplate = properties.getProperty(_PROPS_AR_SAMPLE_TEMPLATE);
    String mesSampleId = properties.getProperty(_PROP_MES_SAMPLE_ID);
    String containerQty = properties.getProperty(_PROPS_CONTAINER_QTY);
    String reprocessedFlag = properties.getProperty(__PROP_REPROCESSFLAG);

    // **************Below are list of local variables ************
    String templateFlag = "", activeFlag = "", sampleId="";
    try {

        //Checking if AR Sample Template exists or not
        DataSet dsCheckTemplateDetails = checkTemplateExists(aRSampleTemplate);
        templateFlag = dsCheckTemplateDetails.getValue(0, _PROP_TEMPLATE_FLAG);
        if ("N".equalsIgnoreCase(templateFlag)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0003, aRSampleTemplate)));
        }
        //Checking if AR Sample Template is active or not
        activeFlag = dsCheckTemplateDetails.getValue(0, _PROP_ACTIVE_FLAG);
        if ("N".equalsIgnoreCase(activeFlag)) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0004, aRSampleTemplate)));
        }
        //Checking if mesSampleId already exists in LIMS
        checkExistingMESSampleId(mesSampleId);
        //Create new Sample using that AR_Sample_Template
        sampleId = createNewSample(aRSampleDescription, aRSampleTemplate, mesSampleId, sapPlant, containerQty,transactionDateTime,__PROP_USER_MES_INTERFACE);

    }
    catch (SapphireException ex) {
        // ******** For ERROR ******* //
        //        // Concatinating LIMS Sample Id with Error Msg.
        throw new SapphireException(ex.getMessage() + "|" + "" + "|" + sampleId);
    }
    // ******** For SUCCESS ******* //
    if ("Y".equalsIgnoreCase(reprocessedFlag)) {
        properties.setProperty(__PROPS_TRANSITEM_STATUS, MES_STATUS_SUCCESS);
    }
    properties.setProperty(__PROPS_LIMS_SAMPLE_ID, sampleId);
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, __PROPS_SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS , "SendMESEquipmentMonitorSamplesToLIMS-processAction");
    }

}


/***********************************************************************
 * This method is used to check if AR Sample Template exists or not
 * @param aRSampleTemplate Sample Template
 * @throws SapphireException OOB Sapphire Exception
 ***********************************************************************/
private DataSet checkTemplateExists(String aRSampleTemplate) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    logger.info("Processing " + ID + ". (Action) : Inside checkTemplateExists (method)");
    SafeSQL safeSQL = new SafeSQL();
    StringBuilder strSQL = new StringBuilder().append("");
    strSQL.append(" select nvl("+ _PROP_TEMPLATE_FLAG + ",'N')templateflag, nvl("+ _PROP_ACTIVE_FLAG +",'N')activeflag from "+_PROP_SDC_SAMPLE+" ");
    strSQL.append(" where "+ _PROP_SAMPLEID +"  = ").append(safeSQL.addVar(aRSampleTemplate));

    DataSet dsCheckTemplateDetails = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
    if (null == dsCheckTemplateDetails) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013, " getting Template details for AR_Sample_Template # - " + aRSampleTemplate)));
    } else if (dsCheckTemplateDetails.size() == 0) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0001, aRSampleTemplate)));
    } else if (dsCheckTemplateDetails.size() > 1) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0002, aRSampleTemplate)));
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, __PROPS_SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS, "SendMESEquipmentMonitorSamplesToLIMS-checkTemplateExists");
    }
    return dsCheckTemplateDetails;
}

/***********************************************************************
 * This method is used to check if AR Sample Template exists or not
 * @param mesSampleId MES Sample Id
 * @throws SapphireException OOB Sapphire Exception
 ***********************************************************************/
private void checkExistingMESSampleId(String mesSampleId) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    logger.info("Processing " + ID + ". (Action) : Inside checkExistingMESSampleId (method)");
    SafeSQL safeSQL = new SafeSQL();
    StringBuilder strSQL = new StringBuilder().append("");
    strSQL.append(" select "+ _PROP_SAMPLEID +" from s_sample ");
    strSQL.append(" where "+ _PROP_MESSAMPLEID +"  = ").append(safeSQL.addVar(mesSampleId));

    DataSet dsCheckExistingMESSampleId = getQueryProcessor().getPreparedSqlDataSet(strSQL.toString(), safeSQL.getValues());
    if (null == dsCheckExistingMESSampleId) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.GENERAL_ERR_00013)));
    } else if (dsCheckExistingMESSampleId.size() >0) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(String.format(MESErrorMessageUtil.SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0005, mesSampleId)));
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, __PROPS_SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS, "SendMESEquipmentMonitorSamplesToLIMS-checkExistingMESSampleId");
    }
}

/***********************************************************************
 * This method is used to check if AR Sample Template exists or not
 * @param aRSampleDescription Sample Description
 * @param aRSampleTemplate Sample Template
 * @param mesSampleId MES Sample Id
 * @param sapPlant SAP Plant
 * @param containerQty Quantity
 * @param transactionDateTime Delivery Datetime
 * @param user Delivered By
 * @throws SapphireException OOB Sapphire Exception
 ***********************************************************************/
private String createNewSample(String aRSampleDescription,String aRSampleTemplate,String mesSampleId,String sapPlant,String containerQty,String transactionDateTime,String user) throws SapphireException {
    Long processingStartTimeInNanoSec = System.currentTimeMillis();
    logger.info("Processing " + ID + ". (Action) : Inside createNewSample (method)");
    String newSampleId="";
    String deliveryDateFormat = MESUtil.getDateTimeStringWithProperFormat(transactionDateTime);
    PropertyList plAddSDI = new PropertyList();
    plAddSDI.setProperty(AddSDI.PROPERTY_SDCID, _PROP_SAMPLE);
    plAddSDI.setProperty("sampledesc", aRSampleDescription);
    plAddSDI.setProperty(AddSDI.PROPERTY_TEMPLATEKEYID1, aRSampleTemplate);
    plAddSDI.setProperty("u_messampleid", mesSampleId);
    plAddSDI.setProperty("u_ismesarsampleflag","Y");
    plAddSDI.setProperty("u_sapplant",sapPlant);
    plAddSDI.setProperty("u_quantity",containerQty);
    plAddSDI.setProperty("u_deliveredby", user);
    plAddSDI.setProperty("u_deliveredon", deliveryDateFormat);
    //plAddSDI.setProperty("duedt","N+3");
    plAddSDI.setProperty(AddSDI.PROPERTY_APPLYWORKITEMS,"Y");
    plAddSDI.setProperty(AddSDI.PROPERTY_FORCENEW,"Y");
    plAddSDI.setProperty(AddSDI.PROPERTY_COPYATTACHMENT,"Y");
    try {
        getActionProcessor().processAction(AddSDI.ID, AddSDI.VERSIONID, plAddSDI);
        newSampleId = plAddSDI.getProperty(__PROPS_NEW_KEYID1, "");
    } catch (SapphireException ex) {
        throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, getTranslationProcessor().translate(ex.getMessage()));
    }
    if (__PROP_LOG_DIAG_SWITCH) {
        MESUtil.calculateElapsedTime(logger, processingStartTimeInNanoSec, __PROPS_SERVICE_SEND_EQUIP_MONITOR_SAMPLE_TO_LIMS, "SendMESEquipmentMonitorSamplesToLIMS-createNewSample");
    }
    return newSampleId;
}

}
