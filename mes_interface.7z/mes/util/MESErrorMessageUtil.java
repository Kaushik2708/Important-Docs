package labvantage.custom.alcon.mes.util;
/**
 * $Author: DIANAR1 $
 * $Date: 2023-01-02 16:48:29 +0530 (Mon, 02 Jan 2023) $
 * $Revision: 424 $
 */

/******************************************************************************
 * $Revision: 424 $
 * Description: Util class for storing the validation/error message(s) for MES.
 ******************************************************************************/
public class MESErrorMessageUtil {
    public static final String DEVOPS_ID = "$Revision: 424 $";
    // ************** General Errors which are common to all ***************
    public static String GENERAL_ERROR = "General Error.";
    public static String GENERAL_ERR_00001 = " [GENERAL_ERR_00001] Aborting transaction. Mandatory key %s can't be blank or null.";
    public static String GENERAL_ERR_00002 = " [GENERAL_ERR_00002] Aborting transaction. Failed to execute query while getting %s details. Returned DataSet is null.";
    public static String GENERAL_ERR_00003 = " [GENERAL_ERR_00003] HTTP Error[Code 401] - Unauthorized access.";
    public static String GENERAL_ERR_00004 = " [GENERAL_ERR_00004] HTTP Error[Code 500] - Internal server error.";
    public static String GENERAL_ERR_00005 = " [GENERAL_ERR_00005] HTTP Error[Code 403] - Access forbidden.";
    public static String GENERAL_ERR_00006 = " [GENERAL_ERR_00006] HTTP Error[Code 400] - Bad request.";
    public static String GENERAL_ERR_00007 = " [GENERAL_ERR_00007] HTTP Error[Code 404] - Resource not found.";
    public static String GENERAL_ERR_00008 = " [GENERAL_ERR_00008] HTTP Error[Code 503] - Service unavailable.";
    public static String GENERAL_ERR_00009 = " [GENERAL_ERR_00009] HTTP Error[Code 504] - Request timeout.";
    public static String GENERAL_ERR_00010 = " [GENERAL_ERR_00010] Aborting transaction. Failed to call  AddSDI. Error is -";
    public static String GENERAL_ERR_00011 = " [GENERAL_ERR_00011] Aborting transaction. Failed to execute action %s";
    public static String GENERAL_ERR_00012 = " [GENERAL_ERR_00012] Aborting transaction. Cannot process MESErrorHandler. ";
    public static String GENERAL_ERR_00013 = " [GENERAL_ERR_00013] Aborting transaction. Null DataSet found. Unable to execute query for %s .";
    public static String GENERAL_ERR_00014 = " [GENERAL_ERR_00014] Site - %s is not ACTIVE or service status is not ACTIVE. ";
    public static String GENERAL_ERR_00015 = " [GENERAL_ERR_00015] Aborting transaction. Not able to convert JSONString. ";
    public static String GENERAL_ERR_00016 = " [GENERAL_ERR_00016] SERVICE_NAME is not available in payload. ";
    public static String GENERAL_ERR_00017 = " [GENERAL_ERR_00017] SITE is not available in payload. ";
    public static String GENERAL_ERR_00018 = " [GENERAL_ERR_00018] SERVICE_NAME is not available in payload. ";
    public static String GENERAL_ERR_00019 = " [GENERAL_ERR_00019] SAP_BATCH_NUMBER is not available in payload. ";
    public static String GENERAL_ERR_00020 = " [GENERAL_ERR_00020] SAP_MATERIAL_NUMBER is not available in payload. ";
    public static String GENERAL_ERR_00021 = " [GENERAL_ERR_00021] TRANSACTIONID is not available in payload. ";
    public static String GENERAL_ERR_00022 = " [GENERAL_ERR_00022] TRANSACTIONDATETIME is not available in payload. ";
    public static String GENERAL_ERR_00023 = " [GENERAL_ERR_00023] SAMPLE_DELIVERY_TYPE is not available in payload. ";
    public static String GENERAL_ERR_00024 = " [GENERAL_ERR_00024] MES_SAMPLE_ID is not available in payload. ";
    public static String GENERAL_ERR_00025 = " [GENERAL_ERR_00025] STAGE_NAME is not available in payload. ";
    public static String GENERAL_ERR_00026 = " [GENERAL_ERR_00026] CONTAINER_QTY is not available in payload. ";
    public static String GENERAL_ERR_00027 = " [GENERAL_ERR_00027] DELIVERY_DATETIME is not available in payload. ";
    public static String GENERAL_ERR_00028 = " [GENERAL_ERR_00028] CONTAINER_QTY - %s is not Integer Number. ";
    public static String GENERAL_ERR_00029 = " [GENERAL_ERR_00029] DELIVERY_DATETIME - %s is not in correct format as yyyyMMdd_HHmmss. ";
    public static String GENERAL_ERR_00030 = " [GENERAL_ERR_00030] PARAMLIST_ID is not available in payload. ";
    public static String GENERAL_ERR_00031 = " [GENERAL_ERR_00031] PARAMLIST_VERSION is not available in payload. ";
    public static String GENERAL_ERR_00032 = " [GENERAL_ERR_00032] PARAMLIST_VARIANT is not available in payload. ";
    public static String GENERAL_ERR_00033 = " [GENERAL_ERR_00033] PARAMLIST_DATASET is not available in payload. ";
    public static String GENERAL_ERR_00034 = " [GENERAL_ERR_00034] PULL_DATE_TIME is not available in payload. ";
    public static String GENERAL_ERR_00035 = " [GENERAL_ERR_00035] ACTUAL_UNITS_PULLED is not available in payload. ";
    public static String GENERAL_ERR_00036 = " [GENERAL_ERR_00036] AR_SAMPLE_DESCRIPTION is not available in payload. ";
    public static String GENERAL_ERR_00037 = " [GENERAL_ERR_00037] AR_SAMPLE_TEMPLATE is not available in payload. ";
    public static String GENERAL_ERR_00038 = " [GENERAL_ERR_00038] RETAIN_STAGE_NAME is not available in payload. ";
    public static String GENERAL_ERR_00039 = " [GENERAL_ERR_00039] RETAIN_MES_SAMPLE_ID is not available in payload. ";
    public static String GENERAL_ERR_00040 = " [GENERAL_ERR_00040] ORIENTATION is not available in payload. ";
    public static String GENERAL_ERR_00041 = " [GENERAL_ERR_00041] RETAIN_INSPECTION_RESULT is not available in payload. ";
    public static String GENERAL_ERR_00042 = " [GENERAL_ERR_00042] RETAIN_CONTAINERS_INSPECTED is not available in payload. ";
    public static String GENERAL_ERR_00043 = " [GENERAL_ERR_00043] RETENTION_STORAGE_LOCATION is not available in payload. ";
    public static String GENERAL_ERR_00044 = " [GENERAL_ERR_00044] RETAIN_STORAGE_LOCATION_ID is not available in payload. ";
    public static String GENERAL_ERR_00045 = " [GENERAL_ERR_00045] RETAIN_CONTAINER_QTY is not available in payload. ";
    public static String GENERAL_ERR_00046 = " [GENERAL_ERR_00046] RETAIN_CONTAINER_QTY - %s is not Integer Number. ";
    public static String GENERAL_ERR_00047 = " [GENERAL_ERR_00047] INSPECTION_STAGE_NAME is not available in payload. ";
    public static String GENERAL_ERR_00048 = " [GENERAL_ERR_00048] INSPECTION_MES_SAMPLE_ID is not available in payload. ";
    public static String GENERAL_ERR_00049 = " [GENERAL_ERR_00049] INSPECTION_RESULT is not available in payload. ";
    public static String GENERAL_ERR_00050 = " [GENERAL_ERR_00050] TRANSACTIONDATETIME - %s is not in correct format as yyyyMMdd_HHmmss. ";


    // ************** Error for Populate weight dispensing - Action used for POMS_Interface  ****************
    public static String DISPENSING_ERR_00001 = " [DISPENSING_ERR_00001] Unable to retrieve data for Dataset dsSQLForStatus.  Please contact System Administrator..";
    public static String DISPENSING_ERR_00002 = " [DISPENSING_ERR_00002] Unable to retrieve data for Dataset dsBatchInformation.  Please contact System Administrator..";
    public static String DISPENSING_ERR_00003 = " [DISPENSING_ERR_00003] Unable to execute query .";
    // ************** Error for Batch Potency service ********************
    public static String BATCH_POTENCY_ERR_00001 = " [BATCH_POTENCY_ERR_00001] Sites are not Active.";
    public static String BATCH_POTENCY_ERR_00002 = " [MESRESPONSE_ERR_00002] Response status is FAILURE.";
    public static String BATCH_POTENCY_ERR_00003 = " [MESRESPONSE_ERR_00003] Aborting transaction. Unable to create JSON Object. Error is - ";
    public static String BATCH_POTENCY_ERR_00004 = " [MESRESPONSE_ERR_00004] Aborting transaction. No response came from MES. ";
    public static String BATCH_POTENCY_ERR_00005 = " [MESRESPONSE_ERR_00005] Aborting transation. Not able to edit MES transaction id . ";
    public static String BATCH_POTENCY_ERR_00006 = " [BATCH_POTENCY_ERR_00006] Aborting transation. Not able to convert JSONString. ";
    public static String BATCH_POTENCY_ERR_00007 = " [BATCH_POTENCY_ERR_00007] Aborting transation. Not able to format JSON. ";
    public static String BATCH_POTENCY_ERR_00008 = " [MESRESPONSE_ERR_00008] Aborting transaction. Unable to find endpoint details for the service - ";
    public static String BATCH_POTENCY_ERR_00009 = " [MESRESPONSE_ERR_00009] Aborting transaction. Unable to send data. Error is - ";

    // ************** Error Codes for Send MES Samples to LIMS ********************
    public static String SEND_SAMPLE_TO_LIMS_ERR_00001 = " [SEND_SAMPLES_TO_LIMS_ERR_00001] Aborting transaction. No LIMS Batch found for SAP Batch # - %s , SAP Material # - %s and SAP Plant - %s . ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00002 = " [SEND_SAMPLES_TO_LIMS_ERR_00002] Aborting transaction. More than one LIMS Batch found for SAP Batch # - %s , SAP Material # - %s and SAP Plant - %s . ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00003 = " [SEND_SAMPLES_TO_LIMS_ERR_00003] Aborting transaction. LIMS Batch Id - %s is in %s status. ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00004 = " [SEND_SAMPLES_TO_LIMS_ERR_00004] Aborting transaction. Blank LIMS Batch Id found. ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00005 = " [SEND_SAMPLES_TO_LIMS_ERR_00005] Aborting transaction. The linked Sampling Plan for the LIMS Batch # - %s  is not Current. ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00006 = " [SEND_SAMPLES_TO_LIMS_ERR_00006] Aborting transaction. More than one current samplingplan details found for LIMS Batch # - %s . ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00007 = " [SEND_SAMPLES_TO_LIMS_ERR_00007] Aborting transaction. No matching MES Stage - %s found in current Samplingplan # %s and Samplingplan version # [ %s ]";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00008 = " [SEND_SAMPLES_TO_LIMS_ERR_00008] Aborting transaction. More than one MES Stage found in current Samplingplan # %s and Samplingplan version # %s";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00009 = " [SEND_SAMPLES_TO_LIMS_ERR_00009] Aborting transaction. No matching MES Stage - %s found in LIMS Batch # - %s";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00010 = " [SEND_SAMPLES_TO_LIMS_ERR_00010] Aborting transaction. More than one MES Stage - %s found in LIMS Batch # - %s";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00011 = " [SEND_SAMPLES_TO_LIMS_ERR_00011] Aborting transaction. Batch stage status is cancelled for  LIMS Batch # - %s and MES Stage - %s ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00012 = " [SEND_SAMPLES_TO_LIMS_ERR_00012] Aborting transaction. No sample found in for LIMS Batch # - %s, MES Stage name - %s .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00013 = " [SEND_SAMPLES_TO_LIMS_ERR_00013] Aborting transaction. More than one matching LIMS Sample # found for MES Sample # - %s .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00014 = " [SEND_SAMPLES_TO_LIMS_ERR_00014] Aborting transaction. MES Sample # - %s [LIMS Sample # - %s] is not in initial status, sample update is not possible. ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00015 = " [SEND_SAMPLES_TO_LIMS_ERR_00015] Aborting transaction. All matching LIMS samples having blank MES Sample # are not having %s status .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00016 = " [SEND_SAMPLES_TO_LIMS_ERR_00016] Unable to execute query .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00017 = " [SEND_SAMPLES_TO_LIMS_ERR_00017] Aborting transaction. Unable to receive sample for sample # - %s .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00018 = " [SEND_SAMPLES_TO_LIMS_ERR_00018] Aborting transaction. Unable to update LIMS Batch # - %s as MES Batch.";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00019 = " [SEND_SAMPLES_TO_LIMS_ERR_00019] Aborting transaction. Unable to update MES Sample # for LIMS Sample # - %s .";
    public static String NULL_SQL_VALUE = " [NULL_SQL_VALUE] Aborting Transaction. Failed to execute SQL. ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00020 = " [SEND_SAMPLE_TO_LIMS_ERR_00020] Aborting transaction. No level sample details found in logged in version of sampling plan ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00021 = " [SEND_SAMPLE_TO_LIMS_ERR_00021] Aborting transaction. There is no level details found in current sampling plan .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00022 = " [SEND_SAMPLE_TO_LIMS_ERR_00022] Aborting transaction. More than one level details found in current sampling plan found for LIMS Batch Id: %s , Product Varinat: %s , Sampling Plan Id : %s [Ver. %s] .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00023 = " [SEND_SAMPLE_TO_LIMS_ERR_00023] Aborting transaction. While adding sample maximum sample sequence# not found for LIMS batch id %s.";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00024 = " [SEND_SAMPLE_TO_LIMS_ERR_00024] Aborting transaction. %s sample count is not zero.";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00025 = " [SEND_SAMPLE_TO_LIMS_ERR_00025] Aborting transaction. No level samples details found in logged in version of sampling plan ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00026 = " [SEND_SAMPLES_TO_LIMS_ERR_00026] Aborting transaction. Unable to update record information for LIMS Sample # - %s .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00027 = " [SEND_SAMPLES_TO_LIMS_ERR_00027] Aborting transaction. Unable to get result information for LIMS Sample # - %s .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00028 = " [SEND_SAMPLES_TO_LIMS_ERR_00028] Aborting transaction. Result entry data point is not found for the combination: Sample Id - %s, Parameter List - %s, Variant - %s, Parameter - %s, Paramtype - %s ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00029 = " [SEND_SAMPLES_TO_LIMS_ERR_00029] Aborting transaction. DataSet # 1 is not found for Parameter EMPLOYEE #( SAMPLER_EMPLOYEE_NUMBER_1_2 ) .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00030 = " [SEND_SAMPLES_TO_LIMS_ERR_00030] Aborting transaction. DataSet # 2 is not found for Parameter EMPLOYEE #( SAMPLER_EMPLOYEE_NUMBER_3_4 ) .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00031 = " [SEND_SAMPLES_TO_LIMS_ERR_00031] Aborting transaction. No Parameter details came from MES .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00032 = " [SEND_SAMPLES_TO_LIMS_ERR_00032] Aborting transaction. No Parameter details found for sample # -  %s .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00033 = " [SEND_SAMPLES_TO_LIMS_ERR_00033] Aborting transaction. Unable to enter results. Error is %s .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00034 = " [SEND_SAMPLES_TO_LIMS_ERR_00034] Aborting transaction. Unable to update DataSet. Error is %s .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00035 = " [SEND_SAMPLES_TO_LIMS_ERR_00035] Aborting transaction. Unable to update Workitem details. Error is %s .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00036 = " [SEND_SAMPLES_TO_LIMS_ERR_00036] Aborting transaction. Unable to update SDIDataSetStatus details. Error is %s .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00037 = " [SEND_SAMPLE_TO_LIMS_ERR_00037] Aborting transation. Not able to convert JSONString. ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00038 = " [SEND_SAMPLE_TO_LIMS_ERR_00038] Site - %s is not ACTIVE or Service Status is not ACTIVE. ";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00039 = " [SEND_SAMPLE_TO_LIMS_ERR_00039] Aborting transaction. Unable to execute query .";
    public static String SEND_SAMPLE_TO_LIMS_ERR_00040 = " [SEND_SAMPLE_TO_LIMS_ERR_00040] Aborting transaction. The LIMS Batch # %s is not received yet. ";

    // ************** Error Codes for MES Process Controller ********************
    public static String MES_PROCESS_CONTROLLER_ERR_00001 = " [MES_PROCESS_CONTROLLER_ERR_00001] Can't process MES process controller. Item data is null";
    public static String MES_PROCESS_CONTROLLER_ERR_00002 = " [MES_PROCESS_CONTROLLER_ERR_00002] Can't process MES process controller. Service name is null";
    // *************** ERROR Codes MES Actionable *************
    public static String MES_ACTIONABLE_RESULTS_ERR_00001 = " [MES_ACTIONABLE_RESULTS_ERR_00001] Unable to execute query  for getting all results inside method - getResultsBySampleId. ";
    // *************** ERROR Codes Send Stability Sample To LIMS *************
    public static String SEND_STABILITY_SAMPLES_ERR_00001 = " [SEND_STABILITY_SAMPLES_ERR_00001] No matching [%s] or [BLANK] MES Sample ID found. ";
    public static String SEND_STABILITY_SAMPLES_ERR_00002 = " [SEND_STABILITY_SAMPLES_ERR_00002] Aborting transaction. LIMS Sample #- [%s] having blank MES Sample # is in %s status  ";
    public static String SEND_STABILITY_SAMPLES_ERR_00005 = " [SEND_STABILITY_SAMPLES_ERR_00005] Aborting transaction. LIMS Sample having MES Sample #- [%s] is in %s status  ";
    public static String SEND_STABILITY_SAMPLES_ERR_00003 = " [SEND_STABILITY_SAMPLES_ERR_00003] Aborting transaction. LIMS Sample having MES Sample #- [%s] doesn't have ParamId - [%s] present in it  ";
    public static String SEND_STABILITY_SAMPLES_ERR_00004 = " [SEND_STABILITY_SAMPLES_ERR_00004] No matching Parameter List - %s , Parameter List Version - %s, Variant - %s, DataSet - %s found in MES Sample # - %s.  ";
    public static String SEND_STABILITY_SAMPLES_ERR_00006 = " [SEND_STABILITY_SAMPLES_ERR_00006] Aborting transaction. Blank LIMS Batch Id found. ";
    public static String SEND_STABILITY_SAMPLES_ERR_00007 = " [SEND_STABILITY_SAMPLES_ERR_00007] Unable to execute query .";
    public static String SEND_STABILITY_SAMPLES_ERR_00008 = " [SEND_STABILITY_SAMPLES_ERR_00008] Aborting transaction. No LIMS Batch found for SAP Batch # - %s , SAP Material # - %s and SAP Plant - %s . ";
    public static String SEND_STABILITY_SAMPLES_ERR_00009 = " [SEND_STABILITY_SAMPLES_ERR_00009] Aborting transaction. More than one LIMS Batch found for SAP Batch # - %s , SAP Material # - %s and SAP Plant - %s . ";
    public static String SEND_STABILITY_SAMPLES_ERR_00010 = " [SEND_STABILITY_SAMPLES_ERR_00010] Aborting transaction. LIMS Batch Id - %s is in %s status. ";
    public static String SEND_STABILITY_SAMPLES_ERR_00011 = " [SEND_STABILITY_SAMPLES_ERR_00011] Aborting transaction. No matching MES Stage - %s found in LIMS Batch # - %s";
    public static String SEND_STABILITY_SAMPLES_ERR_00012 = " [SEND_STABILITY_SAMPLES_ERR_00012] Aborting transaction. More than one MES Stage - %s found in LIMS Batch # - %s";
    public static String SEND_STABILITY_SAMPLES_ERR_00013 = " [SEND_STABILITY_SAMPLES_ERR_00013] Aborting transaction. Batch stage status is cancelled for  LIMS Batch # - %s and MES Stage - %s ";
    public static String SEND_STABILITY_SAMPLES_ERR_00014 = " [SEND_STABILITY_SAMPLES_ERR_00014] Aborting transaction. No sample found in for LIMS Batch # - %s, MES Stage Name - %s .";
    public static String SEND_STABILITY_SAMPLES_ERR_00015 = " [SEND_STABILITY_SAMPLES_ERR_00015] Aborting transaction. More than one matching LIMS Sample # found for MES Sample # - %s .";
    public static String SEND_STABILITY_SAMPLES_ERR_00016 = " [SEND_STABILITY_SAMPLES_ERR_00016] Aborting transaction. Unable to update LIMS Batch # - %s as MES Batch.";
    public static String SEND_STABILITY_SAMPLES_ERR_00017 = " [SEND_STABILITY_SAMPLES_ERR_00017] Aborting transaction. Unable to update MES sample # for LIMS Sample # - %s .";
    public static String SEND_STABILITY_SAMPLES_ERR_00018 = " [SEND_STABILITY_SAMPLES_ERR_00018] Aborting transaction. Unable to execute query .";
    public static String SEND_STABILITY_SAMPLES_ERR_00019 = " [SEND_STABILITY_SAMPLES_ERR_00019] Aborting transaction. No Parameter details came from MES .";
    public static String SEND_STABILITY_SAMPLES_ERR_00020 = " [SEND_STABILITY_SAMPLES_ERR_00020] Aborting transaction. No Parameter details found for sample # -  %s .";
    public static String SEND_STABILITY_SAMPLES_ERR_00021 = " [SEND_STABILITY_SAMPLES_ERR_00021] Aborting transaction. Unable to enter results. Error is %s .";
    public static String SEND_STABILITY_SAMPLES_ERR_00022 = " [SEND_STABILITY_SAMPLES_ERR_00022] Aborting transaction. Unable to update DataSet. Error is %s .";
    public static String SEND_STABILITY_SAMPLES_ERR_00023 = " [SEND_STABILITY_SAMPLES_ERR_00023] Aborting transaction. Unable to update Workitem details. Error is %s .";
    public static String SEND_STABILITY_SAMPLES_ERR_00024 = " [SEND_STABILITY_SAMPLES_ERR_00024] Aborting transaction. Unable to update SDIDataSetStatus details. Error is %s .";
    public static String SEND_STABILITY_SAMPLES_ERR_00025 = " [SEND_STABILITY_SAMPLES_ERR_00025] Aborting transaction. The LIMS Batch # %s is not received yet. ";


// *************** ERROR Codes Send Equipment Monitor Test Results To LIMS *************
    public static String SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0001 = " [SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0001] Aborting transaction. No matching AR_Sample_Template - %s found .";
    public static String SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0002 = " [SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0002] Aborting transaction. More than one AR_Sample_Template # - %s found .";
    public static String SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0003 = " [SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0003] Aborting transaction. AR_Sample_Template # - %s doesn't exist .";
    public static String SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0004 = " [SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0004] Aborting transaction. AR_Sample_Template # - %s is not active .";
    public static String SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0005 = " [SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0005] Aborting transaction. More than one MES Sample Id # - %s found .";
    public static String SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0006 = " [SEND_EQUIP_MONITOR_TEST_RESULTS_ERR_0006] Aborting transaction. Unable to get results .";
    // *************** ERROR Codes Send Retention Samples To LIMS *************
    public static String SEND_RETENTION_SAMPLES_ERR_00001 = " [SEND_RETENTION_SAMPLES_ERR_00001] No matching [%s] or [BLANK] MES Sample ID found. ";
    public static String SEND_RETENTION_SAMPLES_ERR_00002 = " [SEND_RETENTION_SAMPLES_ERR_00002] Aborting transaction. LIMS Sample #- [%s] having blank MES Sample # is in %s status  ";
    public static String SEND_RETENTION_SAMPLES_ERR_00005 = " [SEND_RETENTION_SAMPLES_ERR_00005] Aborting transaction. LIMS Sample having MES Sample #- [%s] is in %s status  ";
    public static String SEND_RETENTION_SAMPLES_ERR_00006 = " [SEND_RETENTION_SAMPLES_ERR_00006] Aborting transaction. Blank LIMS Batch Id found. ";
    public static String SEND_RETENTION_SAMPLES_ERR_00007 = " [SEND_RETENTION_SAMPLES_ERR_00007] Unable to execute query .";
    public static String SEND_RETENTION_SAMPLES_ERR_00008 = " [SEND_RETENTION_SAMPLES_ERR_00008] Aborting transaction. No LIMS Batch found for SAP Batch # - %s , SAP Material # - %s and SAP Plant - %s . ";
    public static String SEND_RETENTION_SAMPLES_ERR_00009 = " [SEND_RETENTION_SAMPLES_ERR_00009] Aborting transaction. More than one LIMS Batch found for SAP Batch # - %s , SAP Material # - %s and SAP Plant - %s . ";
    public static String SEND_RETENTION_SAMPLES_ERR_00010 = " [SEND_RETENTION_SAMPLES_ERR_00010] Aborting transaction. LIMS Batch Id - %s is in %s status. ";
    public static String SEND_RETENTION_SAMPLES_ERR_00011 = " [SEND_RETENTION_SAMPLES_ERR_00011] Aborting transaction. No matching MES Stage - %s found in LIMS Batch # - %s";
    public static String SEND_RETENTION_SAMPLES_ERR_00012 = " [SEND_RETENTION_SAMPLES_ERR_00012] Aborting transaction. More than one MES Stage - %s found in LIMS Batch # - %s";
    public static String SEND_RETENTION_SAMPLES_ERR_00013 = " [SEND_RETENTION_SAMPLES_ERR_00013] Aborting transaction. Batch stage status is cancelled for  LIMS Batch # - %s and MES Stage - %s ";
    public static String SEND_RETENTION_SAMPLES_ERR_00014 = " [SEND_RETENTION_SAMPLES_ERR_00014] Aborting transaction. No sample found in for LIMS Batch # - %s, MES Stage Name - %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00015 = " [SEND_RETENTION_SAMPLES_ERR_00015] Aborting transaction. More than one matching LIMS Sample # found for MES Sample # - %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00016 = " [SEND_RETENTION_SAMPLES_ERR_00016] Aborting transaction. Unable to update LIMS Batch # - %s as MES Batch.";
    public static String SEND_RETENTION_SAMPLES_ERR_00017 = " [SEND_RETENTION_SAMPLES_ERR_00017] Aborting transaction. Unable to update MES sample # for LIMS Sample # - %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00018 = " [SEND_RETENTION_SAMPLES_ERR_00018] Aborting transaction. Unable to execute query .";
    public static String SEND_RETENTION_SAMPLES_ERR_00019 = " [SEND_RETENTION_SAMPLES_ERR_00019] Aborting transaction. No Parameter details came from MES .";
    public static String SEND_RETENTION_SAMPLES_ERR_00020 = " [SEND_RETENTION_SAMPLES_ERR_00020] Aborting transaction. No Parameter details found for sample # -  %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00021 = " [SEND_RETENTION_SAMPLES_ERR_00021] Aborting transaction. Unable to enter results. Error is %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00022 = " [SEND_RETENTION_SAMPLES_ERR_00022] Aborting transaction. Unable to update DataSet. Error is %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00023 = " [SEND_RETENTION_SAMPLES_ERR_00023] Aborting transaction. Unable to update Workitem details. Error is %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00024 = " [SEND_RETENTION_SAMPLES_ERR_00024] Aborting transaction. Unable to update SDIDataSetStatus details. Error is %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00025 = " [SEND_RETENTION_SAMPLES_ERR_00025] Aborting transaction. Unable to receive sample for sample # - %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00026 = " [SEND_RETENTION_SAMPLES_ERR_00026] Aborting transaction. Result entry data point is not found for the following combination: Sample Id - %s, Parameter List - %s, Variant - %s, Parameter - %s, Paramtype - %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00027 = " [SEND_RETENTION_SAMPLES_ERR_00027] Aborting transaction. Result entry is already completed for the following combination: Sample Id - %s, Parameter List - %s, Parameter List Version - %s, Variant - %s, Dataset - %s, Parameter - %s, Paramtype - %s, Replicate - %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00028 = " [SEND_RETENTION_SAMPLES_ERR_00028] Aborting transaction. No matching RETAIN_STORAGE_LOCATION_ID - %s found .";
    public static String SEND_RETENTION_SAMPLES_ERR_00029 = " [SEND_RETENTION_SAMPLES_ERR_00029] Aborting transaction. No matching TrackItemId found for LIMS sample Id - %s and Retain storage location Id - %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00030 = " [SEND_RETENTION_SAMPLES_ERR_00030] Aborting transaction. No matching Sample details found for LIMS sample Id - %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00031 = " [SEND_RETENTION_SAMPLES_ERR_00031] Aborting transaction. ReviewRequiredFlag is not Y. Auto review is not possible for LIMS sample Id - %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00032 = " [SEND_RETENTION_SAMPLES_ERR_00032] Aborting transaction. Sample status is not Completed. Auto review is not possible for LIMS sample Id - %s .";
    public static String SEND_RETENTION_SAMPLES_ERR_00033 = " [SEND_RETENTION_SAMPLES_ERR_00033] Aborting transaction. The LIMS Batch # %s is not received yet. ";

// *************** ERROR Codes Send Inspection Samples To LIMS *************
    public static String SEND_INSPECTION_SAMPLES_ERR_00001 = " [SEND_INSPECTION_SAMPLES_ERR_00001] No matching [%s] or [BLANK] MES Sample ID found. ";
    public static String SEND_INSPECTION_SAMPLES_ERR_00006 = " [SEND_INSPECTION_SAMPLES_ERR_00006] Aborting transaction. Blank LIMS Batch Id found. ";
    public static String SEND_INSPECTION_SAMPLES_ERR_00007 = " [SEND_INSPECTION_SAMPLES_ERR_00007] Unable to execute query .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00008 = " [SEND_INSPECTION_SAMPLES_ERR_00008] Aborting transaction. No LIMS Batch found for SAP Batch # - %s , SAP Material # - %s and SAP Plant - %s . ";
    public static String SEND_INSPECTION_SAMPLES_ERR_00009 = " [SEND_INSPECTION_SAMPLES_ERR_00009] Aborting transaction. More than one LIMS Batch found for SAP Batch # - %s , SAP Material # - %s and SAP Plant - %s . ";
    public static String SEND_INSPECTION_SAMPLES_ERR_00010 = " [SEND_INSPECTION_SAMPLES_ERR_00010] Aborting transaction. LIMS Batch Id - %s is in %s status. ";
    public static String SEND_INSPECTION_SAMPLES_ERR_00011 = " [SEND_INSPECTION_SAMPLES_ERR_00011] Aborting transaction. No matching MES Stage - %s found in LIMS Batch # - %s";
    public static String SEND_INSPECTION_SAMPLES_ERR_00012 = " [SEND_INSPECTION_SAMPLES_ERR_00012] Aborting transaction. More than one MES Stage - %s found in LIMS Batch # - %s";
    public static String SEND_INSPECTION_SAMPLES_ERR_00013 = " [SEND_INSPECTION_SAMPLES_ERR_00013] Aborting transaction. Batch stage status is cancelled for  LIMS Batch # - %s and MES Stage - %s ";
    public static String SEND_INSPECTION_SAMPLES_ERR_00014 = " [SEND_INSPECTION_SAMPLES_ERR_00014] Aborting transaction. No sample found in for LIMS Batch # - %s, MES Stage Name - %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00015 = " [SEND_INSPECTION_SAMPLES_ERR_00015] Aborting transaction. More than one matching LIMS Sample # found for MES Sample # - %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00016 = " [SEND_INSPECTION_SAMPLES_ERR_00016] Aborting transaction. Unable to update LIMS Batch # - %s as MES Batch.";
    public static String SEND_INSPECTION_SAMPLES_ERR_00017 = " [SEND_INSPECTION_SAMPLES_ERR_00017] Aborting transaction. Unable to update MES sample # for LIMS Sample # - %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00018 = " [SEND_INSPECTION_SAMPLES_ERR_00018] Aborting transaction. Unable to execute query .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00019 = " [SEND_INSPECTION_SAMPLES_ERR_00019] Aborting transaction. No Parameter details came from MES .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00020 = " [SEND_INSPECTION_SAMPLES_ERR_00020] Aborting transaction. No Parameter details found for sample # -  %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00021 = " [SEND_INSPECTION_SAMPLES_ERR_00021] Aborting transaction. Unable to enter results. Error is %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00022 = " [SEND_INSPECTION_SAMPLES_ERR_00022] Aborting transaction. Unable to update DataSet. Error is %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00023 = " [SEND_INSPECTION_SAMPLES_ERR_00023] Aborting transaction. Unable to update Workitem details. Error is %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00024 = " [SEND_INSPECTION_SAMPLES_ERR_00024] Aborting transaction. Unable to update SDIDataSetStatus details. Error is %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00025 = " [SEND_INSPECTION_SAMPLES_ERR_00025] Aborting transaction. Unable to receive sample for sample # - %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00026 = " [SEND_INSPECTION_SAMPLES_ERR_00026] Aborting transaction. Result entry data point is not found for the following combination: Sample Id - %s, Parameter List - %s, Variant - %s, Parameter - %s, Paramtype - %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00027 = " [SEND_INSPECTION_SAMPLES_ERR_00027] Aborting transaction. Result entry is already completed for the following combination: Sample Id - %s, Parameter List - %s, Parameter List Version - %s, Variant - %s, Dataset - %s, Parameter - %s, Paramtype - %s, Replicate - %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00030 = " [SEND_RETENTION_SAMPLES_ERR_00030] Aborting transaction. No matching Sample details found for LIMS sample Id - %s .";
    public static String SEND_INSPECTION_SAMPLES_ERR_00031 = " [SEND_INSPECTION_SAMPLES_ERR_00031] Aborting transaction. The LIMS Batch # %s is not received yet. ";
    public static String SEND_INSPECTION_SAMPLES_ERR_00032 = " [SEND_INSPECTION_SAMPLES_ERR_00032] Aborting transaction.Required Parameters are missing in Master Data setup . ";


}


