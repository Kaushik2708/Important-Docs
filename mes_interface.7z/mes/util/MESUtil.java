package labvantage.custom.alcon.mes.util;

import sapphire.SapphireException;
import sapphire.accessor.ConfigurationProcessor;
import sapphire.accessor.QueryProcessor;
import sapphire.accessor.TranslationProcessor;
import sapphire.error.ErrorDetail;
import sapphire.util.DataSet;
import sapphire.util.Logger;
import sapphire.util.SafeSQL;
import sapphire.xml.PropertyList;
import sapphire.xml.PropertyListCollection;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * $Author: DIANAR1 $
 * $Date: 2022-11-24 14:53:08 +0530 (Thu, 24 Nov 2022) $
 * $Revision: 355 $
 */

/*************************************************************************************************
 * $Revision: 355 $
 * Description: This class is Util class for MES.
 **************************************************************************************************/


public class MESUtil {
    public static final String DEVOPS_ID = "$Revision: 355 $";
    private static final String __BLANK_STRING = "";
    private static final String __PROPS_DATE_FORMAT = "MMM dd, yyyy HH:mm:ss a";
    private static final String __PROPS_DATE_FORMAT1 = "MMM dd, yyyy hh:mm:ss a";
    private static final String __PROPS_DATE_TIME_FORMAT = "yyyyMMdd_HHmmss";

    //************ Variables for REST Connections ************
    private static final String PROP_METHOD_POST = "POST";
    private static final String PROP_HEADER_CONTENT_TYPE_JSON = "Content-Type";
    private static final String PROP_VALUE_HEADER_CONTENT_TYPE_JSON = "application/json";
    private static final String PROP_HEADER_ACCEPT_ENCODING = "Accept-Encoding";
    private static final String PROP_VALUE_HEADER_ACCEPT_ENCODING = "gzip, deflate, br";
    private static final String PROP_HEADER_CONNECTION = "Connection";
    private static final String PROP_VALUE_HEADER_CONNECTION = "keep-alive";
    private static final String PROP_HEADER_ACCEPT = "Accept";
    private static final String PROP_VALUE_HEADER_ACCEPT = "application/json";
    private static final String PROP_HEADER_CLIENT_ID = "client_id";
    private static final String PROP_HEADER_CLIENT_SECRET = "client_secret";
    // ************************ Variables for Policy ****************
    private static final String PROP_POLICY_CLIENT_ID = "clientid";
    private static final String PROP_POLICY_CLIENT_SECRET = "clientsecret";
    private static final String PROP_POLICY_TESTING_MODE = "testingmode";
    private static final String PROP_POLICY_SERVICE_NAME = "servicename";
    private static final String PROP_POLICY_END_POINT_URL = "endpointurl";
    // ********************** Variables for Testing mode ***************
    private static final String PROP_TESTMODE_STANDARD = "STANDARD"; // For MuleSoft
    private static final String PROP_POLICY_TESTING_CLIENT_ID = "testingclientid";
    private static final String PROP_POLICY_TESTING_CLIENT_SECRET = "testingclientsecret";
    private static final String PROP_POLICY_TESTING_END_POINT_URL = "testingurl";
    private static final String __MES_INTERFACE_POLICY_ID = "MESInterfacePolicy";
    private static final String __MES_INTERFACE_POLICY_NODE = "Custom";
    private static final String __MES_INTERFACE_POLICY_PROP_TIMELOGDIAG = "timelogdiag";


    /**************************************************************************
     * This method is used to send REST message and status.
     * @param JSONString Sapphire.Accessor Configuration Processor Object.
     * @param translationProcessor .
     * @return Array of endpoint details.
     * @throws SapphireException OOB Sapphire Exceprtion.
     ***************************************************************************/
    public static String[] sendRESTMessage(String JSONString, TranslationProcessor translationProcessor, String[] endpointDetails) throws SapphireException {
        String output = "";
        String outMsg = "";
        String[] outMsgs = new String[3];
        String jsonInputString = "";
        HttpURLConnection conn = null;
        String endpointURL = endpointDetails[0];
        String clientId = endpointDetails[1];
        String clientSecretCode = endpointDetails[2];
        String servicename = endpointDetails[4];
        // ************* Checking if Testing Mode is BLANK - Yes then STANDARD **********************
        String testingMode = "".equalsIgnoreCase(endpointDetails[3]) ? PROP_TESTMODE_STANDARD : endpointDetails[3];
        String connectionErrorMsg = "";
        try {
            // ************** Creating URL Request ****************
            URL requestURL = new URL(endpointURL);
            //turnOffCertificate();
            // ************** Openning the Connection *************
            conn = (HttpURLConnection) requestURL.openConnection();
            // ************** Setting the request method ( Get / Post ) **************
            conn.setRequestMethod(PROP_METHOD_POST);
            // ************** Creating Request Header ************
            conn.setRequestProperty(PROP_HEADER_ACCEPT_ENCODING, PROP_VALUE_HEADER_ACCEPT_ENCODING);
            conn.setRequestProperty(PROP_HEADER_CONTENT_TYPE_JSON, PROP_VALUE_HEADER_CONTENT_TYPE_JSON);
            conn.setRequestProperty(PROP_HEADER_CONNECTION, PROP_VALUE_HEADER_CONNECTION);
            conn.setRequestProperty(PROP_HEADER_ACCEPT, PROP_VALUE_HEADER_ACCEPT);
            // ********** Client Id and Secret Code for MuleSoft ***************
            if (PROP_TESTMODE_STANDARD.equalsIgnoreCase(testingMode)) {
                conn.setRequestProperty(PROP_HEADER_CLIENT_ID, clientId);
                conn.setRequestProperty(PROP_HEADER_CLIENT_SECRET, clientSecretCode);
                jsonInputString = JSONString;
            } else {
                // ****** Todo: Need to comment / remove ELSE part once unit / internal QA testing is done and real testing started ********
                // *************** Below properties are for LV REST Connection *****************
                conn.setRequestProperty("AUTHORIZATION", clientId + " " + clientSecretCode);
                jsonInputString = "{\"data\": " + JSONString + ",\"servicename\": \"" + servicename + "\", \"pushdt\": \"n\"}";
            }
            conn.setDoOutput(true);

            // ************** Creating Request Body ************

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            boolean connectionError = false;

            switch (conn.getResponseCode()) {
                case HttpURLConnection.HTTP_OK:

                    break; // fine, go on
                case HttpURLConnection.HTTP_UNAUTHORIZED:
                    connectionErrorMsg = MESErrorMessageUtil.GENERAL_ERR_00003;
                    connectionError = true;
                    break;
                case HttpURLConnection.HTTP_GATEWAY_TIMEOUT:
                    connectionErrorMsg = MESErrorMessageUtil.GENERAL_ERR_00009;
                    connectionError = true;
                    break;// retry
                case HttpURLConnection.HTTP_UNAVAILABLE:
                    connectionErrorMsg = MESErrorMessageUtil.GENERAL_ERR_00008;
                    connectionError = true;
                    break;// retry, server is unstable
                case HttpURLConnection.HTTP_INTERNAL_ERROR:
                    connectionErrorMsg = MESErrorMessageUtil.GENERAL_ERR_00004;
                    connectionError = true;
                    break;
                case HttpURLConnection.HTTP_BAD_REQUEST:
                    connectionErrorMsg = MESErrorMessageUtil.GENERAL_ERR_00006;
                    connectionError = true;
                    break;
                case HttpURLConnection.HTTP_NOT_FOUND:
                    connectionErrorMsg = MESErrorMessageUtil.GENERAL_ERR_00007;
                    connectionError = true;
                    break;
                case HttpURLConnection.HTTP_FORBIDDEN:
                    connectionErrorMsg = MESErrorMessageUtil.GENERAL_ERR_00005;
                    connectionError = true;
                    break;
                default:
                    connectionErrorMsg = conn.getResponseMessage();
                    connectionError = true;
            }

            if (connectionError) {
                outMsgs[0] = "ERROR";
                outMsgs[1] = connectionErrorMsg;
            }

            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            while ((output = br.readLine()) != null) {
                outMsg = outMsg + output;
            }
            outMsgs[0] = "SUCCESS";
            outMsgs[1] = outMsg;

        } catch (Exception ex) {
            outMsgs[0] = "ERROR";
            if (__BLANK_STRING.equalsIgnoreCase(connectionErrorMsg)) {
                outMsgs[1] = ex.getMessage();
            } else {
                outMsgs[1] = connectionErrorMsg;
            }
        } finally {
            conn.disconnect();
        }
        return outMsgs;
    }

    /**************************************************************************
     * This method is used to get endpoint details from policy.
     * @param configProcessor Sapphire.Accessor Configuration Processor Object.
     * @param serviceName MES service name.
     * @return Array of endpoint details.
     * @throws SapphireException OOB Sapphire Exceprtion.
     ***************************************************************************/
    public static String[] getEndPointDetails(String serviceName, ConfigurationProcessor configProcessor, TranslationProcessor translationProcessor) throws SapphireException {
        String arrEndPoints[] = new String[5];
        arrEndPoints[4] = serviceName;
        PropertyList plMESInterfacePolicy = configProcessor.getPolicy(__MES_INTERFACE_POLICY_ID, __MES_INTERFACE_POLICY_NODE);
        PropertyListCollection plEndPointDetails = plMESInterfacePolicy.getCollection("mesinterfaceoutbound");
        String propServiceName = "";
        for (int row = 0; row < plEndPointDetails.size(); row++) {
            propServiceName = plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_SERVICE_NAME);
            if ((serviceName).equalsIgnoreCase(propServiceName)) {
                if (plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_TESTING_MODE).equalsIgnoreCase(PROP_TESTMODE_STANDARD) || plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_TESTING_MODE).equalsIgnoreCase("")) {
                    arrEndPoints[0] = plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_END_POINT_URL);
                    arrEndPoints[1] = plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_CLIENT_ID);
                    arrEndPoints[2] = plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_CLIENT_SECRET);
                    arrEndPoints[3] = plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_TESTING_MODE);
                } else {
                    arrEndPoints[0] = plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_TESTING_END_POINT_URL);
                    arrEndPoints[1] = plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_TESTING_CLIENT_ID);
                    arrEndPoints[2] = plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_TESTING_CLIENT_SECRET);
                    arrEndPoints[3] = plEndPointDetails.getPropertyList(row).getProperty(PROP_POLICY_TESTING_MODE);
                }
                return arrEndPoints;
            }
        }
        if (arrEndPoints.length == 0) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, translationProcessor.translate(String.format(MESErrorMessageUtil.BATCH_POTENCY_ERR_00008) + serviceName));
        }
        return arrEndPoints;
    }

    /*************************************************************
     * This method is used to get Date String in specified format.
     * @param inputDateString Date String
     * @param dateFormat Output Date format
     * @return Returns formatted output Date String
     * @throws SapphireException OOB Sapphire Exception.
     **************************************************************/
    public static String getDateStringWithProperFormat(String inputDateString, String dateFormat) throws SapphireException {
        SimpleDateFormat dateParser = new SimpleDateFormat(__PROPS_DATE_FORMAT);
        String dateTime = "";

        try {
            Date date = dateParser.parse(inputDateString);
            SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);
            dateTime = (dateFormatter.format(date));

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateTime;
    }

    /**************************************************************
     * This method is used to fetch the server details.
     * @return
     * @throws Exception
     **************************************************************/

    public static String getServerDetails() throws Exception {
        StringBuilder errMsg = new StringBuilder().append(" ");
        InetAddress ip;
        try {
            ip = InetAddress.getLocalHost();

        } catch (Exception e) {
            errMsg.append(" Can't get the Server Address. ");
            throw new Exception(errMsg.toString());
        }
        return ip.toString();
    }

    /*************************************************************
     * This method is used to get Date Time String in specified format.
     * @param inputDateString Date String
     * @return Returns formatted output Date String
     * @throws SapphireException OOB Sapphire Exception.
     **************************************************************/
    public static String getDateTimeStringWithProperFormat(String inputDateString) throws SapphireException {
        SimpleDateFormat dateParser = new SimpleDateFormat(__PROPS_DATE_TIME_FORMAT);
        String dateTime = "";

        try {
            Date date = dateParser.parse(inputDateString);
            SimpleDateFormat dateFormatter = new SimpleDateFormat(__PROPS_DATE_FORMAT1);
            dateTime = (dateFormatter.format(date));

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateTime;
    }


    /************************************************************
     * This method is used to get Service wise Active site lists
     * @param  qp as Query Processor
     * @param serviceNames  String
     * @param site  String
     * @return DataSet of Sites
     * @throws SapphireException OOB Sapphire Exceptions
     *************************************************************/
    public static DataSet getActiveSiteForService(QueryProcessor qp, String serviceNames, String site) throws SapphireException {

        SafeSQL safeSQL1 = new SafeSQL();
        StringBuilder strSQL = new StringBuilder().append("");
        strSQL.append(" SELECT u_mesintfsystemsites.plant,u_mesintfsystemsites.siteid, u_mesintfsystemsites.sitename , u_mesintfsystemservices.servicename ");
        strSQL.append(" FROM u_mesintfsystem INNER JOIN u_mesintfsystemservices  ");
        strSQL.append(" ON u_mesintfsystem.u_mesintfsystemid = u_mesintfsystemservices.u_mesintfsystemid ");
        strSQL.append(" INNER JOIN u_mesintfsystemsites ");
        strSQL.append(" ON u_mesintfsystem.u_mesintfsystemid = u_mesintfsystemsites.u_mesintfsystemid ");
        strSQL.append(" WHERE u_mesintfsystem.sysstatus = 'ACTIVE' ");
        strSQL.append(" AND u_mesintfsystemservices.servicestatus = 'ACTIVE' ");
        strSQL.append(" AND u_mesintfsystemsites.plant = ").append(safeSQL1.addVar(site));
        strSQL.append(" AND u_mesintfsystemservices.servicename = ").append(safeSQL1.addVar(serviceNames));

        DataSet dsActiveSites = qp.getPreparedSqlDataSet(strSQL.toString(), safeSQL1.getValues());
        return dsActiveSites;
    }

    /********************************************************
     * This method is used to check Mandatory properties.
     * @param props PropertyList of all properties.
     * @param mandatoryProps Mandatory properties to check.
     * @throws SapphireException OOB Sapphire Exception.
     ********************************************************/
    public static void checkMadatoryFields(PropertyList props, String... mandatoryProps) throws SapphireException {
        // Getting Iterator object for iterating property list
        String errMsg = "";
        Iterator propertyIterator = props.entrySet().iterator();
        // ********* Looping through PropertyList ************
        while (propertyIterator.hasNext()) {
            Map.Entry property = (Map.Entry) propertyIterator.next();
            String propValue = "";
            // ********** For each mandatory properties ***********
            for (String key : mandatoryProps) {
                // ************** Checking if PropertyList --> Key matches Mandatory Key properties ***********
                if (key.equalsIgnoreCase(property.getKey().toString())) {
                    // *********** Getting property value ************
                    propValue = property.getValue().toString();
                    // *********** Checking Null / BLANK ***********
                    try {
                        if (null == propValue || "".equalsIgnoreCase(propValue)) {
                            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, String.format(MESErrorMessageUtil.GENERAL_ERR_00001, property.getKey().toString()));
                        }
                    } catch (SapphireException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
    }

    /********************************************************
     * This method is used to Format JSON.
     * @param JSONString as String.
     * @return Formatted JSON String
     * @throws SapphireException OOB Sapphire Exception.
     ********************************************************/

    public static String getFormattedJSON(String JSONString) throws SapphireException {
        String formattedJSON = "";
        StringBuilder strAdd = new StringBuilder("");
        int lastIndex = JSONString.length() - 1;
        int brac = 0;
        try {
            for (int i = 0; i < lastIndex; i++) {
                char indexChar = JSONString.charAt(i);
                char nextIndexChar = JSONString.charAt(i + 1);
                char prevIndexChar = i > 0 ? JSONString.charAt(i - 1) : 0;
                if (indexChar == ',' && (prevIndexChar == '"' || prevIndexChar == '}')) {
                    strAdd.append(indexChar + "\n");
                } else if (indexChar == '{' || indexChar == '[') {
                    brac++;
                    strAdd.append(indexChar + "\n");
                } else {
                    strAdd.append(indexChar);
                }

                if (nextIndexChar == '}' || nextIndexChar == ']') {
                    brac--;
                    strAdd.append("\n");
                }

                if (brac > 0 && ((indexChar == ',' && (prevIndexChar == '"' || prevIndexChar == '}')) || indexChar == '{' || indexChar == '[' || nextIndexChar == '}' || nextIndexChar == ']')) {
                    for (int j = 0; j < brac; j++) {
                        strAdd.append("\t");
                    }
                }
            }
            formattedJSON = strAdd.append(JSONString.charAt(lastIndex)).toString();
            return formattedJSON;
        } catch (Exception ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, MESErrorMessageUtil.BATCH_POTENCY_ERR_00007 + "\n" + ex.getMessage());
        }

    }

    /*********************************************************************
     * This method is to create a JSON String from a LinkedHashMap
     * @param map Properties as Key: Value pair.
     * @return JSON String
     * @throws SapphireException OOB Sapphire Exception.
     ***********************************************************************/
    public static String lhmToJSONString(LinkedHashMap<String, String> map) throws SapphireException {
        LinkedHashMap lhmap = new LinkedHashMap<>();
        try {
            for (Map.Entry<String, String> item : map.entrySet()) {
                if ((item.getValue() != null && !"".equalsIgnoreCase(item.getValue())) && (item.getValue().charAt(0) == '{' || item.getValue().charAt(0) == '['))
                    lhmap.put("\"" + item.getKey() + "\"", item.getValue());
                else {
                    if (!"".equalsIgnoreCase(item.getValue())) {
                        lhmap.put("\"" + item.getKey() + "\"", "\"" + item.getValue() + "\"");
                    } else {
                        lhmap.put("\"" + item.getKey() + "\"", "\"" + "" + "\"");
                    }
                }
            }
        } catch (Exception ex) {
            throw new SapphireException(MESErrorMessageUtil.GENERAL_ERROR, ErrorDetail.TYPE_FAILURE, MESErrorMessageUtil.BATCH_POTENCY_ERR_00006 + "\n" + ex.getMessage());
        }
        return lhmap.toString().replace("=", ": ");
    }

    /***************************************************************************************************
     * This method is used to get Property value of time log diagnostic switch from MES Interface Policy
     * @param configProcessor Configuration processor
     * @return Returns switch value (ON / OFF)
     * @throws SapphireException OOB Sapphire Exception
     ***************************************************************************************************/
    public static String getLogDiagSwitchValue(ConfigurationProcessor configProcessor) throws SapphireException {
        String propTimeLogDiag = configProcessor.getPolicy(__MES_INTERFACE_POLICY_ID, __MES_INTERFACE_POLICY_NODE).getProperty(__MES_INTERFACE_POLICY_PROP_TIMELOGDIAG, "");
        return "".equalsIgnoreCase(propTimeLogDiag) ? "OFF" : propTimeLogDiag;
    }

    /**************************************************************************************************
     * This method is used to calcu;ate processing time of any Service / Method / Module for performance
     * @param logger Sapphire Logger Object
     * @param processingStartTimeInNanoSec Processing Start Time
     * @param serviceName Service Name
     * @param methodName Method Name
     * @throws SapphireException OOB Sapphire Exception
     ****************************************************************************************************/
    public static void calculateElapsedTime(Logger logger, Long processingStartTimeInNanoSec, String serviceName, String methodName) throws SapphireException {
        Long processingEndTimeInNanoSec = System.currentTimeMillis();
        Long elapsedTime = processingEndTimeInNanoSec - processingStartTimeInNanoSec;
        logger.info(" ***** [TIME_LOG_DIAGNOSTIC] Processing time of service - " + serviceName + " , module / method - " + methodName + " took " + String.valueOf(elapsedTime) + " ms ***** ");
    }

    /*********************************************************
     * This method is used to get server time in proper format
     * @return Server date and time in proper format.
     *********************************************************/
    public static String setTransactiondatetime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(__PROPS_DATE_TIME_FORMAT);
        LocalDateTime now = LocalDateTime.now();
        return formatter.format(now);
    }

}